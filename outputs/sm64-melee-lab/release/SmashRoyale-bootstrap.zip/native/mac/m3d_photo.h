#ifndef M3D_PHOTO_H
#define M3D_PHOTO_H
#ifdef __cplusplus
extern "C" {
#endif
int m3d_PhotoActive(void);
int m3d_GameplayCaptureActive(void);
int m3d_PhotoState(void);
void m3d_PhotoCapture(void);
#ifdef __cplusplus
}
#endif
#endif
