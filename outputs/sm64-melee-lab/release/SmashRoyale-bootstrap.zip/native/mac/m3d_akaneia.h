/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef M3D_AKANEIA_H
#define M3D_AKANEIA_H
#include <stdarg.h>
#include <stdint.h>
#include <stddef.h>
struct HSD_GObj;
struct _HSD_GObj;
struct Fighter;
int m3d_akaneia_enabled(void);
int m3d_akaneia_air_drift(struct Fighter* fighter);
void m3d_akaneia_init(void);
int m3d_akaneia_internal(int kind);
int m3d_akaneia_base(int kind);
int m3d_akaneia_sound(struct Fighter* fighter,int sound);
int m3d_akaneia_item_sound(void* item,int sound);
void m3d_akaneia_audio_load(void);
unsigned m3d_akaneia_costume_count(int kind);
unsigned m3d_akaneia_stock_stride(void);
unsigned m3d_akaneia_stock_reserved(void);
unsigned m3d_akaneia_emblem(int kind);
unsigned m3d_akaneia_costume_row(int kind,unsigned costume,int textures);
void m3d_akaneia_common_loaded(void* archive);
void m3d_akaneia_archive_named(const char* name,void* archive);
void m3d_akaneia_archive_removed(void* archive);
void m3d_akaneia_loaded(int kind, void* archive, unsigned size);
void m3d_akaneia_reapply(void* object);
int m3d_akaneia_event(void* object, unsigned slot);
uint32_t m3d_akaneia_call(void* owner, uint32_t target, const uint32_t* args, unsigned count);
uint32_t m3d_akaneia_object_export(void* object, unsigned kind);
uint32_t m3d_akaneia_owned_export(void* object,unsigned kind,void* owner);
void* m3d_akaneia_current_actor(void);
uint32_t m3d_akaneia_joint_export(void* joint, void* root);
void m3d_roster_tables(void);
void m3d_akaneia_joint_removed(void* joint);
void m3d_akaneia_asset_lifetime_probe(void* object);
void m3d_akaneia_process_removed(void* process);
void m3d_akaneia_object_removed(void* object);
void m3d_akaneia_scene_reset(void);
void m3d_akaneia_item_created(void* object, void* owner);
uint32_t m3d_akaneia_guest_data(const void* pointer);
void* m3d_akaneia_native_data(uint32_t pointer);
void m3d_bind_effects(void);
void* m3d_akaneia_effect_sync(int id, struct HSD_GObj* object, va_list arguments);
void m3d_akaneia_effect_removed(void* object, int particle);
void m3d_akaneia_effect_scene_reset(void);
int m3d_akaneia_effect_observe(uint32_t address, size_t size, int writing);
uint32_t m3d_akaneia_effect_identity(void* effect);
#endif
