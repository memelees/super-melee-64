/* SPDX-License-Identifier: GPL-3.0-or-later
 * The native synth reads through DVD, whereas DAT archives use the file cache.
 * Mount the locally imported SEM/SSM files through Aurora's existing DVD overlay.
 */
#include "m3d_sound.h"
#include <aurora/dvd.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <memory>
#include <string>
#include <vector>

namespace {
struct File {std::string source,disc;size_t size;};
// Aurora retains userdata for future opens. Keep records stable across a disc
// re-open; each in-flight read has its own independent stdio handle.
std::vector<std::unique_ptr<File>> files;
void* open_file(void* data){return std::fopen(static_cast<File*>(data)->source.c_str(),"rb");}
void close_file(void* handle){std::fclose(static_cast<FILE*>(handle));}
int64_t read_file(void* handle,uint8_t* out,size_t size){
    FILE* file=static_cast<FILE*>(handle);size_t read=std::fread(out,1,size,file);
    return std::ferror(file)?-1:static_cast<int64_t>(read);
}
int64_t seek_file(void* handle,int64_t offset,int32_t whence){
#ifdef _WIN32
    return _fseeki64(static_cast<FILE*>(handle),offset,whence)?-1:_ftelli64(static_cast<FILE*>(handle));
#else
    return fseeko(static_cast<FILE*>(handle),offset,whence)?-1:ftello(static_cast<FILE*>(handle));
#endif
}
}
int m3d_audio_mount(void)
{
    const char* enabled=std::getenv("MELEE3D_NATIVE_AKANEIA");
    if(!enabled||std::strcmp(enabled,"1"))return 1;
    try {
        const char* root=std::getenv("MELEE_FILES_DIR");if(!root)return 0;
        std::filesystem::path audio=std::filesystem::path(root)/"audio";
        std::vector<AuroraOverlayFile> overlay;
        for(const auto& entry:std::filesystem::recursive_directory_iterator(audio)){
            auto ext=entry.path().extension();if(!entry.is_regular_file()||(ext!=".ssm"&&ext!=".sem"))continue;
            auto size=entry.file_size();if(size>UINT32_MAX)return 0;
            auto file=std::make_unique<File>();file->source=entry.path().string();
            file->disc="/audio/"+entry.path().lexically_relative(audio).generic_string();file->size=size;
            overlay.push_back({file->disc.c_str(),file.get(),file->size});files.push_back(std::move(file));
        }
        // The stage preloader reads through DVD rather than the DAT cache.
        // Mount the same verified Onett aliases used by synchronous loads so
        // menu starts cannot silently preload the retail 2D collision table.
        const char* onett=std::getenv("MELEE3D_NATIVE_ONETT_OVERLAY");
        if(onett&&*onett)for(const char* name:{"GrOt.dat","GrOt.usd"}){
            auto path=std::filesystem::path(root)/name;
            auto file=std::make_unique<File>();file->source=path.string();
            file->disc=std::string("/")+name;file->size=std::filesystem::file_size(path);
            overlay.push_back({file->disc.c_str(),file.get(),file->size});files.push_back(std::move(file));
        }
        const AuroraOverlayCallbacks callbacks={open_file,close_file,read_file,seek_file};
        aurora_dvd_overlay_callbacks(&callbacks);
        std::vector<s32> ids(overlay.size());aurora_dvd_overlay_files(overlay.data(),overlay.size(),ids.data());
        for(int id:ids)if(id<0)return 0;
        std::fprintf(stderr,"M3D AUDIO OVERLAY files=%zu\n",overlay.size());return !overlay.empty();
    }catch(const std::exception& e){std::fprintf(stderr,"M3D AUDIO OVERLAY FAIL: %s\n",e.what());return 0;}
}
