/* SPDX-License-Identifier: GPL-3.0-or-later
 * Load the actual production article loader in isolation. Rendering is forbidden
 * in this probe; live diagnostics verify actual native items separately. */
#include "m3d_vm.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
extern void gw_panic(const char*,...);
void GXCmd1u8(unsigned char value) { (void)value; gw_panic("Unexpected rendering in article loader fixture"); }
void GXCmd1u16(unsigned short value) { (void)value; gw_panic("Unexpected rendering in article loader fixture"); }
void GXCmd1u32(unsigned value) { (void)value; gw_panic("Unexpected rendering in article loader fixture"); }
int main(int argc,char** argv)
{
    const char* files[]={"PlWf.dat","PlDd.dat","PlLz.dat","PlLc.dat","PlSn.dat","PlDe.dat","PlTs.dat"};
    const char* symbols[]={"ftDataWolf","ftDataDiddy","ftDataLizardon","ftDataLucas","ftDataSonic","ftDataDedede","ftDataTails"};
    const unsigned counts[]={2,3,3,10,1,4,1};
    unsigned i,j,k,total=0;
    char path[4096];
    if(argc!=2)return 1;
    m3d_vm_init();
    snprintf(path,sizeof path,"%s/MxDt.dat",argv[1]); m3d_vm_load_metadata(path);
    for(i=0;i<7;++i) {
        snprintf(path,sizeof path,"%s/%s",argv[1],files[i]); m3d_vm_load(i,path,symbols[i]);
        for(j=0;j<counts[i];++j) {
            uint32_t states=m3d_vm_article(i,j,0);
            unsigned n=m3d_vm_article_states(i,j);
            if(!states) { if(n)gw_panic("Hole has states"); continue; }
            if(!n || n>64)gw_panic("Invalid article state count");
            for(k=0;k<n;++k) {
                /* Reading every relocated state word also exercises its exact
                 * code/data span in the production guest-memory adapter. */
                unsigned c;
                for(c=0;c<4;++c)(void)m3d_vm_read32(states+k*16+c*4);
            }
            ++total;
        }
    }
    if(total!=22)gw_panic("Wrong number of Akaneia article modules: %u",total);
    puts("M3D ARTICLE LOADER PASS slots=24 modules=22 holes=2 recovered_sizes=3");
    return 0;
}
