/* SPDX-License-Identifier: GPL-3.0-or-later
 * DELFINO: no low-address mmap, no truncation of native pointers. */
#include "m3d_guest_memory.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif
extern void gw_panic(const char*, ...);

unsigned char* gw_mem1;
uint32_t gw_mem1_size = 64 * 1024 * 1024;
/* Isolated transient identity bank: never overlaps PPC modules/heap/stack. */
static uint32_t identity_top=0x82000000;
uint32_t m3d_guest_identity(uint32_t size)
{
    uint32_t extent=(size+255u)&~255u,base=identity_top;
    if(!size || size>0x10000 || (uint64_t)base+extent>0x84000000u)
        gw_panic("Transient guest identity generations exhausted");
    identity_top+=extent;return base;
}
struct Span { uint32_t base,size; };
static struct Span views[4096],fields[32768];
static unsigned view_count, field_count;
static struct { uint32_t base, size; void* host; } regions[1024];
static unsigned region_count;
/* Exact address/extent translations, never permissions. A new/retired region
 * invalidates its pages (all multi-page hints); permission/lifetime checks precede each hit.
 * Exact keys preserve the existing first-containing-host rule even where
 * aliases overlap or a request crosses the end of a smaller alias. */
static struct { uint32_t address,size,epoch; void* host; } translations[16384];
static uint32_t region_epoch=1;
static uint32_t translation_pages[16384];
static void invalidate_translations(uint32_t base,uint32_t size)
{
    if(!++region_epoch){memset(translations,0,sizeof translations);region_epoch=1;}
    for(unsigned p=(base-0x80000000u)/4096;p<=(base+size-1-0x80000000u)/4096;p++)
        if(!++translation_pages[p]){memset(translations,0,sizeof translations);translation_pages[p]=1;}
}
/* Conservative page hints avoid region scans only after retirement and field
 * validation. Backing hints require a whole registered page; retirement clears
 * overlapping hints. Host aliases always force the authoritative region scan. */
static unsigned char host_pages[16384],backing_pages[16384],view_pages[16384];
/* Copy one validated field; every whitelist/lifetime mutation invalidates it.
 * View-page hints only grow, so retirement can cause extra checks, not misses. */
static struct Span cached_field;
static struct Span retired[4096];
static unsigned retired_count;
static void (*access_observer)(uint32_t,size_t,int);
static int observer_active;
void m3d_guest_observer(void (*observer)(uint32_t,size_t,int)) { access_observer=observer; }
void m3d_guest_touch(const void* pointer,size_t size,int writing)
{
    uintptr_t value=(uintptr_t)pointer;
#ifdef _WIN32
    /* PE globals, stacks and CRT allocations can be below 4 GB. Only the
     * reserved guest window belongs to the sparse object-view observer. */
    if(value<0x80000000u || value>=UINT64_C(0x80000000)+gw_mem1_size)return;
#endif
    if(access_observer && !observer_active && value<=UINT32_MAX && size) {
        /* Validate before invoking an adapter; an adapter cannot authorize an
         * unregistered or retired address merely by observing it. */
        m3d_guest_address(pointer,size);
        observer_active=1; access_observer((uint32_t)value,size,writing); observer_active=0;
    }
}
void m3d_guest_retire(uint32_t base,uint32_t size)
{
    cached_field=(struct Span){0};
    unsigned start=0,end;
    uint64_t limit=(uint64_t)base+size;
    if(!size || base<0x80000000u || limit>UINT64_C(0x80000000)+gw_mem1_size)abort();
    invalidate_translations(base,size);
    while(start<retired_count && (uint64_t)retired[start].base+retired[start].size<base)++start;
    end=start;
    while(end<retired_count && retired[end].base<=limit) {
        if(retired[end].base<base)base=retired[end].base;
        if((uint64_t)retired[end].base+retired[end].size>limit)limit=(uint64_t)retired[end].base+retired[end].size;
        ++end;
    }
    if(end==start && retired_count==4096)abort();
    memmove(retired+start+1,retired+end,(retired_count-end)*sizeof(*retired));
    retired[start]=(struct Span){base,(uint32_t)(limit-base)};
    retired_count=retired_count-(end-start)+1;
    for(uint32_t page=(base-0x80000000u)/4096;page<=(limit-1-0x80000000u)/4096;page++)backing_pages[page]=0;
    /* The native allocator may reuse this storage for a new Item. Retiring
     * only guest reads left its reverse host mapping pointing at the old view. */
    for(unsigned i=0;i<region_count;++i)
        if(regions[i].base>=base && (uint64_t)regions[i].base+regions[i].size<=limit)
            regions[i].host=NULL,regions[i].size=0;
    /* Dead whitelist rows are metadata, not persistent permissions. Keep
     * retired address tombstones while reclaiming only fully retired rows. */
    unsigned count=0;
    for(unsigned i=0;i<view_count;++i)
        if(!(views[i].base>=base && (uint64_t)views[i].base+views[i].size<=limit))views[count++]=views[i];
    view_count=count;count=0;
    for(unsigned i=0;i<field_count;++i)
        if(!(fields[i].base>=base && (uint64_t)fields[i].base+fields[i].size<=limit))fields[count++]=fields[i];
    field_count=count;
}

static int retired_span(uintptr_t value,size_t size)
{
    unsigned low=0,high=retired_count;
    while(low<high) { unsigned mid=low+(high-low)/2;
        if((uint64_t)retired[mid].base+retired[mid].size<=value)low=mid+1; else high=mid; }
    return low<retired_count && value+size>retired[low].base;
}

void m3d_guest_region(uint32_t base, uint32_t size)
{
    m3d_guest_region_host(base,size,NULL);
}

void m3d_guest_region_host(uint32_t base, uint32_t size, void* host)
{
    unsigned slot;
    for(slot=0;slot<region_count && regions[slot].size;++slot) {}
    if (!size || slot==1024 || base<0x80000000u ||
        (uint64_t)base+size>UINT64_C(0x80000000)+gw_mem1_size) abort();
    invalidate_translations(base,size);
    regions[slot].base=base; regions[slot].host=host;
    regions[slot].size=size;if(slot==region_count)++region_count;
    if(!host)for(uint32_t page=(base-0x80000000u+4095)/4096;page<(base+size-0x80000000u)/4096;page++)backing_pages[page]=1;
    if(host)for(uint32_t page=(base-0x80000000u)/4096;page<=(base+size-1-0x80000000u)/4096;page++)host_pages[page]=1;
}

void m3d_guest_view(uint32_t base, uint32_t size)
{
    unsigned i=0;
    if (!size || view_count == 4096 || base < 0x80000000u ||
        (uint64_t)base+size > UINT64_C(0x80000000)+gw_mem1_size) abort();
    while(i<view_count && views[i].base<base)++i;
    if((i && (uint64_t)views[i-1].base+views[i-1].size>base) ||
       (i<view_count && (uint64_t)base+size>views[i].base))abort();
    memmove(views+i+1,views+i,(view_count-i)*sizeof(*views));
    views[i]=(struct Span){base,size}; ++view_count;cached_field=(struct Span){0};
    for(uint32_t page=(base-0x80000000u)/4096;page<=(base+size-1-0x80000000u)/4096;page++)view_pages[page]=1;
}
void m3d_guest_field(uint32_t address, uint32_t size)
{
    cached_field=(struct Span){0};
    unsigned i;
    if (!size || field_count == 32768) abort();
    for (i=0; i<view_count; ++i)
        if (address >= views[i].base && (uint64_t)address+size <= (uint64_t)views[i].base+views[i].size) break;
    if (i==view_count) abort();
    i=0;
    while(i<field_count && fields[i].base<address)++i;
    if((i && (uint64_t)fields[i-1].base+fields[i-1].size>address) ||
       (i<field_count && (uint64_t)address+size>fields[i].base))abort();
    memmove(fields+i+1,fields+i,(field_count-i)*sizeof(*fields));
    fields[i]=(struct Span){address,size}; ++field_count;
}

void m3d_guest_init(void)
{
#ifdef _WIN32
    static int reserved;
    if(!reserved) {
        /* Keep future CRT host allocations out of our guest pointer namespace.
         * This is an inaccessible guard reservation, not guest backing memory. */
        if(VirtualAlloc((void*)(uintptr_t)0x80000000u,gw_mem1_size,MEM_RESERVE,PAGE_NOACCESS)!=(void*)(uintptr_t)0x80000000u)
            gw_panic("Cannot reserve the isolated guest pointer namespace");
        reserved=1;
    }
#endif
    if (!gw_mem1) gw_mem1 = calloc(1, gw_mem1_size);
    if (!gw_mem1) abort();
}

uint32_t m3d_guest_encode_buffer(const void* host)
{
    uintptr_t p=(uintptr_t)host, base=(uintptr_t)gw_mem1;
    unsigned i;
    if(!host)return 0;
    if(p>=base && p-base<gw_mem1_size)return 0x80000000u+(uint32_t)(p-base);
    for(i=0;i<region_count;++i) {
        uintptr_t start=(uintptr_t)regions[i].host;
        if(start && p>=start && p-start<regions[i].size) {
            uint32_t candidate=regions[i].base+(uint32_t)(p-start);
            if(!retired_span(candidate,1))return candidate;
        }
    }
    {extern uint32_t m3d_native_current_call;fprintf(stderr,"M3D BRIDGE UNREGISTERED host=%p call=%08x\n",host,m3d_native_current_call);}
    gw_panic("M3D BRIDGE FAIL native pointer has no registered guest buffer");
    return 0;
}

void* m3d_guest_address(const void* pointer, size_t size)
{
    uintptr_t value = (uintptr_t)pointer;
    unsigned i,low,high;
    int mapped=0;
    if (value > UINT32_MAX) return (void*)pointer;
    if (!size) return (void*)pointer;
#ifdef _WIN32
    if(value<0x80000000u || value>=UINT64_C(0x80000000)+gw_mem1_size) {
        MEMORY_BASIC_INFORMATION region;
        if(value>=0x10000u && VirtualQuery(pointer,&region,sizeof region)==sizeof region &&
           region.State==MEM_COMMIT && !(region.Protect&(PAGE_NOACCESS|PAGE_GUARD)) &&
           size<=UINTPTR_MAX-value && value+size<=(uintptr_t)region.BaseAddress+region.RegionSize)
            return (void*)pointer;
        gw_panic("M3D BRIDGE FAIL invalid host address 0x%zx size=%zu",value,size);
    }
#endif
    if(retired_span(value,size)) {
            gw_panic("M3D BRIDGE FAIL retired guest allocation 0x%zx",value);
    }
    if (value < 0x80000000u || value - 0x80000000u > gw_mem1_size ||
        size > gw_mem1_size - (value - 0x80000000u)) {
        gw_panic("M3D BRIDGE FAIL unmapped guest address 0x%zx size=%zu", value, size);
    }
    uintptr_t first_page=(value-0x80000000u)/4096,last_page=(value+size-1-0x80000000u)/4096;
    if(cached_field.size && value>=cached_field.base && value+size<=(uint64_t)cached_field.base+cached_field.size)mapped=1;
    else if(first_page!=last_page || view_pages[first_page]) {
    low=0;high=view_count;
    while(low<high) { unsigned mid=low+(high-low)/2;
        if((uint64_t)views[mid].base+views[mid].size<=value)low=mid+1; else high=mid; }
    if(low<view_count && views[low].base<value+size) {
        low=0;high=field_count;
        while(low<high) { unsigned mid=low+(high-low)/2;
            if(fields[mid].base<=value)low=mid+1; else high=mid; }
        if (!low || value+size>(uint64_t)fields[low-1].base+fields[low-1].size) {
            gw_panic("M3D BRIDGE FAIL unexported object field 0x%zx size=%zu", value, size);
        }
        mapped=1;
        cached_field=fields[low-1];
    }
    }
    {uintptr_t first=(value-0x80000000u)/4096,last=(value+size-1-0x80000000u)/4096;
        if(first==last&&!host_pages[first]&&(mapped||backing_pages[first]))return gw_mem1+(value-0x80000000u);}
    uint32_t hash=(uint32_t)(value>>2)^(uint32_t)(size*0x9e3779b9u);
    hash^=hash>>16;hash*=0x7feb352du;hash^=hash>>15;hash*=0x846ca68bu;hash^=hash>>16;
    unsigned hint=hash&16383u;
    uint32_t epoch=first_page==last_page?translation_pages[first_page]:region_epoch;
    if(translations[hint].epoch==epoch && translations[hint].address==value && translations[hint].size==size)
        return translations[hint].host;
    void* result=gw_mem1+(value-0x80000000u);
    for (i=0; i<region_count; ++i)
        if (value>=regions[i].base && value+size<=(uint64_t)regions[i].base+regions[i].size) {
            if (regions[i].host) {result=(unsigned char*)regions[i].host+value-regions[i].base;mapped=1;break;}
            mapped=1;
        }
    if (!mapped) {
        gw_panic("M3D BRIDGE FAIL unregistered guest region 0x%zx size=%zu",value,size);
    }
    translations[hint].address=value;translations[hint].size=size;
    translations[hint].epoch=epoch;translations[hint].host=result;
    return result;
}

void* m3d_guest_memcpy(void* to, const void* from, size_t size)
{
    m3d_guest_touch(from,size,0); m3d_guest_touch(to,size,0);
    memcpy(m3d_guest_address(to, size), m3d_guest_address(from, size), size);
    m3d_guest_touch(to,size,1);
    return to;
}
void* m3d_guest_memset(void* to, int value, size_t size)
{
    m3d_guest_touch(to,size,0);
    memset(m3d_guest_address(to, size), value, size);
    m3d_guest_touch(to,size,1);
    return to;
}
int m3d_guest_memcmp(const void* a, const void* b, size_t size)
{
    m3d_guest_touch(a,size,0); m3d_guest_touch(b,size,0);
    return memcmp(m3d_guest_address(a, size), m3d_guest_address(b, size), size);
}
