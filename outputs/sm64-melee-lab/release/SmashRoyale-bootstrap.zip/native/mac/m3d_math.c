/* SPDX-License-Identifier: GPL-3.0-or-later
 * Structured numeric arguments cross the boundary as values, not native
 * pointers to big-endian stack data. All characters share these adapters. */
#include "m3d_vm.h"
#include <melee/cm/camera.h>
#include "m3d_native_calls.h"
#include <dolphin/mtx.h>
#include <sysdolphin/baselib/mtx.h>
#include <melee/mp/mplib.h>
#include <dolphin/gx.h>
#include <melee/lb/lb_00B0.h>
#include <melee/lb/lbvector.h>
#include <melee/ft/ftlib.h>
#include <melee/ft/ftcoll.h>
#include <melee/ft/kinds/ftCommon/ftCo_CaptureKirby.h>
#include <melee/ft/ft_081B.h>
#include <melee/ft/kinds/ftCommon/types.h>
#include <melee/it/item.h>
#include <melee/it/it_26B1.h>
#include <melee/it/it_2725.h>
#include <melee/it/kinds/itkirby_2F23.h>
#include <math.h>
#include <string.h>

static void read_floats(float* destination,uint32_t source,unsigned count)
{
    unsigned i;
    for(i=0;i<count;++i) { uint32_t value=m3d_vm_read32(source+4*i); memcpy(destination+i,&value,4); }
}
static void write_floats(uint32_t destination,const float* source,unsigned count)
{
    unsigned i;
    for(i=0;i<count;++i) { uint32_t value; memcpy(&value,source+i,4); m3d_vm_write32(destination+4*i,value); }
}
static bool check_all_remap(uint32_t position,uint32_t line,uint32_t flags,uint32_t normal,int skip,int only,float x0,float y0,float x1,float y1)
{
    Vec3 p,n;
    int l=0;
    uint32_t f=0;
    if(position)read_floats(&p.x,position,3);
    if(normal)read_floats(&n.x,normal,3);
    if(line)l=(int32_t)m3d_vm_read32(line);
    if(flags)f=m3d_vm_read32(flags);
    bool result=mpCheckAllRemap(position ? &p : NULL,line ? &l : NULL,flags ? &f : NULL,
        normal ? &n : NULL,skip,only,x0,y0,x1,y1);
    if(position)write_floats(position,&p.x,3);
    if(normal)write_floats(normal,&n.x,3);
    if(line)m3d_vm_write32(line,l);
    if(flags)m3d_vm_write32(flags,f);
    return result;
}
static void matrix_srt(uint32_t output,uint32_t scale,uint32_t rotation,uint32_t translation,uint32_t parent_scale)
{
    Mtx result;
    Vec3 s,r,t,p;
    read_floats(&s.x,scale,3); read_floats(&r.x,rotation,3); read_floats(&t.x,translation,3);
    if(parent_scale)read_floats(&p.x,parent_scale,3);
    HSD_MtxSRT(result,&s,&r,&t,parent_scale ? &p : NULL);
    write_floats(output,&result[0][0],12);
}
static void matrix_identity(uint32_t out) { Mtx value; PSMTXIdentity(value); write_floats(out,&value[0][0],12); }
static void matrix_copy(uint32_t source,uint32_t out) { Mtx value; read_floats(&value[0][0],source,12); write_floats(out,&value[0][0],12); }
static void matrix_concat(uint32_t a,uint32_t b,uint32_t out)
{
    Mtx left,right,result; read_floats(&left[0][0],a,12); read_floats(&right[0][0],b,12);
    PSMTXConcat(left,right,result); write_floats(out,&result[0][0],12);
}
static void matrix_transpose(uint32_t a,uint32_t out)
{
    Mtx value,result; read_floats(&value[0][0],a,12); PSMTXTranspose(value,result); write_floats(out,&result[0][0],12);
}
static uint32_t matrix_inverse(uint32_t a,uint32_t out)
{
    Mtx value,result; uint32_t success; read_floats(&value[0][0],a,12);
    success=PSMTXInverse(value,result); if(success)write_floats(out,&result[0][0],12); return success;
}
static void matrix_rot(uint32_t out,int8_t axis,float radians)
{
    Mtx value; MTXRotRad(value,axis,radians); write_floats(out,&value[0][0],12);
}
static void matrix_rot_trig(uint32_t out,int8_t axis,float sine,float cosine)
{
    Mtx value; PSMTXRotTrig(value,axis,sine,cosine); write_floats(out,&value[0][0],12);
}
static void matrix_translate(uint32_t out,float x,float y,float z)
{
    Mtx value; PSMTXTrans(value,x,y,z); write_floats(out,&value[0][0],12);
}
static void matrix_scale(uint32_t out,float x,float y,float z)
{
    Mtx value; PSMTXScale(value,x,y,z); write_floats(out,&value[0][0],12);
}
static void matrix_quat(uint32_t out,uint32_t quaternion)
{
    Mtx value; Quaternion q; read_floats(&q.x,quaternion,4); PSMTXQuat(value,&q); write_floats(out,&value[0][0],12);
}
static void matrix_mult_vec(uint32_t matrix,uint32_t source,uint32_t out)
{
    Mtx value; Vec3 v,result; read_floats(&value[0][0],matrix,12); read_floats(&v.x,source,3);
    PSMTXMultVec(value,&v,&result); write_floats(out,&result.x,3);
}
static void matrix_mult_vec_sr(uint32_t matrix,uint32_t source,uint32_t out)
{
    Mtx value; Vec3 v,result; read_floats(&value[0][0],matrix,12); read_floats(&v.x,source,3);
    PSMTXMultVecSR(value,&v,&result); write_floats(out,&result.x,3);
}
static void vector_add(uint32_t a,uint32_t b,uint32_t out)
{
    Vec3 left,right,result; read_floats(&left.x,a,3); read_floats(&right.x,b,3);
    PSVECAdd(&left,&right,&result); write_floats(out,&result.x,3);
}
static void vector_subtract(uint32_t a,uint32_t b,uint32_t out)
{
    Vec3 left,right,result; read_floats(&left.x,a,3); read_floats(&right.x,b,3);
    PSVECSubtract(&left,&right,&result); write_floats(out,&result.x,3);
}
static void vector_scale(uint32_t source,uint32_t out,float scale)
{
    Vec3 value,result; read_floats(&value.x,source,3); PSVECScale(&value,&result,scale); write_floats(out,&result.x,3);
}
static float vector_magnitude(uint32_t source)
{
    Vec3 value; read_floats(&value.x,source,3); return PSVECMag(&value);
}
static void vector_normalize(uint32_t source,uint32_t out)
{
    Vec3 value,result; read_floats(&value.x,source,3); PSVECNormalize(&value,&result); write_floats(out,&result.x,3);
}
static float vector_dot(uint32_t a,uint32_t b)
{
    Vec3 left,right; read_floats(&left.x,a,3); read_floats(&right.x,b,3); return PSVECDotProduct(&left,&right);
}
static void vector_cross(uint32_t a,uint32_t b,uint32_t out)
{
    Vec3 left,right,result; read_floats(&left.x,a,3); read_floats(&right.x,b,3);
    PSVECCrossProduct(&left,&right,&result); write_floats(out,&result.x,3);
}
static void gx_position(uint32_t matrix,uint32_t index)
{
    Mtx value; read_floats(&value[0][0],matrix,12); GXLoadPosMtxImm(value,index);
}
static void bone_position(HSD_JObj* joint,uint32_t offset,uint32_t output)
{
    Vec3 local,world;
    if(offset)read_floats(&local.x,offset,3);
    lb_8000B1CC(joint,offset ? &local : NULL,&world);
    write_floats(output,&world.x,3);
}
static bool collision_air_box(HSD_GObj* object,uint32_t box)
{
    ftCollisionBox value;
    if(box)read_floats(&value.top,box,6);
    return ft_800824A0(object,box ? &value : NULL);
}
static bool collision_ground_box(HSD_GObj* object,uint32_t box)
{
    ftCollisionBox value;
    if(box)read_floats(&value.top,box,6);
    return ft_80082888(object,box ? &value : NULL);
}
static void item_position(HSD_GObj* object,uint32_t out)
{
    Vec3 value; it_8026BB68(object,&value); write_floats(out,&value.x,3);
}
static void item_set_position(HSD_GObj* object,uint32_t source)
{
    Vec3 value; read_floats(&value.x,source,3); it_8027429C(object,&value);
}
static void item_launch(HSD_GObj* object,uint32_t origin,uint32_t velocity,float facing)
{
    Vec3 p,v; read_floats(&p.x,origin,3); read_floats(&v.x,velocity,3);
    Item_8026AC74(object,&p,&v,facing);
    write_floats(origin,&p.x,3); write_floats(velocity,&v.x,3);
}
static double item_kirby_position(HSD_GObj* object,uint32_t output)
{
    Vec3 value; read_floats(&value.x,output,3); return it_802F23AC(object,&value);
}
static void ecb_position(HSD_GObj* object,uint32_t output)
{
    Vec3 value; ftLib_GetECBCenter(object,&value); write_floats(output,&value.x,3);
}
static float game_normalize(uint32_t address)
{
    Vec3 value; float length;
    read_floats(&value.x,address,3); length=lbVector_Normalize(&value);
    write_floats(address,&value.x,3); return length;
}
static uint32_t game_cross_normalized(uint32_t a,uint32_t b,uint32_t output)
{
    Vec3 left,right,result;read_floats(&left.x,a,3);read_floats(&right.x,b,3);
    lbVector_CrossprodNormalized(&left,&right,&result);write_floats(output,&result.x,3);
    return output;
}
static float game_angle(uint32_t a,uint32_t b)
{
    Vec3 left,right; read_floats(&left.x,a,3); read_floats(&right.x,b,3);
    return lbVector_Angle(&left,&right);
}
static float game_angle_xy(uint32_t a,uint32_t b)
{
    Vec3 left,right; read_floats(&left.x,a,3); read_floats(&right.x,b,3);
    return lbVector_AngleXY(&left,&right);
}
static void game_rotate(uint32_t a,uint32_t axis,float angle)
{
    Vec3 value,unit; read_floats(&value.x,a,3); read_floats(&unit.x,axis,3);
    lbVector_RotateAboutUnitAxis(&value,&unit,angle); write_floats(a,&value.x,3);
}
static void game_mirror(uint32_t a,uint32_t axis)
{
    Vec3 value,unit; read_floats(&value.x,a,3); read_floats(&unit.x,axis,3);
    lbVector_Mirror(&value,&unit); write_floats(a,&value.x,3);
}

static void original_throw_credit(HSD_GObj* source,HSD_GObj* victim,uint32_t data)
{
    int32_t packet[3];
    if(data)for(unsigned i=0;i<3;++i)packet[i]=(int32_t)m3d_vm_read32(data+i*4);
    ftColl_80078710(source,victim,data ? packet : NULL);
}
static bool original_damage(Fighter* fp,uint32_t damage)
{
    float value; read_floats(&value,damage,1); bool result=ftColl_80076640(fp,&value); write_floats(damage,&value,1); return result;
}
static float original_capture_distance(HSD_GObj* object,uint32_t position)
{
    Vec3 pos; read_floats(&pos.x,position,3); return ftCo_800BD19C(object,&pos);
}
static void original_quake(int kind,uint32_t position)
{
    Vec3 pos; if(position)read_floats(&pos.x,position,3); Camera_RequestQuake(kind,position ? &pos : NULL);
}
void m3d_bind_math(void)
{
    const struct M3dNativeCall quake={0x80030e44,(void(*)(void))original_quake,M3D_VOID,2,{M3D_I32,M3D_U32},{-1,-1}};
    m3d_native_register(&quake);
    const struct M3dNativeCall damage={0x80076640,(void(*)(void))original_damage,M3D_U8,2,{M3D_OBJECT,M3D_U32},{-1,-1},{2,0}};
    m3d_native_register(&damage);
    const struct M3dNativeCall credit={0x80078710,(void(*)(void))original_throw_credit,M3D_VOID,3,{M3D_OBJECT,M3D_OBJECT,M3D_U32},{-1,-1,-1},{1,1,0}};
    m3d_native_register(&credit);
    const struct M3dNativeCall capture_distance={0x800bd19c,(void(*)(void))original_capture_distance,M3D_F32,2,{M3D_OBJECT,M3D_U32},{-1,-1},{1,0}};
    m3d_native_register(&capture_distance);
    {
        const struct M3dNativeCall air={0x800824a0,(void(*)(void))collision_air_box,M3D_U8,2,{M3D_OBJECT,M3D_U32},{-1,-1},{1,0}};
        const struct M3dNativeCall ground={0x80082888,(void(*)(void))collision_ground_box,M3D_U8,2,{M3D_OBJECT,M3D_U32},{-1,-1},{1,0}};
        const struct M3dNativeCall position={0x8026bb68,(void(*)(void))item_position,M3D_VOID,2,{M3D_OBJECT,M3D_U32},{-1,-1},{1,0}};
        const struct M3dNativeCall set={0x8027429c,(void(*)(void))item_set_position,M3D_VOID,2,{M3D_OBJECT,M3D_U32},{-1,-1},{1,0}};
        const struct M3dNativeCall launch={0x8026ac74,(void(*)(void))item_launch,M3D_VOID,4,{M3D_OBJECT,M3D_U32,M3D_U32,M3D_F32},{-1,-1,-1,-1},{1,0,0,0}};
        const struct M3dNativeCall kirby={0x802f23ac,(void(*)(void))item_kirby_position,M3D_F64,2,{M3D_OBJECT,M3D_U32},{-1,-1},{1,0}};
        const struct M3dNativeCall sweep={0x800524dc,(void(*)(void))check_all_remap,M3D_U8,10,
            {M3D_U32,M3D_U32,M3D_U32,M3D_U32,M3D_I32,M3D_I32,M3D_F32,M3D_F32,M3D_F32,M3D_F32},
            {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1}};
        m3d_native_register(&sweep);
        m3d_native_register(&air); m3d_native_register(&ground); m3d_native_register(&position);
        m3d_native_register(&set); m3d_native_register(&launch); m3d_native_register(&kirby);
    }
    const struct M3dNativeCall bone={0x8000b1cc,(void(*)(void))bone_position,M3D_VOID,3,
        {M3D_OBJECT,M3D_U32,M3D_U32},{-1,-1,-1},{3,0,0}};
    const struct M3dNativeCall ecb={0x80086990,(void(*)(void))ecb_position,M3D_VOID,2,
        {M3D_OBJECT,M3D_U32},{-1,-1},{1,0}};
    m3d_native_register(&bone);
    m3d_native_register(&ecb);
#define BIND(address,function,result,count,...) \
    { const struct M3dNativeCall call={address,(void(*)(void))function,result,count,{__VA_ARGS__},{-1,-1,-1,-1}}; m3d_native_register(&call); }
    BIND(0x8000d2ec,game_normalize,M3D_F32,1,M3D_U32)
    BIND(0x8000d530,game_cross_normalized,M3D_U32,3,M3D_U32,M3D_U32,M3D_U32)
    BIND(0x8000d620,game_angle,M3D_F32,2,M3D_U32,M3D_U32)
    BIND(0x8000d790,game_angle_xy,M3D_F32,2,M3D_U32,M3D_U32)
    BIND(0x8000d8f4,game_rotate,M3D_VOID,3,M3D_U32,M3D_U32,M3D_F32)
    BIND(0x8000dc6c,game_mirror,M3D_VOID,2,M3D_U32,M3D_U32)
    BIND(0x80022c30,atan2f,M3D_F32,2,M3D_F32,M3D_F32)
    BIND(0x8000d5bc,sqrtf,M3D_F32,1,M3D_F32)
    BIND(0x80326240,cosf,M3D_F32,1,M3D_F32)
    BIND(0x803263d4,sinf,M3D_F32,1,M3D_F32)
    BIND(0x80364340,fmodf,M3D_F32,2,M3D_F32,M3D_F32)
    BIND(0x803421a4,matrix_identity,M3D_VOID,1,M3D_U32)
    BIND(0x803421d0,matrix_copy,M3D_VOID,2,M3D_U32,M3D_U32)
    BIND(0x80342204,matrix_concat,M3D_VOID,3,M3D_U32,M3D_U32,M3D_U32)
    BIND(0x803422d0,matrix_transpose,M3D_VOID,2,M3D_U32,M3D_U32)
    BIND(0x80342320,matrix_inverse,M3D_U32,2,M3D_U32,M3D_U32)
    BIND(0x80342418,matrix_rot,M3D_VOID,3,M3D_U32,M3D_I8,M3D_F32)
    BIND(0x80342488,matrix_rot_trig,M3D_VOID,4,M3D_U32,M3D_I8,M3D_F32,M3D_F32)
    BIND(0x80342634,matrix_translate,M3D_VOID,4,M3D_U32,M3D_F32,M3D_F32,M3D_F32)
    BIND(0x80342668,matrix_scale,M3D_VOID,4,M3D_U32,M3D_F32,M3D_F32,M3D_F32)
    BIND(0x80342690,matrix_quat,M3D_VOID,2,M3D_U32,M3D_U32)
    BIND(0x80342aa8,matrix_mult_vec,M3D_VOID,3,M3D_U32,M3D_U32,M3D_U32)
    BIND(0x80342afc,matrix_mult_vec_sr,M3D_VOID,3,M3D_U32,M3D_U32,M3D_U32)
    BIND(0x80342d54,vector_add,M3D_VOID,3,M3D_U32,M3D_U32,M3D_U32)
    BIND(0x80342d78,vector_subtract,M3D_VOID,3,M3D_U32,M3D_U32,M3D_U32)
    BIND(0x80342d9c,vector_scale,M3D_VOID,3,M3D_U32,M3D_U32,M3D_F32)
    BIND(0x80342db8,vector_normalize,M3D_VOID,2,M3D_U32,M3D_U32)
    BIND(0x80342dfc,vector_magnitude,M3D_F32,1,M3D_U32)
    BIND(0x80342e38,vector_dot,M3D_F32,2,M3D_U32,M3D_U32)
    BIND(0x80342e58,vector_cross,M3D_VOID,3,M3D_U32,M3D_U32,M3D_U32)
    BIND(0x8037a250,matrix_srt,M3D_VOID,5,M3D_U32,M3D_U32,M3D_U32,M3D_U32,M3D_U32)
    BIND(0x80341494,gx_position,M3D_VOID,2,M3D_U32,M3D_U32)
#undef BIND
}
