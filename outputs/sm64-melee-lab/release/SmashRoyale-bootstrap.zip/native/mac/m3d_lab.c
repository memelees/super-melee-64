#include <melee/gm/gm_1601.h>
#include <melee/if/ifnametag.h>
#include <melee/ft/ft_0D4D.h>
#include <melee/ft/ftcoll.h>
#include <melee/ft/ftanim.h>
#include <melee/it/kinds/it_2E5A.h>
#include <melee/it/it_279C.h>
#include <melee/it/kinds/itbombhei.h>
#include <melee/it/kinds/itsamusgrapple.h>
#include <melee/it/kinds/itlinkhookshot.h>
#include <melee/it/kinds/itmsbomb.h>
#include <melee/gr/stage.h>
#include <melee/gr/ground.h>
#include <melee/gr/types.h>
#include <melee/lb/lb_00B0.h>
#include <melee/ft/ft_07C6.h>
/* DELFINO: opt-in native laboratory; ordinary CPU logic and combat are retained. */
#include "m3d_lab.h"
#include "m3d_menu.h"
#include "m3d_css_policy.h"
#include "m3d_photo.h"
#include "m3d_pause.h"
#include "m3d_sound.h"
#include <melee/ft/ft_0881.h>
#include <melee/lb/lbaudio_ax.h>
#include "m3d_room.h"
#include "m3d_akaneia.h"
#include "m3d_items.h"
#include "m3d_vm.h"
#include "m3d_native_calls.h"
#include <sysdolphin/baselib/psstructs.h>
#include "world/m3d.h"
#include "world/m3d_combat_rules.h"
#include <melee/ft/ftdata.h>
#include <melee/ft/kinds/ftCommon/ftCo_Attack100.h>
#include <melee/ft/kinds/ftCommon/ftCo_Throw.h>
#include <melee/ft/kinds/ftCommon/ftCo_WarpStar.h>
#include <melee/ft/kinds/ftCommon/ftCo_CargoThrow.h>
#include <melee/ft/kinds/ftKoopa/ftkoopaspecials.h>
#include <melee/ef/efsync.h>
#include <sysdolphin/baselib/gobjplink.h>
#include <melee/ef/eflib.h>
#include <melee/ef/types.h>
#include <melee/cm/camera.h>
#include <melee/ft/ftparts.h>
#include <melee/ft/kinds/ftFox/forward.h>
#include <melee/ft/kinds/ftNess/forward.h>
#include <melee/ft/kinds/ftNess/ftnessspecialhi.h>
#include <melee/it/types.h>
#include <melee/it/kinds/itsamuschargeshot.h>
#include <melee/it/kinds/itwstar.h>
#include <sysdolphin/baselib/controller.h>
#include <sysdolphin/baselib/jobj.h>
#include <melee/ft/ftcommon.h>
#include <melee/ft/ftchangeparam.h>
#include <melee/ft/ft_0892.h>
#include <melee/ft/kinds/ftCommon/ftCo_Fall.h>
#include <melee/ft/kinds/ftCommon/ftCo_FallSpecial.h>
#include <melee/ft/kinds/ftCommon/ftCo_AirCatch.h>
#include <melee/ft/kinds/ftCommon/ftCo_DownAttack.h>
#include <melee/ft/kinds/ftCommon/forward.h>
#include <melee/it/item.h>
#include <melee/mp/mplib.h>
#include <melee/mp/mpcoll.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#ifdef _WIN32
#define flockfile _lock_file
#define funlockfile _unlock_file
#endif
#include "pc.h"
#include <melee/ft/types.h>
#include <melee/ft/fighter.h>
#include <melee/ft/ftlib.h>
#include <melee/ft/ft_0D31.h>
#include <melee/ft/kinds/ftKirby/ftkirby.h>
#include <melee/gm/gmvs.h>
#include <melee/if/forward.h>
#include <melee/if/ifstatus.h>
#include <melee/if/types.h>
#include <melee/lb/types.h>
#include <melee/mn/types.h>
#include <melee/pl/player.h>
#include <dolphin/gx.h>
#include <sysdolphin/baselib/cobj.h>
#include <sysdolphin/baselib/gobj.h>
#include <sysdolphin/baselib/gobjgxlink.h>
#include <sysdolphin/baselib/shadow.h>
#include <sysdolphin/baselib/state.h>
#include <sysdolphin/baselib/tev.h>
#include <sysdolphin/baselib/tobj.h>

static unsigned fixture_ticks;
/* Opt-in diagnostics only. Measure thread CPU alongside wall time so a host
 * scheduling/GPU wait is not mistaken for expensive simulation work. */
static int frame_trace_enabled=-1,frame_trace_stage;
static unsigned frame_trace_ticks;
static uint64_t frame_trace_wall,frame_trace_cpu;
static uint64_t trace_wall[M3D_TRACE_STAGES],trace_cpu[M3D_TRACE_STAGES];
static int tracing(void) {
    if(frame_trace_enabled<0)frame_trace_enabled=getenv("MELEE3D_NATIVE_FRAME_TRACE")!=NULL;
    return frame_trace_enabled;
}
static uint64_t thread_ns(void) {
#ifdef __APPLE__
    struct timespec time;if(clock_gettime(CLOCK_THREAD_CPUTIME_ID,&time))return 0;
    return (uint64_t)time.tv_sec*1000000000u+time.tv_nsec;
#else
    return 0;
#endif
}
void m3d_lab_trace_stage(int stage) {
    if(!tracing())return;
    uint64_t wall=pc_monotonic_ns(),cpu=thread_ns();
    if(frame_trace_wall){trace_wall[frame_trace_stage]+=wall-frame_trace_wall;trace_cpu[frame_trace_stage]+=cpu-frame_trace_cpu;}
    frame_trace_wall=wall;frame_trace_cpu=cpu;frame_trace_stage=stage;
}
void m3d_lab_trace_tick(void) {if(tracing())++frame_trace_ticks;}
void m3d_lab_trace_frame(unsigned frame) {
    if(!tracing())return;m3d_lab_trace_stage(frame_trace_stage);
    uint64_t wall=0,cpu=0;for(int i=0;i<M3D_TRACE_STAGES;i++){wall+=trace_wall[i];cpu+=trace_cpu[i];}
    if(wall>23000000u || frame%60==0) {
        static const char* names[]={"pad","sim","draw","submit","host","pace","begin"};
        flockfile(stderr);
        fprintf(stderr,"M3D FRAME TRACE frame=%u ticks=%u total=%.3f cpu=%.3f",frame,frame_trace_ticks,wall/1e6,cpu/1e6);
        for(int i=0;i<M3D_TRACE_STAGES;i++)fprintf(stderr," %s=%.3f/%.3f",names[i],trace_wall[i]/1e6,trace_cpu[i]/1e6);
        fputc('\n',stderr);
        funlockfile(stderr);
    }
    memset(trace_wall,0,sizeof trace_wall);memset(trace_cpu,0,sizeof trace_cpu);frame_trace_ticks=0;
}
static struct {
    int grabbed,pummel,thrown,released,release_tick,alive,continuous;
    float before_damage,max_step;
    Vec3 previous;
} grab_check;
static struct {float peak;unsigned maximum,airborne;int budget_ok,falls;} jump_check;
static bool reflector_checked;
static int sequence_profile(void)
{
    const char* value=getenv("MELEE3D_NATIVE_SEQUENCE_PROFILE");
    if(!value || !strcmp(value,"entries"))return 0;
    if(!strcmp(value,"charge"))return 1;
    if(!strcmp(value,"hits"))return 2;
    if(!strcmp(value,"reflect"))return 3;
    if(!strcmp(value,"grabs"))return 4;
    if(!strcmp(value,"inputs"))return 5;
    if(!strcmp(value,"jab"))return 6;
    if(!strcmp(value,"jumps"))return 7;
    if(!strcmp(value,"latch"))return 8;
    fprintf(stderr,"M3D LAB FAIL invalid sequence profile\n");abort();
}

int m3d_lab_count(void)
{
    static int count = -1;
    if (count < 0) {
        const char* value = getenv("MELEE3D_NATIVE_LAB");
        count = value ? atoi(value) : 0;
        if (count < 2 || count > GM_MAX_PLAYERS) count = 0;
    }
    return count;
}

/* Test-only: one added fighter and one retail opponent. Each process owns one
 * character's sequence; the regular sixteen-player integration lane is separate. */
static int sequence_config(unsigned* mask, unsigned* window)
{
    const char* value = getenv("MELEE3D_NATIVE_SEQUENCE");
    unsigned character;
    int consumed = 0;
    if (!value) return -1;
    if (sscanf(value, "%u:%u:%u%n", &character, mask, window, &consumed) != 3 ||
        value[consumed] || character >= 7 || !*mask || *mask > 255 ||
        *window < 300 || *window > 1200 || m3d_lab_count() != 2) {
        fprintf(stderr, "M3D LAB FAIL invalid sequence configuration\n");
        abort();
    }
    return (int)character;
}

void m3d_lab_input(Fighter* fp)
{
    if((m3d_GameplayCaptureActive()&&!getenv("MELEE3D_NATIVE_CAPTURE_LIVE"))||getenv("MELEE3D_NATIVE_ONETT_CAR_PROBE")) {
        fp->input.held_buttons[0]=0;fp->input.lstick[0]=(Vec2){0};fp->input.cstick[0]=(Vec2){0};fp->input.triggers[0]=0;return;
    }
    unsigned mask,window,ordinal,move,count=0,offset;
    int character=sequence_config(&mask,&window),profile=sequence_profile();
    if(character<0 || profile>=5 || fixture_ticks<240)return;
    ordinal=(fixture_ticks-240)/window;offset=(fixture_ticks-240)%window;
    if(ordinal>=__builtin_popcount(mask))return;
    for(move=0;move<8;++move)if(mask&(1u<<move)) { if(count++==ordinal)break; }
    fp->input.held_buttons[0]=0;fp->input.lstick[0].x=fp->input.lstick[0].y=0;
    fp->input.cstick[0].x=fp->input.cstick[0].y=0;fp->input.triggers[0]=0;
    if(fp->player_idx==0) {
        if(profile==1 || profile==2 || profile==3) {
            if(offset<90)fp->input.held_buttons[0]=HSD_PAD_B;
        }
        if(profile==4) {
            if(offset==15)fp->input.held_buttons[0]=HSD_PAD_Z;
            if(offset==40)fp->input.held_buttons[0]=HSD_PAD_A;
            if(offset>=75 && offset<79) {
                if(move<2)fp->input.lstick[0].x=move ? -1:1;
                else fp->input.lstick[0].y=move==2 ? 1:-1;
            }
        }
    } else if(profile==3 && offset<180)fp->input.held_buttons[0]=HSD_PAD_B;
}

#include "m3d_player_roster.inc"
static const char* playable_name(int character) {
    for(unsigned i=0;i<sizeof(m3d_playable)/sizeof(*m3d_playable);i++)
        if(m3d_playable[i].character==character)return m3d_playable[i].name;
    return NULL;
}
const char* m3d_lab_character_name(int character){return playable_name(character);}
static bool selected_lineup;
static int expected_lineup[GM_MAX_PLAYERS];
static void assign_lineup(StartMeleeData* start,int count) {
    const char* cursor=getenv("MELEE3D_NATIVE_LINEUP");selected_lineup=cursor!=NULL;
    if(!cursor)return;
    for(int i=0;i<count;i++) {
        char* end;long value=strtol(cursor,&end,10);
        if(end==cursor||value<0||value>40||!playable_name(value)||(i<count-1?*end!=',':*end!=0))
            m3d_vm_fail("Invalid playable roster lineup");
        start->players[i].ckind=(CharacterKind)value;
        expected_lineup[i]=Player_800325C8(value,false);
        fprintf(stderr,"M3D ROSTER SLOT slot=%d character=%ld kind=%d name=%s\n",i,value,expected_lineup[i],playable_name(value));
        cursor=end+(*end==',');
    }
}

static bool varied_costumes;
static unsigned expected_costumes[GM_MAX_PLAYERS];
static void assign_costumes(StartMeleeData* start,int count)
{
    unsigned used[ChKind_Max]={0},reserved[ChKind_Max]={0};
    const char* value=getenv("MELEE_SEED");unsigned seed=value?(unsigned)strtoul(value,NULL,10):1;
    unsigned offset=seed ? seed-1:0;
    const char* outfits=getenv("MELEE3D_NATIVE_HUMAN_COSTUMES");
    for(int i=0;i<count;i++)if(start->players[i].slot_type==Gm_PKind_Human){
        PlayerInitData* p=&start->players[i];int variants=m3d_MenuCostumeCount(p->ckind);
        if(outfits){char* end;long color=strtol(outfits,&end,10);if(end==outfits||color<0||color>31||(*end&&*end!=','))m3d_vm_fail("Invalid human costume list");p->color=(unsigned)color;outfits=*end?end+1:end;}
        p->color=m3d_css_costume(p->color,variants);if(p->color<32)reserved[p->ckind]|=1u<<p->color;
    }
    if(outfits&&*outfits)m3d_vm_fail("Too many human costumes");
    for(int i=0;i<count;i++) {
        PlayerInitData* player=&start->players[i];int kind=Player_800325C8(player->ckind,false);
        if(kind<0 || kind>=Ft_Kind_Max)m3d_vm_fail("Invalid costume character mapping");
        unsigned variants=kind>=33 && kind<40 ? m3d_akaneia_costume_count(kind) : CostumeListsForeachCharacter[kind].numCostumes;
        if(!variants)m3d_vm_fail("Character has no registered costumes");
        unsigned color=player->color;
        if(player->slot_type!=Gm_PKind_Human)color=m3d_css_cpu_costume(used[player->ckind]++,variants,reserved[player->ckind],offset);
        player->color=color;player->sub_color=0;expected_costumes[i]=color;
        fprintf(stderr,"M3D COSTUME SETUP slot=%d kind=%d color=%u available=%u human=%d\n",i,kind,color,variants,player->slot_type==Gm_PKind_Human);
    }
}

void m3d_lab_setup(StartMeleeData* start)
{
    int i, count = m3d_lab_count();
    const char* roster = getenv("MELEE3D_NATIVE_ROSTER");
    static const CharacterKind kinds[16] = {
        CKind_Mario, CKind_Fox, CKind_Captain, CKind_Donkey,
        CKind_Kirby, CKind_Koopa, CKind_Link, CKind_Samus,
        CKind_Pikachu, CKind_Ness, CKind_Purin, CKind_Peach,
        CKind_Mars, CKind_Mewtwo, CKind_Falco, CKind_Ganon,
    };
    unsigned mask, window;
    int sequence = sequence_config(&mask, &window);
    if (!count) return;
    const char* game_speed=getenv("MELEE3D_NATIVE_GAME_SPEED");
    if(game_speed){char* end;float value=strtof(game_speed,&end);if(!*game_speed||*end||!isfinite(value)||value<.5f||value>1.5f)abort();start->rules.game_speed=value;}
    fprintf(stderr,"M3D RULE MATCH speed=%.4f\n",start->rules.game_speed);
    for (i = 0; i < GM_MAX_PLAYERS; ++i) {
        PlayerInitData* p = &start->players[i];
        p->slot_type = i < count ? Gm_PKind_Cpu : Gm_PKind_NA;
        p->ckind = CKind_Fox;
        if (roster && !strcmp(roster,"mixed")) p->ckind=kinds[i % 4];
        if (roster && !strcmp(roster,"full")) p->ckind=kinds[i%16];
        /* Keep the four existing HUD panels on retail entries while the
         * expanded roster UI is being ported. Added fighters occupy 4..15. */
        if (i>=4 && roster && !strcmp(roster,"akaneia")) p->ckind=(CharacterKind)(34+(i-4)%7);
        if (i>=4 && roster && !strcmp(roster,"wolf")) p->ckind=(CharacterKind)34;
        if (sequence >= 0 && i == 0) p->ckind=(CharacterKind)(34+sequence);
        p->slot = 0; /* A CPU slot is independent of a physical controller. */
        p->cpu_level = getenv("MELEE3D_NATIVE_DELFINO")?9:6;
        p->cpu_kind = 4;
        if(i>=4 && getenv("MELEE3D_NATIVE_SPAWN_ONLY"))p->cpu_kind=0;
        if(getenv("MELEE3D_NATIVE_SPECIAL"))p->cpu_kind=0;
        if(sequence >= 0)p->cpu_kind=0;
        p->color = 0;
        p->sub_color = 0;
        p->rumble_enabled = false;
    }
    assign_lineup(start,count);
    if(sequence_profile()>=5)start->players[0].slot_type=Gm_PKind_Human;
    if(getenv("MELEE3D_NATIVE_CONTROLS")||getenv("MELEE3D_NATIVE_COMBAT_PROBE")) {
        start->players[0].slot_type=Gm_PKind_Human;
        for(i=0;i<count;i++)start->players[i].cpu_kind=0;
    }
    /* The laboratory has retail-only HUD art. Disable percentage panels in
     * this diagnostic rather than loading four filler fighters to hide them. */
    if(sequence >= 0) {
        start->rules.x2_6=0;
        fprintf(stderr,"M3D SEQUENCE SETUP character=%d mask=%u window=%u fighters=2\n",sequence,mask,window);
    }
    if (getenv("MELEE3D_NATIVE_HUMAN")) {
        start->players[0].slot_type=Gm_PKind_Human;
        const char* selected=getenv("MELEE3D_NATIVE_CHARACTER");
        if(selected) {
            int found=0;
            for(unsigned j=0;j<sizeof(m3d_playable)/sizeof(*m3d_playable);j++)
                if(!strcmp(selected,m3d_playable[j].name)) {
                    start->players[0].ckind=(CharacterKind)m3d_playable[j].character;found=1;break;
                }
            if(!found)m3d_vm_fail("Invalid human character");
        }
    }
    if(getenv("MELEE3D_NATIVE_RECOVERY")) {
        const char* selection=getenv("MELEE3D_NATIVE_RECOVERY");int kind=atoi(selection);
        const CharacterKind characters[]={CKind_Fox,CKind_Mewtwo,CKind_Pikachu,CKind_Seak,CKind_Zelda,CKind_Ness,CKind_Falco,CKind_Pichu};
        if(kind<0 || kind>=8 || count!=2)abort();
        start->players[0].slot_type=Gm_PKind_Human;start->players[0].ckind=characters[kind];
        for(i=0;i<count;i++)start->players[i].cpu_kind=0;
    }
    if(getenv("MELEE3D_NATIVE_EFFECT_REUSE")||getenv("MELEE3D_NATIVE_CAMERA_PROBE")) {
        if(count!=2)abort();start->players[0].slot_type=Gm_PKind_Human;
        if(getenv("MELEE3D_NATIVE_EFFECT_REUSE"))start->players[0].ckind=(CharacterKind)38;
        for(i=0;i<count;i++)start->players[i].cpu_kind=0;
    }
    if(getenv("MELEE3D_NATIVE_DELFINO_PROBE")) {
        if(strcmp(getenv("MELEE3D_NATIVE_DELFINO_PROBE"),"rules")&&count!=2)abort();start->players[0].slot_type=Gm_PKind_Human;
        for(i=0;i<count;i++)start->players[i].cpu_kind=0;
    }
    if(getenv("MELEE3D_NATIVE_AREA_PROBE")) {
        if(count!=2)abort();
        start->players[0].ckind=CKind_Ganon;start->players[1].ckind=CKind_Mario;
        start->players[0].slot_type=Gm_PKind_Human;
        for(i=0;i<count;i++)start->players[i].cpu_kind=0;
    }
    if(getenv("MELEE3D_NATIVE_STORM_PROBE")&&(!strcmp(getenv("MELEE3D_NATIVE_STORM_PROBE"),"fixture")||!strcmp(getenv("MELEE3D_NATIVE_STORM_PROBE"),"visual"))) {
        if(count!=2)abort();for(i=0;i<count;i++)start->players[i].cpu_kind=0;
    }
    if(getenv("MELEE3D_NATIVE_PLATFORM")) {
        if(count!=2)abort();for(i=0;i<count;i++)start->players[i].cpu_kind=0;
    }
    const char* route=getenv("MELEE3D_NATIVE_DELFINO_ROUTE");
    if(route&&!strcmp(route,"islands")){
        for(i=0;i<count;i++)start->players[i].ckind=(CharacterKind)(i%2?40:38);
        fprintf(stderr,"M3D ISLAND ROUTE roster=Sonic,Tails native attributes only\n");
    }
    const char* grab_target=getenv("MELEE3D_NATIVE_GRAB_TARGET");
    if(grab_target && sequence>=0 && sequence_profile()==4) {
        static const char* names[]={"wolf","diddy","charizard","lucas","sonic","dedede","tails"};
        int found=0;
        for(i=0;i<7;i++)if(!strcmp(grab_target,names[i])){start->players[1].ckind=(CharacterKind)(34+i);found=1;break;}
        if(!found)m3d_vm_fail("Invalid grab-fixture opponent");
        fprintf(stderr,"M3D GRAB TARGET name=%s kind=%d\n",grab_target,Player_800325C8(start->players[1].ckind,false));
    }
    varied_costumes=getenv("MELEE3D_NATIVE_DELFINO") && !getenv("MELEE3D_NATIVE_DELFINO_PROBE") && !getenv("MELEE3D_NATIVE_DELFINO_ROUTE");
    m3d_MenuRoster(start);
    if(m3d_MenuActive()){selected_lineup=false;for(int j=0;j<32;j++){expected_lineup[j]=Player_800325C8(start->players[j].ckind,false);fprintf(stderr,"M3D ROSTER SLOT slot=%d character=%d kind=%d name=%s\n",j,start->players[j].ckind,expected_lineup[j],playable_name(start->players[j].ckind));}selected_lineup=true;}
    m3d_RoomSetup(start);
    if(varied_costumes)assign_costumes(start,count);
    if(getenv("MELEE3D_NATIVE_DELFINO"))start->rules.x2_6=1; // Keep the native damage panel; its view filters to the human.
    if(getenv("MELEE3D_NATIVE_DELFINO")){start->rules.item_freq=m3d_ItemDropFrequency();start->rules.x20=(u64)-1;
        fprintf(stderr,"M3D ITEM RULES frequency=%d\n",start->rules.item_freq);}
    if(getenv("MELEE3D_NATIVE_CAPTURE_CHECK")){if(count!=2)abort();for(i=0;i<count;i++){start->players[i].cpu_kind=0;start->players[i].slot_type=Gm_PKind_Human;}}
    if(getenv("MELEE3D_NATIVE_TETHER_CHECK")||getenv("MELEE3D_NATIVE_CLOTH_CHECK"))for(i=0;i<count;i++)start->players[i].cpu_kind=0;
    /* Standing CPUs still aim their slice at the opponent. Cloth comparisons
     * require an entirely stationary world heading, with no CPU adapter. */
    if(getenv("MELEE3D_NATIVE_CLOTH_CHECK"))for(i=0;i<count;i++)start->players[i].slot_type=Gm_PKind_Human;
    m3d_MatchSetup(start);
    if(getenv("MELEE3D_NATIVE_RULE_CHECK")){if(count!=2)abort();for(int j=0;j<count;j++)start->players[j].cpu_kind=0;}
    if(m3d_GameplayCaptureActive()&&!getenv("MELEE3D_NATIVE_CAPTURE_LIVE")){for(i=0;i<count;i++)start->players[i].cpu_kind=0;start->rules.item_freq=0;}
    m3d_PartySetup(start);
    fprintf(stderr, "M3D LAB SETUP slots=%d capacity=%d ports=4\n", count, GM_MAX_PLAYERS);
}

static void sequence_ground(HSD_GObj* object,float x)
{
    Fighter* fp=object->user_data;
    Vec3 position,normal;int line;u32 flags;
    if(!mpCheckFloor(x,100,x,-100,0,&position,&line,&flags,&normal,-1,-1,-1,NULL,NULL)) {
        fprintf(stderr,"M3D LAB FAIL no reset floor\n");abort();
    }
    fp->cur_pos=position;fp->prev_pos=position;
    fp->coll_data.cur_pos=fp->coll_data.prev_pos=fp->coll_data.last_pos=position;
    fp->coll_data.floor.index=line;fp->coll_data.floor.flags=flags;fp->coll_data.floor.normal=normal;
    ftCommon_8007D7FC(fp);ft_8008A2BC(object);
}

/* Real pad dispatch fixture, opt-in only. No special-entry callbacks are called. */
static unsigned world_buttons(unsigned tick)
{
    if(m3d_SeparateAttackInputs()) {
        if(tick>=1200&&tick<1440&&(tick-1200)%60==10){unsigned phase=(tick-1200)/60;return HSD_PAD_A|(phase==1?HSD_PAD_DPADUP:phase==2?HSD_PAD_L:0);}
        if(tick==310||tick==460)return HSD_PAD_B|HSD_PAD_DPADUP;
        if(tick==610||tick==760)return HSD_PAD_B|HSD_PAD_L;
    }
    if(tick==221)return HSD_PAD_X;
    if(tick==310 || tick==460 || tick==610 || tick==760)return HSD_PAD_B;
    if(tick==1050 || tick==1100 || tick==1150)return HSD_PAD_DPADLEFT;
    return 0;
}
static void recovery_pad(HSD_PadStatus* pad,unsigned tick)
{
    if(tick<240)return;
    if(getenv("MELEE3D_NATIVE_RECOVERY_AIM")) {
        unsigned phase=(tick-240)/140,offset=(tick-240)%140;if(phase>=20)return;
        if(offset==10){pad->button=pad->trigger=HSD_PAD_B|HSD_PAD_DPADUP;pad->nml_stickY=0;}
        if(offset>=15&&offset<115) {
            int aim=phase%5;
            pad->nml_stickX=aim==0||aim==2?-1:aim==4?1:0;
            pad->button=aim<2?HSD_PAD_DPADUP:aim>=3?HSD_PAD_L:0;
        }
        pad->stickX=(s8)(pad->nml_stickX*80);pad->stickY=(s8)(pad->nml_stickY*80);return;
    }
    unsigned phase=(tick-240)/180,offset=(tick-240)%180;
    if(phase>=4)return;
    bool ness=atoi(getenv("MELEE3D_NATIVE_RECOVERY"))==5;
    if(offset==10){pad->button=pad->trigger=HSD_PAD_B;pad->nml_stickY=1;}
    if(ness && phase>=2 && offset>=10 && offset<100){pad->button=HSD_PAD_B;pad->nml_stickY=0;}
    if(offset==11)pad->last_button=pad->release=HSD_PAD_B;
    if(offset>=15 && offset<100) {
        if(phase==1)pad->nml_stickY=-1;
        else pad->nml_stickX=1;
        if(phase>=2){pad->button|=HSD_PAD_R;pad->nml_analogR=1;}
        if(phase==2)pad->nml_subStickY=1;
        if(ness){pad->nml_stickX=0;pad->nml_stickY=-1;pad->button|=HSD_PAD_R;pad->nml_analogR=1;pad->nml_subStickY=.35f;}
    }
    pad->stickX=(s8)(pad->nml_stickX*80);pad->stickY=(s8)(pad->nml_stickY*80);
    pad->subStickX=(s8)(pad->nml_subStickX*80);pad->subStickY=(s8)(pad->nml_subStickY*80);
}

/* Real native summon and collision diagnostics. The fixture never applies a
 * status or damage itself: only the original item scripts may do that. */
static bool area_probe_activate(Item_GObj* gobj) {
    Item* ip=gobj->user_data;
    if(ip->kind==It_Kind_BombHei)it_8027D730(gobj);
    else if(ip->kind==It_Kind_MSBomb)it_802905D8(gobj);
    else if(ip->kind==It_Kind_WStar){Vec3 impact=ip->pos;it_802947CC(gobj,&impact);}
    else {
        int variant=atoi(getenv("MELEE3D_NATIVE_AREA_VARIANT"));
        if(variant<2||variant>6)abort();
        ip->xDAC_itcmd_var0=0;
        Item_80268E5C(gobj,variant,ITEM_ANIM_UPDATE);
        ip->entered_hitlag=ip->exited_hitlag=NULL;
        fprintf(stderr,"M3D AREA VARIANT kind=%d state=%d native_animation_phase=1\n",ip->kind,variant);
    }
    return false;
}

static void area_probe_tick(unsigned tick) {
    const char* option=getenv("MELEE3D_NATIVE_AREA_PROBE");
    if(!option || tick<240)return;
    unsigned window=getenv("MELEE3D_NATIVE_AREA_LIFECYCLE")?1800:(atoi(option)==It_PKind_Marumine || atoi(option)==It_PKind_Kabigon)?480:atoi(option)<It_PKind_Start?120:240;
    unsigned phase=(tick-240)/window,offset=(tick-240)%window;
    if(phase>=(getenv("MELEE3D_NATIVE_AREA_LIFECYCLE")?1:12))return;
    static HSD_GObj* summon;static int affected,active;static Vec3 center;
    static float before_damage,peak_damage,return_damage;static int cloud_quadrants,return_reset;
    HSD_GObj* subject=Player_GetEntity(0);Fighter* f=subject->user_data;
    if(!offset) {
        for(int slot=0;slot<2;slot++) {
            HSD_GObj* g=Player_GetEntity(slot);Fighter* v=g->user_data;
            if(v->x1980)ftCommon_8007FF74(g);
        }
        while(HSD_GObjPLinkHead[HSD_GOBJ_PLINK_ITEM])Item_8026A8EC(HSD_GObjPLinkHead[HSD_GOBJ_PLINK_ITEM]);
    }
    /* Let the real damage pipeline drain before resetting the next subject.
     * Changing an action alone does not cancel a queued hit from last frame. */
    if(offset<60)return;
    if(offset==60) {
        sequence_ground(subject,0);sequence_ground(Player_GetEntity(1),0);
        center=(Vec3){819,100,-732};Vec3 floor;
        if(!m3d_DelfinoFloor(&center,&floor))abort();center=floor;
        for(int slot=0;slot<2;slot++) {
            HSD_GObj* g=Player_GetEntity(slot);Fighter* v=g->user_data;Vec3 p=center;
            float angle=(phase%8)*.785398163f;if(phase==9)angle=1.570796327f;
            if(slot==0){float distance=phase==8||phase==9?200:atoi(option)<It_PKind_Start?8:18;p.x+=cosf(angle)*distance;p.z+=sinf(angle)*distance;}
            else p.x+=120;
            v->cur_pos=v->prev_pos=v->coll_data.cur_pos=v->coll_data.prev_pos=v->coll_data.last_pos=p;
            v->self_vel=(Vec3){0};v->x8c_kb_vel=(Vec3){0};v->gr_vel=v->xF0_ground_kb_vel=0;
            v->dmg.x1830_percent=0;Player_SetHUDDamage(slot,0);v->facing_dir=1;
            v->x1990=v->x1994=0;ftColl_8007B6EC(g);ftColl_8007B62C(g,0);
            ftColl_8007B0C0(g,HurtCapsule_Enabled);
            m3d_SetLane(v,slot==0?cosf(angle):1,slot==0?sinf(angle):0);HSD_JObjSetTranslate(g->hsd_obj,&p);
        }
        SpawnItem spawn={0};spawn.kind=atoi(option);spawn.prev_pos=spawn.pos=center;
        spawn.facing_dir=1;spawn.x0_parent_gobj=spawn.x4_parent_gobj2=Player_GetEntity(phase==11?0:1);spawn.x44_flag.x0.b0=1;
        ItemKind kind=spawn.kind;HSD_GObj* ball=NULL;
        if(kind>=It_PKind_Start && kind<It_PKind_Terminate) {
            spawn.kind=It_Kind_M_Ball;ball=Item_80268B18(&spawn);if(!ball)abort();
            spawn.kind=kind;spawn.x4_parent_gobj2=ball;
        }
        summon=Item_80268B18(&spawn);if(!summon)abort();
        if(ball)it_8027AAA0(ball,summon->user_data,kind);affected=active=0;
        before_damage=f->dmg.x1830_percent;peak_damage=return_damage=0;return_reset=0;cloud_quadrants=0;
        if(phase==10){ftCommon_8007D5D4(f);ftCo_Fall_Enter(subject);}
        fprintf(stderr,"M3D AREA BEGIN kind=%d phase=%u pos=%.2f,%.2f,%.2f victim=%.2f,%.2f,%.2f state=%d\n",spawn.kind,phase,center.x,center.y,center.z,f->cur_pos.x,f->cur_pos.y,f->cur_pos.z,f->motion_id);
    }
    if(phase==10) {
        f->cur_pos.y=center.y+4;f->self_vel=(Vec3){0};f->gr_vel=0;
    }
    peak_damage=fmaxf(peak_damage,f->dmg.x1830_percent-before_damage);
    bool exists=false;for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_ITEM];g;g=g->next) {
        if(g==summon)exists=true;
        Item* child=g->user_data;
        if(child->kind==It_Kind_Matadogas_Gas1 || child->kind==It_Kind_Matadogas_Gas2) {
            float dx=child->pos.x-center.x,dz=child->pos.z-center.z;
            if(dx*dx+dz*dz>4)cloud_quadrants|=1<<((dx<0?1:0)|(dz<0?2:0));
            for(int i=0;i<4;i++)active+=child->x5D4_hitboxes[i].hit.state!=HitCapsule_Disabled;
        }
    }
    if(exists) {
        Item* ip=summon->user_data;
        if(ip->kind==It_PKind_Kabigon&&ip->msid==1&&!ip->xDAC_itcmd_var0&&ip->xDD4_itemVar.kabigon.x6C<=20&&!return_reset) {
            /* Prove the returning slam itself hits, independently of ascent. */
            sequence_ground(subject,0);Vec3 p=center;float angle=(phase%8)*.785398163f;if(phase==9)angle=1.570796327f;
            float distance=phase==8||phase==9?200:18;p.x+=cosf(angle)*distance;p.z+=sinf(angle)*distance;
            if(phase==10){p.y+=4;ftCommon_8007D5D4(f);ftCo_Fall_Enter(subject);}
            f->cur_pos=f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=p;
            f->self_vel=f->x8c_kb_vel=(Vec3){0};f->gr_vel=f->xF0_ground_kb_vel=0;
            f->dmg.x1830_percent=0;Player_SetHUDDamage(0,0);return_reset=1;
        }
        if(return_reset)return_damage=fmaxf(return_damage,f->dmg.x1830_percent);
        if(getenv("MELEE3D_NATIVE_AREA_LIFECYCLE") && offset%15==0) {
            HSD_JObj* joint=summon->hsd_obj;
            fprintf(stderr,"M3D AREA LIFE frame=%u state=%d falling=%d hidden=%d pos=%.3f,%.3f,%.3f velocity=%.3f scale=%.3f blast_top=%.3f\n",offset,ip->msid,ip->xDAC_itcmd_var0,!!(joint->flags&JOBJ_HIDDEN),ip->pos.x,ip->pos.y,ip->pos.z,ip->x40_vel.y,joint->scale.x,Stage_GetBlastZoneTopOffset());
        }
        /* Schedule activation inside Item Think - Animation. A one-frame
         * Metronome hit must reach collision later in that same native tick. */
        if(offset==89 && (ip->kind==It_Kind_BombHei || ip->kind==It_Kind_MSBomb || ip->kind==It_Kind_WStar ||
            ((ip->kind==It_PKind_Togepy || ip->kind==It_PKind_Pippi) && getenv("MELEE3D_NATIVE_AREA_VARIANT"))))
            ip->animated=area_probe_activate;
        for(int i=0;i<4;i++)if(ip->x5D4_hitboxes[i].hit.state!=HitCapsule_Disabled) {
            HitCapsule* h=&ip->x5D4_hitboxes[i].hit;active++;
            if(offset%30==0)fprintf(stderr,"M3D AREA HIT phase=%u frame=%u state=%d element=%d radius=%.2f center=%.2f,%.2f,%.2f item=%.2f,%.2f,%.2f victimstate=%d flags=%d%d%d victim=%.2f,%.2f,%.2f air=%d\n",phase,offset,ip->msid,h->element,h->scale*ip->scl,h->x4C.x,h->x4C.y,h->x4C.z,ip->pos.x,ip->pos.y,ip->pos.z,f->motion_id,h->x40_b2,h->x40_b3,h->x42_b5,f->cur_pos.x,f->cur_pos.y,f->cur_pos.z,f->ground_or_air);
        }
    }
    if(f->motion_id>=ftCo_MS_DamageSong && f->motion_id<=ftCo_MS_DamageSongRv)affected++;
    if(offset==window-1)fprintf(stderr,"M3D AREA END kind=%s phase=%u active=%d affected=%d state=%d damage=%.1f cloud_quadrants=%x\n",option,phase,active,affected,f->motion_id,peak_damage,cloud_quadrants);
    if(offset==window-1&&atoi(option)==It_PKind_Kabigon)fprintf(stderr,"M3D AREA RETURN phase=%u reset=%d damage=%.2f\n",phase,return_reset,return_damage);
}

static int coin_probe_before;
static void coin_probe_tick(unsigned tick) {
    const char* probe=getenv("MELEE3D_NATIVE_DELFINO_PROBE");if(!probe||strcmp(probe,"coins")||tick<240)return;
    unsigned phase=(tick-240)/120,offset=(tick-240)%120;if(phase>=8)return;
    HSD_GObj* object=Player_GetEntity(0);Fighter* f=object->user_data;
    if(!offset){
        sequence_ground(object,0);Vec3 p;m3d_DelfinoSpawn(phase*3,32,&p);
        p.y-=10;f->cur_pos=f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=p;
        f->self_vel=(Vec3){0};f->x8c_kb_vel=(Vec3){0};f->gr_vel=0;
        m3d_SetLane(f,cosf(phase*.785398163f),sinf(phase*.785398163f));
        HSD_JObjSetTranslate(object->hsd_obj,&p);coin_probe_before=Player_GetCoins(0);
    }
    if(offset==10){Vec3 p=f->cur_pos,v={0};p.y+=4;it_802E5F00(Player_GetEntity(1),&p,&v,10);}
    if(offset==65){int gain=Player_GetCoins(0)-coin_probe_before;
        fprintf(stderr,"M3D COIN PICKUP %s ordinal=%u gain=%d pos=%.2f,%.2f,%.2f\n",gain>0?"PASS":"FAIL",phase,gain,f->cur_pos.x,f->cur_pos.y,f->cur_pos.z);
    }
    if(offset==85){int before=Player_GetCoins(0);Vec3 p=f->cur_pos;
        ftCo_800D4E50(f,&p,1,0);
        int after=Player_GetCoins(0),expected=before-before/2;
        fprintf(stderr,"M3D COIN KO %s ordinal=%u before=%d after=%d expected=%d\n",before>0&&after==expected?"PASS":"FAIL",phase,before,after,expected);
    }

}
static Vec3 rule_start;static float rule_peak;static int rule_air;
static void rules_probe_tick(unsigned tick) {
    const char* probe=getenv("MELEE3D_NATIVE_DELFINO_PROBE");if(!probe||strcmp(probe,"rules")||tick<240||tick>600)return;
    Fighter* player=Player_GetEntity(0)->user_data;
    if(tick==240) {
        rule_start=player->cur_pos;rule_peak=rule_start.y;rule_air=0;
        for(int i=0;i<m3d_lab_count();i++) {
            HSD_GObj* object=Player_GetEntity(i);Fighter* f=object->user_data;
            ftCo_800D105C(object);float dash=f->co_attrs.dash_max_velocity,g=f->co_attrs.gravity,terminal=f->co_attrs.terminal_velocity;
            ftCo_800D105C(object);
            bool ok=fabsf(dash-f->co_attrs.dash_max_velocity)<.00001f&&fabsf(g-f->co_attrs.gravity)<.00001f&&fabsf(terminal-f->co_attrs.terminal_velocity)<.00001f;
            fprintf(stderr,"M3D RULE REBUILD %s slot=%d dash=%.6f gravity=%.6f terminal=%.6f\n",ok?"PASS":"FAIL",i,f->co_attrs.dash_max_velocity,f->co_attrs.gravity,f->co_attrs.terminal_velocity);
        }
    }
    rule_peak=fmaxf(rule_peak,player->cur_pos.y);if(tick>=325&&player->ground_or_air==GA_Air)rule_air++;
    if(tick==600)fprintf(stderr,"M3D RULE MOTION distance=%.3f rise=%.3f airborne=%d\n",hypotf(player->cur_pos.x-rule_start.x,player->cur_pos.z-rule_start.z),rule_peak-rule_start.y,rule_air);
}
static void rules_probe_pad(HSD_PadStatus* pad,unsigned tick) {
    if((tick>=260&&tick<300)||(tick>=325&&tick<365)){pad->nml_stickX=1;pad->stickX=80;}
    bool jump=tick>=325&&tick<331,last=tick>=326&&tick<332;pad->button=jump?HSD_PAD_X:0;pad->last_button=last?HSD_PAD_X:0;pad->trigger=pad->button&~pad->last_button;pad->release=pad->last_button&~pad->button;
}

static Vec3 ledge_point,ledge_inward,ledge_previous;
static int ledge_caught,ledge_hung,ledge_climbed,ledge_alive,ledge_falls,ledge_jump;static float ledge_jump_peak;static float ledge_step;
static void ledge_probe_pad(HSD_PadStatus* pad,unsigned tick) {
    if(tick<240)return;unsigned phase=(tick-240)/180,offset=(tick-240)%180;if(phase>=18)return;
    if(phase==17){bool held=offset>=80&&offset<86,last=offset>=81&&offset<87;pad->button=held?HSD_PAD_X:0;pad->last_button=last?HSD_PAD_X:0;pad->trigger=pad->button&~pad->last_button;pad->release=pad->last_button&~pad->button;return;}
    if(phase==16&&offset>=80){pad->button=HSD_PAD_L;pad->nml_analogL=1;return;}
    if(offset>=80&&offset<120&&!ledge_climbed){float yaw=m3d_CameraGetYaw();pad->nml_stickX=ledge_inward.x*cosf(yaw)-ledge_inward.z*sinf(yaw);pad->nml_stickY=-ledge_inward.x*sinf(yaw)-ledge_inward.z*cosf(yaw);pad->stickX=pad->nml_stickX*80;pad->stickY=pad->nml_stickY*80;}
}
static void ledge_probe_tick(unsigned tick) {
    const char* probe=getenv("MELEE3D_NATIVE_DELFINO_PROBE");if(!probe||strcmp(probe,"ledges")||tick<240)return;
    bool reference=m3d_ReferenceOverlayActive();
    unsigned phase=(tick-240)/180,offset=(tick-240)%180;if(phase>=(reference?1:18))return;
    HSD_GObj* object=Player_GetEntity(0);Fighter* fp=object->user_data;
    if(!offset) {
        bool found;
        if(reference) {
            /* Native borrowed collision, catch/hang/climb and floor checks;
             * the query begins just outside the actual Onett hospital roof. */
            Vec3 near={-22,88,-525};
            found=m3d_ReferenceLedge(&near,&ledge_point)&&m3d_ReferenceInward(&near,&ledge_inward.x,&ledge_inward.z);
            ledge_inward.y=0;
        } else {
            if(!phase)m3d_DelfinoLedgeTargetsCheck();
            found=m3d_DelfinoLedgeProbe(phase>=16?16:phase,&ledge_point,&ledge_inward);
        }
        if(!found){fprintf(stderr,"M3D LAB FAIL missing ledge %u\n",phase);exit(2);}
        sequence_ground(object,0);
        fp->cur_pos=(Vec3){ledge_point.x-ledge_inward.x*5,ledge_point.y-7,ledge_point.z-ledge_inward.z*5};
        fp->self_vel=(Vec3){0,-.1f,0};fp->x8c_kb_vel=(Vec3){0};fp->gr_vel=fp->xF0_ground_kb_vel=0;fp->facing_dir=1;
        fp->x2064_ledgeCooldown=0;fp->x213C=-1;
        fp->prev_pos=fp->coll_data.cur_pos=fp->coll_data.prev_pos=fp->coll_data.last_pos=fp->cur_pos;
        ftCommon_8007D60C(fp);ftCo_Fall_Enter(object);m3d_SetLane(fp,ledge_inward.x,ledge_inward.z);m3d_CameraSetYaw(0);
        HSD_JObjSetTranslate(object->hsd_obj,&fp->cur_pos);ledge_previous=fp->cur_pos;ledge_caught=ledge_hung=ledge_climbed=ledge_step=0;ledge_alive=1;ledge_jump=0;ledge_jump_peak=ledge_point.y;ledge_falls=Player_GetFalls(0);
        fprintf(stderr,"M3D LEDGE BEGIN ordinal=%u edge=%.3f,%.3f,%.3f inward=%.4f,%.4f\n",phase,ledge_point.x,ledge_point.y,ledge_point.z,ledge_inward.x,ledge_inward.z);
    }
    if(offset&&offset<170) {
        float dx=fp->cur_pos.x-ledge_previous.x,dy=fp->cur_pos.y-ledge_previous.y,dz=fp->cur_pos.z-ledge_previous.z;float step=sqrtf(dx*dx+dy*dy+dz*dz);ledge_step=fmaxf(ledge_step,step);
        if(!isfinite(step)||Player_GetFalls(0)!=ledge_falls)ledge_alive=0;
        if(fp->motion_id==ftCo_MS_CliffCatch&&!ledge_caught) {
            Vec3 anchor;bool began=m3d_LocalBegin(fp);
            if(fp->facing_dir>0)mpLib_80053ECC_Floor(fp->mv.co.cliff.ledge_id,&anchor);else mpLib_80053DA4_Floor(fp->mv.co.cliff.ledge_id,&anchor);
            m3d_MapToWorld(&anchor);m3d_LocalEnd(fp,began);
            float dx=anchor.x-ledge_point.x,dy=anchor.y-ledge_point.y,dz=anchor.z-ledge_point.z;
            float distance=sqrtf(dx*dx+dy*dy+dz*dz);
            if(distance>24||!isfinite(distance))ledge_alive=0;
            fprintf(stderr,"M3D LEDGE CATCH ordinal=%u anchor=%.3f,%.3f,%.3f selection_distance=%.3f\n",phase,anchor.x,anchor.y,anchor.z,distance);
            ledge_point=anchor;ledge_caught=1;
        }
        if(fp->motion_id==ftCo_MS_CliffWait)ledge_hung++;
        if(fp->motion_id>=ftCo_MS_CliffJumpSlow1&&fp->motion_id<=ftCo_MS_CliffJumpQuick2)ledge_jump=1;
        ledge_jump_peak=fmaxf(ledge_jump_peak,fp->cur_pos.y);
        if(fp->motion_id>=ftCo_MS_CliffClimbSlow&&fp->motion_id<=ftCo_MS_CliffClimbQuick)ledge_climbed=1;
        if(offset%20==0||(offset>=103&&offset<=118)||step>=30)fprintf(stderr,"M3D LEDGE TRACE ordinal=%u offset=%u state=%d pos=%.3f,%.3f,%.3f env=%x\n",phase,offset,fp->motion_id,fp->cur_pos.x,fp->cur_pos.y,fp->cur_pos.z,fp->coll_data.env_flags);
    }
    ledge_previous=fp->cur_pos;
    if(offset==170){Vec3 landing=fp->cur_pos,floor;landing.y+=.5f;
        bool ground=fp->ground_or_air==GA_Ground&&(reference?m3d_ReferenceFloor(&landing,&floor):m3d_DelfinoFloor(&landing,&floor))&&fabsf(fp->cur_pos.y-floor.y)<1&&hypotf(fp->cur_pos.x-ledge_point.x,fp->cur_pos.z-ledge_point.z)<35;
        if(phase==17){fprintf(stderr,"M3D LEDGE JUMP caught=%d jumped=%d rise=%.3f alive=%d\n",ledge_caught,ledge_jump,ledge_jump_peak-ledge_point.y,ledge_alive);return;}
        if(phase==16){fprintf(stderr,"M3D LEDGE DROP caught=%d hung=%d dropped=%d died=%d\n",ledge_caught,ledge_hung,fp->motion_id<ftCo_MS_CliffCatch||fp->motion_id>ftCo_MS_CliffJumpQuick2,Player_GetFalls(0)>ledge_falls);return;}
        fprintf(stderr,"M3D LEDGE END ordinal=%u caught=%d hung=%d climbed=%d grounded=%d alive=%d step=%.3f\n",phase,ledge_caught,ledge_hung,ledge_climbed,ground,ledge_alive,ledge_step);}
}

static Vec3 stair_point,stair_normal,stair_start,stair_previous;
static float stair_rise,stair_run,stair_step;static int stair_ground,stair_air,stair_alive;
static void stair_probe_pad(HSD_PadStatus* pad,unsigned tick) {
    if(tick<240)return;unsigned phase=(tick-240)/120,offset=(tick-240)%120;if(phase>=24||offset<20||offset>=85)return;
    float sign=phase%2?1:-1,dx=stair_normal.x*sign*.4f,dz=stair_normal.z*sign*.4f,yaw=m3d_CameraGetYaw();
    pad->nml_stickX=dx*cosf(yaw)-dz*sinf(yaw);pad->nml_stickY=-dx*sinf(yaw)-dz*cosf(yaw);
    pad->stickX=pad->nml_stickX*80;pad->stickY=pad->nml_stickY*80;
}
static void stair_probe_tick(unsigned tick) {
    const char* probe=getenv("MELEE3D_NATIVE_DELFINO_PROBE");if(!probe||(strcmp(probe,"stairs")&&strcmp(probe,"stairs-raw"))||tick<240)return;
    unsigned phase=(tick-240)/120,offset=(tick-240)%120;if(phase>=24)return;
    HSD_GObj* object=Player_GetEntity(0);Fighter* f=object->user_data;
    if(!offset) {
        if(!m3d_DelfinoStepProbe(phase/2,&stair_point,&stair_normal,&stair_rise,&stair_run))abort();
        sequence_ground(object,0);float distance=phase%2?-3:3+stair_run;
        Vec3 p={stair_point.x+stair_normal.x*distance,stair_point.y+10,stair_point.z+stair_normal.z*distance},floor;
        if(!m3d_DelfinoFloor(&p,&floor))abort();p.y=floor.y+2;
        fprintf(stderr,"M3D STAIR BEGIN ordinal=%u point=%.3f,%.3f,%.3f normal=%.4f,%.4f start=%.3f,%.3f,%.3f\n",phase,stair_point.x,stair_point.y,stair_point.z,stair_normal.x,stair_normal.z,p.x,p.y,p.z);
        f->cur_pos=p;f->self_vel=(Vec3){0};f->gr_vel=0;f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=p;
        ftCommon_8007D60C(f);ftCo_Fall_Enter(object);m3d_SetLane(f,-stair_normal.x,-stair_normal.z);m3d_CameraSetYaw(0);
        HSD_JObjSetTranslate(object->hsd_obj,&p);stair_ground=stair_air=0;stair_alive=1;stair_step=0;
    }
    if(offset==20)stair_start=stair_previous=f->cur_pos;
    if(offset>20&&offset<100) {
        if(f->motion_id<14)stair_alive=0;
        if(f->ground_or_air==GA_Ground)stair_ground++;else stair_air++;
        stair_step=fmaxf(stair_step,fabsf(f->cur_pos.y-stair_previous.y));stair_previous=f->cur_pos;
    }
    if(offset==100) {
        fprintf(stderr,"M3D STAIR STATE ordinal=%u state=%d flags=%x floor=%d speed=%.4f\n",phase,f->motion_id,f->coll_data.env_flags,f->coll_data.floor.index,f->gr_vel);
        float sign=phase%2?1:-1,travel=((f->cur_pos.x-stair_start.x)*stair_normal.x+(f->cur_pos.z-stair_start.z)*stair_normal.z)*sign;
        float cross=((f->cur_pos.x-stair_point.x)*stair_normal.x+(f->cur_pos.z-stair_point.z)*stair_normal.z)*sign-(phase%2?stair_run:0);
        fprintf(stderr,"M3D STAIR END ordinal=%u down=%u travel=%.3f rise=%.3f grounded=%d air=%d alive=%d step=%.3f cross=%.3f\n",phase,phase%2,travel,f->cur_pos.y-stair_start.y,stair_ground,stair_air,stair_alive,stair_step,cross);
    }
}

/* Offshore native landing/jump checks. These are starts on donor surfaces,
 * not navigation teleports: every fall, jump and landing is native physics. */
static const Vec3 island_points[]={
 {1128,34.04f,-832},{1240,48.43f,-816},{1240,48.43f,-952},
 {1376,67.94f,-1024},{1424,48.43f,-768},{1472,48.43f,-976},
 {1488,88.13f,-1152},{1520,92.72f,-848}};
static int island_ground,island_air,island_alive;static float island_peak,island_floor;
static void island_probe_pad(HSD_PadStatus* pad,unsigned tick){
    if(tick<240)return;unsigned phase=(tick-240)/180,offset=(tick-240)%180;if(phase>=8)return;
    bool held=offset>=45&&offset<51,last=offset>=46&&offset<52;
    pad->button=held?HSD_PAD_X:0;pad->last_button=last?HSD_PAD_X:0;pad->trigger=pad->button&~pad->last_button;pad->release=pad->last_button&~pad->button;
}
static void island_probe_tick(unsigned tick){
    const char* probe=getenv("MELEE3D_NATIVE_DELFINO_PROBE");if(!probe||strcmp(probe,"islands")||tick<240)return;
    unsigned phase=(tick-240)/180,offset=(tick-240)%180;if(phase>=8)return;
    HSD_GObj* object=Player_GetEntity(0);Fighter* f=object->user_data;
    if(!offset){
        Vec3 p=island_points[phase],floor;p.y+=20;
        if(!m3d_DelfinoFloor(&p,&floor)||fabsf(floor.y-island_points[phase].y)>10){fprintf(stderr,"M3D ISLAND FAIL missing floor ordinal=%u\n",phase);abort();}
        island_floor=floor.y;p=floor;p.y+=15;sequence_ground(object,0);
        f->cur_pos=p;f->self_vel=(Vec3){0};f->x8c_kb_vel=(Vec3){0};f->gr_vel=f->xF0_ground_kb_vel=0;
        f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=p;
        ftCommon_8007D60C(f);ftCo_Fall_Enter(object);m3d_SetLane(f,cosf(phase*.785398163f),sinf(phase*.785398163f));m3d_CameraSetYaw(phase*.785398163f);
        HSD_JObjSetTranslate(object->hsd_obj,&p);island_ground=island_air=0;island_alive=1;island_peak=floor.y;
    }
    if(offset>40&&offset<160){if(f->motion_id<14)island_alive=0;if(f->ground_or_air==GA_Ground)island_ground++;else island_air++;island_peak=fmaxf(island_peak,f->cur_pos.y);}
    if(offset==160){float error=fabsf(f->cur_pos.y-island_floor);
        fprintf(stderr,"M3D ISLAND END ordinal=%u ground=%d air=%d alive=%d rise=%.3f error=%.3f pos=%.3f,%.3f,%.3f\n",phase,island_ground,island_air,island_alive,island_peak-island_floor,error,f->cur_pos.x,f->cur_pos.y,f->cur_pos.z);
    }
}
static int snap_air;static float snap_peak,snap_base;static Vec3 snap_start;
static void snap_probe_pad(HSD_PadStatus* pad,unsigned tick) {
    if(tick<240)return;unsigned phase=(tick-240)/120,offset=(tick-240)%120;if(phase>=6)return;
    if(offset>=20&&offset<90) {
        pad->nml_subStickX=phase==1?-1:phase==3?(offset<50?-1:1):phase==4?0:1;
        if(phase==4)pad->nml_subStickY=1;
        if(phase==5&&offset>=35&&offset<45)pad->nml_subStickX=0;
    }
    if(phase==2&&offset>=20&&offset<90)pad->nml_stickX=.4f;
    bool held=phase==2&&offset>=30&&offset<36,last=phase==2&&offset>=31&&offset<37;
    pad->button=held?HSD_PAD_X:0;pad->last_button=last?HSD_PAD_X:0;pad->trigger=pad->button&~pad->last_button;pad->release=pad->last_button&~pad->button;
    pad->subStickX=pad->nml_subStickX*80;pad->subStickY=pad->nml_subStickY*80;pad->stickX=pad->nml_stickX*80;
}
static void snap_probe_tick(unsigned tick) {
    const char* probe=getenv("MELEE3D_NATIVE_DELFINO_PROBE");if(!probe||strcmp(probe,"camera-turn")||tick<240)return;
    unsigned phase=(tick-240)/120,offset=(tick-240)%120;if(phase>=6)return;
    Fighter* f=Player_GetEntity(0)->user_data;
    if(!offset){m3d_CameraSetMode(0);m3d_CameraSetYaw(0);snap_air=0;snap_peak=snap_base=f->cur_pos.y;snap_start=f->cur_pos;}
    if(f->ground_or_air==GA_Air)snap_air++;snap_peak=fmaxf(snap_peak,f->cur_pos.y);
    if(offset==100){float degrees=m3d_CameraGetYaw()*180/3.14159265f;
        fprintf(stderr,"M3D SNAP END ordinal=%u degrees=%.3f air=%d rise=%.3f travel=%.3f\n",phase,degrees,snap_air,snap_peak-snap_base,hypotf(f->cur_pos.x-snap_start.x,f->cur_pos.z-snap_start.z));}
}
static void ceiling_probe_tick(unsigned tick) {
    const char* probe=getenv("MELEE3D_NATIVE_DELFINO_PROBE");
    if(!probe||strcmp(probe,"ceilings")||tick<240)return;
    unsigned phase=(tick-240)/60,offset=(tick-240)%60;if(phase>=6||offset)return;
    HSD_GObj* object=Player_GetEntity(0);Fighter* f=object->user_data;Vec3 floor;
    if(m3d_ReferenceOverlayActive()) {
        Vec3 query=phase/3 ? (Vec3){75,120,-530} : (Vec3){0,50,90};
        if(!m3d_ReferenceFloor(&query,&floor))abort();
    } else if(!m3d_DelfinoCeilingProbe(phase/3,&floor))abort();
    sequence_ground(object,0);ftCommon_8007D60C(f);ftCo_Fall_Enter(object);
    f->cur_pos=floor;f->cur_pos.y+=M3D_DELFINO_KO_CLEARANCE+(phase%3==0?-1:2);
    f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=f->cur_pos;
    f->self_vel=(Vec3){0};f->x8c_kb_vel=(Vec3){0};f->x2222_b3=0;
    f->x222A_b1=f->x2228_b5=f->x2219_b2=f->x2219_b1=0;
    if(phase%3!=1)f->x8c_kb_vel.y=10;
    HSD_JObjSetTranslate(object->hsd_obj,&f->cur_pos);
    float top=m3d_ImportedBlastTop(f);
    bool died=ftCo_800D3158(object),expected=phase%3==2;
    bool ok=died==expected&&fabsf(top-floor.y-M3D_DELFINO_KO_CLEARANCE)<.01f;
    fprintf(stderr,"M3D CEILING %s ordinal=%u roof=%u launch=%d died=%d expected=%d ground=%.3f top=%.3f state=%d\n",ok?"PASS":"FAIL",phase,phase/3,phase%3!=1,died,expected,floor.y,top,f->motion_id);
    if(!ok)abort();
}
static Vec3 wall_start,wall_normal,wall_face;
static float wall_top,wall_min,wall_peak;static int wall_contact,wall_air,wall_occluded,wall_views;
static int walljump_seen,walljump_contact;
static void walljump_probe_pad(HSD_PadStatus* pad,unsigned tick) {
    if(tick<240)return;unsigned phase=(tick-240)/120,offset=(tick-240)%120;if(phase>=16)return;
    float yaw=m3d_CameraGetYaw(),sign=offset<13?-1:offset<35?1:0;
    float dx=wall_normal.x*sign,dz=wall_normal.z*sign;
    pad->nml_stickX=dx*cosf(yaw)-dz*sinf(yaw);pad->nml_stickY=-dx*sinf(yaw)-dz*cosf(yaw);
    pad->stickX=pad->nml_stickX*80;pad->stickY=pad->nml_stickY*80;
}
static void walljump_probe_tick(unsigned tick) {
    const char* probe=getenv("MELEE3D_NATIVE_DELFINO_PROBE");if(!probe||strcmp(probe,"walljump")||tick<240)return;
    unsigned phase=(tick-240)/120,offset=(tick-240)%120;if(phase>=16)return;
    HSD_GObj* object=Player_GetEntity(0);Fighter* f=object->user_data;
    if(!offset){
        if(!m3d_DelfinoWallProbe(phase,&wall_start,&wall_normal,&wall_face,&wall_top))abort();
        sequence_ground(object,0);ftCommon_8007D60C(f);ftCo_Fall_Enter(object);
        Vec3 p=wall_start;p.y+=25;
        f->cur_pos=f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=p;
        f->self_vel=(Vec3){3,0,0};f->gr_vel=0;f->x8c_kb_vel=(Vec3){0};
        m3d_SetLane(f,-wall_normal.x,-wall_normal.z);m3d_CameraSetYaw(phase*.392699082f);
        HSD_JObjSetTranslate(object->hsd_obj,&p);walljump_seen=walljump_contact=0;
    }
    if(f->coll_data.env_flags&(Collide_RightWallHug|Collide_LeftWallHug))walljump_contact++;
    if(f->motion_id==ftCo_MS_PassiveWallJump)walljump_seen++;
    if(offset==65)fprintf(stderr,"M3D WALLJUMP END ordinal=%u capable=%d contacts=%d jumped=%d state=%d\n",phase,f->can_walljump,walljump_contact,walljump_seen,f->motion_id);
}
static void delfino_probe_pad(HSD_PadStatus* pad,unsigned tick) {
    if(tick<240)return;unsigned offset=(tick-240)%180,phase=(tick-240)/180;
    if(phase>=16)return;
    if(offset>=20&&offset<150&&!(offset>=30&&offset<65)){float yaw=m3d_CameraGetYaw(),dx=-wall_normal.x,dz=-wall_normal.z;
        pad->nml_stickX=dx*cosf(yaw)-dz*sinf(yaw);pad->nml_stickY=-dx*sinf(yaw)-dz*cosf(yaw);}
    /* Let the native uncancellable wall-bonk animation end before testing
     * jump. Sonic stays in StopWall longer than Fox at this input magnitude. */
    bool jump=offset>=60&&offset<66,previous=offset>=61&&offset<67;
    pad->button=jump?HSD_PAD_X:0;pad->last_button=previous?HSD_PAD_X:0;
    pad->trigger=pad->button&~pad->last_button;pad->release=pad->last_button&~pad->button;
    pad->stickX=(s8)(pad->nml_stickX*80);pad->stickY=(s8)(pad->nml_stickY*80);
}
static void delfino_probe_tick(unsigned tick) {
    const char* probe=getenv("MELEE3D_NATIVE_DELFINO_PROBE");if(!probe||strcmp(probe,"walls")||tick<240)return;
    unsigned phase=(tick-240)/180,offset=(tick-240)%180;if(phase>=16)return;
    HSD_GObj* object=Player_GetEntity(0);Fighter* fp=object->user_data;
    if(!offset){
        if(!m3d_DelfinoWallProbe(phase,&wall_start,&wall_normal,&wall_face,&wall_top)){fprintf(stderr,"M3D LAB FAIL missing wall probe %u\n",phase);abort();}
        sequence_ground(object,0);fp->cur_pos=wall_start;fp->self_vel=(Vec3){0};fp->gr_vel=0;
        fp->prev_pos=fp->coll_data.cur_pos=fp->coll_data.prev_pos=fp->coll_data.last_pos=fp->cur_pos;
        ftCommon_8007D60C(fp);ftCo_Fall_Enter(object);m3d_SetLane(fp,-wall_normal.x,-wall_normal.z);m3d_CameraSetYaw(0);
        HSD_JObjSetTranslate(object->hsd_obj,&fp->cur_pos);wall_min=1e20f;wall_peak=wall_start.y;wall_contact=wall_air=wall_occluded=wall_views=0;
        fprintf(stderr,"M3D WALL BEGIN ordinal=%u start=%.3f,%.3f,%.3f normal=%.4f,%.4f,%.4f face=%.3f,%.3f,%.3f top=%.3f\n",phase,wall_start.x,wall_start.y,wall_start.z,wall_normal.x,wall_normal.y,wall_normal.z,wall_face.x,wall_face.y,wall_face.z,wall_top);
    }
    if(offset>=42&&offset<=60)fprintf(stderr,"M3D WALL JUMP phase=%u offset=%u state=%d air=%d pos=%.3f,%.3f,%.3f vy=%.4f held=%x pressed=%x env=%x\n",phase,offset,fp->motion_id,fp->ground_or_air,fp->cur_pos.x,fp->cur_pos.y,fp->cur_pos.z,fp->self_vel.y,fp->input.held_buttons[0],fp->input.pressed_buttons,fp->coll_data.env_flags);
    if(offset>20&&offset<150){
        float distance=(fp->cur_pos.x-wall_face.x)*wall_normal.x+(fp->cur_pos.z-wall_face.z)*wall_normal.z;
        if(fp->cur_pos.y<wall_top-8)wall_min=fminf(wall_min,distance);
        if(fp->coll_data.env_flags&Collide_WallMask)wall_contact++;
        if(fp->ground_or_air==GA_Air)wall_air++;wall_peak=fmaxf(wall_peak,fp->cur_pos.y);
    }
    if(offset==150){HSD_CObj* c=Camera_80030A50()->hsd_obj;Vec3 eye,focus;HSD_CObjGetEyePosition(c,&eye);HSD_CObjGetInterest(c,&focus);
        float distance=sqrtf((eye.x-focus.x)*(eye.x-focus.x)+(eye.y-focus.y)*(eye.y-focus.y)+(eye.z-focus.z)*(eye.z-focus.z));
        fprintf(stderr,"M3D WALL END ordinal=%u penetration=%.3f contact=%d airborne=%d rise=%.3f fall=%.3f camera=%.3f occluded=%d views=%d\n",phase,fmaxf(0,-wall_min),wall_contact,wall_air,wall_peak-wall_start.y,fp->cur_pos.y-wall_start.y,distance,wall_occluded,wall_views);}

}

/* Observe the camera that will actually render this pose. The logic callback
 * runs before the camera/render callback and can still see the preceding eye. */
void m3d_lab_camera_render(void) {
    const char* probe=getenv("MELEE3D_NATIVE_DELFINO_PROBE");if(!probe||strcmp(probe,"walls")||fixture_ticks<240)return;
    unsigned phase=(fixture_ticks-240)/180,offset=(fixture_ticks-240)%180;if(phase>=16||offset<=30||offset>=150)return;
    Fighter* fp=Player_GetEntity(0)->user_data;HSD_CObj* c=Camera_80030A50()->hsd_obj;Vec3 eye,point=fp->cur_pos;HSD_CObjGetEyePosition(c,&eye);
    /* Independent interior samples of the current native ceiling body. A
     * fixed 9*scale marker can be outside it during Sonic's jump animation. */
    float height=fp->coll_data.ecb.top.y;if(!isfinite(height)||height<=1)height=9*fp->x34_scale.y;
    point.y+=height/3;bool clear=m3d_DelfinoCameraReveals(&eye,&point);point.y=fp->cur_pos.y+height*2/3;
    wall_views++;if(!clear||!m3d_DelfinoCameraReveals(&eye,&point)){wall_occluded++;fprintf(stderr,"M3D WALL OCCLUDED phase=%u offset=%u state=%d eye=%.3f,%.3f,%.3f actor=%.3f,%.3f,%.3f\n",phase,offset,fp->motion_id,eye.x,eye.y,eye.z,fp->cur_pos.x,fp->cur_pos.y,fp->cur_pos.z);}
}

static int water_ground,water_alive,water_falls,water_wet,water_recovered,water_jump_tick;
static float water_surface,water_peak;
static Vec3 water_floor;
static void water_probe_pad(HSD_PadStatus* pad,unsigned tick) {
    if(tick<240)return;unsigned phase=(tick-240)/120;
    if((phase==9||phase==10)&&water_jump_tick>0) {
        bool held=tick>=(unsigned)water_jump_tick&&tick<(unsigned)water_jump_tick+4;
        bool last=tick>(unsigned)water_jump_tick&&tick<=(unsigned)water_jump_tick+4;
        pad->button=held?HSD_PAD_X:0;pad->last_button=last?HSD_PAD_X:0;
        pad->trigger=pad->button&~pad->last_button;pad->release=pad->last_button&~pad->button;
    }
}
static void water_probe_tick(unsigned tick) {
    const char* probe=getenv("MELEE3D_NATIVE_DELFINO_PROBE");if(!probe||strcmp(probe,"water")||tick<240)return;
    unsigned phase=(tick-240)/120,offset=(tick-240)%120;if(phase>=11)return;
    HSD_GObj* object=Player_GetEntity(0);Fighter* f=object->user_data;
    if(!offset) {
        Vec3 p;if(!m3d_DelfinoWaterProbe(phase,&p,&water_floor)){fprintf(stderr,"M3D LAB FAIL water target %u\n",phase);abort();}
        water_surface=p.y;
        fprintf(stderr,"M3D WATER START ordinal=%u surface=%.3f,%.3f,%.3f bed=%.3f\n",phase,p.x,p.y,p.z,water_floor.y);
        p.y+=12;
        sequence_ground(object,0);f->cur_pos=p;f->self_vel=(Vec3){0};f->x8c_kb_vel=(Vec3){0};f->gr_vel=f->xF0_ground_kb_vel=0;
        f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=p;
        ftCommon_8007D60C(f);ftCo_Fall_Enter(object);HSD_JObjSetTranslate(object->hsd_obj,&p);
        f->x1968_jumpsUsed=phase==9?1:f->co_attrs.max_jumps;
        water_ground=water_wet=water_recovered=water_jump_tick=0;water_alive=1;water_falls=Player_GetFalls(0);water_peak=-1e20f;
    }
    if(phase>=8&&f->motion_id>=14&&f->cur_pos.y<water_surface&&Player_GetFalls(0)==water_falls) {
        water_wet++;
        if(!water_jump_tick)water_jump_tick=tick+3;
    }
    if(water_wet&&f->motion_id>=14&&Player_GetFalls(0)==water_falls) {
        water_peak=fmaxf(water_peak,f->cur_pos.y-water_surface);
        if(f->cur_pos.y>water_surface+3&&f->x1968_jumpsUsed>1)water_recovered=1;
    }
    if(offset>30&&offset<100){if(f->motion_id<14)water_alive=0;if(f->ground_or_air==GA_Ground)water_ground++;}
    if(offset==100) {
        fprintf(stderr,"M3D WATER END ordinal=%u ground=%d alive=%d falls=%d error=%.3f\n",phase,water_ground,water_alive,Player_GetFalls(0)-water_falls,phase<8?fabsf(f->cur_pos.y-water_floor.y):0);
        if(phase>=8)fprintf(stderr,"M3D WATER RECOVERY ordinal=%u wet=%d recovered=%d peak=%.3f jumps=%d maximum=%d\n",phase,water_wet,water_recovered,water_peak,f->x1968_jumpsUsed,f->co_attrs.max_jumps);
    }
}
static void spectator_probe_tick(unsigned tick) {
    if(!getenv("MELEE3D_NATIVE_SPECTATOR_CHECK"))return;
    if(!strcmp(getenv("MELEE3D_NATIVE_SPECTATOR_CHECK"),"cycle")) {
        if(tick==180||tick==240||tick==600) {
            for(int i=0;i<GM_MAX_PLAYERS;i++) {
                HSD_GObj* g=Player_GetEntity(i);if(!g||Player_GetStocks(i)<=0)continue;
                if((tick==180&&i!=0&&i!=1&&i!=3&&i!=31)||(tick==240&&i==0)||(tick==600&&i==31))ftCo_800D3BC8(g);
            }
        }
        static const unsigned checks[][2]={{125,0},{330,1},{350,3},{390,3},{430,31},{450,1},{470,31},{490,3},{510,1},{530,31},{630,1},{670,3}};
        for(unsigned i=0;i<sizeof checks/sizeof *checks;i++)if(tick==checks[i][0]) {
            Fighter* f=m3d_CameraSubject();int slot=f?f->player_idx:-1;
            bool pass=slot==(int)checks[i][1]&&m3d_CameraGetMode()==2;
            fprintf(stderr,"M3D SPECTATOR CYCLE %s tick=%u slot=%d expected=%u mode=%d\n",pass?"PASS":"FAIL",tick,slot,checks[i][1],m3d_CameraGetMode());
            if(!pass)abort();
        }
        return;
    }
    if(tick==240||tick==480) {
        for(int i=0;i<GM_MAX_PLAYERS;i++) {
            HSD_GObj* g=Player_GetEntity(i);if(!g||Player_GetStocks(i)<=0)continue;
            Fighter* f=g->user_data;
            if((tick==240&&i==0)||(tick==480&&f->kind!=Ft_Kind_Peach))ftCo_800D3BC8(g);
        }
    }
    if(tick>=700&&tick<1000) {
        Fighter* f=m3d_CameraSubject();
        fprintf(stderr,"M3D SPECTATOR CHECK tick=%u slot=%d kind=%d mode=%d yaw=%.6f\n",tick,f?f->player_idx:-1,f?f->kind:-1,m3d_CameraGetMode(),m3d_CameraGetYaw());
    }
}
/* Native tether/cloth regressions use two stationary fighters, never the
 * user's ordinary control path. Every case resets at a translated XZ point. */
static void tether_polish_tick(unsigned tick) {
    if(!getenv("MELEE3D_NATIVE_TETHER_CHECK")||tick<240)return;
    unsigned phase=(tick-240)/140,offset=(tick-240)%140;if(phase>=16)return;
    HSD_GObj* g=Player_GetEntity(0);Fighter* fp=g->user_data;
    bool air=phase>=8;float angle=(phase%8)*.7853981634f;
    if(!offset){
        if(fp->kind==Ft_Kind_Samus){if(fp->u.ss.x223C)it_802BAC3C(g);}
        else if(fp->u.lk.xC)it_802A7AAC(g);
        ftCo_800DC920(g,Player_GetEntity(1));sequence_ground(g,0);
        Vec3 base={12,0,24};if(m3d_DelfinoActive()){m3d_DelfinoNavObjective(0,&base);base.y+=2;}
        fp->cur_pos=base;fp->cur_pos.y+=air?45:0;fp->prev_pos=fp->coll_data.cur_pos=fp->coll_data.prev_pos=fp->coll_data.last_pos=fp->cur_pos;
        fp->self_vel=fp->x8c_kb_vel=(Vec3){0};fp->gr_vel=0;fp->facing_dir=1;m3d_SetLane(fp,cosf(angle),sinf(angle));
        ftCommon_8007D5D4(fp);ftCo_Fall_Enter(g);m3d_PostMap(fp);HSD_JObjSetTranslate(g->hsd_obj,&fp->cur_pos);
        fprintf(stderr,"M3D TETHER BEGIN case=%u air=%d angle=%.1f\n",phase,air,angle*57.2957795f);
    }
    if(air){fp->self_vel.y=0;fp->co_attrs.gravity=0;}
    if(offset==15){if(air)ftCo_800C3BE8(g);else ftCo_800D8C54(g,ftCo_MS_Catch);}
    if(offset==110)fprintf(stderr,"M3D TETHER END case=%u state=%d finite=%d\n",phase,fp->motion_id,isfinite(fp->cur_pos.x)&&isfinite(fp->cur_pos.y)&&isfinite(fp->cur_pos.z));
}
static void cloth_polish_tick(unsigned tick) {
    if(!getenv("MELEE3D_NATIVE_CLOTH_CHECK")||tick<240)return;
    HSD_GObj* g=Player_GetEntity(0);Fighter* fp=g->user_data;unsigned phase=(tick-240)/90,offset=(tick-240)%90;if(phase>=16)return;
    if(!offset){sequence_ground(g,0);
        /* Compare the same pose. Random native Wait variants can begin after
         * one loop (Zelda's hair/skirt have different extents in those poses). */
        ftAnim_8006EBE8(g,0,0,0);
        fp->cur_pos.z=24;HSD_JObjSetTranslate(g->hsd_obj,&fp->cur_pos);
        for(int i=0;i<fp->dynamics_num;i++)for(struct DynamicsData* d=DP(struct DynamicsData,fp->dynamic_bone_sets[i].dyn_desc.data);d;d=d->next)HSD_JObjSetRotation(d->desc.lb_unk0.jobj,&d->desc.lb_unk0.unk_58);
        m3d_DynamicsReset(fp);
    }
    /* Alternate internal lane/facing signs without changing world heading. */
    float a=(phase%8)*.7853981634f;fp->facing_dir=phase>=8&&offset%2?-1:1;
    ftPartSetRotY(fp,0,1.5707963268f*fp->facing_dir);
    m3d_SetLane(fp,cosf(a)*fp->facing_dir,sinf(a)*fp->facing_dir);m3d_PostMap(fp);
    if(offset==70){int nodes=0;float maximum=0,angular=0;bool finite=true;
        for(int i=0;i<fp->dynamics_num;i++)for(struct DynamicsData* d=DP(struct DynamicsData,fp->dynamic_bone_sets[i].dyn_desc.data);d;d=d->next){
            Vec3 p=d->desc.lb_unk0.unk_2C;float distance=sqrtf((p.x-fp->cur_pos.x)*(p.x-fp->cur_pos.x)+(p.y-fp->cur_pos.y)*(p.y-fp->cur_pos.y)+(p.z-fp->cur_pos.z)*(p.z-fp->cur_pos.z));
            finite=finite&&isfinite(distance)&&isfinite(d->desc.lb_unk0.unk_44);maximum=fmaxf(maximum,distance);angular=fmaxf(angular,fabsf(d->desc.lb_unk0.unk_44));nodes++;
        }
        fprintf(stderr,"M3D CLOTH END case=%u nodes=%d finite=%d reach=%.3f angular=%.4f\n",phase,nodes,finite,maximum,angular);
    }
}
/* Opt-in real collision/capture/release regression. No synthetic victim links. */
static void capture_probe_tick(unsigned tick) {
    const char* profile=getenv("MELEE3D_NATIVE_CAPTURE_CHECK");if(!profile||tick<240)return;
    unsigned phase=(tick-240)/300,offset=(tick-240)%300;bool diddy=!strcmp(profile,"diddy"),command=strcmp(profile,"grab")!=0;
    unsigned cases=command?6:5;if(phase>=cases)return;
    HSD_GObj* object=Player_GetEntity(0);HSD_GObj* other=Player_GetEntity(1);
    Fighter* f=object->user_data;Fighter* v=other->user_data;
    static Vec3 prior[2],base;static int held_ticks,released,alive,falls;static float step,pair_distance;
    float angle=getenv("MELEE3D_NATIVE_ANGLE")?atof(getenv("MELEE3D_NATIVE_ANGLE"))*.01745329252f:0;
    float lx=cosf(angle),lz=sinf(angle);bool air=command&&phase>=3;
    if(!offset) {
        if(f->victim_gobj||v->victim_gobj)ftCo_800DC920(object,other);
        sequence_ground(object,0);sequence_ground(other,10);
        base=(Vec3){12,0,24};
        if(m3d_DelfinoActive()){m3d_DelfinoNavObjective(0,&base);base.y+=2;}
        for(int i=0;i<2;i++) {
            HSD_GObj* g=i?other:object;Fighter* p=g->user_data;
            Vec3 pos=base;float spacing=diddy?18:air?22:10;pos.x+=i*spacing*lx;pos.z+=i*spacing*lz;
            p->cur_pos=p->prev_pos=p->coll_data.cur_pos=p->coll_data.prev_pos=p->coll_data.last_pos=pos;
            p->self_vel=p->x8c_kb_vel=(Vec3){0};p->gr_vel=p->xF0_ground_kb_vel=0;p->facing_dir=i?-1:1;
            ftLib_SetPercent(g,0);m3d_SetLane(p,i?-lz:lx,i?lx:lz);
            /* Let each fighter acquire its actual floor in this world slice;
             * the reset's old floor index belongs to a different position. */
            ftCommon_8007D5D4(p);ftCo_Fall_Enter(g);
            m3d_PostMap(p);HSD_JObjSetTranslate(g->hsd_obj,&pos);prior[i]=pos;
        }
        held_ticks=released=0;alive=1;step=pair_distance=0;falls=Player_GetFalls(1);
        fprintf(stderr,"M3D CAPTURE BEGIN case=%u profile=%s kind=%d victim=%d angle=%.1f base=%.3f,%.3f,%.3f\n",phase,profile,f->kind,v->kind,angle/.01745329252f,base.x,base.y,base.z);
    }
    if(offset==20) {
        if(air)for(int i=0;i<2;i++) {
            HSD_GObj* g=i?other:object;Fighter* p=g->user_data;p->cur_pos.y+=45;
            p->prev_pos=p->coll_data.cur_pos=p->coll_data.prev_pos=p->coll_data.last_pos=p->cur_pos;
            ftCommon_8007D5D4(p);ftCo_Fall_Enter(g);p->self_vel.y=i?1.0f:1.5f;HSD_JObjSetTranslate(g->hsd_obj,&p->cur_pos);
            prior[i]=p->cur_pos;
        }
        if(command)(air?ftData_SpecialAirS[f->kind]:ftData_SpecialS[f->kind])(object);
        else ftCo_800D8C54(object,ftCo_MS_Catch);
    }
    bool held=f->victim_gobj==other||f->x1A5C==other||v->victim_gobj==object||v->x1A5C==object;
    if(held)held_ticks++;
    if(!command&&offset==70&&held)fn_800DA4FC(object);
    if(offset==100&&held) {
        unsigned move=command?phase%3:phase;
        if(diddy) {
            if(move==2) {
                uint32_t args[4]={m3d_akaneia_object_export(object,1),m3d_akaneia_object_export(other,1),2,2};
                m3d_akaneia_call(object,m3d_vm_symbol(1,"SpecialS_BreakDetach"),args,4);
            } else {
                f->input.pressed_buttons=move?HSD_PAD_X:HSD_PAD_A;
                f->input.held_buttons[0]=f->input.pressed_buttons;
                if(f->input_cb)f->input_cb(object);
            }
        } else if(move==(command?2:4))ftCo_800DA698(object,true);
        else if(command){f->input.lstick[1].x=0;f->input.lstick[0].x=move? -f->facing_dir:f->facing_dir;
            if(f->ground_or_air==GA_Air)ftKp_SpecialAirSHit_IASA(object);else ftKp_SpecialSHit_IASA(object);
        }else ftCo_800DD4B0(object,ftCo_MS_ThrowF+move);
        fprintf(stderr,"M3D CAPTURE ACTION case=%u move=%u state=%d victim=%d\n",phase,move,f->motion_id,v->motion_id);
    }
    if(offset==140&&!command&&phase==0&&f->kind==Ft_Kind_Donkey&&held) {
        f->input.pressed_buttons=HSD_PAD_A;f->input.lstick[0].x=f->facing_dir;
        bool thrown=ftCo_8009BF3C(object);
        fprintf(stderr,"M3D CAPTURE CARGO throw=%d state=%d victim=%d\n",thrown,f->motion_id,v->motion_id);
    }
    if(offset>100&&held_ticks&&!held)released=1;
    if(offset>20&&offset<=180) {
        for(int i=0;i<2;i++) {
            Fighter* p=i?v:f;Vec3 a=p->cur_pos,b=prior[i];float d=sqrtf((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y)+(a.z-b.z)*(a.z-b.z));step=fmaxf(step,d);
            if(!isfinite(d)||p->motion_id<14)alive=0;
        }
        if(held)pair_distance=fmaxf(pair_distance,hypotf(f->cur_pos.x-v->cur_pos.x,f->cur_pos.z-v->cur_pos.z));
    }
    prior[0]=f->cur_pos;prior[1]=v->cur_pos;
    if(offset<260&&(held||offset%10==0))fprintf(stderr,"M3D CAPTURE TRACE case=%u offset=%u held=%d state=%d,%d pos=%.3f,%.3f,%.3f victim=%.3f,%.3f,%.3f step=%.3f\n",phase,offset,held,f->motion_id,v->motion_id,f->cur_pos.x,f->cur_pos.y,f->cur_pos.z,v->cur_pos.x,v->cur_pos.y,v->cur_pos.z,step);
    if(offset>=100&&offset<260&&getenv("MELEE3D_NATIVE_CAPTURE_DETAIL"))fprintf(stderr,"M3D CAPTURE DETAIL case=%u offset=%u frame=%.2f rate=%.2f ground=%d vel=%.3f,%.3f,%.3f root=%.3f,%.3f,%.3f latch=%d landed=%d cmd=%d\n",phase,offset,f->cur_anim_frame,f->frame_speed_mul,f->ground_or_air,f->self_vel.x,f->self_vel.y,f->self_vel.z,f->x6A4_transNOffset.x,f->x6A4_transNOffset.y,f->x6A4_transNOffset.z,f->mv.co.fighterthrow.x4,f->mv.co.fighterthrow.x8,f->cmd_vars[0]);
    if(offset==240)fprintf(stderr,"M3D CAPTURE END case=%u held=%d released=%d alive=%d falls=%d step=%.3f pair=%.3f damage=%.3f\n",phase,held_ticks,released,alive,Player_GetFalls(1)-falls,step,pair_distance,v->dmg.x1830_percent);
}

/* Opt-in observation only: catch discontinuities during real CPU matches. */
static void live_capture_audit(unsigned tick) {
    if(!getenv("MELEE3D_NATIVE_CAPTURE_AUDIT"))return;
    static struct {Fighter* fp;Vec3 pos;int motion,held,trail;} history[GM_MAX_PLAYERS];
    static unsigned frames,releases,anomalies,bowser;static float peak;
    for(int i=0;i<GM_MAX_PLAYERS;i++) {
        HSD_GObj* g=Player_GetEntity(i);if(!g)continue;Fighter* f=g->user_data;
        int held=f->victim_gobj!=NULL||f->x1A5C!=NULL;
        if(history[i].fp==f&&history[i].motion>=14&&f->motion_id>=14&&(held||history[i].held||history[i].trail)) {
            Vec3 a=f->cur_pos,b=history[i].pos;float d=sqrtf((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y)+(a.z-b.z)*(a.z-b.z));peak=fmaxf(peak,d);
            if(!isfinite(d)||d>=80){anomalies++;fprintf(stderr,"M3D CAPTURE ANOMALY tick=%u slot=%d kind=%d motion=%d,%d step=%.3f from=%.3f,%.3f,%.3f to=%.3f,%.3f,%.3f\n",tick,i,f->kind,history[i].motion,f->motion_id,d,b.x,b.y,b.z,a.x,a.y,a.z);}
        }
        if(held){frames++;if(f->kind==Ft_Kind_Koopa)bowser++;}
        if(history[i].fp==f&&history[i].held&&!held)releases++;
        history[i].trail=held?8:history[i].trail?history[i].trail-1:0;
        history[i].fp=f;history[i].pos=f->cur_pos;history[i].held=held;history[i].motion=f->motion_id;
    }
    if(tick%600==0)fprintf(stderr,"M3D CAPTURE AUDIT tick=%u frames=%u releases=%u peak=%.3f anomalies=%u bowser=%u\n",tick,frames,releases,peak,anomalies,bowser);
}


static void combat_probe_pad(HSD_PadStatus* pad,unsigned tick) {
    if(tick<240)return;unsigned phase=(tick-240)/120,offset=(tick-240)%120;if(phase>=6)return;
    const float angles[6]={0,45,90,180,0,0};float a=angles[phase]*M3D_COMBAT_RAD;
    if(phase==4&&offset>=14)a+=90*M3D_COMBAT_RAD;
    if(offset>=10&&offset<65) {
        float mag=phase==1?1:.5f,yaw=m3d_CameraGetYaw(),x=cosf(a)*mag,z=sinf(a)*mag;
        pad->nml_stickX=x*cosf(yaw)-z*sinf(yaw);pad->nml_stickY=-x*sinf(yaw)-z*cosf(yaw);
    }
    pad->button=offset>=10&&offset<12?(phase==3?HSD_PAD_Z:HSD_PAD_A):0;
    pad->last_button=offset>=11&&offset<13?(phase==3?HSD_PAD_Z:HSD_PAD_A):0;
    pad->trigger=pad->button&~pad->last_button;pad->release=pad->last_button&~pad->button;
    pad->stickX=pad->nml_stickX*80;pad->stickY=pad->nml_stickY*80;
}
static void combat_probe_tick(unsigned tick) {
    if(!getenv("MELEE3D_NATIVE_COMBAT_PROBE")||tick<240)return;
    unsigned phase=(tick-240)/120,offset=(tick-240)%120;if(phase>=6)return;
    static int entered,active,first_motion;static float first,last,turned,post_active;
    HSD_GObj *g=Player_GetEntity(0),*h=Player_GetEntity(1);if(!g||!h)return;
    Fighter *f=g->user_data,*v=h->user_data;const float angles[6]={0,45,90,180,0,0};float a=angles[phase]*M3D_COMBAT_RAD;
    if(!offset) {
        sequence_ground(g,0);sequence_ground(h,26);f->facing_dir=1;m3d_SetLane(f,cosf(a),sinf(a));
        f->cur_pos=(Vec3){0,phase==2?80:0,0};f->self_vel=f->x8c_kb_vel=(Vec3){0};f->gr_vel=f->xF0_ground_kb_vel=0;
        if(phase==2){ftCommon_8007D5D4(f);ftCo_Fall_Enter(g);ftCommon_8007D5D4(v);ftCo_Fall_Enter(h);}
        f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=f->cur_pos;
        m3d_PostMap(f);HSD_JObjSetTranslate(g->hsd_obj,&f->cur_pos);m3d_CameraSetYaw(0);
        entered=active=first_motion=0;first=last=a;turned=post_active=0;
    }
    /* A scripted lateral target isolates angular tracking from opponent AI. */
    float range=phase==5?-26:26,side=offset<10?2:fminf(12,2+(offset-10)*.5f);
    v->cur_pos=(Vec3){range*cosf(a)-side*sinf(a),f->cur_pos.y,range*sinf(a)+side*cosf(a)};
    v->self_vel=v->x8c_kb_vel=(Vec3){0};v->gr_vel=v->xF0_ground_kb_vel=0;
    v->prev_pos=v->coll_data.cur_pos=v->coll_data.prev_pos=v->coll_data.last_pos=v->cur_pos;
    m3d_PostMap(v);HSD_JObjSetTranslate(h->hsd_obj,&v->cur_pos);
    float lx,lz;m3d_GetLane(f,&lx,&lz);float heading=atan2f(lz,lx);
    bool normal=m3d_CombatNormal(f);
    if(offset>=10&&normal) {
        if(!entered){entered=1;first_motion=f->motion_id;first=last=heading;}
        bool hitbox=false;for(int i=0;i<4;i++)hitbox|=f->x914[i].state!=HitCapsule_Disabled;
        if(f->motion_id==first_motion) {
            if(active)post_active=fmaxf(post_active,fabsf(m3d_combat_angle(heading-last))/M3D_COMBAT_RAD);
            else turned=fmaxf(turned,fabsf(m3d_combat_angle(heading-first))/M3D_COMBAT_RAD);
            active|=hitbox;last=heading;
        }
    }
    if(offset==85) {
        /* Call the actual input adapter on a damage state and restore the
         * fixture. This checks the native ABI and modifier mapping too. */
        typeof(f->input) old=f->input;int motion=f->motion_id,move=f->x2068_attackID;float hitlag=f->dmg.x195c_hitlag_frames;bool stun=f->x221C_b6;HSD_PadStatus saved=HSD_PadGameStatus[f->pad_port];
        float values[2];for(int i=0;i<2;i++) {
            HSD_PadGameStatus[f->pad_port]=(HSD_PadStatus){0};HSD_PadGameStatus[f->pad_port].button=i?HSD_PAD_L:HSD_PAD_DPADUP;
            f->motion_id=ftCo_MS_DamageFlyN;f->x221C_b6=true;f->x2068_attackID=FtMoveId_Default;f->input.lstick[0]=(Vec2){1,0};m3d_RemapInput(f);
            values[i]=fabsf(f->input.lstick[0].y);if(hypotf(f->input.lstick[0].x,f->input.lstick[0].y)>1.0001f)abort();
        }
        f->x221C_b6=false;f->dmg.x195c_hitlag_frames=0;
        HSD_PadGameStatus[f->pad_port]=(HSD_PadStatus){0};HSD_PadGameStatus[f->pad_port].button=HSD_PAD_DPADUP;
        HSD_PadGameStatus[f->pad_port].trigger=HSD_PAD_A;f->input.lstick[0]=(Vec2){0,0};
        m3d_RemapInput(f);
        if(f->input.lstick[0].y<.999f){fprintf(stderr,"M3D LAB FAIL actionable up attack modifier\n");abort();}
        f->input=old;f->motion_id=motion;f->x2068_attackID=move;f->x221C_b6=stun;f->dmg.x195c_hitlag_frames=hitlag;HSD_PadGameStatus[f->pad_port]=saved;
        if(fabsf(values[0]-values[1])>.0001f){fprintf(stderr,"M3D LAB FAIL DI symmetry\n");abort();}
    }
    if(offset==100) {
        bool pass=entered&&(phase>=4||active)&&(phase>=4||turned>.1f)&&(phase==4||post_active<.01f)&&(phase==4||turned<=30.01f);
        if(phase==5)pass=pass&&turned<.01f;
        fprintf(stderr,"M3D COMBAT PROBE %s phase=%u kind=%d state=%d entered=%d active=%d turned=%.3f post=%.3f\n",pass?"PASS":"FAIL",phase,f->kind,first_motion,entered,active,turned,post_active);
        if(!pass)abort();
    }
}

void m3d_lab_pause_check(void* camera,int paused)
{
    if(!getenv("MELEE3D_NATIVE_PAUSE_CHECK"))return;
    static unsigned tick,frames,game_frame,world_frame,cycles;static bool was_paused;
    static Vec3 positions[32],eye;static float travel;
    tick++;
    if(tick==240||tick==850||tick==1460)m3d_PauseRequest();
    if(paused){
        if(!was_paused){frames=0;game_frame=gm_GetFrameCount();world_frame=m3d_match_frame;travel=0;
            HSD_CObjGetEyePosition(camera,&eye);
            for(int i=0;i<32;i++){HSD_GObj* g=Player_GetEntity(i);if(g)positions[i]=((Fighter*)g->user_data)->cur_pos;}}
        if(gm_GetFrameCount()!=game_frame||m3d_match_frame!=(int)world_frame)abort();
        for(int i=0;i<32;i++){HSD_GObj* g=Player_GetEntity(i);if(g){Vec3 p=((Fighter*)g->user_data)->cur_pos;
            if(fabsf(p.x-positions[i].x)+fabsf(p.y-positions[i].y)+fabsf(p.z-positions[i].z)>.0001f)abort();}}
        HSD_PadStatus* p=&HSD_PadCopyStatus[0];p->button=p->trigger=0;p->nml_stickX=p->nml_stickY=p->nml_subStickX=p->nml_subStickY=p->nml_analogL=p->nml_analogR=0;
        if(frames<60)p->nml_stickY=1;else if(frames<120)p->nml_subStickX=.75f;else if(frames<160)p->nml_analogR=1;
        if(frames==180)p->trigger=p->button=HSD_PAD_Z;
        Vec3 now;HSD_CObjGetEyePosition(camera,&now);travel=fmaxf(travel,hypotf(hypotf(now.x-eye.x,now.z-eye.z),now.y-eye.y));
        if(++frames==(getenv("MELEE3D_NATIVE_PAUSE_VISUAL")?1800u:240u))m3d_PauseRequest();
    } else if(was_paused){
        if(frames<240||travel<100)abort();cycles++;
        fprintf(stderr,"M3D PAUSE CHECK cycle=%u frozen_frames=%u camera_travel=%.2f native_frame=%u\n",cycles,frames,travel,game_frame);
    }
    was_paused=paused;
    if(tick==1900&&!getenv("MELEE3D_NATIVE_PAUSE_VISUAL")){if(cycles!=3)abort();fprintf(stderr,"M3D PAUSE CHECK PASS cycles=3\n");}
}

/* Opt-in pad regression: compare ordinary jumps with L2-modified jumps,
 * then inspect the real kick effects in eight headings, both facings/air states. */
static void down_polish_pad(HSD_PadStatus* p,unsigned tick)
{
    if(tick<240)return;unsigned phase=(tick-240)/120,t=(tick-240)%120;
    if(phase<3){
        if(t>=12&&t<18){p->button=HSD_PAD_X;if(t==12)p->trigger=HSD_PAD_X;}
        if((phase==1&&t>=20)||(phase==2&&((t>=55&&t<60)||(t>=80&&t<85)))){p->button|=HSD_PAD_L;p->nml_analogL=1;}
    } else if(phase<35&&t==12){p->button=p->trigger=HSD_PAD_B|HSD_PAD_L;p->nml_analogL=1;}
}
static void down_polish_tick(unsigned tick)
{
    if(!getenv("MELEE3D_NATIVE_DOWN_CHECK")||tick<240)return;
    unsigned phase=(tick-240)/120,t=(tick-240)%120;if(phase>=35)return;
    HSD_GObj* g=Player_GetEntity(0);Fighter* f=g->user_data;
    static float baseline[120],error;static int effects,travel;static Vec3 previous;
    unsigned kick=phase>=3?phase-3:0;bool air=phase>=3&&kick>=16;float a=(kick%8)*.7853981634f;
    if(!t){
        efLib_DestroyAll(g);sequence_ground(g,0);
        Vec3 p={0,air?90:0,0};f->cur_pos=f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=p;
        f->self_vel=f->x8c_kb_vel=(Vec3){0};f->gr_vel=0;f->fall_fast=false;f->facing_dir=kick%16>=8?-1:1;
        ftPartSetRotY(f,0,1.570796327f*f->facing_dir);m3d_SetLane(f,cosf(a),sinf(a));m3d_PostMap(f);
        if(air){ftCommon_8007D5D4(f);ftCo_Fall_Enter(g);}
        HSD_JObjSetTranslate(g->hsd_obj,&p);m3d_CameraSetYaw(0);
        Fighter* other=Player_GetEntity(1)->user_data;other->is_sleeping=true;
        previous=p;effects=travel=0;error=0;
    }
    if(phase<3){
        if(phase==0)baseline[t]=f->cur_pos.y;
        else if(fabsf(f->cur_pos.y-baseline[t])>.001f||f->fall_fast){fprintf(stderr,"M3D LAB FAIL L2 jump phase=%u t=%u y=%.4f base=%.4f fast=%d\n",phase,t,f->cur_pos.y,baseline[t],f->fall_fast);abort();}
        if(t==110)fprintf(stderr,"M3D DOWN JUMP PASS phase=%u kind=%d fast=%d\n",phase,f->kind,f->fall_fast);
    } else {
        float lx,lz;m3d_GetLane(f,&lx,&lz);float fx=lx*f->facing_dir,fz=lz*f->facing_dir;
        for(int link=11;link<=12;link++)for(HSD_GObj* e=HSD_GObjPLinkHead[link];e;e=e->next){
            EF_Effect* effect=e->user_data;
            if(!effect||effect->parent_gobj!=g||effect->update!=efLib_Cb_SetRotYZ_FromParamZ_FighterDir)continue;
            float yaw=HSD_JObjGetRotationY(e->hsd_obj);
            float off=hypotf(sinf(yaw)-fx,cosf(yaw)-fz);error=fmaxf(error,off);effects++;
            float dx=f->cur_pos.x-previous.x,dz=f->cur_pos.z-previous.z;
            if(hypotf(dx,dz)>.1f&&dx*fx+dz*fz>.1f)travel++;
        }
        if(t==110){fprintf(stderr,"M3D DOWN KICK %s kind=%d phase=%u air=%d facing=%.0f angle=%.0f effects=%d travel=%d error=%.6f\n",effects&&travel&&error<.001f?"PASS":"FAIL",f->kind,kick,air,f->facing_dir,a*57.2957795f,effects,travel,error);
            if(!effects||!travel||error>=.001f)abort();}
        previous=f->cur_pos;
    }
}

static HSD_GObj* thunder_head(Fighter* f)
{
    if(f->kind==8)return f->u.ns.pkthunder_gobj;
    uint32_t v=m3d_akaneia_object_export(f,2),head=m3d_vm_read32(v+0x2244);
    return head?m3d_native_object(head,1):NULL;
}
static unsigned thunder_loop_waypoint;
static void thunder_probe_pad(HSD_PadStatus* p,unsigned tick)
{
    if(tick<240)return;unsigned phase=(tick-240)/480,t=(tick-240)%480;if(phase>=4)return;
    if(t==12){p->button=p->trigger=HSD_PAD_B|HSD_PAD_DPADUP;return;}
    if(t<25)return;
    Fighter* f=Player_GetEntity(0)->user_data;HSD_GObj* head=thunder_head(f);if(!head)return;
    if(getenv("MELEE3D_NATIVE_THUNDER_LOOP")){
        Item* ip=head->user_data;
        static const float path[5][2]={{25,0},{25,20},{-22,20},{-22,0},{0,0}};
        float angle=phase*.785398163f,fx=cosf(angle),fz=sinf(angle);
        float dx=ip->pos.x-f->cur_pos.x,dz=ip->pos.z-f->cur_pos.z;
        float along=dx*fx+dz*fz,side=-dx*fz+dz*fx;
        if(thunder_loop_waypoint<4&&hypotf(along-path[thunder_loop_waypoint][0],side-path[thunder_loop_waypoint][1])<7)thunder_loop_waypoint++;
        unsigned w=thunder_loop_waypoint;float a=path[w][0]-along,b=path[w][1]-side;
        float x=a*fx-b*fz,z=a*fz+b*fx,length=hypotf(x,z);if(length<.01f)return;x/=length;z/=length;
        float yaw=m3d_CameraGetYaw();p->nml_stickX=x*cosf(yaw)-z*sinf(yaw);p->nml_stickY=-x*sinf(yaw)-z*cosf(yaw);
        p->stickX=p->nml_stickX*80;p->stickY=p->nml_stickY*80;return;
    }
    if(!(phase%2)){p->button=HSD_PAD_DPADUP;return;}
    if(t<25)return; /* The forward spawn already clears the separation latch. */
    Item* ip=head->user_data;float dx=f->cur_pos.x-ip->pos.x,dz=f->cur_pos.z-ip->pos.z,dy=f->cur_pos.y+5*f->x34_scale.y-ip->pos.y;
    float h=hypotf(dx,dz),scale=fmaxf(h,fabsf(dy));if(scale<.01f)return;
    if(fabsf(dy)>.45f*h)p->button=dy>0?HSD_PAD_DPADUP:HSD_PAD_L;
    float yaw=m3d_CameraGetYaw(),x=dx/scale,z=dz/scale;
    p->nml_stickX=x*cosf(yaw)-z*sinf(yaw);p->nml_stickY=-x*sinf(yaw)-z*cosf(yaw);
    p->stickX=p->nml_stickX*80;p->stickY=p->nml_stickY*80;
}
static void thunder_probe_tick(unsigned tick)
{
    if(!getenv("MELEE3D_NATIVE_THUNDER_CHECK")||tick<240)return;
    unsigned phase=(tick-240)/480,t=(tick-240)%480;if(phase>=4)return;
    static int live,hit,behind,rocket;static float closest,speed;static Vec3 origin;static float depth;
    HSD_GObj* g=Player_GetEntity(0);Fighter* f=g->user_data;
    if(!t){sequence_ground(g,0);Vec3 p={819,10000,-732},floor;if(m3d_DelfinoActive()){if(!m3d_DelfinoFloor(&p,&floor))abort();p=floor;}else p=(Vec3){0,0,0};p.y+=3;
        if(phase>=2&&!getenv("MELEE3D_NATIVE_THUNDER_LOOP")){p.y+=180;ftCommon_8007D5D4(f);ftCo_Fall_Enter(g);}
        f->cur_pos=f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=p;f->self_vel=f->x8c_kb_vel=(Vec3){0};f->gr_vel=0;f->facing_dir=1;
        m3d_SetLane(f,cosf(phase*.785398163f),sinf(phase*.785398163f));m3d_CameraSetYaw(phase%2?1.570796327f:0);HSD_JObjSetTranslate(g->hsd_obj,&p);
        live=hit=behind=rocket=0;thunder_loop_waypoint=0;closest=10000;speed=depth=0;origin=p;Fighter* other=Player_GetEntity(1)->user_data;other->is_sleeping=true;
        fprintf(stderr,"M3D THUNDER CASE kind=%d phase=%u\n",f->kind,phase);
    }
    HSD_GObj* head=thunder_head(f);
    if(head){Item* ip=head->user_data;live++;
        if(live==1){int count=f->kind==8?16:24;uint32_t v=f->kind==8?0:m3d_items_view(head);
            if(fabsf(ip->x40_vel.y)>.25f){fprintf(stderr,"M3D LAB FAIL thunder did not launch horizontally\n");abort();}
            float vertical=ip->pos.y-f->cur_pos.y-5*f->x34_scale.y;
            float along=(ip->pos.x-f->cur_pos.x)*cosf(phase*.785398163f)+(ip->pos.z-f->cur_pos.z)*sinf(phase*.785398163f);
            if(fabsf(vertical)>3||along<14*f->x34_scale.y){fprintf(stderr,"M3D LAB FAIL thunder spawn height=%.3f ahead=%.3f\n",vertical,along);abort();}
            fprintf(stderr,"M3D THUNDER FORWARD kind=%d vx=%.3f vy=%.3f height=%.3f ahead=%.3f\n",f->kind,ip->x40_vel.x,ip->x40_vel.y,vertical,along);
            for(int point=0;point<count;point++){
                uint32_t bits=0;float z;
                if(f->kind==8)z=ip->xDD4_itemVar.pkthunder.positions[point].z;
                else {bits=m3d_vm_read32(v+0xdfc+point*12+8);memcpy(&z,&bits,4);}
                if(fabsf(z-ip->pos.z)>8){fprintf(stderr,"M3D LAB FAIL thunder history depth kind=%d point=%d z=%.2f actual=%.2f\n",f->kind,point,z,ip->pos.z);abort();}
            }
            fprintf(stderr,"M3D THUNDER INITIAL DEPTH kind=%d points=%d pass=1\n",f->kind,count);
        }
        float dist=hypotf(hypotf(ip->pos.x-f->cur_pos.x,ip->pos.z-f->cur_pos.z),ip->pos.y-f->cur_pos.y-5*f->x34_scale.y);
        if(getenv("MELEE3D_NATIVE_THUNDER_LOOP")){
            float along=(ip->pos.x-f->cur_pos.x)*cosf(phase*.785398163f)+(ip->pos.z-f->cur_pos.z)*sinf(phase*.785398163f);
            if(thunder_loop_waypoint==4&&along<0&&dist<20)behind=1;
        }
        if(t>35)closest=fminf(closest,dist);speed=fmaxf(speed,hypotf(ip->x40_vel.x,ip->x40_vel.y));depth=fmaxf(depth,fabsf(ip->pos.z-origin.z));}
    if(live&&t>25){
        if(f->kind==8){if(f->mv.ns.specialhi.thunderColl==2||f->motion_id==ftNs_MS_SpecialHi||f->motion_id==ftNs_MS_SpecialAirHi||f->motion_id==ftNs_MS_SpecialAirHiRebound)hit++;}
        else if(m3d_vm_read32(m3d_akaneia_object_export(f,2)+0x2340)==2||f->motion_id==0x161||f->motion_id==0x165)hit++;
    }
    bool recovery=f->kind==8?(f->motion_id==ftNs_MS_SpecialHi||f->motion_id==ftNs_MS_SpecialAirHi||f->motion_id==ftNs_MS_SpecialAirHiRebound):(f->motion_id==0x161||f->motion_id==0x165);
    if(recovery&&!rocket++)fprintf(stderr,"M3D THUNDER ROCKET kind=%d phase=%u state=%d speed=%.3f\n",f->kind,phase,f->motion_id,hypotf(f->self_vel.x,f->self_vel.y));
    if(t==450&&getenv("MELEE3D_NATIVE_THUNDER_LOOP"))fprintf(stderr,"M3D THUNDER LOOP kind=%d phase=%u waypoint=%u behind=%d hit=%d rocket=%d\n",f->kind,phase,thunder_loop_waypoint,behind,hit,rocket);
    if(t==450){fprintf(stderr,"M3D THUNDER CASE END kind=%d phase=%u live=%d hit=%d closest=%.3f speed=%.3f depth=%.3f state=%d\n",f->kind,phase,live,hit,closest,speed,depth,f->motion_id);}
}

static void move_polish_pad(HSD_PadStatus* pad,unsigned tick) {
    if(tick<240)return;
    unsigned t=(tick-240)%160;
    if(t>=20&&t<65){pad->nml_stickX=0;pad->nml_stickY=-1;pad->stickY=-80;}
}
static void article_probe_pad(HSD_PadStatus* pad,unsigned tick);
void m3d_lab_pad(void)
{
    if(getenv("MELEE3D_NATIVE_DRIFT_CHECK")){
        HSD_PadStatus* p=&HSD_PadGameStatus[0];memset(p,0,sizeof *p);move_polish_pad(p,fixture_ticks);return;
    }
    if(getenv("MELEE3D_NATIVE_AUDIO_CHECK")){
        HSD_PadStatus* p=&HSD_PadGameStatus[0];unsigned t=fixture_ticks;memset(p,0,sizeof *p);
        if(t>=120&&t<240)p->nml_stickX=t<180?1:-1;
        if(t==260||t==261)p->button=HSD_PAD_X;
        if(t==380||t==420)p->button=HSD_PAD_A;
        if(t==540)p->button=HSD_PAD_B;
        if(t==660){p->button=HSD_PAD_B|HSD_PAD_DPADUP;}
        p->trigger=p->button;p->stickX=(s8)(p->nml_stickX*80);return;
    }
    if(!getenv("MELEE3D_NATIVE_DOWN_CHECK") && !getenv("MELEE3D_NATIVE_THUNDER_CHECK") && !getenv("MELEE3D_NATIVE_ARTICLE_CHECK") && !getenv("MELEE3D_NATIVE_AREA_PROBE") && !getenv("MELEE3D_NATIVE_COMBAT_PROBE") && !getenv("MELEE3D_NATIVE_SPECTATOR_CHECK") && !getenv("MELEE3D_NATIVE_EFFECT_REUSE") && !getenv("MELEE3D_NATIVE_CAMERA_PROBE") && !getenv("MELEE3D_NATIVE_DELFINO_PROBE") && !getenv("MELEE3D_NATIVE_CONTROLS") && !getenv("MELEE3D_NATIVE_RECOVERY") && sequence_profile()<5)return;
    HSD_PadStatus* pad=&HSD_PadGameStatus[0];unsigned tick=fixture_ticks;
    memset(pad,0,sizeof *pad);
    if(getenv("MELEE3D_NATIVE_DOWN_CHECK")){down_polish_pad(pad,tick);return;}
    if(getenv("MELEE3D_NATIVE_THUNDER_CHECK")){thunder_probe_pad(pad,tick);return;}
    if(getenv("MELEE3D_NATIVE_ARTICLE_CHECK")){article_probe_pad(pad,tick);return;}
    if(getenv("MELEE3D_NATIVE_AREA_PROBE"))return;
    if(getenv("MELEE3D_NATIVE_COMBAT_PROBE")){combat_probe_pad(pad,tick);return;}
    if(getenv("MELEE3D_NATIVE_CAPTURE_CHECK"))return;
    if(getenv("MELEE3D_NATIVE_SPECTATOR_CHECK")){
        if(!strcmp(getenv("MELEE3D_NATIVE_SPECTATOR_CHECK"),"cycle")) {
            if(tick==120||(tick>=340&&tick<=400)||tick==420||tick==440||tick==660)pad->button=HSD_PAD_DPADRIGHT;
            if(tick==460||tick==480||tick==500||tick==520)pad->button=HSD_PAD_DPADLEFT;
            pad->trigger=pad->button;
        } else if(tick>480&&tick%2)pad->button=pad->trigger=HSD_PAD_DPADLEFT;
        return;
    }
    if(getenv("MELEE3D_NATIVE_EFFECT_REUSE")){if(tick>=240&&(tick-240)%40>=5){pad->nml_stickX=1;pad->stickX=80;}return;}
    if(getenv("MELEE3D_NATIVE_CAMERA_PROBE")){if(tick>=240&&(tick-240)%90>=10&&(tick-240)%90<20){pad->nml_subStickX=.6f;pad->subStickX=48;}return;}
    if(getenv("MELEE3D_NATIVE_DELFINO_PROBE")){if(!strcmp(getenv("MELEE3D_NATIVE_DELFINO_PROBE"),"water")){water_probe_pad(pad,tick);return;}if(!strcmp(getenv("MELEE3D_NATIVE_DELFINO_PROBE"),"coins"))return;if((!strcmp(getenv("MELEE3D_NATIVE_DELFINO_PROBE"),"stairs")||!strcmp(getenv("MELEE3D_NATIVE_DELFINO_PROBE"),"stairs-raw")))stair_probe_pad(pad,tick);else if(!strcmp(getenv("MELEE3D_NATIVE_DELFINO_PROBE"),"islands"))island_probe_pad(pad,tick);else if(!strcmp(getenv("MELEE3D_NATIVE_DELFINO_PROBE"),"camera-turn"))snap_probe_pad(pad,tick);else if(!strcmp(getenv("MELEE3D_NATIVE_DELFINO_PROBE"),"ledges"))ledge_probe_pad(pad,tick);else if(!strcmp(getenv("MELEE3D_NATIVE_DELFINO_PROBE"),"rules"))rules_probe_pad(pad,tick);else if(!strcmp(getenv("MELEE3D_NATIVE_DELFINO_PROBE"),"walljump"))walljump_probe_pad(pad,tick);else delfino_probe_pad(pad,tick);return;}
    if(getenv("MELEE3D_NATIVE_RECOVERY")){recovery_pad(pad,tick);return;}
    if(sequence_profile()==8)return;
    if(sequence_profile()>=5) {
        unsigned mask,window,count=0,move=0;
        if(sequence_config(&mask,&window)<0 || tick<240)return;
        unsigned ordinal=(tick-240)/window,offset=(tick-240)%window;
        if(ordinal>=__builtin_popcount(mask))return;
        for(move=0;move<8;++move)if(mask&(1u<<move)) {if(count++==ordinal)break;}
        if(sequence_profile()==7){
            bool held=move==0 ? ((offset>=15&&offset<21)||(offset>=45&&offset<240)) : (offset>=15&&offset<240&&((offset-15)%30)<6);
            unsigned last=offset?offset-1:0;
            bool previous=move==0 ? ((last>=15&&last<21)||(last>=45&&last<240)) : (last>=15&&last<240&&((last-15)%30)<6);
            pad->button=held?HSD_PAD_X:0;pad->last_button=previous?HSD_PAD_X:0;
            pad->trigger=pad->button&~pad->last_button;pad->release=pad->last_button&~pad->button;return;
        }
        if(offset==15) {
            pad->button=pad->trigger=sequence_profile()==6 ? HSD_PAD_A:HSD_PAD_B;
            if(move/2==1)pad->nml_stickX=1;
            if(move/2==2)pad->nml_stickY=1;
            if(move/2==3)pad->nml_stickY=-1;
            if(m3d_SeparateAttackInputs()) {
                const char* value=getenv("MELEE3D_NATIVE_ANGLE");float angle=(value?atof(value):0)*3.14159265f/180;
                pad->nml_stickX=move/2?cosf(angle):0;pad->nml_stickY=move/2?-sinf(angle):0;
                if(move/2==2)pad->button|=HSD_PAD_DPADUP;
                if(move/2==3){pad->button|=HSD_PAD_L;pad->nml_analogL=1;}
                pad->trigger=pad->button;
            }

            pad->stickX=(s8)(pad->nml_stickX*80);pad->stickY=(s8)(pad->nml_stickY*80);
        }
        if(offset==16)pad->last_button=pad->release=sequence_profile()==6 ? HSD_PAD_A:HSD_PAD_B;
        return;
    }
    pad->button=world_buttons(tick);pad->last_button=tick ? world_buttons(tick-1):0;
    pad->trigger=pad->button&~pad->last_button;pad->release=pad->last_button&~pad->button;
    if(tick>=181 && tick<=200)pad->nml_stickY=1;
    if(tick>=201 && tick<=250) {
        pad->nml_stickX=.65f;pad->nml_subStickX=.6f;
    }
    if(tick==310 || tick==460)pad->nml_stickY=1;
    if(tick==610 || tick==760)pad->nml_stickY=-1;
    if(tick>=901 && tick<=940)pad->nml_stickY=1;
    pad->stickX=(s8)(pad->nml_stickX*80);pad->stickY=(s8)(pad->nml_stickY*80);
    pad->subStickX=(s8)(pad->nml_subStickX*80);
    if(m3d_SeparateAttackInputs()) {
        if(tick==310||tick==460||tick==610||tick==760){pad->nml_stickX=1;pad->nml_stickY=0;if(tick>=610)pad->nml_analogL=1;}
        if(tick>=1200&&tick<1440&&(tick-1200)%60==10){unsigned phase=(tick-1200)/60;
            pad->nml_stickX=phase==0||phase==2?-1:0;pad->nml_stickY=phase==1?1:phase==3?-1:0;if(phase==2)pad->nml_analogL=1;}
        pad->stickX=(s8)(pad->nml_stickX*80);pad->stickY=(s8)(pad->nml_stickY*80);
    }
}
static void world_check(const char* name,int passed,Fighter* fp)
{
    fprintf(stderr,"M3D CONTROL %s name=%s tick=%u state=%d x=%.3f y=%.3f z=%.3f yaw=%.4f\n",
        passed ? "PASS":"FAIL",name,fixture_ticks,fp->motion_id,
        fp->cur_pos.x,fp->cur_pos.y,fp->cur_pos.z,m3d_CameraGetYaw());
    if(!passed) { fprintf(stderr,"M3D LAB FAIL world controls %s\n",name);abort(); }
}
static void world_controls_tick(unsigned tick)
{
    static Vec3 start,turn;static float yaw,peak;static int airborne;
    if(!getenv("MELEE3D_NATIVE_CONTROLS"))return;
    HSD_GObj* object=Player_GetEntity(0);if(!object)return;
    Fighter* fp=object->user_data;float lx,lz;
    if(tick==180 || tick==300 || tick==450 || tick==600 || tick==750 || tick==900) {
        sequence_ground(object,0);fp->self_vel=(Vec3){0,0,0};fp->gr_vel=0;
        fp->cur_pos.z=tick==900 ? 80:0;fp->facing_dir=1;
        m3d_SetLane(fp,1,0);m3d_CameraSetYaw(0);
        if(tick==450 || tick==750) {
            fp->cur_pos.y=45;ftCommon_8007D5D4(fp);ftCo_Fall_Enter(object);
        }
        if(tick==900) {m3d_SetLane(fp,0,1);m3d_CameraSetYaw(3.14159265f);}
        fp->prev_pos=fp->cur_pos;
        fp->coll_data.cur_pos=fp->coll_data.prev_pos=fp->coll_data.last_pos=fp->cur_pos;
        m3d_PostMap(fp);HSD_JObjSetTranslate(object->hsd_obj,&fp->cur_pos);
        if(tick==180)start=fp->cur_pos;
    }
    if(tick==200) {
        world_check("camera_relative_travel",fp->cur_pos.z<start.z-5,fp);
        turn=fp->cur_pos;yaw=m3d_CameraGetYaw();
    }
    if(tick==220)world_check("turn_while_moving",fabsf(m3d_CameraGetYaw()-yaw)>.3f &&
        hypotf(fp->cur_pos.x-turn.x,fp->cur_pos.z-turn.z)>5,fp);
    if(tick==220) { peak=fp->cur_pos.y;airborne=0; }
    if(tick>221 && tick<260) {
        if(fp->ground_or_air==GA_Air)airborne=1;
        if(fp->cur_pos.y>peak)peak=fp->cur_pos.y;
    }
    if(tick==260)world_check("jump_move_and_camera",airborne && peak>8 && fabsf(m3d_CameraGetYaw()-yaw)>.7f,fp);
    if(tick==311 || tick==461 || tick==611 || tick==761) {
        int expected=tick==311 ? ftFx_MS_SpecialHiHold:tick==461 ? ftFx_MS_SpecialHiHoldAir:
            tick==611 ? ftFx_MS_SpecialLwStart:ftFx_MS_SpecialAirLwStart;
        m3d_GetLane(fp,&lx,&lz);
        world_check(tick==311 ? "up_special_ground":tick==461 ? "up_special_air":
            tick==611 ? "down_special_ground":"down_special_air",
            fp->motion_id==expected && lx>.999f && fabsf(lz)<.001f,fp);
    }
    if(tick==940)world_check("depth_edge_fall",fp->ground_or_air==GA_Air && fp->cur_pos.z>85 && fp->cur_pos.y<0,fp);
    if(tick==1060)world_check("smash_camera_toggle",m3d_CameraGetMode()==1,fp);
    if(tick==1110)world_check("combat_camera_toggle",m3d_CameraGetMode()==2,fp);
    if(tick==1160)world_check("orbit_camera_toggle",m3d_CameraGetMode()==0,fp);
    if(m3d_SeparateAttackInputs()&&tick>=1200&&tick<1440){unsigned phase=(tick-1200)/60,offset=(tick-1200)%60;
        if(!offset){sequence_ground(object,0);fp->self_vel=(Vec3){0};fp->gr_vel=0;fp->facing_dir=1;m3d_SetLane(fp,1,0);m3d_CameraSetYaw(0);}
        if(offset==11){
            m3d_GetLane(fp,&lx,&lz);int expected=phase==1?FtMoveId_AttackHi4:phase==2?FtMoveId_AttackLw4:FtMoveId_AttackS4;
            bool heading=phase==0||phase==2?lx<-.999f&&fabsf(lz)<.001f:phase==1?lz<-.999f&&fabsf(lx)<.001f:lz>.999f&&fabsf(lx)<.001f;
            const char* names[]={"side_attack_behind","up_attack_forward","down_attack_behind","side_attack_depth"};
            world_check(names[phase],fp->x2068_attackID==expected&&heading,fp);
        }
    }

}

/* Full article lifecycles at translated world positions, through real pad
 * attacks/pickup and the original item state machine. Never normal play. */
static Vec3 article_start;static float article_peak,article_x,article_z;static int article_live,article_trails,article_jump,article_fall,article_impact,article_falls;
static void article_probe_pad(HSD_PadStatus* pad,unsigned tick) {
    const char* probe=getenv("MELEE3D_NATIVE_ARTICLE_CHECK");if(!probe||tick<240)return;
    unsigned window=!strcmp(probe,"warp")?400:260,phase=(tick-240)/window,t=(tick-240)%window;
    if(phase>=(!strcmp(probe,"warp")?4:8))return;
    if(!strcmp(probe,"warp")) {
        if(t==12||t==25||t==40)pad->button=pad->trigger=HSD_PAD_A;
        Fighter* f=Player_GetEntity(0)->user_data;
        if(f->motion_id==ftCo_MS_WarpStarFall&&phase%2&&article_fall<9){pad->nml_stickY=phase==1?-1:1;pad->stickY=pad->nml_stickY*80;}
        return;
    }
    if(t==12){pad->button=pad->trigger=HSD_PAD_B;if(phase>=6)pad->button|=HSD_PAD_L;else if(phase>=4)pad->button|=HSD_PAD_DPADUP;else if(phase>=2){pad->nml_stickX=1;pad->stickX=80;}}
    if(phase<2&&t>=13&&t<150)pad->button=HSD_PAD_B;
    if(phase>=6&&t>=13&&t<130)pad->button=HSD_PAD_B|HSD_PAD_L;
    if(t>=25&&t<170&&(phase<2||(phase>=4&&phase<6))) {
        pad->nml_stickX=t<80?1:0;pad->nml_stickY=t<80?0:1;
        if(t>=105&&t<130)pad->button|=HSD_PAD_DPADUP;
        if(t>=130)pad->button|=HSD_PAD_L;
        pad->stickX=pad->nml_stickX*80;pad->stickY=pad->nml_stickY*80;
    }
}
static void article_probe_tick(unsigned tick) {
    const char* probe=getenv("MELEE3D_NATIVE_ARTICLE_CHECK");if(!probe||tick<240)return;
    bool warp=!strcmp(probe,"warp");unsigned window=warp?400:260,phase=(tick-240)/window,t=(tick-240)%window;
    if(phase>=(warp?4:8))return;
    HSD_GObj* g=Player_GetEntity(0);Fighter* f=g->user_data;
    if(!t) {
        sequence_ground(g,0);Vec3 p={warp?819:-80,10000,warp?-732:640},ground;if(!m3d_DelfinoFloor(&p,&ground))abort();p=ground;p.y+=3;
        if(!warp&&phase%2){p.y+=80;ftCommon_8007D5D4(f);ftCo_Fall_Enter(g);}
        f->cur_pos=f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=p;
        f->self_vel=f->x8c_kb_vel=(Vec3){0};f->gr_vel=0;f->facing_dir=1;
        m3d_SetLane(f,cosf(phase*.785398163f),sinf(phase*.785398163f));m3d_CameraSetYaw(phase%2?1.570796327f:0);HSD_JObjSetTranslate(g->hsd_obj,&p);
        article_start=p;article_peak=p.y;article_x=article_z=0;article_live=article_trails=article_jump=article_fall=article_impact=0;article_falls=Player_GetFalls(0);
        Fighter* other=Player_GetEntity(1)->user_data;Vec3 away=p;away.x+=500;other->cur_pos=other->prev_pos=other->coll_data.cur_pos=other->coll_data.prev_pos=other->coll_data.last_pos=away;
        if(warp){SpawnItem spawn={0};spawn.kind=It_Kind_WStar;spawn.pos=spawn.prev_pos=p;spawn.pos.y+=3;spawn.facing_dir=1;spawn.x0_parent_gobj=spawn.x4_parent_gobj2=NULL;spawn.x44_flag.x0.b0=0;if(!Item_80268B18(&spawn))abort();}
        fprintf(stderr,"M3D ARTICLE BEGIN kind=%s phase=%u x=%.3f y=%.3f z=%.3f\n",probe,phase,p.x,p.y,p.z);
    }
    if(warp) {
        article_peak=fmaxf(article_peak,f->cur_pos.y);article_x=fmaxf(article_x,fabsf(f->cur_pos.x-article_start.x));article_z=fmaxf(article_z,fabsf(f->cur_pos.z-article_start.z));
        if(f->motion_id==ftCo_MS_WarpStarJump)article_jump++;
        if(f->motion_id==ftCo_MS_WarpStarFall){article_fall++;if(article_fall==1)fprintf(stderr,"M3D WARP APEX phase=%u x=%.3f z=%.3f expected=%.3f,%.3f\n",phase,f->cur_pos.x,f->cur_pos.z,article_start.x,article_start.z);}
        if(article_fall&&t%10==0&&f->motion_id==ftCo_MS_WarpStarFall)fprintf(stderr,"M3D WARP DESCENT phase=%u x=%.3f y=%.3f z=%.3f\n",phase,f->cur_pos.x,f->cur_pos.y,f->cur_pos.z);
        for(HSD_GObj* item=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_ITEM];item;item=item->next){Item* ip=item->user_data;if(ip->kind==It_Kind_WStar&&ip->msid==5){
            if(!article_impact)fprintf(stderr,"M3D WARP IMPACT phase=%u item=%.3f,%.3f,%.3f fighter=%.3f,%.3f,%.3f\n",phase,ip->pos.x,ip->pos.y,ip->pos.z,f->cur_pos.x,f->cur_pos.y,f->cur_pos.z);
            article_impact++;
        }}
    } else {
        HSD_GObj* head=phase<2?f->u.ns.pkflash_gobj:phase<4?NULL:phase<6?f->u.ns.pkthunder_gobj:NULL;
        if(head){Item* ip=head->user_data;article_live++;article_x=fmaxf(article_x,fabsf(ip->pos.x-article_start.x));article_z=fmaxf(article_z,fabsf(ip->pos.z-article_start.z));article_peak=fmaxf(article_peak,ip->pos.y);
            if(phase>=4)for(int i=0;i<6;i++)if(ip->xDD4_itemVar.pkthunder.xDD4[i])article_trails++;
            if(phase>=4&&t==90) {
                Vec3 saved=ip->xDD4_itemVar.pkthunder.positions[0];int state=f->mv.ns.specialhi.thunderColl;
                ip->xDD4_itemVar.pkthunder.positions[0]=(Vec3){f->cur_pos.x,f->cur_pos.y+5*f->x34_scale.y,f->cur_pos.z+100};
                f->mv.ns.specialhi.thunderColl=0;
                if(ftNs_SpecialHi_ItemPKThunder_CheckNessCollide(g))abort();
                ip->xDD4_itemVar.pkthunder.positions[0]=saved;f->mv.ns.specialhi.thunderColl=state;
                fprintf(stderr,"M3D THUNDER DEPTH REJECT phase=%u\n",phase);
            }
            if(phase>=4&&t==100) {
                /* Controlled self-hit fixture after free steering: the next
                 * original animation callback must detect and launch it. */
                ip->pos=ip->xDD4_itemVar.pkthunder.positions[0]=(Vec3){f->cur_pos.x-3,f->cur_pos.y+5*f->x34_scale.y-2,f->cur_pos.z-4};
                ip->xDD4_itemVar.pkthunder.positions[1]=(Vec3){ip->pos.x-3,ip->pos.y-2,ip->pos.z-4};f->mv.ns.specialhi.thunderColl=0;
            }
        }
        if(phase>=4&&phase<6&&t==101) {
            float lx,lz;m3d_GetLane(f,&lx,&lz);
            bool launch=f->motion_id==ftNs_MS_SpecialHi||f->motion_id==ftNs_MS_SpecialAirHi;
            bool direction=lx>.55f&&lx<.65f&&lz>.75f&&lz<.85f&&f->self_vel.x>0&&f->self_vel.y>0;
            fprintf(stderr,"M3D THUNDER SELF HIT phase=%u pass=%d state=%d lane=%.3f,%.3f vel=%.3f,%.3f\n",phase,launch&&direction,f->motion_id,lx,lz,f->self_vel.x,f->self_vel.y);
            if(!launch||!direction)abort();
        }
        if(phase>=2&&phase<4)for(HSD_GObj* item=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_ITEM];item;item=item->next){Item* ip=item->user_data;if(ip->kind==It_Kind_Ness_PKFire)article_live++;}
        if(phase>=6&&f->motion_id>=ftNs_MS_SpecialLwStart&&f->motion_id<=ftNs_MS_SpecialAirLwEnd)article_live++;
    }
    if(t==window-30)fprintf(stderr,"M3D ARTICLE END kind=%s phase=%u live=%d trails=%d jump=%d fall=%d impact=%d dx=%.3f dz=%.3f rise=%.3f deaths=%d state=%d\n",probe,phase,article_live,article_trails,article_jump,article_fall,article_impact,article_x,article_z,article_peak-article_start.y,Player_GetFalls(0)-article_falls,f->motion_id);
}

static void recovery_tick(unsigned tick)
{
    static bool entered;static Vec3 start;static float mark_yaw,mark_pitch,travel;
    static float depth;static int negative;static bool article;
    if(!getenv("MELEE3D_NATIVE_RECOVERY") || tick<240)return;
    bool aim_probe=getenv("MELEE3D_NATIVE_RECOVERY_AIM")!=NULL;
    unsigned window=aim_probe?140:180,phase=(tick-240)/window,offset=(tick-240)%window;
    if(phase>=(aim_probe?20:4))return;
    HSD_GObj* object=Player_GetEntity(0);Fighter* fp=object->user_data;
    bool ness=atoi(getenv("MELEE3D_NATIVE_RECOVERY"))==5;
    if(offset==0) {
        entered=false;travel=depth=0;negative=0;article=false;sequence_ground(object,0);
        fp->self_vel=(Vec3){0,0,0};fp->gr_vel=0;
        if(ness){fp->cur_pos.z=25;}
        if(ness ? phase%2:phase) {
            fp->cur_pos=(Vec3){!ness && phase==3 ? 120:0,!ness && phase==3 ? -10:40,ness ? 25:phase==3 ? 50:0};
            fp->prev_pos=fp->coll_data.cur_pos=fp->coll_data.prev_pos=fp->coll_data.last_pos=fp->cur_pos;
            ftCommon_8007D60C(fp);ftCo_Fall_Enter(object);
        }
        m3d_SetLane(fp,fp->facing_dir,0);m3d_CameraSetYaw(0);m3d_CameraSetPitch(.2f);
        if(aim_probe) {
            Vec3 p={819,100,-732},floor;if(!m3d_DelfinoFloor(&p,&floor))abort();
            p=floor;if(phase<10)p.y+=100;
            fp->cur_pos=fp->prev_pos=fp->coll_data.cur_pos=fp->coll_data.prev_pos=fp->coll_data.last_pos=p;
            fp->self_vel=fp->x8c_kb_vel=(Vec3){0};fp->gr_vel=fp->xF0_ground_kb_vel=0;
            if(phase<10){ftCommon_8007D5D4(fp);ftCo_Fall_Enter(object);}
            m3d_CameraSetYaw((phase/5%2)*1.570796327f);
        }
        start=fp->cur_pos;mark_yaw=m3d_CameraGetYaw();mark_pitch=m3d_CameraGetPitch();
        fprintf(stderr,"M3D RECOVERY CASE BEGIN ordinal=%u kind=%d tick=%u\n",phase,fp->kind,tick);
    }
    if(offset>=11 && offset<100 && fp->motion_id>=341)entered=true;
    if(ness && offset>10 && offset<150) {
        HSD_GObj* item=phase<2 ? fp->u.ns.pkthunder_gobj:fp->u.ns.pkflash_gobj;
        if(item) {
            Item* ip=item->user_data;article=true;depth=fmaxf(depth,fabsf(ip->pos.z-start.z));
            if(phase<2 && !negative) {
                Vec3 saved=ip->xDD4_itemVar.pkthunder.positions[0];int old=fp->mv.ns.specialhi.thunderColl;
                ip->xDD4_itemVar.pkthunder.positions[0]=(Vec3){fp->cur_pos.x,fp->cur_pos.y+5*fp->x34_scale.y,fp->cur_pos.z+100};
                fp->mv.ns.specialhi.thunderColl=0;
                if(ftNs_SpecialHi_ItemPKThunder_CheckNessCollide(object)){fprintf(stderr,"M3D LAB FAIL PK Thunder depth self-hit\n");abort();}
                ip->xDD4_itemVar.pkthunder.positions[0]=saved;fp->mv.ns.specialhi.thunderColl=old;negative=1;
            }
        }
    }
    float dx=fp->cur_pos.x-start.x,dy=fp->cur_pos.y-start.y,dz=fp->cur_pos.z-start.z;
    travel=fmaxf(travel,sqrtf(dx*dx+dy*dy+dz*dz));
    if(offset==(aim_probe?120:150)) {
        bool camera=phase<2 || (fabsf(m3d_CameraGetYaw()-mark_yaw)<.001f && fabsf(m3d_CameraGetPitch()-mark_pitch)<.001f);
        fprintf(stderr,"M3D RECOVERY CASE END ordinal=%u entered=%d travel=%.3f camera=%d state=%d\n",phase,entered,travel,camera,fp->motion_id);
        if(ness)fprintf(stderr,"M3D NESS ITEM ordinal=%u article=%d depth=%.3f negative=%d\n",phase,article,depth,negative);
    }
}

static void sequence_tick(unsigned ticks)
{
    unsigned mask, window, move, ordinal=0, offset, count;
    int character=sequence_config(&mask,&window);
    HSD_GObj* object;
    Fighter* fp;
    if(character < 0 || ticks < 240)return;
    count=__builtin_popcount(mask);
    if(ticks==240+count*window) {
        fprintf(stderr,"M3D SEQUENCE COMPLETE kind=%d mask=%u cases=%u tick=%u\n",33+character,mask,count,ticks);
        return;
    }
    if(ticks>=240+count*window)return;
    ordinal=(ticks-240)/window;
    offset=(ticks-240)%window;
    for(move=0,count=0;move<8;++move)if(mask&(1u<<move)) {
        if(count++==ordinal)break;
    }
    object=Player_GetEntity(0);
    if(!object || ((Fighter*)object->user_data)->kind!=33+character) {
        fprintf(stderr,"M3D LAB FAIL sequence subject identity\n"); abort();
    }
    fp=object->user_data;
    if(offset==0) {
        unsigned removed=0;
        reflector_checked=false;
        fprintf(stderr,"M3D SEQUENCE BEGIN kind=%d move=%u ordinal=%u tick=%u\n",fp->kind,move,ordinal,ticks);
        if(fp->victim_gobj || fp->x1A5C) {
            fprintf(stderr,"M3D LAB FAIL sequence reset during capture; rerun isolated\n"); abort();
        }
        /* Leave the previous action through the engine, then destroy residual
         * items through their real callbacks. Never zero character-private state. */
        sequence_ground(object,0);
        while(HSD_GObjPLinkHead[9]) {
            if(++removed>256) { fprintf(stderr,"M3D LAB FAIL sequence item cleanup loop\n"); abort(); }
            Item_8026A8EC(HSD_GObjPLinkHead[9]);
        }
        fp->cur_pos=(Vec3){0,(move&1)&&sequence_profile()!=7 ? 45 : 0,0};
        fp->prev_pos=fp->cur_pos; fp->coll_data.cur_pos=fp->cur_pos;
        fp->coll_data.prev_pos=fp->cur_pos;
        fp->self_vel=(Vec3){0,0,0}; fp->gr_vel=0; fp->facing_dir=1;
        fp->x8c_kb_vel=(Vec3){0,0,0};fp->xF0_ground_kb_vel=0;
        float angle=getenv("MELEE3D_NATIVE_ANGLE") ? atof(getenv("MELEE3D_NATIVE_ANGLE"))*.01745329252f:0;
        if(sequence_profile()==8){static const float angles[4]={0,45,90,180};angle=angles[move/2]*.01745329252f;}
        float lx=cosf(angle),lz=sinf(angle);
        if(m3d_StageIs3D())m3d_SetLane(fp,lx,lz);
        int profile=sequence_profile();
        if(profile==7){memset(&jump_check,0,sizeof jump_check);jump_check.budget_ok=1;jump_check.falls=Player_GetFalls(0);}
        if(profile) {
            HSD_GObj* other=Player_GetEntity(1);Fighter* v=other->user_data;
            if(v->victim_gobj || v->x1A5C) { fprintf(stderr,"M3D LAB FAIL victim still captured at reset\n");abort(); }
            float distance=profile==4 ? 10:profile==3 ? 22:profile==8 ? 18:30;
            sequence_ground(other,distance);
            v->cur_pos=(Vec3){distance,0,0};v->prev_pos=v->cur_pos;
            if(m3d_StageIs3D()) { v->cur_pos.x=distance*lx;v->cur_pos.z=distance*lz;v->prev_pos=v->cur_pos;m3d_SetLane(v,lx,lz); }
            v->coll_data.cur_pos=v->coll_data.prev_pos=v->cur_pos;
            v->self_vel=v->x8c_kb_vel=(Vec3){0,0,0};v->gr_vel=v->xF0_ground_kb_vel=0;v->facing_dir=-1;
            ftLib_SetPercent(other,0);
            if(profile==8) {
                memset(&grab_check,0,sizeof grab_check);grab_check.alive=grab_check.continuous=1;
                if(move&1){v->cur_pos.y=fp->cur_pos.y;v->prev_pos=v->cur_pos;ftCommon_8007D5D4(v);ftCo_Fall_Enter(other);v->self_vel.y=2.5f;}
                v->coll_data.cur_pos=v->coll_data.prev_pos=v->cur_pos;grab_check.previous=v->cur_pos;
            }
            if(profile==3)ftData_SpecialLw[v->kind](other);
            if(profile==4) {
                fp->cur_pos.y=fp->prev_pos.y=fp->coll_data.cur_pos.y=fp->coll_data.prev_pos.y=0;
                memset(&grab_check,0,sizeof grab_check);grab_check.alive=grab_check.continuous=1;
                grab_check.previous=v->cur_pos;
            }
        }
        if((move&1) && profile!=4 && profile!=7) { ftCommon_8007D5D4(fp); ftCo_Fall_Enter(object); }
        if(m3d_StageIs3D()) { m3d_PostMap(fp);HSD_JObjSetTranslate(object->hsd_obj,&fp->cur_pos); }
        {
            HSD_GObjEvent entries[8]={ftData_SpecialN[fp->kind],ftData_SpecialAirN[fp->kind],
                ftData_SpecialS[fp->kind],ftData_SpecialAirS[fp->kind],ftData_SpecialHi[fp->kind],
                ftData_SpecialAirHi[fp->kind],ftData_SpecialLw[fp->kind],ftData_SpecialAirLw[fp->kind]};
            if(!entries[move])abort();
            if(profile<4 || profile==8)entries[profile==8?2+(move&1):move](object);
        }
        fprintf(stderr,"M3D SEQUENCE ENTER kind=%d move=%u ordinal=%u tick=%u state=%d\n",fp->kind,move,ordinal,ticks,fp->motion_id);
    }
    if(sequence_profile()==6 && offset>=14 && offset<=60) {
        for(unsigned hand=0;hand<2;++hand) {
            int bone=ftParts_GetBoneIndex(fp,hand ? FtPart_RHandN:FtPart_LHandN);
            HSD_JObj* joint=fp->parts[bone].joint;HSD_JObjSetupMatrix(joint);
            float wx=0,wy=0,wz=0;
            for(unsigned k=0;k<3;++k) {wx+=joint->mtx[k][0]*joint->mtx[k][0];wy+=joint->mtx[k][1]*joint->mtx[k][1];wz+=joint->mtx[k][2]*joint->mtx[k][2];}
            fprintf(stderr,"M3D SCALE hand=%u bone=%d state=%d frame=%d sx=%d sy=%d sz=%d wx=%d wy=%d wz=%d flags=%x\n",hand,bone,fp->motion_id,
                (int)(fp->cur_anim_frame*1000),(int)(joint->scale.x*1000),(int)(joint->scale.y*1000),(int)(joint->scale.z*1000),
                (int)(sqrtf(wx)*1000),(int)(sqrtf(wy)*1000),(int)(sqrtf(wz)*1000),joint->flags);
            if(hand==0 && fp->motion_id==44 && fp->cur_anim_frame==4) {
                HSD_JObj* ancestor=joint;
                for(unsigned depth=0;ancestor && depth<16;depth++,ancestor=ancestor->parent) {
                    float ax=0,ay=0,az=0;
                    HSD_JObjSetupMatrix(ancestor);
                    for(unsigned k=0;k<3;k++) {ax+=ancestor->mtx[k][0]*ancestor->mtx[k][0];ay+=ancestor->mtx[k][1]*ancestor->mtx[k][1];az+=ancestor->mtx[k][2]*ancestor->mtx[k][2];}
                    fprintf(stderr,"M3D CHAIN depth=%u flags=%x local=%f,%f,%f rot=%f,%f,%f,%f accum=%f,%f,%f world=%f,%f,%f\n",depth,ancestor->flags,
                        ancestor->scale.x,ancestor->scale.y,ancestor->scale.z,ancestor->rotate.x,ancestor->rotate.y,ancestor->rotate.z,ancestor->rotate.w,
                        ancestor->scl ? ancestor->scl->x:0,ancestor->scl ? ancestor->scl->y:0,ancestor->scl ? ancestor->scl->z:0,sqrtf(ax),sqrtf(ay),sqrtf(az));
                }
            }
        }
        if(offset==16 && fp->motion_id!=ftCo_MS_Attack11) {fprintf(stderr,"M3D LAB FAIL real jab input\n");abort();}
    }
    if(sequence_profile()==5 && offset==16) {
        float lx,lz;m3d_GetLane(fp,&lx,&lz);
        const char* angle=getenv("MELEE3D_NATIVE_ANGLE");float radians=(angle ? atof(angle):0)*3.14159265f/180;
        int ok=fp->motion_id>=ftCo_MS_Count && (move/2<2 ||
            (fabsf(lx-cosf(radians))<.001f && fabsf(lz-sinf(radians))<.001f));
        fprintf(stderr,"M3D INPUT %s move=%u state=%d lx=%.5f lz=%.5f\n",ok ? "PASS":"FAIL",move,fp->motion_id,lx,lz);
        if(!ok) {fprintf(stderr,"M3D LAB FAIL input dispatch heading\n");abort();}
    }
    if(sequence_profile()==7){
        jump_check.peak=fmaxf(jump_check.peak,fp->cur_pos.y);
        if(fp->x1968_jumpsUsed>jump_check.maximum)jump_check.maximum=fp->x1968_jumpsUsed;
        if(fp->ground_or_air==GA_Air)jump_check.airborne++;
        if(move==0&&offset==239&&fp->can_multijump&&jump_check.maximum<(unsigned)fp->co_attrs.max_jumps)jump_check.budget_ok=0;
        if(offset==window-2){int ok=jump_check.airborne>5&&jump_check.peak>4&&jump_check.peak<500&&jump_check.maximum<=(unsigned)fp->co_attrs.max_jumps&&jump_check.budget_ok&&
            fp->ground_or_air==GA_Ground&&fabsf(fp->cur_pos.y)<1&&Player_GetFalls(0)==jump_check.falls;
            fprintf(stderr,"M3D JUMP %s move=%u peak=%.3f maximum=%u/%d airborne=%u budget=%d landed=%d falls=%d\n",ok?"PASS":"FAIL",move,jump_check.peak,jump_check.maximum,fp->co_attrs.max_jumps,jump_check.airborne,jump_check.budget_ok,fp->ground_or_air==GA_Ground,Player_GetFalls(0)-jump_check.falls);
        }
    }
    if(sequence_profile()==8) {
        HSD_GObj* other=Player_GetEntity(1);Fighter* v=other->user_data;
        int held=fp->victim_gobj==other || fp->x1A5C==other || v->victim_gobj==object || v->x1A5C==object;
        if(held)grab_check.grabbed++;
        if(offset<=90&&offset%5==0)fprintf(stderr,"M3D LATCH TRACE move=%u offset=%u state=%d target_state=%d self=%.3f,%.3f,%.3f target=%.3f,%.3f,%.3f held=%d\n",move,offset,fp->motion_id,v->motion_id,fp->cur_pos.x,fp->cur_pos.y,fp->cur_pos.z,v->cur_pos.x,v->cur_pos.y,v->cur_pos.z,held);
        if(offset>0 && offset<180) {
            float dx=v->cur_pos.x-grab_check.previous.x,dy=v->cur_pos.y-grab_check.previous.y,dz=v->cur_pos.z-grab_check.previous.z;
            float step=sqrtf(dx*dx+dy*dy+dz*dz);
            if(step>grab_check.max_step)grab_check.max_step=step;
            if(!isfinite(step)||step>=40)grab_check.continuous=0;
            if(v->motion_id<=10)grab_check.alive=0;
        }
        grab_check.previous=v->cur_pos;
        if(offset==240)fprintf(stderr,"M3D LATCH %s move=%u captured_ticks=%d alive=%d continuity=%d max_step=%.3f\n",
            grab_check.grabbed&&grab_check.alive&&grab_check.continuous?"PASS":"FAIL",move,grab_check.grabbed,grab_check.alive,grab_check.continuous,grab_check.max_step);
    }
    if(sequence_profile()==4) {
        HSD_GObj* other=Player_GetEntity(1);Fighter* v=other->user_data;
        int held=fp->victim_gobj==other && v->victim_gobj==object;
        if(held && offset<75)grab_check.grabbed=1;
        if(fp->motion_id==ftCo_MS_CatchAttack)grab_check.pummel=1;
        if(offset==74)grab_check.before_damage=v->dmg.x1830_percent;
        if(offset>=75 && fp->motion_id==ftCo_MS_ThrowF+move)grab_check.thrown=1;
        if(offset>=75 && grab_check.grabbed && !held && !grab_check.released) {
            grab_check.released=1;grab_check.release_tick=offset;
        }
        if(offset>=16 && (!grab_check.released || offset<=grab_check.release_tick+8)) {
            float dx=v->cur_pos.x-grab_check.previous.x,dy=v->cur_pos.y-grab_check.previous.y,dz=v->cur_pos.z-grab_check.previous.z;
            float step=sqrtf(dx*dx+dy*dy+dz*dz);
            if(step>grab_check.max_step)grab_check.max_step=step;
            if(!isfinite(step) || step>=40)grab_check.continuous=0;
            if(v->motion_id<=10)grab_check.alive=0;
        }
        grab_check.previous=v->cur_pos;
        if(offset==240) {
            int ok=grab_check.grabbed && grab_check.pummel && grab_check.thrown && grab_check.released &&
                grab_check.alive && grab_check.continuous && v->dmg.x1830_percent>grab_check.before_damage;
            fprintf(stderr,"M3D GRAB %s move=%u grabbed=%d pummel=%d throw=%d release=%d alive=%d continuity=%d damage=%.3f max_step=%.3f\n",
                ok ? "PASS":"FAIL",move,grab_check.grabbed,grab_check.pummel,grab_check.thrown,grab_check.released,
                grab_check.alive,grab_check.continuous,v->dmg.x1830_percent-grab_check.before_damage,grab_check.max_step);
        }
    }
    if(sequence_profile()>=1 && sequence_profile()<=3) {
        if(sequence_profile()==3 && fp->kind==33 && move>=6 && offset>0 && offset<200 && !reflector_checked && fp->reflect_hit_cb) {
            /* Exercise the real installed hit callback, not just reflector
             * entry. Native collision supplies this direction on a hit; the
             * original Wolf callback reads it before choosing its hit state. */
            float direction=(move&1) ? 1.0f:-1.0f;
            reflector_checked=true;
            fp->ReflectAttr.x1A2C_reflectHitDirection=direction;
            fp->reflect_hit_cb(object);
            if(fp->facing_dir!=direction || fp->ReflectAttr.x1A2C_reflectHitDirection!=direction) {
                fprintf(stderr,"M3D LAB FAIL Wolf reflector hit direction\n");abort();
            }
            fprintf(stderr,"M3D REFLECTOR HIT PASS move=%u direction=%.1f\n",move,direction);
        }
        if(sequence_profile()==3 && fp->kind==33 && move>=6 && offset==200 && !reflector_checked) {
            fprintf(stderr,"M3D LAB FAIL missing Wolf reflector hit callback\n");abort();
        }
        if(offset==30 || offset==120)
            fprintf(stderr,"M3D CHARGE INPUT move=%u phase=%s held=%d\n",move,offset==30 ? "hold":"release",!!(fp->input.held_buttons[0]&HSD_PAD_B));
        if(offset==240) {
            Fighter* v=Player_GetEntity(1)->user_data;
            fprintf(stderr,"M3D MOVE OUTCOME move=%u damage=%.3f\n",move,v->dmg.x1830_percent);
        }
    }
    if(offset==240 || offset==window-1)
        fprintf(stderr,"M3D SEQUENCE %s kind=%d move=%u ordinal=%u tick=%u state=%d\n",
                offset==240 ? "OBSERVED" : "END",fp->kind,move,ordinal,ticks,fp->motion_id);
}

/* Real native Fountain motion: compare its changing surface height with
 * mpGetSpeed, and keep idle fighters riding both moving platforms. */
static void platform_tick(unsigned tick)
{
    static float last[2],minimum[2],maximum[2],speed_error[2],ride_error[2],x_error[2];
    static int moving[2],riding[2];
    static bool last_valid[2];
    if(!getenv("MELEE3D_NATIVE_PLATFORM") || tick<120 || tick>1500)return;
    for(int i=0;i<2;i++) {
        HSD_GObj* object=Player_GetEntity(i);Fighter* fp=object->user_data;Vec3 floor;
        bool valid=m3d_ReferenceSurfacePoint(i,&floor);
        if(tick==120) {
            if(!valid){fprintf(stderr,"M3D LAB FAIL no moving platform\n");abort();}
            Vec3 top=floor,bottom=floor,hit,normal;int line=-1;u32 flags;
            top.y+=2;bottom.y-=2;
            bool began=m3d_MapBegin(fp,&floor,1,0),found=false;
            if(began){m3d_MapToLocal(&top);m3d_MapToLocal(&bottom);
                found=mpCheckFloor(top.x,top.y,bottom.x,bottom.y,0,&hit,&line,&flags,&normal,-1,-1,-1,NULL,NULL);
                if(found)m3d_MapToWorld(&hit);m3d_MapEnd(fp);}
            if(!found || line!=i){fprintf(stderr,"M3D LAB FAIL platform setup line=%d\n",line);abort();}
            fp->cur_pos=fp->prev_pos=hit;fp->coll_data.cur_pos=fp->coll_data.prev_pos=fp->coll_data.last_pos=hit;
            fp->coll_data.floor.index=line;fp->coll_data.floor.flags=flags;fp->coll_data.floor.normal=normal;
            fp->self_vel=(Vec3){0};fp->gr_vel=0;ftCommon_8007D7FC(fp);ft_8008A2BC(object);m3d_SetLane(fp,i ? 0:1,i ? 1:0);
            last[i]=minimum[i]=maximum[i]=floor.y;last_valid[i]=true;continue;
        }
        if(valid) {
            float dy=floor.y-last[i];Vec3 point=floor,speed={0};point.y=last[i];
            bool began=m3d_MapBegin(fp,&floor,1,0),ok=false;
            if(began){m3d_MapToLocal(&point);ok=mpGetSpeed(i,&point,&speed);m3d_MapEnd(fp);}
            if(last_valid[i] && fabsf(dy)>.001f && ok){moving[i]++;speed_error[i]=fmaxf(speed_error[i],fabsf(speed.y-dy));}
            if(fp->ground_or_air==GA_Ground && fp->coll_data.floor.index==i) {
                riding[i]++;ride_error[i]=fmaxf(ride_error[i],fabsf(fp->cur_pos.y-floor.y));
                x_error[i]=fmaxf(x_error[i],fabsf(fp->cur_pos.x-floor.x));
                minimum[i]=fminf(minimum[i],fp->cur_pos.y);maximum[i]=fmaxf(maximum[i],fp->cur_pos.y);
            }
            last[i]=floor.y;
        }
        last_valid[i]=valid;
        if(tick>=121 && tick<241)m3d_ReferenceTestTranslate(i,i ? -.1f:.1f);
        if(tick==1500)fprintf(stderr,"M3D PLATFORM slot=%d moving=%d riding=%d range=%.5f speed_error=%.5f ride_error=%.5f x_error=%.5f\n",i,moving[i],riding[i],maximum[i]-minimum[i],speed_error[i],ride_error[i],x_error[i]);
    }
}

void m3d_lab_hit(int attacker, int victim)
{
    static unsigned seen[GM_MAX_PLAYERS];
    int count=m3d_lab_count();
    if (!count || attacker < 0 || victim < 0 || attacker >= count || victim >= count || attacker==victim) return;
    m3d_PlaytestHit(attacker, victim);
    if (!(seen[attacker] & (1u << victim))) {
        seen[attacker] |= 1u << victim;
        fprintf(stderr,"M3D LAB HIT attacker=%d victim=%d\n",attacker,victim);
    }
}

int m3d_lab_spawn(int slot, void* position)
{
    Vec3* p = position;
    int count = m3d_lab_count();
    if (!count) return 0;
    if(m3d_StageIs3D()) { m3d_SpawnPoint(slot,p);return 1; }
    /* FD lab only: distribute across the real walkable span, without querying
     * nonexistent fifth-through-sixteenth spawn joints in the stage archive. */
    p->x = -65.0f + 130.0f * slot / (count - 1);
    p->y = 0;
    p->z = 0;
    return 1;
}

/* Real native bone/ECB evaluation must be invariant under translating and
 * rotating the borrowed collision frame. Freeze one pose within this tick. */
static void ecb_invariance_tick(unsigned tick){
    if(tick!=230||sequence_profile()!=7||!m3d_StageIs3D())return;
    HSD_GObj* object=Player_GetEntity(0);Fighter* fp=object->user_data;
    Vec3 saved=fp->cur_pos,model;CollData original=fp->coll_data;float lx,lz;
    m3d_GetLane(fp,&lx,&lz);HSD_JObjGetTranslation(object->hsd_obj,&model);
    ftECB reference={0};const float angles[]={0,45,90,135,180,-90};
    const Vec3 offsets[]={{0,0,0},{432,0,-256},{-500,0,600}};unsigned ordinal=0;
    for(unsigned a=0;a<6;a++)for(unsigned location=0;location<3;location++,ordinal++){
        fp->cur_pos=offsets[location];fp->cur_pos.y=saved.y;fp->coll_data=original;
        fp->coll_data.cur_pos=fp->coll_data.prev_pos=fp->coll_data.last_pos=fp->cur_pos;
        HSD_JObjSetTranslate(object->hsd_obj,&fp->cur_pos);
        float yaw=angles[a]*3.14159265358979323846f/180;m3d_SetLane(fp,cosf(yaw),sinf(yaw));m3d_PostMap(fp);
        bool began=m3d_LocalBegin(fp);if(!began){fprintf(stderr,"M3D LAB FAIL ECB fixture has no collision frame\n");abort();}
        HSD_JObjSetTranslate(object->hsd_obj,&fp->cur_pos);mpColl_LoadECB(&fp->coll_data);
        ftECB actual=fp->coll_data.desired_ecb;
        if(!ordinal)reference=actual;
        float error=0;for(int i=0;i<8;i++)error=fmaxf(error,fabsf(((float*)&actual)[i]-((float*)&reference)[i]));
        m3d_LocalEnd(fp,began);
        fprintf(stderr,"M3D ECB %s case=%u angle=%.0f origin=%.0f,%.0f error=%.5f\n",error<.02f?"PASS":"FAIL",ordinal,angles[a],offsets[location].x,offsets[location].z,error);
        if(error>=.02f){fprintf(stderr,"M3D LAB FAIL collision bone point escaped its lane\n");exit(2);}
    }
    fp->cur_pos=saved;fp->coll_data=original;m3d_SetLane(fp,lx,lz);m3d_PostMap(fp);HSD_JObjSetTranslate(object->hsd_obj,&model);
}
static void presentation_tick(unsigned tick) {
    if(tick<240)return;
    HSD_GObj* object=Player_GetEntity(0);if(!object)return;Fighter* fp=object->user_data;
    if(getenv("MELEE3D_NATIVE_EFFECT_REUSE")) {
        static void* pool_addresses[512];static unsigned allocations,reused;
        if(tick>=240&&tick<304){
            for(unsigned n=0;n<8;n++){
                EF_Effect* effect=efSync_Spawn(5006,object,fp->parts[0].joint,NULL);
                if(!effect||effect->user_data){fprintf(stderr,"M3D LAB FAIL recycled effect callback data\n");abort();}
                for(unsigned j=0;j<allocations;j++)if(pool_addresses[j]==effect){reused++;break;}
                pool_addresses[allocations++]=effect;
                effect->user_data=(void*)(uintptr_t)0x123456789ull;HSD_GObjFree(effect->gobj);
            }
        }
        if(tick==304) {
            uint32_t args[4]={0x421,m3d_akaneia_object_export(object,1),m3d_akaneia_object_export(fp,2)+0xb0,0};
            uint32_t handle=m3d_akaneia_call(object,0x8005fddc,args,4);
            HSD_Generator* generator=m3d_native_object(handle,7);
            HSD_Generator* reference=efLib_CreateGenerator(0x3f,&fp->cur_pos);
            if(!generator || !reference || generator->bank!=reference->bank ||
               generator->cmdList!=reference->cmdList || generator->type!=reference->type ||
               hypotf(generator->pos.x-fp->cur_pos.x,generator->pos.z-fp->cur_pos.z)>.001f ||
               fabsf(generator->pos.y-fp->cur_pos.y)>.001f) {
                fprintf(stderr,"M3D LAB FAIL common projectile effect mapping\n");abort();
            }
            fprintf(stderr,"M3D COMMON PARTICLE PASS effect=1057 bank=0 particle=63\n");
        }
        if(tick==304 && getenv("MELEE3D_NATIVE_ASSET_LIFETIME"))m3d_akaneia_asset_lifetime_probe(object);
        if(tick==304){fprintf(stderr,"M3D EFFECT POOL PASS allocations=%u reused=%u\n",allocations,reused);if(allocations!=512||!reused){fprintf(stderr,"M3D LAB FAIL effect pool did not reuse native storage\n");abort();}}
        if((tick-240)%40==0){sequence_ground(object,-40);fp->self_vel=(Vec3){0};fp->gr_vel=0;fp->facing_dir=1;m3d_SetLane(fp,1,0);}
        if(tick==2400)fprintf(stderr,"M3D EFFECT RUN PASS cycles=54\n");
    }
    if(getenv("MELEE3D_NATIVE_CAMERA_PROBE")) {
        unsigned phase=(tick-240)/90,offset=(tick-240)%90;if(phase>=8)return;
        Fighter* target=Player_GetEntity(1)->user_data;
        if(!offset){
            sequence_ground(object,0);sequence_ground(target->gobj,phase%2? -35:35);
            target->cur_pos.z=phase%2?25:-25;target->self_vel=(Vec3){0};fp->self_vel=(Vec3){0};fp->gr_vel=target->gr_vel=0;
            target->coll_data.cur_pos=target->coll_data.prev_pos=target->coll_data.last_pos=target->prev_pos=target->cur_pos;
            m3d_CameraSetMode(2);m3d_CameraSetPitch(38*3.14159265f/180);m3d_CameraSetYaw(phase*3.14159265f/4);
        }
        if(offset==60){
            HSD_CObj* camera=Camera_80030A50()->hsd_obj;Vec3 eye,focus;HSD_CObjGetEyePosition(camera,&eye);HSD_CObjGetInterest(camera,&focus);
            Vec3 d={eye.x-focus.x,eye.y-focus.y,eye.z-focus.z};float length=sqrtf(d.x*d.x+d.y*d.y+d.z*d.z),h=hypotf(d.x,d.z);
            Vec3 right={d.z/h,0,-d.x/h},up={-d.x*d.y/(length*h),h/length,-d.z*d.y/(length*h)};
            float tv=tanf(HSD_CObjGetFov(camera)*3.14159265f/360),th=tv*HSD_CObjGetAspect(camera),worst=0;
            for(int i=0;i<2;i++){Fighter* f=Player_GetEntity(i)->user_data;Vec3 p={f->cur_pos.x-eye.x,f->cur_pos.y+9*f->x34_scale.y-eye.y,f->cur_pos.z-eye.z};
                float depth=-(p.x*d.x+p.y*d.y+p.z*d.z)/length;
                if(depth<10){fprintf(stderr,"M3D LAB FAIL camera behind fighter\n");abort();}
                worst=fmaxf(worst,fmaxf(fabsf(p.x*right.x+p.z*right.z)/(depth*th),fabsf(p.x*up.x+p.y*up.y+p.z*up.z)/(depth*tv)));
            }
            bool ok=worst<.9f&&d.y>40&&m3d_CameraGetMode()==2;
            fprintf(stderr,"M3D CAMERA %s phase=%u ndc=%.5f height=%.3f yaw=%.4f\n",ok?"PASS":"FAIL",phase,worst,d.y,m3d_CameraGetYaw());
            if(!ok)abort();
        }
    }
}

/* Exercise the real 32-seat queue and simultaneous native KO/rebirth path. */
static void respawn_probe_tick(unsigned tick)
{
    if(!getenv("MELEE3D_NATIVE_RESPAWN_CHECK"))return;
    static int initial[GM_MAX_PLAYERS],forced[GM_MAX_PLAYERS];
    if(tick==180){
        VsSceneState* state=gmVs_GetSceneState();int x8[GM_MAX_PLAYERS],x9[GM_MAX_PLAYERS];
        int previous=stage_info.unk8C.b4;
        for(int i=0;i<GM_MAX_PLAYERS;i++){x8[i]=state->fighters[i].x8;x9[i]=state->fighters[i].x9;initial[i]=Player_GetFalls(i);}
        for(int flag=0;flag<2;flag++)for(int slot=0;slot<GM_MAX_PLAYERS;slot++){
            for(int i=0;i<GM_MAX_PLAYERS;i++)state->fighters[i].x8=i==slot?0:144;
            stage_info.unk8C.b4=flag;Vec3 p={NAN,NAN,NAN},offset=p;
            fn_80167638(slot,&p,&offset);
            if(!isfinite(p.x)||!isfinite(p.y)||!isfinite(p.z)||!isfinite(offset.x)||fabsf(offset.x)>32||offset.y!=0||offset.z!=0){fprintf(stderr,"M3D LAB FAIL respawn queue slot=%d flag=%d\n",slot,flag);abort();}
        }
        for(int i=0;i<GM_MAX_PLAYERS;i++){state->fighters[i].x8=x8[i];state->fighters[i].x9=x9[i];}
        stage_info.unk8C.b4=previous;
        if(!m3d_HumanNamesActive())abort();
        /* Retired callbacks must do no work, even before dereferencing a model. */
        fn_802FCC44(NULL);fn_802FCAC4(NULL,0);un_802FD28C(31);
        fprintf(stderr,"M3D RESPAWN QUEUE PASS cases=64 legacy_markers=0\n");
    }
    if(tick>=180)for(int i=0;i<GM_MAX_PLAYERS;i++){
        Vec3 p;Player_LoadPlayerCoords(i,&p);
        if(!isfinite(p.x)||!isfinite(p.y)||!isfinite(p.z)||fabsf(p.x)>=50000||fabsf(p.y)>=50000||fabsf(p.z)>=50000){fprintf(stderr,"M3D LAB FAIL cached respawn slot=%d tick=%u pos=%g,%g,%g\n",i,tick,p.x,p.y,p.z);abort();}
    }
    if(tick>=240&&tick<=2040&&(tick-240)%600==0){
        for(int i=0;i<GM_MAX_PLAYERS;i++){
            HSD_GObj* object=Player_GetEntity(i);Fighter* fp=object?object->user_data:NULL;
            if(!fp||fp->is_sleeping||fp->motion_id<ftCo_MS_Wait)continue;
            ftCo_800D3BC8(object);forced[i]++;
        }
        fprintf(stderr,"M3D RESPAWN WAVE tick=%u\n",tick);
    }
    if(tick==2640){
        for(int i=0;i<GM_MAX_PLAYERS;i++){
            HSD_GObj* object=Player_GetEntity(i);Fighter* fp=object?object->user_data:NULL;
            int deaths=Player_GetFalls(i)-initial[i];
            if(forced[i]<3||deaths<forced[i]||!fp||fp->is_sleeping||fp->motion_id<ftCo_MS_Wait){fprintf(stderr,"M3D LAB FAIL respawn completion slot=%d forced=%d deaths=%d\n",i,forced[i],deaths);abort();}
            fprintf(stderr,"M3D RESPAWN PASS slot=%d forced=%d deaths=%d x=%.2f y=%.2f z=%.2f\n",i,forced[i],deaths,fp->cur_pos.x,fp->cur_pos.y,fp->cur_pos.z);
        }
    }
}

void m3d_lab_audio(Fighter* f,int sound,int voice)
{
    static int enabled=-1;if(enabled<0)enabled=getenv("MELEE3D_NATIVE_AUDIO_CHECK")!=NULL;
    if(enabled&&f->player_idx==0)fprintf(stderr,"M3D OWN SOUND tick=%u kind=%d state=%d sound=%d voice=%d\n",fixture_ticks,f->kind,f->motion_id,sound,voice);
}
/* Reproduce the exact common-effect ABI requested by Lucas's original
 * SpecialHi_CollisionWithAngle. No fighter positions or inputs are changed. */
static void impact_effect_probe_tick(unsigned t)
{
    if(!getenv("MELEE3D_NATIVE_IMPACT_EFFECT_CHECK")||t<240||t>360||(t-240)%15)return;
    for(int i=0;i<m3d_lab_count();i++) {
        HSD_GObj* g=Player_GetEntity(i);Fighter* f=g?g->user_data:NULL;
        if(!f||f->kind!=36)continue;
        uint32_t data=m3d_vm_alloc(16),bits;float angle=((int)(t-240)/15-4)*.785398163f;
        Vec3 pos=f->cur_pos;
        for(int n=0;n<3;n++){memcpy(&bits,(char*)&pos+n*4,4);m3d_vm_write32(data+n*4,bits);}
        memcpy(&bits,&angle,4);m3d_vm_write32(data+12,bits);
        uint32_t args[]={0x406,m3d_akaneia_object_export(g,1),data,data+12};
        uint32_t effect=m3d_akaneia_call(g,0x8005fddc,args,4);
        fprintf(stderr,"M3D IMPACT EFFECT PASS case=%u angle=%.3f handle=%08x\n",(t-240)/15,angle,effect);
        if(!effect)abort();
        m3d_vm_free(data);return;
    }
    fprintf(stderr,"M3D LAB FAIL impact fixture requires Lucas\n");abort();
}
static void audio_probe_tick(unsigned t)
{
    if(!getenv("MELEE3D_NATIVE_AUDIO_CHECK"))return;
    HSD_GObj* o=Player_GetEntity(0);if(!o)return;Fighter* f=o->user_data;
    if(t==120||t==350||t==510||t==630||t==890){
        sequence_ground(o,0);Vec3 p={819,10000,-732},floor;if(!m3d_DelfinoFloor(&p,&floor))abort();
        f->cur_pos=floor;f->cur_pos.y+=3;m3d_SetLane(f,1,0);m3d_CameraSetYaw(0);
        f->prev_pos=f->cur_pos;f->self_vel=(Vec3){0};f->gr_vel=0;
        f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=f->cur_pos;m3d_PostMap(f);HSD_JObjSetTranslate(o->hsd_obj,&f->cur_pos);
    }
    if(t==120)for(int i=1;i<m3d_lab_count();i++){
        HSD_GObj* g=Player_GetEntity(i);if(g){Fighter* other=g->user_data;other->is_sleeping=true;}
    }
    if(t==900)ft_80088510(f,0x85,127,64);
    if(t==903){
        HSD_GObj* g=Player_GetEntity(m3d_lab_count()>18?18:1);Fighter* other=g->user_data;
        other->cur_pos=f->cur_pos;
        ft_800881D8(other,0x85,127,64);
    }
    if(t==906){
        HSD_GObj* g=Player_GetEntity(m3d_lab_count()>18?18:1);ft_80088770(g->user_data);
    }
    if(t==905||t==909){
        bool ok=f->x2150!=-1&&lbAudioAx_80023710(f->x2150);
        fprintf(stderr,"M3D AUDIO GROUP %s tick=%u own=%d\n",ok?"PASS":"FAIL",t,f->x2150);if(!ok)abort();
    }
    if(t==915)ft_80088884(f);
    if(t==1000)fprintf(stderr,"M3D AUDIO CHECK COMPLETE kind=%d fighters=%d\n",f->kind,m3d_lab_count());
}
/* Native post-recovery fall, with original acceleration/gravity. The
 * fixture changes only the starting pose and then sends normal pad input. */
static void drift_probe_tick(unsigned tick) {
    if(!getenv("MELEE3D_NATIVE_DRIFT_CHECK")||tick<240)return;
    unsigned phase=(tick-240)/160,t=(tick-240)%160;if(phase>=4)return;
    static Vec3 start;static int state;
    HSD_GObj* g=Player_GetEntity(0);Fighter* f=g->user_data;
    if(!t) {
        sequence_ground(g,0);Vec3 p={819,10000,-732},floor;if(!m3d_DelfinoFloor(&p,&floor))abort();
        p=floor;p.y+=180;
        f->cur_pos=f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=p;
        f->self_vel=f->x8c_kb_vel=(Vec3){0};f->gr_vel=0;f->facing_dir=phase%2?-1:1;
        m3d_SetLane(f,phase%2?-1:1,0);m3d_CameraSetYaw(0);
        ftCommon_8007D5D4(f);ftCo_80096900(g,0,1,0,1,10);
        if(f->kind>=33) {
            const char* name=f->kind==39?(phase<2?"SpecialHi_Exhaust_Phys":"SpecialHi_Cancel_Phys"):
                f->kind==36?"SpecialHi_Fall_Phys":f->kind==33?"SpecialHiFall_Phys":NULL;
            if(name) {
                uint32_t target=m3d_vm_symbol(f->kind-33,name),table=m3d_vm_slot(f->kind-33,3);int found=-1;
                for(unsigned i=0;i<(m3d_vm_symbol_end(f->kind-33,table)-table)/32;i++)if(m3d_vm_read32(table+i*32+20)==target){found=i;break;}
                if(found<0)abort();
                Fighter_ChangeMotionState(g,f->x18+found,0,0,1,0,NULL);
            }
        }
        start=p;state=f->motion_id;HSD_JObjSetTranslate(g->hsd_obj,&p);
    }
    if(t==65) {
        float lx,lz;m3d_GetLane(f,&lx,&lz);float dz=f->cur_pos.z-start.z;
        bool ok=isfinite(dz)&&dz>8&&f->cur_pos.y<start.y;
        fprintf(stderr,"M3D DRIFT %s kind=%d phase=%u state=%d end=%d dz=%.3f drop=%.3f lane=%.3f,%.3f\n",ok?"PASS":"FAIL",f->kind,phase,state,f->motion_id,dz,start.y-f->cur_pos.y,lx,lz);
        if(!ok)abort();
    }
}

/* Opt-in staged scale references. Native rendering and collision stay active. */
static Vec3 atlas_focus;
static float atlas_radius=150;
static bool atlas_ready;
int m3d_lab_atlas_camera(HSD_CObj* camera) {
    const char* inspect=getenv("MELEE3D_NATIVE_INSPECT_CAMERA");
    if(inspect && m3d_GameplayCaptureActive()) {
        Vec3 eye,focus;char extra;
        if(sscanf(inspect,"%f %f %f %f %f %f %c",&eye.x,&eye.y,&eye.z,&focus.x,&focus.y,&focus.z,&extra)!=6 ||
           !isfinite(eye.x)||!isfinite(eye.y)||!isfinite(eye.z)||!isfinite(focus.x)||!isfinite(focus.y)||!isfinite(focus.z)||
           fabsf(eye.x-focus.x)+fabsf(eye.y-focus.y)+fabsf(eye.z-focus.z)<.01f) {
            fprintf(stderr,"M3D LAB FAIL inspection camera requires distinct finite eye/focus vectors\n");abort();
        }
        HSD_CObjSetEyePosition(camera,&eye);HSD_CObjSetInterest(camera,&focus);
        HSD_CObjSetFov(camera,45);HSD_CObjSetAspect(camera,4.0f/3.0f);
        HSD_CObjSetNear(camera,1);HSD_CObjSetFar(camera,16384);return 1;
    }
    const char* view=getenv("MELEE3D_NATIVE_ATLAS_VIEW");
    if(!m3d_GameplayCaptureActive() || !atlas_ready || !view || !strcmp(view,"gameplay"))return 0;
    float yaw=!strcmp(view,"reverse")?3.92699082f:.785398163f;
    float pitch=!strcmp(view,"front")?.35f:.615479709f;
    float dist=atlas_radius*2.9f+45;
    Vec3 eye={atlas_focus.x+sinf(yaw)*cosf(pitch)*dist,atlas_focus.y+sinf(pitch)*dist,atlas_focus.z+cosf(yaw)*cosf(pitch)*dist};
    HSD_CObjSetEyePosition(camera,&eye);HSD_CObjSetInterest(camera,&atlas_focus);
    HSD_CObjSetFov(camera,45);HSD_CObjSetAspect(camera,4.0f/3.0f);return 1;
}
int m3d_lab_atlas_ready(void) {
    static unsigned capture_tick;
    if(!capture_tick) {
        capture_tick=300;
        const char* value=getenv("MELEE3D_NATIVE_CAPTURE_TICK");
        if(value) {
            char* end;unsigned long tick=strtoul(value,&end,10);
            if(!*value||*end||tick<300||tick>216000) {
                fprintf(stderr,"M3D LAB FAIL capture tick must be300..216000\n");abort();
            }
            capture_tick=(unsigned)tick;
            fprintf(stderr,"M3D CAPTURE CLOCK requested_tick=%u\n",capture_tick);
        }
    }
    return fixture_ticks>=capture_tick;
}
/* Custom banks provide candidate anchors in native world units. This keeps
 * their staged inspection independent of the nine reference-stage surfaces. */
static int atlas_points(Vec3* points,int capacity) {
    const char* path=getenv("MELEE3D_NATIVE_ATLAS_POINTS");
    if(!path)return m3d_ReferenceAtlasPoints(points,capacity);
    FILE* f=fopen(path,"r");if(!f){fprintf(stderr,"M3D LAB FAIL atlas point file\n");abort();}
    int count=0;Vec3 p,floor;
    while(count<capacity && fscanf(f,"%f %f %f",&p.x,&p.y,&p.z)==3) {
        if(!isfinite(p.x)||!isfinite(p.y)||!isfinite(p.z)){fclose(f);abort();}
        p.y+=2;
        bool found=m3d_DelfinoActive()?m3d_DelfinoFloor(&p,&floor):m3d_ReferenceFloor(&p,&floor);
        if(found&&fabsf(p.y-2-floor.y)<1)points[count++]=floor;
    }
    if(!feof(f)){fprintf(stderr,"M3D LAB FAIL atlas point format/capacity\n");abort();}
    fclose(f);return count;
}
static void atlas_tick(unsigned tick) {
    if(!m3d_GameplayCaptureActive())return;
    if(m3d_PhotoState())exit(m3d_PhotoState()<0?2:0);
    /* Inspect unsupported/reference-free original stages without staging actors. */
    if(getenv("MELEE3D_NATIVE_CAPTURE_UNSTAGED"))return;
    if(tick==120 || (tick>=299 && getenv("MELEE3D_NATIVE_ATLAS_SNAPSHOT"))) {
        Vec3 candidates[1024],chosen[GM_MAX_PLAYERS];int n=atlas_points(candidates,1024),count=m3d_lab_count();
        if(n<count){fprintf(stderr,"M3D LAB FAIL atlas samples=%d fighters=%d\n",n,count);abort();}
        chosen[0]=candidates[0];float central=1e30f;
        for(int j=0;j<n;j++){Vec3 p=candidates[j];float d=p.x*p.x+p.z*p.z+.25f*p.y*p.y;if(d<central){central=d;chosen[0]=p;}}
        for(int i=1;i<count;i++) {
            float best=-1;int index=0;
            for(int j=0;j<n;j++) {
                float nearest=1e30f;
                for(int k=0;k<i;k++){Vec3 d={candidates[j].x-chosen[k].x,candidates[j].y-chosen[k].y,candidates[j].z-chosen[k].z};nearest=fminf(nearest,d.x*d.x+d.y*d.y+d.z*d.z);}
                if(nearest>best){best=nearest;index=j;}
            }
            chosen[i]=candidates[index];
        }
        Vec3 lo=candidates[0],hi=lo;
        for(int j=0;j<n;j++){lo.x=fminf(lo.x,candidates[j].x);lo.y=fminf(lo.y,candidates[j].y);lo.z=fminf(lo.z,candidates[j].z);hi.x=fmaxf(hi.x,candidates[j].x);hi.y=fmaxf(hi.y,candidates[j].y);hi.z=fmaxf(hi.z,candidates[j].z);}
        atlas_focus=(Vec3){(lo.x+hi.x)/2,(lo.y+hi.y)/2+8,(lo.z+hi.z)/2};
        atlas_radius=fmaxf(40,sqrtf((hi.x-lo.x)*(hi.x-lo.x)+(hi.y-lo.y)*(hi.y-lo.y)+(hi.z-lo.z)*(hi.z-lo.z))/2);atlas_ready=true;
        fprintf(stderr,"M3D ATLAS BOUNDS lo=%.3f,%.3f,%.3f hi=%.3f,%.3f,%.3f samples=%d\n",lo.x,lo.y,lo.z,hi.x,hi.y,hi.z,n);
        for(int i=0;i<count;i++) {
            HSD_GObj* g=Player_GetEntity(i);Fighter* f=g->user_data;Vec3 p=chosen[i];
            f->cur_pos=f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=p;
            f->self_vel=f->x8c_kb_vel=(Vec3){0};f->gr_vel=f->xF0_ground_kb_vel=0;
            m3d_SetLane(f,1,0);
            bool began=m3d_LocalBegin(f);Vec3 hit,normal;int line;u32 flags;
            if(!began || !mpCheckFloor(f->cur_pos.x,f->cur_pos.y+1,f->cur_pos.x,f->cur_pos.y-1,0,&hit,&line,&flags,&normal,-1,-1,-1,NULL,NULL)) {
                fprintf(stderr,"M3D LAB FAIL atlas grounding slot=%d\n",i);abort();
            }
            f->cur_pos=f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=hit;
            f->coll_data.floor.index=line;f->coll_data.floor.flags=flags;f->coll_data.floor.normal=normal;
            ftCommon_8007D7FC(f);ft_8008A2BC(g);m3d_LocalEnd(f,began);
            HSD_JObjSetTranslate(g->hsd_obj,&f->cur_pos);
            fprintf(stderr,"M3D ATLAS PLACED slot=%d kind=%d floor=%.3f,%.3f,%.3f\n",i,f->kind,chosen[i].x,chosen[i].y,chosen[i].z);
        }
        m3d_CameraSetYaw(0);
    }
    if(tick==299)for(int i=0;i<m3d_lab_count();i++) {
        Fighter* f=Player_GetEntity(i)->user_data;Vec3 floor,probe=f->cur_pos;probe.y+=2;
        bool valid=m3d_DelfinoActive()?m3d_DelfinoFloor(&probe,&floor):m3d_ReferenceFloor(&probe,&floor);
        fprintf(stderr,"M3D ATLAS ACTUAL slot=%d kind=%d pos=%.3f,%.3f,%.3f floor=%d height=%.3f\n",i,f->kind,f->cur_pos.x,f->cur_pos.y,f->cur_pos.z,valid,valid?f->cur_pos.y-floor.y:-9999);
    }
}

/* Opt-in original source traffic contact test: no direct hit/damage calls. */
static bool car_probe_space(Vec3* p) {
    const float offsets[5][2]={{0,0},{6,0},{-6,0},{0,6},{0,-6}};
    for(int i=0;i<5;i++) {
        Vec3 low={p->x+offsets[i][0],p->y+.1f,p->z+offsets[i][1]},high=low;high.y=p->y+24;
        if(!m3d_ReferenceOverlayBodyClear(p,&low,&high))return false;
    }
    return true;
}
static bool car_probe_ground(HSD_GObj* object,Vec3 p) {
    Fighter* f=object->user_data;Vec3 probe=p,floor;probe.y+=8;
    if(!m3d_ReferenceFloor(&probe,&floor)||fabsf(floor.y-p.y)>8||!m3d_ReferenceOverlayGroundAllowed(&floor)||!car_probe_space(&floor))return false;
    m3d_ExitLocal(f);f->cur_pos=f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=floor;
    f->self_vel=f->x8c_kb_vel=(Vec3){0};f->gr_vel=f->xF0_ground_kb_vel=0;
    m3d_SetLane(f,1,0);bool began=m3d_LocalBegin(f);Vec3 hit,normal;int line;u32 flags;
    bool found=began&&mpCheckFloor(f->cur_pos.x,f->cur_pos.y+1,f->cur_pos.x,f->cur_pos.y-1,0,&hit,&line,&flags,&normal,-1,-1,-1,NULL,NULL);
    if(found){f->cur_pos=f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=hit;f->coll_data.floor.index=line;f->coll_data.floor.flags=flags;f->coll_data.floor.normal=normal;ftCommon_8007D7FC(f);ft_8008A2BC(object);}
    m3d_LocalEnd(f,began);if(!found)return false;
    f->dmg.x1830_percent=0;Player_SetHUDDamage(f->player_idx,0);f->x1990=f->x1994=0;ftColl_8007B6EC(object);ftColl_8007B62C(object,0);ftColl_8007B0C0(object,HurtCapsule_Enabled);
    HSD_JObjSetTranslate(object->hsd_obj,&f->cur_pos);return true;
}
static void onett_car_probe_tick(void) {
    if(!getenv("MELEE3D_NATIVE_ONETT_CAR_PROBE")||!m3d_ReferenceOverlayActive())return;
    static int last=-1,ready,selected_source,passed;static HSD_GObj* selected;
    static float damage,knockback,control_damage;static unsigned mask;
    int phase=(m3d_match_frame-240)/150,offset=(m3d_match_frame-240)%150;
    if(m3d_match_frame<240||phase>=16)return;
    if(m3d_lab_count()!=2){fprintf(stderr,"M3D LAB FAIL car probe requires exactly two nonhuman actors\n");abort();}
    if(last!=phase){last=phase;ready=selected_source=0;selected=NULL;damage=knockback=control_damage=0;}
    HSD_GObj* a=Player_GetEntity(0);HSD_GObj* b=Player_GetEntity(1);
    if(!a||!b)return;
    if(Player_GetPlayerSlotType(0)!=Gm_PKind_Cpu||Player_GetPlayerSlotType(1)!=Gm_PKind_Cpu){fprintf(stderr,"M3D LAB FAIL car probe disallows human actors\n");abort();}
    Fighter* f=a->user_data;Fighter* c=b->user_data;int model=(phase%8)/2,reverse=phase%2,which=phase/8;
    if(!ready&&offset>=15&&offset<40) {
        HSD_GObj* original=Ground_GetMapGObj(3);
        for(HSD_GObj* object=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_ITEM];object;object=object->next) {
            Item* ip=object->user_data;if(ip->kind!=It_PKind_Random||ip->xDD4_itemVar.yaku.x2!=1)continue;
            Ground* gp=ip->xDD4_itemVar.yaku.x10;
            if(!gp||gp->map_id!=3||((original&&original->user_data==gp)?0:1)!=which)continue;
            HSD_JObj* root=ip->xDD4_itemVar.yaku.x4_u.x4;
            if(gp->u.onettcar.car_jobjs[model]!=root||(root->flags&JOBJ_HIDDEN)||ip->msid!=model+2)continue;
            float xs[4]={1.75f,-1.25f,2,-.25f},zs[4]={.125f,.125f,.125f,-.125f};
            Vec3 local={xs[model],0,zs[model]},center,origin,axis_local={1,0,0},axis;
            lb_8000B1CC(HSD_JObjGetChild(root),&local,&center);lb_8000B1CC(root,NULL,&origin);lb_8000B1CC(root,&axis_local,&axis);
            float dx=axis.x-origin.x,dz=axis.z-origin.z,length=hypotf(dx,dz),sign=reverse?1:-1;
            if(length<.001f)continue;dx*=sign/length;dz*=sign/length;
            Vec3 target={center.x+40*dx,center.y,center.z+40*dz},control=target;bool control_found=false;
            for(int side=0;side<4;side++) {
                float distances[4]={60,-60,80,-80};Vec3 candidate={target.x-dz*distances[side],target.y,target.z+dx*distances[side]},probe=candidate,floor;probe.y+=8;
                if(m3d_ReferenceFloor(&probe,&floor)&&fabsf(floor.y-candidate.y)<2&&m3d_ReferenceOverlayGroundAllowed(&floor)&&car_probe_space(&floor)) {control=floor;control_found=true;break;}
            }
            if(!control_found||!car_probe_ground(a,target)||!car_probe_ground(b,control))continue;
            selected=object;ready=1;HitCapsule* h=&ip->x5D4_hitboxes[0].hit;
            fprintf(stderr,"M3D CAR PROBE BEGIN phase=%d generator=%d model=%d reverse=%d item=%p state=%d held=%d hitbone_child=%d hit=%.3f,%.3f,%.3f radius=%.3f damage=%.1f victim=%.3f,%.3f,%.3f control=%.3f,%.3f,%.3f\n",phase,which,model,reverse,(void*)object,h->state,ip->xDC8_word.flags.x13,h->jobj==HSD_JObjGetChild(root),h->x4C.x,h->x4C.y,h->x4C.z,h->scale*ip->scl,h->damage,f->cur_pos.x,f->cur_pos.y,f->cur_pos.z,c->cur_pos.x,c->cur_pos.y,c->cur_pos.z);
            break;
        }
    }
    if(ready) {
        damage=fmaxf(damage,f->dmg.x1830_percent);control_damage=fmaxf(control_damage,c->dmg.x1830_percent);
        float kb=sqrtf(f->x8c_kb_vel.x*f->x8c_kb_vel.x+f->x8c_kb_vel.y*f->x8c_kb_vel.y+f->x8c_kb_vel.z*f->x8c_kb_vel.z);knockback=fmaxf(knockback,kb);
        if(f->dmg.x1868_source==selected&&f->dmg.x1830_percent>0)selected_source=1;
    }
    if(offset==120) {
        bool ok=ready&&damage>0&&knockback>.01f&&selected_source&&control_damage==0;
        if(ok){passed++;mask|=1u<<phase;}
        fprintf(stderr,"M3D CAR PROBE %s phase=%d generator=%d model=%d reverse=%d ready=%d damage=%.2f knockback=%.4f exact_source=%d offroad_damage=%.2f passed=%d mask=%04x direct_damage_calls=0\n",ok?"PASS":"FAIL",phase,which,model,reverse,ready,damage,knockback,selected_source,control_damage,passed,mask);
    }
}

static void charge_probe_tick(unsigned tick) {
    if(!getenv("MELEE3D_NATIVE_CHARGE_CHECK")||tick<240)return;
    unsigned phase=(tick-240)/90,t=(tick-240)%90;if(phase>=8)return;
    static HSD_GObj* shot;static Vec3 start,expected;
    HSD_GObj* g=Player_GetEntity(0);Fighter* f=g->user_data;
    if(!t) {
        sequence_ground(g,0);Vec3 p={819,10000,-732},floor;if(!m3d_DelfinoFloor(&p,&floor))abort();
        p=floor;p.y+=80;
        f->cur_pos=f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=p;
        f->self_vel=f->x8c_kb_vel=(Vec3){0};f->gr_vel=0;f->facing_dir=phase%2?-1:1;
        ftCommon_8007D5D4(f);ftCo_Fall_Enter(g);m3d_SetLane(f,1,0);
        shot=it_802B55C8(g,&p,FtPart_RHandNb,It_Kind_Samus_Charge,f->facing_dir);
        if(!shot)abort();
        float yaw=phase*.785398163f;m3d_SetLane(f,cosf(yaw),sinf(yaw));m3d_PostMap(f);
        expected=(Vec3){cosf(yaw)*f->facing_dir,0,sinf(yaw)*f->facing_dir};
        it_802B56E4(shot,&p,f->facing_dir>0?0:3.141592653589793f,7,7);
        start=((Item*)shot->user_data)->pos;
    }
    if(t==10) {
        Item* ip=shot->user_data;Vec3 d={ip->pos.x-start.x,ip->pos.y-start.y,ip->pos.z-start.z};
        float along=d.x*expected.x+d.z*expected.z,across=fabsf(d.x*expected.z-d.z*expected.x);
        bool ok=along>10&&across<.01f&&fabsf(d.y)<.01f;
        fprintf(stderr,"M3D CHARGE %s phase=%u along=%.3f across=%.3f dy=%.3f\n",ok?"PASS":"FAIL",phase,along,across,d.y);
        if(!ok)abort();Item_8026A8EC(shot);shot=NULL;
    }
}

void m3d_lab_tick(void)
{
    static unsigned ticks;
    static unsigned damaged, moved;
    static float first_x[GM_MAX_PLAYERS], first_y[GM_MAX_PLAYERS];
    int i, present = 0, count = m3d_lab_count();
    if (!count) return;
    ++ticks;
    fixture_ticks=ticks;
    if(getenv("MELEE3D_NATIVE_PAUSE_QUIT_DEAD")&&ticks==120){
        HSD_GObj* g=Player_GetEntity(0);if(!g)abort();Player_SetStocks(0,1);ftCo_800D3BC8(g);
        fprintf(stderr,"M3D PAUSE QUIT eliminated human through native death\n");
    }
    if(getenv("MELEE3D_NATIVE_PAUSE_QUIT_DEAD")&&ticks==180){
        Fighter* viewed=m3d_CameraSubject();
        if(Player_GetStocks(0)>0||!viewed||viewed->player_idx==0)abort();
        fprintf(stderr,"M3D PAUSE QUIT spectating slot=%d\n",viewed->player_idx);
    }
    audio_probe_tick(ticks);
    atlas_tick(ticks);
    if(m3d_DelfinoActive()&&(ticks==120||ticks==480)) {
        HudIndex* hud=ifStatus_GetHUDInfo();int panels=0,human=-1,visible=-1;
        for(int slot=0;slot<GM_MAX_PLAYERS;slot++) {
            if(Player_GetPlayerSlotType(slot)==Gm_PKind_Human&&m3d_RoomIsViewer(slot))human=slot;
            if(hud->players[slot].HUD_parent_entity){panels++;visible=slot;}
        }
        if(!getenv("MELEE3D_NATIVE_CAPTURE_CHECK")&&(panels!=(human<0?0:1)||(human>=0&&visible!=human))){fprintf(stderr,"M3D LAB FAIL native human HUD panels=%d slot=%d expected=%d\n",panels,visible,human);abort();}
        HSD_GObj* entity=human>=0?Player_GetEntity(human):NULL;
        fprintf(stderr,"M3D PLAYER HUD CHECK tick=%u panels=%d slot=%d kind=%d frame=%.0f native=1\n",ticks,panels,human,entity?((Fighter*)entity->user_data)->kind:-1,human>=0?m3d_HudStockFrame(human):-1);
    }
    respawn_probe_tick(ticks);
    onett_car_probe_tick();
    area_probe_tick(ticks);
    ecb_invariance_tick(ticks);
    presentation_tick(ticks);
    stair_probe_tick(ticks);
    snap_probe_tick(ticks);
    island_probe_tick(ticks);
    coin_probe_tick(ticks);delfino_probe_tick(ticks);walljump_probe_tick(ticks);
    ceiling_probe_tick(ticks);
    ledge_probe_tick(ticks);
    rules_probe_tick(ticks);
    water_probe_tick(ticks);
    spectator_probe_tick(ticks);
    if(m3d_PhotoActive()) {
        if(m3d_PhotoState())exit(m3d_PhotoState()<0?2:0);
        for(int i=0;i<2;i++){Fighter* f=Player_GetEntity(i)->user_data;f->invisible=true;}
    }
    tether_polish_tick(ticks);cloth_polish_tick(ticks);
    capture_probe_tick(ticks);
    live_capture_audit(ticks);
    world_controls_tick(ticks);
    combat_probe_tick(ticks);
    recovery_tick(ticks);
    drift_probe_tick(ticks);
    charge_probe_tick(ticks);
    impact_effect_probe_tick(ticks);
    article_probe_tick(ticks);
    thunder_probe_tick(ticks);
    down_polish_tick(ticks);
    platform_tick(ticks);
    sequence_tick(ticks);
    if(getenv("MELEE3D_NATIVE_STAGE_PROBE") && (ticks==120 || ticks==480))m3d_ReferenceValidate(ticks);
    if(ticks==120 && getenv("MELEE3D_NATIVE_KO_TEST")) {
        struct { unsigned long long before; Item_FtTrack track; unsigned long long after; } guard={0};
        guard.before=guard.after=0x4d33444341504143ULL;
        ftCo_80098634(&guard.track);
        unsigned n=0;
        for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];g;g=g->next,++n) {
            Fighter* f=g->user_data;
            if(n>=2*GM_MAX_PLAYERS || memcmp(&guard.track.ft_pos_arr[n],&f->cur_pos,sizeof(Vec3)))abort();
        }
        if(n<(unsigned)count || guard.track.count!=n || guard.before!=0x4d33444341504143ULL || guard.after!=guard.before)abort();
        fprintf(stderr,"M3D LAB ITEM TRACK PASS fighters=%u capacity=%u guards=2\n",n,2*GM_MAX_PLAYERS);
    }
    for (i = 0; i < count; ++i) {
        HSD_GObj* object = Player_GetEntity(i);
        Fighter* fp;
        if (!object) continue;
        fp = object->user_data;
        if(getenv("MELEE3D_NATIVE_DELFINO")&&ticks==120&&Player_GetPlayerSlotType(i)==Gm_PKind_Cpu) {
            if(fp->cpu.level!=m3d_MatchCpuLevel()){fprintf(stderr,"M3D LAB FAIL CPU difficulty slot=%d level=%d\n",i,fp->cpu.level);abort();}
            fprintf(stderr,"M3D CPU DIFFICULTY slot=%d level=%d\n",i,fp->cpu.level);
        }
        if(selected_lineup && ticks==1) {
            if(fp->kind!=expected_lineup[i])m3d_vm_fail("Loaded fighter differs from chosen roster");
            fprintf(stderr,"M3D ROSTER LOADED slot=%d kind=%d\n",i,fp->kind);
        }
        if(varied_costumes && fp && (ticks==120 || ticks==480)) {
            if(fp->costume_id!=expected_costumes[i])m3d_vm_fail("Live fighter costume differs from selected outfit");
            fprintf(stderr,"M3D COSTUME LIVE tick=%u slot=%d kind=%d color=%u\n",ticks,i,fp->kind,fp->costume_id);
        }
        if (!fp || fp->player_idx != i || !isfinite(fp->cur_pos.x) || !isfinite(fp->cur_pos.y)) {
            fprintf(stderr, "M3D LAB FAIL identity_position slot=%d tick=%u\n", i, ticks);
            abort();
        }
        ++present;
        if(getenv("MELEE3D_NATIVE_SPECIAL")) {
            unsigned character,move;
            const char* value=getenv("MELEE3D_NATIVE_SPECIAL");
            if(sscanf(value,"%u:%u",&character,&move)!=2 || character>=7 || move>=8)abort();
            if(i==(int)(4+character)) {
                if(ticks==240) {
                    HSD_GObjEvent entries[8]={ftData_SpecialN[fp->kind],ftData_SpecialAirN[fp->kind],
                        ftData_SpecialS[fp->kind],ftData_SpecialAirS[fp->kind],ftData_SpecialHi[fp->kind],
                        ftData_SpecialAirHi[fp->kind],ftData_SpecialLw[fp->kind],ftData_SpecialAirLw[fp->kind]};
                    fp->cur_pos.x=0; fp->cur_pos.y=(move&1) ? 45 : 0;
                    fp->cur_pos.z=0; fp->prev_pos=fp->cur_pos; fp->coll_data.cur_pos=fp->cur_pos;
                    fp->coll_data.prev_pos=fp->cur_pos;
                    fp->self_vel=(Vec3){0,0,0}; fp->gr_vel=0;
                    if(move&1) { ftCommon_8007D5D4(fp); ftCo_Fall_Enter(object); }
                    else { ftCommon_8007D7FC(fp); ft_8008A2BC(object); }
                    fprintf(stderr,"M3D LIVE SPECIAL BEGIN kind=%d move=%u slot=%d\n",fp->kind,move,i);
                    if(!entries[move])abort();
                    entries[move](object);
                    fprintf(stderr,"M3D LIVE SPECIAL ENTER kind=%d move=%u state=%d\n",fp->kind,move,fp->motion_id);
                }
                if(ticks==480)fprintf(stderr,"M3D LIVE SPECIAL OBSERVED kind=%d move=%u state=%d\n",fp->kind,move,fp->motion_id);
            }
        }
        if (count>=8 && getenv("MELEE3D_NATIVE_KO_TEST") &&
            ((ticks==240 && i==count-1) || (ticks==600 && i==count-2) || (ticks==840 && i==count-3))) {
            // Fixture: enter the real KO path with controlled attribution.
            int attacker=ticks==240 ? 6 : ticks==600 ? count-1 : Gm_Player_Other;
            int before=attacker==Gm_Player_Other ? Player_GetSelfDestructs(i) : Player_GetKOsByPlayerIndex(attacker,i);
            fp->dmg.x18c4_source_ply=attacker;
            ftCo_800D3BC8(object);
            if ((attacker==Gm_Player_Other ? Player_GetSelfDestructs(i) : Player_GetKOsByPlayerIndex(attacker,i))!=before+1) {
                fprintf(stderr,"M3D LAB FAIL KO credit attacker=%d victim=%d\n",attacker,i); abort();
            }
            fprintf(stderr,"M3D LAB KO CREDIT PASS attacker=%d victim=%d\n",attacker,i);
        }
        if (ticks==180 && fp->kind==Ft_Kind_Kirby && getenv("MELEE3D_NATIVE_KIRBY_COPY")) {
            if(!strcmp(getenv("MELEE3D_NATIVE_KIRBY_COPY"),"all")) {
                for(int target=33;target<40;target++) {
                    ftKb_SpecialN_800EEC34(target,0,1);
                    ftKb_SpecialN_800EED50(target,0);
                    ftKb_SpecialN_800F1BAC(object,target,false);
                    if(fp->u.kb.hat.kind!=Ft_Kind_Kirby)m3d_vm_fail("Unsupported Kirby copy did not retain inhale");
                    fprintf(stderr,"M3D KIRBY ADDED COPY SAFE target=%d hat=%d\n",target,fp->u.kb.hat.kind);
                }
            }
            // Fixture: exercise real copy-model setup and its texture callback immediately.
            ftKb_SpecialN_800F1BAC(object,Ft_Kind_Donkey,false);
            ftKb_Init_OnKnockbackExit(object);
            fprintf(stderr,"M3D LAB KIRBY COPY PASS kind=%d hat_textures=%u\n",fp->u.kb.hat.kind,fp->u.kb.x44.n_costume_tobjs);
        }
        if (ticks == 180) {
            first_x[i] = fp->cur_pos.x;
            first_y[i] = fp->cur_pos.y;
        }
        if (ticks > 180 && (fabsf(fp->cur_pos.x-first_x[i]) > 5 || fabsf(fp->cur_pos.y-first_y[i]) > 5))
            moved |= 1u << i;
        if (Player_GetDamage(i) > 0) damaged |= 1u << i;
        if (ticks % 120 == 0)
            fprintf(stderr, "M3D LAB FRAME tick=%u slot=%d kind=%d x=%.3f y=%.3f damage=%.1f falls=%d\n",
                    ticks, i, fp->kind, fp->cur_pos.x, fp->cur_pos.y, (double)Player_GetDamage(i), Player_GetFalls(i));
    }
    if (ticks % 120 == 0)
        fprintf(stderr, "M3D LAB SUMMARY tick=%u present=%d moved=%u damaged=%u\n", ticks, present,
                __builtin_popcount(moved), __builtin_popcount(damaged));
}

/* Render each native animated shadow separately. Putting sixteen shadow
 * textures on every stage material exceeds GX's sixteen TEV stages. One
 * texture per multiplicative draw keeps every fighter's silhouette. */
static void m3d_lab_shadows(HSD_GObj* object, intptr_t pass)
{
    int i, j;
    const Vec3 vertices[4] = {{-85, .03f, -25}, {85, .03f, -25}, {85, .03f, 25}, {-85, .03f, 25}};
    const Vec3 octagon[8]={{-35.36f,.03f,-85.37f},{35.36f,.03f,-85.37f},{85.37f,.03f,-35.36f},{85.37f,.03f,35.36f},{35.36f,.03f,85.37f},{-35.36f,.03f,85.37f},{-85.37f,.03f,35.36f},{-85.37f,.03f,-35.36f}};
    const Vec3* surface=m3d_StageIs3D() ? octagon:vertices;
    int corners=m3d_StageIs3D() ? 8:4;
    (void)object;
    if (pass != 0 || !m3d_lab_count()) return;
    HSD_StateInvalidate(-1);
    HSD_StateInitTev();
    GXSetColorUpdate(GX_ENABLE); GXSetAlphaUpdate(GX_DISABLE);
    GXSetBlendMode(GX_BM_BLEND, GX_BL_ZERO, GX_BL_SRCCLR, GX_LO_NOOP);
    GXSetZMode(GX_ENABLE, GX_LEQUAL, GX_DISABLE);
    GXSetZCompLoc(GX_ENABLE); GXSetCullMode(GX_CULL_NONE);
    GXSetAlphaCompare(GX_ALWAYS, 0, GX_AOP_AND, GX_ALWAYS, 0);
    GXSetNumTexGens(1); GXSetNumTevStages(1); GXSetNumChans(1);
    GXSetChanCtrl(GX_COLOR0A0, GX_DISABLE, GX_SRC_REG, GX_SRC_VTX, 0, GX_DF_NONE, GX_AF_NONE);
    GXSetTexCoordGen(GX_TEXCOORD0, GX_TG_MTX2x4, GX_TG_TEX0, GX_IDENTITY);
    GXSetTevOrder(GX_TEVSTAGE0, GX_TEXCOORD0, GX_TEXMAP0, GX_COLOR0A0);
    GXSetTevOp(GX_TEVSTAGE0, GX_REPLACE);
    GXClearVtxDesc();
    GXSetVtxAttrFmt(GX_VTXFMT0, GX_VA_POS, GX_POS_XYZ, GX_F32, 0);
    GXSetVtxAttrFmt(GX_VTXFMT0, GX_VA_CLR0, GX_CLR_RGBA, GX_RGBA8, 0);
    GXSetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX0, GX_TEX_ST, GX_F32, 0);
    GXSetVtxDesc(GX_VA_POS, GX_DIRECT); GXSetVtxDesc(GX_VA_CLR0, GX_DIRECT); GXSetVtxDesc(GX_VA_TEX0, GX_DIRECT);
    GXLoadPosMtxImm(HSD_CObjGetViewingMtxPtrDirect(HSD_CObjGetCurrent()), 0);
    GXSetCurrentMtx(0);
    for (i=0; i<m3d_lab_count(); ++i) {
        HSD_GObj* fighter=Player_GetEntity(i);
        LbShadow* lbs=fighter ? ftLib_GetShadow(fighter) : NULL;
        HSD_Shadow* shadow=lbs ? lbs->shadow : NULL;
        HSD_ImageDesc* image=shadow && shadow->texture ? shadow->texture->imagedesc : NULL;
        GXTexObj texture;
        if (!shadow || !shadow->active || !image || !image->image_ptr) continue;
        GXInitTexObj(&texture, DP(void, image->image_ptr), image->width, image->height, image->format, GX_CLAMP, GX_CLAMP, GX_FALSE);
        GXInitTexObjLOD(&texture, GX_LINEAR, GX_LINEAR, 0, 0, 0, GX_FALSE, GX_FALSE, GX_ANISO_1);
        GXLoadTexObj(&texture, GX_TEXMAP0);
        if(m3d_DelfinoActive()) {m3d_DelfinoShadow(shadow);continue;}
        if(m3d_ReferenceActive()) {
            m3d_ReferenceShadow(shadow);
            continue;
        }
        GXBegin(m3d_StageIs3D() ? GX_TRIANGLEFAN:GX_QUADS, GX_VTXFMT0, corners);
        for (j=0; j<corners; ++j) {
            const Vec3* p=&surface[j];
            float u=shadow->texture->mtx[0][0]*p->x+shadow->texture->mtx[0][1]*p->y+shadow->texture->mtx[0][2]*p->z+shadow->texture->mtx[0][3];
            float v=shadow->texture->mtx[1][0]*p->x+shadow->texture->mtx[1][1]*p->y+shadow->texture->mtx[1][2]*p->z+shadow->texture->mtx[1][3];
            GXPosition3f32(p->x,p->y,p->z); GXColor4u8(255,255,255,255); GXTexCoord2f32(u,v);
        }
        GXEnd();
    }
    HSD_StateInvalidate(-1);
}

void m3d_lab_graphics(void)
{
    HSD_GObj* object;
    if (!m3d_lab_count()) return;
    object=GObj_Create(HSD_GOBJ_CLASS_UI, 15, 0);
    GObj_SetupGXLink(object, m3d_lab_shadows, 3, 250);
}
