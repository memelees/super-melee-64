#include "m3d_control_labels.h"
#include <cassert>
#include <cstdio>
int main() {
    assert(m3d_ButtonLabel(SDL_GAMEPAD_TYPE_PS4,SDL_GAMEPAD_BUTTON_SOUTH)=="Cross");
    assert(m3d_ButtonLabel(SDL_GAMEPAD_TYPE_PS5,SDL_GAMEPAD_BUTTON_WEST)=="Square");
    assert(m3d_ButtonLabel(SDL_GAMEPAD_TYPE_XBOXONE,SDL_GAMEPAD_BUTTON_SOUTH)=="A");
    assert(m3d_ButtonLabel(SDL_GAMEPAD_TYPE_NINTENDO_SWITCH_PRO,SDL_GAMEPAD_BUTTON_SOUTH)=="B");
    assert(m3d_ButtonLabel(SDL_GAMEPAD_TYPE_NINTENDO_SWITCH_PRO,SDL_GAMEPAD_BUTTON_EAST)=="A");
    assert(m3d_ButtonLabel(SDL_GAMEPAD_TYPE_PS4,SDL_GAMEPAD_BUTTON_LEFT_SHOULDER)=="L1");
    assert(m3d_ButtonLabel(SDL_GAMEPAD_TYPE_XBOXONE,SDL_GAMEPAD_BUTTON_RIGHT_SHOULDER)=="RB");
    assert(m3d_AxisLabel(SDL_GAMEPAD_TYPE_PS5,SDL_GAMEPAD_AXIS_LEFT_TRIGGER)=="L2");
    assert(m3d_AxisLabel(SDL_GAMEPAD_TYPE_NINTENDO_SWITCH_PRO,SDL_GAMEPAD_AXIS_RIGHT_TRIGGER)=="ZR");
    assert(m3d_AxisLabel(SDL_GAMEPAD_TYPE_XBOX360,SDL_GAMEPAD_AXIS_RIGHT_TRIGGER)=="RT");
    puts("Controller labels PASS: PlayStation, Xbox, Nintendo positions and modifiers");
}
