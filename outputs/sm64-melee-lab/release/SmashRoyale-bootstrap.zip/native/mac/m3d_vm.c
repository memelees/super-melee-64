/* SPDX-License-Identifier: GPL-3.0-or-later
 * Original m-ex modules in a separate explicit guest address space. */
#include "gw.h"
#include "gw_ppc.h"
#include "gw_mex_ftfunction.h"
#include "m3d_vm.h"
#include "m3d_native_calls.h"
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#undef memcpy
#undef memset
#undef memcmp

extern uint32_t m3d_ppc_pc(void);
static gw_ftfunction modules[7];
static uint32_t fighter_data[7];
static gw_ftfunction item_modules[7][16];
static unsigned item_counts[7],item_states[7][16];
static unsigned active_index;
static uint32_t active_function;
static unsigned call_depth;
static const uint32_t mexdata=0x80a00000;
static uint32_t metadata_root;
static struct { uint32_t base,size; int freed; } allocations[256];
static unsigned allocation_count;
static uint32_t heap_top=0x80f00000;
uint32_t m3d_vm_alloc(uint32_t size)
{
    uint32_t base=heap_top,aligned;
    if(!size || size>0x100000 || allocation_count==256)gw_panic("Invalid/exhausted guest allocation");
    aligned=(size+31)&~31u;
    if((uint64_t)heap_top+aligned>0x81f00000)gw_panic("Guest allocation arena exhausted");
    heap_top+=aligned;
    m3d_guest_region(base,size);
    m3d_guest_memset((void*)(uintptr_t)base,0,size);
    allocations[allocation_count].base=base; allocations[allocation_count++].size=size;
    return base;
}
void m3d_vm_free(uint32_t address)
{
    unsigned i;
    if(!address)return;
    for(i=0;i<allocation_count;++i)if(allocations[i].base==address)break;
    if(i==allocation_count || allocations[i].freed)gw_panic("Unknown/repeated guest allocation free");
    allocations[i].freed=1; m3d_guest_retire(address,allocations[i].size);
}
void gw_log(const char* fmt, ...)
{
    va_list ap; va_start(ap,fmt); vfprintf(stderr,fmt,ap); va_end(ap); fputc('\n',stderr);
}
void gw_panic(const char* fmt, ...)
{
    const char* symbol=gw_ftfunction_symbol_name(&modules[active_index],active_function);
    unsigned article;
    for(article=0;!symbol && article<item_counts[active_index];++article)
        symbol=gw_ftfunction_symbol_name(&item_modules[active_index][article],active_function);
    unsigned owner;
    for(owner=0;!symbol && owner<7;++owner) {
        symbol=gw_ftfunction_symbol_name(&modules[owner],active_function);
        for(article=0;!symbol && article<item_counts[owner];++article)symbol=gw_ftfunction_symbol_name(&item_modules[owner][article],active_function);
    }
    va_list ap;
    uint32_t pc=m3d_ppc_pc();
    const char* site=gw_ftfunction_symbol_name(&modules[active_index],pc);
    for(article=0;!site && article<item_counts[active_index];++article)site=gw_ftfunction_symbol_name(&item_modules[active_index][article],pc);
    for(owner=0;!site && owner<7;++owner) {
        site=gw_ftfunction_symbol_name(&modules[owner],pc);
        for(article=0;!site && article<item_counts[owner];++article)site=gw_ftfunction_symbol_name(&item_modules[owner][article],pc);
    }
    fprintf(stderr,"M3D LIVE FAIL module=%u function=0x%08x symbol=%s pc=%08x site=%s: ",active_index,active_function,symbol ? symbol : "?",pc,site ? site : "?");
    va_start(ap,fmt); vfprintf(stderr,fmt,ap); va_end(ap); fputc('\n',stderr); exit(2);
}
void m3d_vm_fail(const char* message) { gw_panic("%s",message); }
void gw_prof_begin(unsigned a,unsigned b) { (void)a; (void)b; }
void gw_prof_end(void) {}
void gw_prof_counter_detail(unsigned a,unsigned b,double value) { (void)a; (void)b; (void)value; }
int gw_Geno_DefinePPCProbe(uint32_t value) { (void)value; return 0; }
uint32_t gw_mex_bridge_lookup(uint32_t address,int* kind) { (void)address; if(kind)*kind=0; return 0; }
uint32_t gw_mex_bridge_guest_data(uint32_t address) { (void)address; return 0; }
int gw_mex_bridge_is_native_data(uint32_t address,uint32_t size) { (void)address; (void)size; return 0; }
/* The in-game runtime links the real Aurora GX FIFO functions. */
void* gw_DVDReadFileAlloc(const char* path,uint32_t* size)
{
    FILE* f=fopen(path,"rb"); void* data; long length;
    if(!f)return NULL;
    fseek(f,0,SEEK_END); length=ftell(f); rewind(f);
    if(length<32 || length>16*1024*1024) { fclose(f); return NULL; }
    data=malloc(length);
    if(!data || fread(data,1,length,f)!=(size_t)length) { free(data); fclose(f); return NULL; }
    fclose(f); *size=(uint32_t)length; return data;
}
static gw_ppc_native_fn unresolved(uint32_t address,void* context,gw_ppc_sig* signature)
{
    (void)context; (void)signature;
    gw_panic("Unbound native engine call 0x%08x",address); return NULL;
}
void m3d_vm_init(void)
{
    m3d_guest_init();
    m3d_guest_region(mexdata,0x6000);
    m3d_guest_region(0x81f00000,0x100000);
    gw_ppc_set_bridge(unresolved,NULL,0,0);
}
static uint32_t load_archive(const char* path,const char* symbol,uint32_t base,uint32_t maximum,uint32_t* data_size)
{
    uint32_t size, bytes, relocs, n;
    unsigned char* file;
    int32_t offset;
    file=gw_DVDReadFileAlloc(path,&size);
    if(!file)gw_panic("Cannot read local character archive %s",path);
    bytes=gw_r32(file+4); relocs=gw_r32(file+8);
    if(bytes>maximum || bytes>size-32 || (uint64_t)32+bytes+4ull*relocs>size)
        gw_panic("Character archive does not fit its bounded guest region");
    m3d_guest_region(base,bytes);
    m3d_guest_memcpy((void*)(uintptr_t)base,file+32,bytes);
    for(n=0;n<relocs;++n) {
        uint32_t at=gw_r32(file+32+bytes+4*n),value;
        if(at>bytes-4)gw_panic("Invalid character archive relocation");
        value=gw_r32((void*)(uintptr_t)(base+at));
        if(value>=bytes)gw_panic("Character archive pointer outside data section");
        gw_w32((void*)(uintptr_t)(base+at),base+value);
    }
    offset=gw_ftfunction_find_public(file,size,symbol);
    if(offset<0)gw_panic("Missing original fighter-data symbol %s",symbol);
    free(file);
    *data_size=bytes;
    return base+(uint32_t)offset;
}
void m3d_vm_load_metadata(const char* path)
{
    uint32_t size;
    if(metadata_root)gw_panic("Repeated metadata load");
    metadata_root=load_archive(path,"mexData",0x80900000,0x80000,&size);
}
uint32_t m3d_vm_metadata(void) { return metadata_root; }
/* Article blobs use the same instruction relocations as ftFunction. Keep
 * their original archive-relative addresses, including a valid IRT at offset
 * zero and older MexTK blobs whose codeSize must be recovered from layout.
 * Loader semantics adapted from GD pc-port f5662df (GPL-2.0-or-later). */
static void load_items(unsigned index,const char* path,uint32_t base,uint32_t bytes)
{
    uint32_t length,n,top,count;
    unsigned char* file=gw_DVDReadFileAlloc(path,&length);
    int32_t pub;
    if(!file)gw_panic("Cannot read article archive");
    pub=gw_ftfunction_find_public(file,length,"itFunction");
    if(pub<0) { free(file); return; }
    top=(uint32_t)pub;
    if(top>bytes-4)gw_panic("Article array outside archive");
    count=gw_r32(file+32+top);
    if(count>16 || (uint64_t)top+4+count*4ull>bytes)gw_panic("Invalid article count/extent");
    item_counts[index]=count;
    for(n=0;n<count;++n) {
        uint32_t art=gw_r32(file+32+top+4+n*4),code,irt,ni,frt,nf,size,ns,syms,i;
        gw_ftfunction* out=&item_modules[index][n];
        if(!art)continue;
        if(art>bytes-32)gw_panic("Article MEXFunction outside archive");
        code=gw_r32(file+32+art); irt=gw_r32(file+36+art); ni=gw_r32(file+40+art);
        frt=gw_r32(file+44+art); nf=gw_r32(file+48+art); size=gw_r32(file+52+art);
        ns=gw_r32(file+56+art); syms=gw_r32(file+60+art);
        if(code>=bytes || (uint64_t)irt+ni*8ull>bytes || nf>15 ||
           (uint64_t)frt+nf*8ull>bytes || ns>4096 || (uint64_t)syms+ns*12ull>bytes)
            gw_panic("Invalid article relocation/symbol extent");
        if(!size) {
            uint32_t others[4]={art,irt,frt,syms};
            uint32_t bound=gw_ftfunction_code_bound(file,length,code,others,4);
            uint32_t need=gw_ftfunction_reloc_extent(file,length,irt,ni);
            if(bound<=code || !need || bound-code<need)gw_panic("Cannot recover article code size");
            size=bound-code;
        }
        if(size>bytes-code)gw_panic("Article code exceeds archive");
        /* Start from pristine bytes: the HSD relocation pass may touch words
         * inside a blob that the MEX instruction pass then owns. */
        m3d_vm_copy_in(base+code,file+32+code,size);
        if(gw_ftfunction_reloc(file,length,irt,ni,base+code,size))gw_panic("Article instruction relocation failed");
        out->code_base=base+code; out->code_size=size;
        out->symbols=calloc(ns,sizeof *out->symbols); out->symbol_count=ns;
        if(ns && !out->symbols)gw_panic("Cannot allocate article symbols");
        for(i=0;i<ns;++i) {
            uint32_t at=syms+i*12,start=gw_r32(file+32+at),end=gw_r32(file+36+at),name=gw_r32(file+40+at);
            const unsigned char* zero;
            if(start>=end || end>size || name>=bytes || !(zero=memchr(file+32+name,0,bytes-name)))
                gw_panic("Invalid article debug symbol");
            out->symbols[i].start=base+code+start; out->symbols[i].end=base+code+end;
            size_t name_length=(size_t)(zero-(file+32+name));
            char* symbol_name=malloc(name_length+1);
            if(!symbol_name)gw_panic("Cannot allocate article symbol name");
            memcpy(symbol_name,file+32+name,name_length);symbol_name[name_length]=0;
            out->symbols[i].name=symbol_name;
        }
        for(i=0;i<nf;++i) {
            uint32_t slot=gw_r32(file+32+frt+i*8),off=gw_r32(file+36+frt+i*8),j;
            if(slot>=15 || off>=size)gw_panic("Invalid article logic slot");
            for(j=0;j<i;++j)if(out->overrides[j].slot==slot)gw_panic("Repeated article logic slot");
            out->overrides[i].slot=slot; out->overrides[i].target=base+code+off;
        }
        out->override_count=nf;
        {
            uint32_t states=m3d_vm_article(index,n,0),end=base+code+size;
            if(!states)gw_panic("Custom article has no state table");
            for(i=0;i<nf;++i)if(out->overrides[i].target>states && out->overrides[i].target<end)end=out->overrides[i].target;
            for(i=0;i<ns;++i)if(out->symbols[i].start==states) { end=out->symbols[i].end; break; }
            if(end<=states || (end-states)%16 || (end-states)/16>64)gw_panic("Invalid custom article state table extent");
            item_states[index][n]=(end-states)/16;
        }
        gw_ppc_add_code_range(base+code,base+code+size);
        gw_log("M3D LIVE ARTICLE MODULE owner=%u article=%u states=%u code=%08x size=%x",33+index,n,item_states[index][n],base+code,size);
    }
    free(file);
}
uint32_t m3d_vm_article(unsigned index,unsigned article,unsigned slot)
{
    unsigned i;
    if(index>=7 || article>=item_counts[index] || slot>=15)gw_panic("Article dispatch index outside module table");
    for(i=0;i<(unsigned)item_modules[index][article].override_count;++i)
        if(item_modules[index][article].overrides[i].slot==slot)return item_modules[index][article].overrides[i].target;
    return 0;
}
unsigned m3d_vm_article_states(unsigned index,unsigned article)
{
    if(index>=7 || article>=item_counts[index])gw_panic("Article state-count index outside module table");
    return item_states[index][article];
}
void m3d_vm_load(unsigned index,const char* path,const char* symbol)
{
    uint32_t base=0x80b00000+index*0x80000,bytes;
    if(index>=7 || modules[index].code_base)gw_panic("Invalid/repeated module load");
    fighter_data[index]=load_archive(path,symbol,base,0x80000,&bytes);
    if(gw_ftfunction_load_in_archive(path,27+index,base,bytes,mexdata,&modules[index]))
        gw_panic("Original character module load failed");
    gw_ppc_add_code_range(modules[index].code_base,modules[index].code_base+modules[index].code_size);
    load_items(index,path,base,bytes);
}
void gw_Mex_NoteGuestCodeInstalled(void) {}
uint32_t m3d_vm_slot(unsigned index,unsigned slot)
{
    unsigned i;
    if(index>=7 || slot>=46)gw_panic("Invalid character dispatch index");
    for(i=0;i<modules[index].override_count;++i)
        if(!modules[index].overrides[i].is_func_addr && modules[index].overrides[i].slot==slot)
            return modules[index].overrides[i].target;
    return 0;
}
uint32_t m3d_vm_symbol(unsigned index,const char* name)
{
    unsigned i;
    if(index>=7)gw_panic("Invalid character symbol index");
    for(i=0;i<modules[index].symbol_count;++i)
        if(!strcmp(modules[index].symbols[i].name,name))return modules[index].symbols[i].start;
    return 0;
}
uint32_t m3d_vm_symbol_end(unsigned index,uint32_t address)
{
    unsigned i;
    if(index>=7)gw_panic("Invalid original symbol range index");
    for(i=0;i<modules[index].symbol_count;++i)
        if(modules[index].symbols[i].start==address)return modules[index].symbols[i].end;
    gw_panic("Original motion table has no exact symbol range"); return 0;
}
uint32_t m3d_vm_data(unsigned index) { if(index>=7)gw_panic("Invalid character data index"); return fighter_data[index]; }
static void require_guest(uint32_t address,size_t size) {
    if(address<0x80000000u || (uint64_t)address+size>UINT64_C(0x80000000)+gw_mem1_size)
        gw_panic("VM access outside the isolated guest namespace");
}
uint32_t m3d_vm_read32(uint32_t address) { require_guest(address,4);return gw_r32((void*)(uintptr_t)address); }
void m3d_vm_write32(uint32_t address,uint32_t value) { require_guest(address,4);gw_w32((void*)(uintptr_t)address,value); }
void m3d_vm_copy_in(uint32_t address,const void* source,size_t size) { require_guest(address,size);m3d_guest_memcpy((void*)(uintptr_t)address,source,size); }
void m3d_vm_copy_out(void* destination,uint32_t address,size_t size) { require_guest(address,size);m3d_guest_memcpy(destination,(void*)(uintptr_t)address,size); }
static uint32_t module_call(unsigned index,uint32_t function,const uint32_t* args,unsigned count,int dispatch)
{
    unsigned previous=active_index; uint32_t previous_function=active_function,result;
    gw_ppc_ctx native={0};
    unsigned i;
    if(index>=7 || !function)gw_panic("Invalid original module callback");
    if(count>8)gw_panic("Original callback exceeds its register argument contract");
    if(call_depth>=12)gw_panic("Original callback nesting exhausted its guest-stack budget");
    active_index=index; active_function=function;
    ++call_depth;
    for(i=0;i<count;++i)native.gpr[3+i]=args[i];
    /* Motion/callback tables may retain an original engine helper directly.
     * Such entries use the same checked ABI as calls made inside PPC code. */
    if(dispatch && m3d_native_invoke(function,&native))result=native.gpr[3];
    else result=gw_ppc_call(function,args,count,mexdata,0x81ff0000-0x10000*(call_depth-1));
    --call_depth;
    active_index=previous; active_function=previous_function; return result;
}

uint32_t m3d_vm_call(unsigned index,uint32_t function,const uint32_t* args,unsigned count)
{ return module_call(index,function,args,count,1); }
/* Enter the checked original body behind a registered spatial adapter. Calls
 * made by that body still pass through the ordinary native ABI bindings. */
uint32_t m3d_vm_call_original(unsigned index,uint32_t function,const uint32_t* args,unsigned count)
{ return module_call(index,function,args,count,0); }
