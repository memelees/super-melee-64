/* SPDX-License-Identifier: GPL-3.0-or-later
 * Logical network pads are independent of the four physical controllers.
 * Each peer renders its own camera. The sender's camera basis accompanies
 * its input so another peer never interprets it through the wrong camera.
 */
#include "m3d_room.h"
#include "world/m3d.h"
#include <melee/ft/types.h>
#include <melee/gm/types.h>
#include <melee/it/types.h>
#include <melee/pl/player.h>
#include <sysdolphin/baselib/controller.h>
#include <sysdolphin/baselib/gobj.h>
#include <sysdolphin/baselib/random.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static HSD_PadStatus previous[32];
static float input_yaw[32];
static uint8_t received[32*12];
static HSD_PadStatus master_previous[4];
static int have_inputs;
int m3d_RoomIsViewer(int slot) {
    return m3d_room_enabled()?slot==m3d_room_local():Player_GetPlayerSlotType(slot)==Gm_PKind_Human;
}
float m3d_RoomInputYaw(int slot,float fallback) {
    return m3d_room_enabled()&&slot>=0&&slot<m3d_room_humans()?input_yaw[slot]:fallback;
}
void m3d_RoomSetup(StartMeleeData* start) {
    if(!m3d_room_enabled())return;
    int n=m3d_room_humans(), count=atoi(getenv("MELEE3D_NATIVE_LAB"));
    if(n>count){fprintf(stderr,"M3D ROOM FAIL more humans than fighters\n");exit(3);}
    for(int i=0;i<n;i++){
        start->players[i].slot_type=Gm_PKind_Human;
        start->players[i].slot=0; /* Physical menu/rumble APIs remain four-port. */
    }
    fprintf(stderr,"M3D ROOM SETUP humans=%d fighters=%d viewer=%d\n",n,count,m3d_room_local());
}
static uint32_t mix(uint32_t h,const void* data,size_t n) {
    const unsigned char* p=data;while(n--)h=(h^*p++)*16777619u;return h;
}
unsigned m3d_WorldChecksum(void) {
    uint32_t h=2166136261u;
    if(!m3d_StageIs3D())return h;
    for(int i=0;i<GM_MAX_PLAYERS;i++){
        HSD_GObj* object=Player_GetEntity(i);
        h=mix(h,&i,sizeof i);int present=object!=NULL;h=mix(h,&present,sizeof present);
        if(!object)continue;Fighter* fp=object->user_data;
#define HASH(field) h=mix(h,&fp->field,sizeof fp->field)
        HASH(kind);HASH(motion_id);HASH(cur_pos);HASH(self_vel);HASH(x8c_kb_vel);
        HASH(facing_dir);HASH(cur_anim_frame);HASH(dmg.x1830_percent);HASH(ground_or_air);
#undef HASH
        float lx=0,lz=0;m3d_GetLane(fp,&lx,&lz);h=mix(h,&lx,sizeof lx);h=mix(h,&lz,sizeof lz);
        int stocks=Player_GetStocks(i),coins=Player_GetCoins(i);h=mix(h,&stocks,sizeof stocks);h=mix(h,&coins,sizeof coins);
    }
    int items=0;
    for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_ITEM];g;g=g->next){
        Item* ip=g->user_data;if(!ip)continue;items++;
        h=mix(h,&ip->kind,sizeof ip->kind);h=mix(h,&ip->msid,sizeof ip->msid);
        h=mix(h,&ip->pos,sizeof ip->pos);h=mix(h,&ip->x40_vel,sizeof ip->x40_vel);
    }
    h=mix(h,&items,sizeof items);unsigned party=m3d_PartyChecksum();h=mix(h,&party,sizeof party);
    return h;
}
static int8_t stick(float value) {return (int8_t)lrintf(fmaxf(-1,fminf(1,value))*127);}
void m3d_RoomSync(void) {
    if(!m3d_room_enabled())return;
    HSD_PadStatus* raw=&HSD_PadMasterStatus[0];uint8_t local[12]={0};
    HSD_PadStatus scripted={0};
    if(getenv("MELEE3D_ROOM_SCRIPT")){
        static unsigned tick;unsigned phase=tick++%240;
        if(m3d_StageIs3D()){
            scripted.nml_stickY=phase<140?1:0;
            scripted.nml_stickX=phase<140?(m3d_room_local()%2?.15f:-.15f):0;
            if(phase==145||phase==160)scripted.button=HSD_PAD_A;
            if(phase==180)scripted.button=HSD_PAD_X;
            if(phase==200){scripted.button=HSD_PAD_B|HSD_PAD_DPADUP;}
            if(phase>201&&phase<218&&m3d_room_local()%2==1){scripted.button|=HSD_PAD_R;scripted.nml_subStickY=.7f;}
            if(phase==220)scripted.nml_subStickX=m3d_room_local()%2?-1:1;
        }
        raw=&scripted;
    }
    unsigned button=raw->button&0x1f7f;local[0]=button>>8;local[1]=button;
    local[2]=(uint8_t)stick(raw->nml_stickX);local[3]=(uint8_t)stick(raw->nml_stickY);
    local[4]=(uint8_t)stick(raw->nml_subStickX);local[5]=(uint8_t)stick(raw->nml_subStickY);
    local[6]=(uint8_t)(fmaxf(0,fminf(1,raw->nml_analogL))*255);
    local[7]=(uint8_t)(fmaxf(0,fminf(1,raw->nml_analogR))*255);
    float yaw=fmodf(m3d_CameraGetYaw(),6.28318530718f);if(yaw<0)yaw+=6.28318530718f;
    uint16_t angle=(uint16_t)(yaw*(65536/6.28318530718f));local[8]=angle>>8;local[9]=angle;
    static unsigned finished_ticks;if(m3d_PartyRoundOver()&&++finished_ticks>=180)local[11]=1;
    uint32_t seed;m3d_room_exchange(local,m3d_WorldChecksum(),received,&seed);*HSD_RandSeedPtr=seed;have_inputs=1;
    for(int i=0;i<4;i++){
        HSD_PadStatus* pad=&HSD_PadMasterStatus[i];const uint8_t* p=received+12*i;
        memset(pad,0,sizeof *pad);if(i>=m3d_room_humans()){pad->err=PAD_ERR_NO_CONTROLLER;continue;}
        pad->button=p[0]*256u+p[1];pad->last_button=master_previous[i].button;
        pad->trigger=pad->button&~pad->last_button;pad->release=pad->last_button&~pad->button;pad->repeat=pad->trigger;
        pad->nml_stickX=(int8_t)p[2]/127.f;pad->nml_stickY=(int8_t)p[3]/127.f;
        pad->nml_subStickX=(int8_t)p[4]/127.f;pad->nml_subStickY=(int8_t)p[5]/127.f;
        pad->nml_analogL=p[6]/255.f;pad->nml_analogR=p[7]/255.f;master_previous[i]=*pad;
    }
}
void m3d_RoomPads(void) {
    if(!m3d_room_enabled()||!have_inputs)return;
    for(int i=0;i<m3d_room_humans();i++){
        const uint8_t* p=received+12*i;HSD_PadStatus* pad=&HSD_PadGameStatus[i];
        memset(pad,0,sizeof *pad);pad->button=p[0]*256u+p[1];pad->last_button=previous[i].button;
        pad->trigger=pad->button&~pad->last_button;pad->release=pad->last_button&~pad->button;pad->repeat=pad->trigger;
        pad->nml_stickX=(int8_t)p[2]/127.f;pad->nml_stickY=(int8_t)p[3]/127.f;
        pad->nml_subStickX=(int8_t)p[4]/127.f;pad->nml_subStickY=(int8_t)p[5]/127.f;
        pad->stickX=(int8_t)lrintf(pad->nml_stickX*80);pad->stickY=(int8_t)lrintf(pad->nml_stickY*80);
        pad->subStickX=(int8_t)lrintf(pad->nml_subStickX*80);pad->subStickY=(int8_t)lrintf(pad->nml_subStickY*80);
        pad->analogL=p[6];pad->analogR=p[7];pad->nml_analogL=p[6]/255.f;pad->nml_analogR=p[7]/255.f;
        pc_pad_game_raw_x[i]=pad->stickX;
        input_yaw[i]=(p[8]*256u+p[9])*(6.28318530718f/65536);previous[i]=*pad;
    }
}
