/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef M3D_NATIVE_CALLS_H
#define M3D_NATIVE_CALLS_H
#include <stdint.h>
struct gw_ppc_ctx;
enum M3dAbiType { M3D_VOID, M3D_U32, M3D_I32, M3D_F32, M3D_F64, M3D_SIZE, M3D_BUFFER, M3D_OBJECT,
                 M3D_U8, M3D_I8, M3D_U16, M3D_I16,
                 M3D_CONTEXT /* Explicit full-EABI adapter: one host context pointer, no guest register. */ };
struct M3dNativeCall {
    uint32_t guest_address;
    void (*function)(void);
    enum M3dAbiType result;
    unsigned argument_count;
    enum M3dAbiType arguments[16];
    /* BUFFER arguments: -1 = one byte, otherwise byte count is another U32
     * or SIZE argument. This bounds the entire access before native entry. */
    int buffer_length_argument[16];
    unsigned object_kinds[16];
    unsigned result_object_kind;
};
void m3d_native_register(const struct M3dNativeCall* call);
int m3d_native_is_bound(uint32_t address);
int m3d_native_invoke(uint32_t address, struct gw_ppc_ctx* cpu);
unsigned m3d_native_invocations(uint32_t address);
void m3d_native_sync(void (*before)(void), void (*after)(void));
void m3d_native_result_handler(uint32_t (*handler)(void*,unsigned));
void m3d_native_bind_object(uint32_t handle, void* pointer, unsigned kind);
void m3d_native_unbind_object(uint32_t handle);
void* m3d_native_object(uint32_t handle, unsigned kind);
uint32_t m3d_native_callback_encode_typed(void (*function)(void), unsigned kind, enum M3dAbiType result, unsigned count);
void (*m3d_native_callback_decode_typed(uint32_t address, unsigned kind, enum M3dAbiType result, unsigned count))(void);
uint32_t m3d_native_callback_encode(void (*function)(void));
uint32_t m3d_native_callback_encode_kind(void (*function)(void), unsigned kind);
void (*m3d_native_callback_decode(uint32_t address))(void);
void (*m3d_native_callback_decode_kind(uint32_t address, unsigned kind))(void);

/* Exact void(object*) engine callbacks, or NULL for the interpreted path. */
void (*m3d_native_event_pointer(uint32_t address,unsigned kind))(void);
#endif
