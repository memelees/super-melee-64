/* SPDX-License-Identifier: GPL-3.0-or-later
 * Bounded live metadata with fresh external identities. Retiring a row removes
 * its hash entry; reusing native storage never revives an old guest handle. */
#ifndef M3D_SCENE_POOL_H
#define M3D_SCENE_POOL_H
#include <stdint.h>
#define M3D_SCENE_CAPACITY 2112
#define M3D_SCENE_BUCKETS 4096
typedef struct {void* pointer;uint32_t handle;unsigned kind,next;} M3dSceneRow;
typedef struct {M3dSceneRow rows[M3D_SCENE_CAPACITY];unsigned heads[M3D_SCENE_BUCKETS],count,live,peak,allocations,retirements;} M3dScenePool;
static inline unsigned m3d_scene_bucket(uint32_t handle){return ((handle>>8)*2654435761u)&(M3D_SCENE_BUCKETS-1);}
static inline M3dSceneRow* m3d_scene_pool_find(M3dScenePool* pool,uint32_t handle){
    for(unsigned n=pool->heads[m3d_scene_bucket(handle)];n;n=pool->rows[n-1].next)if(pool->rows[n-1].handle==handle)return &pool->rows[n-1];return 0;
}
static inline M3dSceneRow* m3d_scene_pool_pointer(M3dScenePool* pool,void* pointer,unsigned kind){
    for(unsigned i=0;i<pool->count;i++)if(pool->rows[i].pointer==pointer&&pool->rows[i].kind==kind)return &pool->rows[i];return 0;
}
static inline M3dSceneRow* m3d_scene_pool_acquire(M3dScenePool* pool,void* pointer,unsigned kind,uint32_t handle){
    if(!pointer||!kind||!handle||m3d_scene_pool_find(pool,handle)||m3d_scene_pool_pointer(pool,pointer,kind))return 0;
    unsigned i;for(i=0;i<pool->count&&pool->rows[i].pointer;i++){}if(i==M3D_SCENE_CAPACITY)return 0;
    if(i==pool->count)pool->count++;unsigned h=m3d_scene_bucket(handle);M3dSceneRow* row=&pool->rows[i];
    *row=(M3dSceneRow){pointer,handle,kind,pool->heads[h]};pool->heads[h]=i+1;pool->live++;pool->allocations++;if(pool->live>pool->peak)pool->peak=pool->live;return row;
}
static inline void m3d_scene_pool_release(M3dScenePool* pool,M3dSceneRow* row){
    unsigned* link=&pool->heads[m3d_scene_bucket(row->handle)];unsigned index=(unsigned)(row-pool->rows)+1;
    while(*link&&*link!=index)link=&pool->rows[*link-1].next;
    if(*link){*link=row->next;row->pointer=0;row->next=0;pool->live--;pool->retirements++;}
}
#endif
