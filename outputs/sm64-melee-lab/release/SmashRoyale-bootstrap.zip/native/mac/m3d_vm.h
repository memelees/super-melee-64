/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef M3D_VM_H
#define M3D_VM_H
#include <stddef.h>
#include <stdint.h>
void m3d_vm_init(void);
void m3d_vm_load_metadata(const char* path);
uint32_t m3d_vm_metadata(void);
void m3d_vm_load(unsigned index, const char* path, const char* data_symbol);
uint32_t m3d_vm_article(unsigned index, unsigned article, unsigned slot);
unsigned m3d_vm_article_states(unsigned index, unsigned article);
uint32_t m3d_vm_slot(unsigned index, unsigned slot);
uint32_t m3d_vm_symbol_end(unsigned index, uint32_t address);
uint32_t m3d_vm_symbol(unsigned index, const char* name);
uint32_t m3d_vm_data(unsigned index);
uint32_t m3d_vm_call(unsigned index, uint32_t function, const uint32_t* args, unsigned count);
uint32_t m3d_vm_call_original(unsigned index, uint32_t function, const uint32_t* args, unsigned count);
uint32_t m3d_vm_read32(uint32_t address);
void m3d_vm_write32(uint32_t address, uint32_t value);
void m3d_vm_copy_in(uint32_t address, const void* source, size_t size);
void m3d_vm_copy_out(void* destination, uint32_t address, size_t size);
void m3d_vm_fail(const char* message);
uint32_t m3d_vm_alloc(uint32_t size);
void m3d_vm_free(uint32_t address);
#endif
