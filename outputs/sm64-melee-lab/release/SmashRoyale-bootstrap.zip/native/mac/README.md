# Native Smash Royale

This is the current 32-fighter game implementation, including the Akaneia
bridge, shared 3D gameplay, third-person controls and Delfino Plaza.
Use `/Applications/Smash Royale.app` for normal play on this development Mac.
The [main guide](../../MELEE3D.md) describes the current player flow.

## Source and builds

Run commands from the repository root. The engine is pinned by `capacity.json`
and lives at `build/native-proof/melee-pc`. `capacity.patch` records tracked
engine changes. Owned modules here are copied into that checkout by the build.
Generated Akaneia contracts and donor stage banks use verified private inputs.
See [MacBook setup](../../docs/delfino/MACBOOK_SETUP.md) for prerequisites.

```sh
python3 tools/melee3d/native_mac.py build
python3 tools/melee3d/native_windows.py
python3 tools/melee3d/player_desktop.py build/player-desktop/<new-mac-candidate>
python3 tools/melee3d/player_windows_release.py build/player-desktop/<new-windows-candidate>
```

Choose a new output directory for each candidate. These commands produce local
preview packages; they do not publish a release. Windows x64 cross-builds and
CrossOver checks do not replace Windows GPU testing.

After editing tracked engine files, record the overlay before rebuilding:

```sh
python3 tools/melee3d/native_patch.py
python3 tools/melee3d/native_mac.py build
```

Builders verify the patch, owned modules, generators and executable hashes.
Do not discard the dirty engine checkout or commit extracted game assets.

## Shared runtime ownership

`world/m3d*.c` adapts the original gameplay to 3D. `m3d_akaneia.c` and the
bridge/VM adapters run added character code. `m3d_menu.c` and its includes reuse
the native Melee menus. `world/m3d_party.c` owns the large-match objectives,
results and human-only overhead names. Retail overhead marker models and their
projection/update callbacks are bypassed on the Plaza.

The retail respawn queue has 32 independent timers; `m3d_respawn.h` bounds its
six temporary stage anchors. Final Plaza respawns use collision-derived stage
positions. The original six-seat temporary placements retain their values.

## Plaza Party modes

The app defaults to Battle Royale and also offers Plaza Party, Coin Battle, Free Battle, Time, Stock and
Bonus. Use the native Custom Rules/Item Switch screens for match settings.
For a direct source launch:

```sh
python3 tools/melee3d/player_play.py --quickstart --fighters 32 --mode battle-royale --character sonic
```

Focused regressions include `test_native_respawn.py`, `native_directional.py`,
`native_captures.py`, `native_area.py` and `player_survival_check.py`. Choose the
relevant checks for a change; the [devlog](../../docs/delfino/DEVLOG.md) records
actual evidence and remaining limits.

Earlier laboratory instructions, prototype commands and migration milestones
are in [the historical notes](../../docs/delfino/history/NATIVE_MIGRATION.md).
