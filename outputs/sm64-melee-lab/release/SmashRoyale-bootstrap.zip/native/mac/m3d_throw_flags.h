/* Original animation-event flags use MSB-first bits in the first disc byte.
 * The native union has host bitfields; treating its raw u32 as a scalar moves
 * those bits into the wrong byte and prevents command-grab release events. */
#ifndef M3D_THROW_FLAGS_H
#define M3D_THROW_FLAGS_H
#include <melee/ft/types.h>
#include <stdint.h>
#include <string.h>
static inline uint32_t m3d_ThrowFlagsToGuest(const Fighter* fp)
{
    unsigned char bytes[4];
    memcpy(bytes,&fp->x2210,sizeof bytes);
    bytes[0]=0;
#define FLAG(n) bytes[0]|=(fp->x2210.x0.throw_flags_b##n!=0)<<(7-n)
    FLAG(0);FLAG(1);FLAG(2);FLAG(3);FLAG(4);FLAG(5);FLAG(6);FLAG(7);
#undef FLAG
    return (uint32_t)bytes[0]<<24|(uint32_t)bytes[1]<<16|(uint32_t)bytes[2]<<8|bytes[3];
}
static inline void m3d_ThrowFlagsFromGuest(Fighter* fp,uint32_t flags)
{
    unsigned char bytes[4]={flags>>24,flags>>16,flags>>8,flags};
    memcpy(&fp->x2210,bytes,sizeof bytes);
#define FLAG(n) fp->x2210.x0.throw_flags_b##n=(flags>>(31-n))&1
    FLAG(0);FLAG(1);FLAG(2);FLAG(3);FLAG(4);FLAG(5);FLAG(6);FLAG(7);
#undef FLAG
}
#endif
