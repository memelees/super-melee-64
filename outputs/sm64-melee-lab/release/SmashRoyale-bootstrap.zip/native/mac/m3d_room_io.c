/* SPDX-License-Identifier: GPL-3.0-or-later
 * Native socket boundary. Also compiled standalone by the 32-process test.
 * MACs authenticate inputs; the transport does not encrypt gameplay.
 */
#include "m3d_room_io.h"
#include "monocypher.h"
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
typedef SOCKET RoomSocket;
#define BAD_SOCKET INVALID_SOCKET
#define close_socket closesocket
#define socket_interrupted() (WSAGetLastError()==WSAEINTR)
typedef int SocketLength;
#else
#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/time.h>
#include <unistd.h>
typedef int RoomSocket;
typedef socklen_t SocketLength;
#define BAD_SOCKET (-1)
#define close_socket close
#define socket_interrupted() (errno==EINTR)
#endif

static RoomSocket room_socket = BAD_SOCKET;
static uint32_t frame;
static uint8_t key[32];
static int local_seat, humans;
static int configured;
static _Noreturn void fail(const char* reason) {
    fprintf(stderr, "M3D ROOM FAIL %s\n", reason);
    if (room_socket != BAD_SOCKET) close_socket(room_socket);
    exit(3);
}
static int number(const char* name, int lo, int hi) {
    const char* text = getenv(name); char* end;
    long value = text ? strtol(text, &end, 10) : -1;
    if (!text || !*text || *end || value < lo || value > hi) fail("invalid room configuration");
    return (int)value;
}
static int hex_digit(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return -1;
}
static void hex(const char* text, uint8_t output[32]) {
    if (!text || strlen(text) != 64) fail("invalid room key or identity");
    for (int i = 0; i < 32; ++i) {
        int a = hex_digit(text[2*i]), b = hex_digit(text[2*i+1]);
        if (a < 0 || b < 0) fail("invalid hex room configuration");
        output[i] = (uint8_t)(a * 16 + b);
    }
}
static uint16_t get16(const uint8_t* p) { return (uint16_t)(p[0] * 256u + p[1]); }
static uint32_t get32(const uint8_t* p) { return (uint32_t)get16(p) << 16 | get16(p+2); }
static void put32(uint8_t* p, uint32_t value) {
    p[0]=(uint8_t)(value>>24);p[1]=(uint8_t)(value>>16);p[2]=(uint8_t)(value>>8);p[3]=(uint8_t)value;
}
static void send_all(const uint8_t* data, size_t size) {
    while (size) {
#ifdef MSG_NOSIGNAL
        int n = send(room_socket, (const char*)data, (int)size, MSG_NOSIGNAL);
#else
        int n = send(room_socket, (const char*)data, (int)size, 0);
#endif
        if (n < 0 && socket_interrupted()) continue;
        if (n <= 0) fail("host disconnected or send timed out");
        data += n; size -= (size_t)n;
    }
}
static void receive(uint8_t* data, size_t size) {
    while (size) {
        int n = recv(room_socket, (char*)data, (int)size, 0);
        if (n < 0 && socket_interrupted()) continue;
        if (n <= 0) fail("host disconnected, rejected this client, or timed out");
        data += n; size -= (size_t)n;
    }
}
static void authenticate(const uint8_t* data, size_t size) {
    uint8_t expected[16];
    crypto_blake2b_keyed(expected, 16, key, 32, data, size);
    if (crypto_verify16(expected, data+size)) fail("host message authentication failed");
}
int m3d_room_enabled(void) { return getenv("MELEE3D_ROOM") != NULL; }
static void configure(void) {
    if (configured || !m3d_room_enabled()) return;
    humans=number("MELEE3D_ROOM_HUMANS",2,32);
    local_seat=number("MELEE3D_ROOM_SEAT",0,humans-1);
    configured=1;
}
static void socket_timeout(unsigned seconds) {
#ifdef _WIN32
    DWORD timeout=seconds*1000;
#else
    struct timeval timeout={(long)seconds,0};
#endif
    if(setsockopt(room_socket,SOL_SOCKET,SO_RCVTIMEO,(const char*)&timeout,sizeof timeout)||
       setsockopt(room_socket,SOL_SOCKET,SO_SNDTIMEO,(const char*)&timeout,sizeof timeout))
        fail("could not configure room timeout");
}
int m3d_room_local(void) { configure();return m3d_room_enabled()?local_seat:0; }
int m3d_room_humans(void) { configure();return m3d_room_enabled()?humans:0; }
static void connect_room(void) {
    configure();
#ifdef _WIN32
    WSADATA winsock;
    if(WSAStartup(MAKEWORD(2,2),&winsock))fail("could not initialise Windows sockets");
#endif
    char ip[64], tail; unsigned port;
    const char* endpoint=getenv("MELEE3D_ROOM");
    if (!endpoint || sscanf(endpoint,"%63[^:]:%u%c",ip,&port,&tail)!=2 || !port || port>65535)
        fail("expected IPv4:port");
    struct sockaddr_in address={0};address.sin_family=AF_INET;address.sin_port=htons((uint16_t)port);
    if (inet_pton(AF_INET,ip,&address.sin_addr)!=1) fail("room address must be IPv4");
    room_socket=socket(AF_INET,SOCK_STREAM,0);
    if(room_socket==BAD_SOCKET)fail("could not create room socket");
    int yes=1;setsockopt(room_socket,IPPROTO_TCP,TCP_NODELAY,(const char*)&yes,sizeof yes);
#ifdef SO_NOSIGPIPE
    setsockopt(room_socket,SOL_SOCKET,SO_NOSIGPIPE,&yes,sizeof yes);
#endif
    socket_timeout(180);
#ifdef _WIN32
    u_long nonblocking=1;
    if(ioctlsocket(room_socket,FIONBIO,&nonblocking))fail("could not configure room socket");
#else
    int flags=fcntl(room_socket,F_GETFL,0);
    if(flags<0||fcntl(room_socket,F_SETFL,flags|O_NONBLOCK))fail("could not configure room socket");
#endif
    if(connect(room_socket,(struct sockaddr*)&address,sizeof address)){
#ifdef _WIN32
        if(WSAGetLastError()!=WSAEWOULDBLOCK)fail("could not connect to player host");
#else
        if(errno!=EINPROGRESS)fail("could not connect to player host");
#endif
        fd_set writable;FD_ZERO(&writable);FD_SET(room_socket,&writable);struct timeval wait={5,0};
        int ready=select((int)room_socket+1,NULL,&writable,NULL,&wait),error=0;SocketLength n=sizeof error;
        if(ready<=0||getsockopt(room_socket,SOL_SOCKET,SO_ERROR,(char*)&error,&n)||error)
            fail("could not connect to player host within five seconds");
    }
#ifdef _WIN32
    nonblocking=0;
    if(ioctlsocket(room_socket,FIONBIO,&nonblocking))fail("could not restore room socket mode");
#else
    if(fcntl(room_socket,F_SETFL,flags))fail("could not restore room socket mode");
#endif
    uint8_t challenge[40], hello[68], signed_hello[76], start[32];
    receive(challenge,sizeof challenge);
    if(memcmp(challenge,"M3DROOM1",8))fail("unsupported room protocol");
    memset(hello,0,sizeof hello);hello[1]=(uint8_t)local_seat;
    hex(getenv("MELEE3D_ROOM_KEY"),key);hex(getenv("MELEE3D_ROOM_IDENTITY"),hello+4);
    memcpy(signed_hello,challenge,40);memcpy(signed_hello+40,hello,36);
    crypto_blake2b_keyed(hello+36,32,key,32,signed_hello,sizeof signed_hello);
    send_all(hello,sizeof hello);
    uint8_t session_key[32];crypto_blake2b_keyed(session_key,32,key,32,challenge,sizeof challenge);
    memcpy(key,session_key,32);crypto_wipe(session_key,32);
    receive(start,sizeof start);authenticate(start,16);
    if(memcmp(start,"M3DROOM1",8)||get16(start+8)!=humans||get16(start+10)<1||get16(start+10)>12)
        fail("host changed room configuration");
    socket_timeout(15);
    fprintf(stderr,"M3D ROOM CONNECTED seat=%d humans=%d delay=%u\n",local_seat,humans,get16(start+10));
}
void m3d_room_exchange(const uint8_t input[12],uint32_t checksum,uint8_t inputs[32*12],uint32_t* seed) {
    if(room_socket==BAD_SOCKET)connect_room();
    if(getenv("MELEE3D_ROOM_FRAMES") && frame>=(uint32_t)number("MELEE3D_ROOM_FRAMES",120,432000)){
        fprintf(stderr,"M3D ROOM COMPLETE frames=%u seat=%d\n",frame,local_seat);
        close_socket(room_socket);room_socket=BAD_SOCKET;exit(0);
    }
    uint8_t request[36],response[12+32*12+16];
    put32(request,frame);put32(request+4,checksum);memcpy(request+8,input,12);
    crypto_blake2b_keyed(request+20,16,key,32,request,20);send_all(request,sizeof request);
    size_t size=12+(size_t)humans*12;
    receive(response,size+16);authenticate(response,size);
    if(get32(response)!=frame||get16(response+8)!=humans||get16(response+10)>1)fail("out-of-order host frame");
    if(get16(response+10)==1){
        fprintf(stderr,"M3D ROOM COMPLETE frames=%u seat=%d reason=round-complete\n",frame+1,local_seat);
        close_socket(room_socket);room_socket=BAD_SOCKET;exit(0);
    }
    memcpy(inputs,response+12,(size_t)humans*12);*seed=get32(response+4);
    if(frame%120==0)fprintf(stderr,"M3D ROOM FRAME frame=%u seat=%d hash=%08x\n",frame,local_seat,checksum);
    frame++;
}
