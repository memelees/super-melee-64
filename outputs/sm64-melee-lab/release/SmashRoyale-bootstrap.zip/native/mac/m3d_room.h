/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef M3D_ROOM_H
#define M3D_ROOM_H
#include "m3d_room_io.h"
struct StartMeleeData;
void m3d_RoomSetup(struct StartMeleeData* start);
void m3d_RoomSync(void);
void m3d_RoomPads(void);
float m3d_RoomInputYaw(int slot, float fallback);
int m3d_RoomIsViewer(int slot);
#endif
