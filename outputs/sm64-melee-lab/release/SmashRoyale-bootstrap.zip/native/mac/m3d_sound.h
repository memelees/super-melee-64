/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef M3D_SOUND_H
#define M3D_SOUND_H
/* Keep all retail/global groups below 256. Each fighter category gets an
 * independent pair per logical seat, including Ice Climbers' partner. */
#define M3D_SOUND_GROUPS 1024
#ifdef __cplusplus
extern "C" {
#endif
int m3d_audio_mount(void);
#ifdef __cplusplus
}
#endif
static inline int m3d_sound_track(int seat,int partner,int retail_group)
{
    return 256+((retail_group-30)/12)*64+seat*2+partner;
}
static inline int m3d_sound_relative(int sound,int bank)
{
    return sound>=5000&&sound<10000&&bank>=0 ? bank*10000+sound%5000:sound;
}
#endif
