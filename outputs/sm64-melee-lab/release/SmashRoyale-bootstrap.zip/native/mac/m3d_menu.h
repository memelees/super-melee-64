/* Smash Royale: extensions to the game's existing title/CSS/SSS scenes. */
#ifndef M3D_MENU_H
#define M3D_MENU_H
#include <stdbool.h>
#include <dolphin/gx.h>
struct StartMeleeData;
bool m3d_MenuActive(void);
int m3d_MenuCharacter(void);
int m3d_MenuSelection(void);
int m3d_MenuCpuCharacter(void);
void m3d_MenuCpuChoose(int character);
int m3d_MenuCostume(void);
int m3d_MenuCostumeCount(int character);
void m3d_MenuCostumeChange(int direction);
void m3d_MenuCostumeSet(int costume);
void m3d_MenuChoose(int character);
void m3d_MenuRoster(struct StartMeleeData* start);
void m3d_MenuText(void* context, const char* text, float x, float y, float scale);
void m3d_MenuTitle(void* title_object);
const char* m3d_MenuLabel(int kind, int selection);
const char* m3d_MenuDescription(int kind, int selection);
void m3d_MenuMainInput(unsigned buttons);
int m3d_MenuRule(int row);
void m3d_MenuRuleChange(int row, int direction);
int m3d_MenuRuleCount(void);
const char* m3d_MenuRuleLabel(int row);
bool m3d_MenuRuleBack(void);
bool m3d_MenuRuleActivate(int row);
void m3d_MenuRuleAdjust(int row,int direction);
void m3d_MenuItemsSave(void);
unsigned m3d_MenuItemCheckInput(unsigned buttons);
void m3d_MatchSetup(struct StartMeleeData* start);
int m3d_MatchCpuLevel(void);
void m3d_MenuAutoHandicap(int winner,int loser,int runner_up);
const char* m3d_MenuRuleValue(int row);
void m3d_MenuContinue(void);
unsigned m3d_MenuCheckInput(const char* screen, unsigned buttons);
GXColor m3d_MenuColour(int seat);
void m3d_MenuPreview(void* joint);
void m3d_MenuPreviewChoice(void* joint,int choice);
int m3d_MenuStageTile(int cell,float* x,float* y);
void m3d_MenuStageCursor(float* x,float* y);
bool m3d_MenuStageHighlight(float* x,float* y);
bool m3d_MenuStageConfirm(void);
bool m3d_MenuStageCheckReady(void);
int m3d_MenuStage(void);
const char* m3d_MenuSunshineBank(void);
float m3d_MenuSunshineKillDepth(void);
int m3d_MenuLargeFD(void);
void m3d_MenuStagesInit(void);
void m3d_MenuStagesInput(void);
#endif
