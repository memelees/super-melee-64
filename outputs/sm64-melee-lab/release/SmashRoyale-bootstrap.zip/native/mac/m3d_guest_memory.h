/* SPDX-License-Identifier: GPL-3.0-or-later
 * DELFINO: host memory backing for the original 32-bit PowerPC module ABI. */
#ifndef M3D_GUEST_MEMORY_H
#define M3D_GUEST_MEMORY_H
#include <stddef.h>
#include <stdint.h>
extern uint32_t gw_mem1_size;
void* m3d_guest_address(const void* pointer, size_t size);
void* m3d_guest_memcpy(void* to, const void* from, size_t size);
void* m3d_guest_memset(void* to, int value, size_t size);
int m3d_guest_memcmp(const void* a, const void* b, size_t size);
void m3d_guest_init(void);
uint32_t m3d_guest_identity(uint32_t size);
void m3d_guest_region(uint32_t base, uint32_t size);
void m3d_guest_region_host(uint32_t base, uint32_t size, void* host);
uint32_t m3d_guest_encode_buffer(const void* host);
void m3d_guest_view(uint32_t base, uint32_t size);
void m3d_guest_field(uint32_t address, uint32_t size);
void m3d_guest_retire(uint32_t base, uint32_t size);
void m3d_guest_observer(void (*observer)(uint32_t,size_t,int));
void m3d_guest_touch(const void* pointer,size_t size,int writing);
#endif
