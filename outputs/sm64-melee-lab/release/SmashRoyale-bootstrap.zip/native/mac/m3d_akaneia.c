/* SPDX-License-Identifier: GPL-3.0-or-later
 * Live native fighter / original m-ex callback boundary. Unsupported fields,
 * engine calls and article callbacks stop the experimental run explicitly. */
#include "m3d_akaneia.h"
#include "m3d_items.h"
#include "m3d_targets.h"
#include "m3d_scene.h"
#include "m3d_hitboxes.h"
#include "m3d_sound.h"
#include <sysdolphin/baselib/synth.h>
#include <dolphin/dvd.h>
#include <melee/ft/ftcommon.h>
#include <melee/ft/ftlib.h>
#include <melee/lb/lb_0195.h>
#include <melee/ft/kinds/ftCommon/ftCo_CaptureCut.h>
#include <sysdolphin/baselib/aobj.h>
#include <melee/ft/ft_0881.h>
#include <melee/ft/ft_0892.h>
#include <melee/it/types.h>
#include <melee/it/item.h>
#include <melee/it/it_3F14.h>
#include <melee/it/itdraw.h>
#include "m3d_vm.h"
#include "m3d_throw_flags.h"
#include "m3d_native_calls.h"
#include "gw_ppc.h"
#include <melee/mp/mplib.h>
#include "world/m3d.h"
#include "m3d_guest_memory.h"
#include <melee/ft/types.h>
#include <melee/ft/ftcpuattack.h>
#include <melee/ft/ftdata.h>
#include <melee/ft/fighter.h>
#include <melee/ft/ftcamera.h>
#include <melee/ft/ftdrawcommon.h>
#include <melee/ft/ftparts.h>
#include <melee/ft/ft_081B.h>
#include <melee/ft/ftcoll.h>
#include <melee/lb/lb_013B.h>
#include <melee/lb/lbdvd.h>
#include <melee/lb/lblanguage.h>
#include <melee/gm/forward.h>
#include <melee/gm/types.h>
#include <melee/gm/gmresultplayer.h>
#include <sysdolphin/baselib/gobj.h>
#include <sysdolphin/baselib/gobjproc.h>
#include <sysdolphin/baselib/gobjgxlink.h>
#include <sysdolphin/baselib/gobjplink.h>
#include <sysdolphin/baselib/archive.h>
#include <sysdolphin/baselib/jobj.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

_Static_assert(sizeof(((Fighter*)0)->co_attrs)==0x184,"Original common attribute layout");
_Static_assert(sizeof(((Fighter*)0)->input)==0x50,"Original scalar input layout");
_Static_assert(sizeof(((Fighter*)0)->active_timer)==3,"Original input timer bytes");
_Static_assert(offsetof(Fighter,x68B)-offsetof(Fighter,x67C)==15,"Original byte timer range");
_Static_assert(sizeof(((Fighter*)0)->u)>=0xf8,"Space for original private fighter variables");
_Static_assert(sizeof(((Fighter*)0)->mv)>=0xac,"Space for original private motion variables");

typedef struct M3dCharacter {
    const char* name;
    int kind, character, internal, external, base, effect;
    const char* file;
    const char* symbol;
    const char* animation_file;
    int animations,main_bound,demo_bound,costumes,visibility_costumes,texture_costumes,emblem;
    int sound_bank;
    const char* sound_file;
} M3dCharacter;
#include "m3d_roster_data.inc"
extern HSD_GObjEvent ftKindCalcIndiviParamTable[Ft_Kind_Max];
extern MotionState* ftData_CharacterStateTables[Ft_Kind_Max];
extern HSD_GObjEvent ftData_OnKnockbackEnter[Ft_Kind_Max],ftData_OnKnockbackExit[Ft_Kind_Max];
extern HSD_GObjEvent ftData_OnItemInvisible[Ft_Kind_Max],ftData_OnItemVisible[Ft_Kind_Max];
extern HSD_GObjEvent ftData_UnkMotionStates1[Ft_Kind_Max],ftData_UnkMotionStates2[Ft_Kind_Max];
extern Fighter_ItemEvent ftData_OnItemDropExt[Ft_Kind_Max],ftData_OnItemPickup[Ft_Kind_Max],ftData_OnItemDrop[Ft_Kind_Max];
extern Fighter_UnkMtxEvent ftData_UnkMtxFunc0[Ft_Kind_Max];

static struct Actor {
    HSD_GObj* object;
    Fighter* fighter;
    uint32_t handle, view;
    uint32_t callback[32];
    unsigned index;
    uint32_t parts_view;
    unsigned part_count;
    unsigned matrix_depth;
    uint64_t active_events;
    uint64_t seen_events;
    unsigned dirty_low,dirty_high;
    int stale;
    unsigned char dirty[0x2340];
} actors[GM_MAX_PLAYERS];
static unsigned actor_count;
static int synchronizing_views;
static unsigned char saved_outputs[GM_MAX_PLAYERS][0x2340];
/* Map item drops put many ordinary items in reach of added fighters: Sonic's homing attack, for one, scans them all. */
static struct { HSD_GObj* object; struct Actor* owner; uint32_t handle; } auxiliary[256];
static unsigned auxiliary_count;
static struct Actor* active_actor;
static struct Asset { void* pointer; unsigned kind; uint32_t handle,owner; unsigned next; } assets[3072];
static unsigned asset_heads[4096],asset_allocations,asset_live,asset_peak;
static unsigned asset_count;
static uint32_t asset_owner_override;
static struct { HSD_GObjProc* native; HSD_GObj* owner; uint32_t callback,handle; } processes[512];
static unsigned process_count;
static struct { HSD_GObj* object; uint32_t callback; } renderers[64];
static unsigned renderer_count;
static struct ArchiveView {
    HSD_Archive* native;
    uint32_t guest,size,relocation_count;
    uint32_t* relocations;
} archive_views[128];
/* Archive images are resources, keyed by donor filename across scene loads. */
static struct {char name[128];HSD_Archive* native;int view;} archive_sources[1024];
static unsigned archive_source_count;
static unsigned archive_view_count;
static MotionState moves[7][64];
static unsigned move_counts[7];
static uint32_t drift_physics[7][8];
static unsigned char* native_archives[7];
static unsigned archive_sizes[7];
static int initialized;
extern void m3d_bind_engine(void);
extern void m3d_bind_math(void);
static void free_object(HSD_GObj* object);
static void process_callback(HSD_GObj* object);
static void bind_archive_view(HSD_Archive* archive);
static void render_callback(HSD_GObj* object,intptr_t pass);
static uint32_t process_handle(HSD_GObjProc* process);
static struct { uint32_t guest; void* native; int global; } articles[64];
static unsigned article_count;

int m3d_akaneia_enabled(void)
{
    const char* value=getenv("MELEE3D_NATIVE_AKANEIA"); return value && !strcmp(value,"1");
}
int m3d_akaneia_internal(int kind)
{
    if(kind>=33 && kind<40)return kind-6;
    return kind>=27 && kind<=32 ? m3d_internal_count-6+kind-27 : kind;
}
unsigned m3d_akaneia_stock_stride(void) {return m3d_stock_stride;}
unsigned m3d_akaneia_stock_reserved(void) {return m3d_stock_reserved;}
unsigned m3d_akaneia_emblem(int kind) {return kind>=0&&kind<40?m3d_emblems[kind]:0;}
unsigned m3d_akaneia_costume_count(int kind) {return kind>=33 && kind<40 ? m3d_characters[kind-33].costumes : 0;}
unsigned m3d_akaneia_costume_row(int kind,unsigned costume,int textures) {
    if(!m3d_akaneia_enabled() || kind<33 || kind>=40)return costume;
    const M3dCharacter* c=&m3d_characters[kind-33];
    unsigned rows=textures ? c->texture_costumes:c->visibility_costumes;
    /* Additional recolours inherit the authored default animation/visibility
     * row, just as null authored rows already do in the native engine. */
    return costume<rows ? costume:0;
}
int m3d_akaneia_base(int kind) { return kind>=33 && kind<40 ? m3d_characters[kind-33].base : kind; }
int m3d_akaneia_sound(Fighter* fp,int sound)
{
    if(!m3d_akaneia_enabled()||!fp)return sound;
    int kind=fp->kind;
    if(kind==Ft_Kind_Kirby)kind=fp->u.kb.hat.kind;
    return m3d_sound_relative(sound,kind>=33&&kind<40?m3d_characters[kind-33].sound_bank:-1);
}
int m3d_akaneia_item_sound(void* item,int sound)
{
    Item* ip=item;
    if(!ip||!ip->owner||!ftLib_IsFighter(ip->owner))return sound;
    return m3d_akaneia_sound(ip->owner->user_data,sound);
}
static void audio_loaded(int entry,int mode)
{
    if(entry<0)m3d_vm_fail("Could not load original Akaneia character sound bank");
}
void m3d_akaneia_audio_load(void)
{
    static int language=-1;
    if(!m3d_akaneia_enabled())return;
    int us=lbLang_IsSavedLanguageUS();if(language==us)return;
    if(language>=0)HSD_SynthSFXUnloadBank(3);
    for(unsigned i=0;i<7;i++){
        char path[128];snprintf(path,sizeof path,"/audio/%s%s",us?"us/":"",m3d_characters[i].sound_file);
        if(DVDConvertPathToEntrynum(path)<0)snprintf(path,sizeof path,"/audio/us/%s",m3d_characters[i].sound_file);
        if(DVDConvertPathToEntrynum(path)<0)m3d_vm_fail("Missing original Akaneia character sound file");
        HSD_SynthSFXLoad(path,3,audio_loaded,0);
        HSD_SynthSFXWaitForLoadCompletion(lb_800195D0);
        fprintf(stderr,"M3D AUDIO BANK kind=%d bank=%d file=%s\n",m3d_characters[i].kind,m3d_characters[i].sound_bank,path);
    }
    language=us;
}
static struct Actor* actor(HSD_GObj* object)
{
    unsigned i;
    for(i=0;i<actor_count;++i)if(actors[i].object==object)return &actors[i];
    for(i=0;i<auxiliary_count;++i)if(auxiliary[i].object==object)return auxiliary[i].owner;
    m3d_vm_fail("Unregistered live fighter object"); return NULL;
}
static uint32_t object_handle(HSD_GObj* object)
{
    unsigned i;
    if(!object)return 0;
    for(i=0;i<actor_count;++i)if(actors[i].object==object)return actors[i].handle;
    for(i=0;i<auxiliary_count;++i)if(auxiliary[i].object==object)return auxiliary[i].handle;
    for(unsigned link=0;link<=HSD_GObjLibInitData.p_link_max;++link) {
        HSD_GObj* live=HSD_GObjPLinkHead[link];
        for(unsigned guard=0;live && guard<4096;live=live->next,++guard)if(live==object) {
            fprintf(stderr,"M3D LIVE UNBOUND OBJECT pointer=%p live=1 classifier=%u link=%u\n",(void*)object,live->classifier,link);
            break;
        }
    }
    for(unsigned j=0;j<actor_count;++j)if(actors[j].object) {
        Fighter* fp=actors[j].fighter;
        HSD_GObj* references[5]={fp->item_gobj,fp->x1978,fp->x197C,fp->x1980,fp->x1984_heldItemSpec};
        for(unsigned k=0;k<5;++k)if(references[k]==object)
            fprintf(stderr,"M3D LIVE UNBOUND ITEM REFERENCE slot=%u field=%x pointer=%p\n",fp->player_idx,0x1974+4*k,(void*)object);
    }
    m3d_vm_fail("Native object has no original guest handle"); return 0;
}
static void export_actor(struct Actor*,int);
/* Demo (results-screen) fighters skip match-only initialisation, so their
 * object links may hold stale values: export only objects that are live. */
static void* live_gobj(void* pointer) {
    if(!pointer)return NULL;
    for(unsigned link=0;link<=HSD_GObjLibInitData.p_link_max;++link)
        for(HSD_GObj* g=HSD_GObjPLinkHead[link];g;g=g->next)if(g==pointer)return pointer;
    return NULL;
}
static Fighter* live_fighter(void* pointer) {
    if(!pointer)return NULL;
    for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];g;g=g->next)if(g->user_data==pointer)return pointer;
    return NULL;
}
static void export_all(int into_guest)
{
    unsigned i;
    ++synchronizing_views;
    for(i=0;i<actor_count;++i)if(actors[i].object && (into_guest || actors[i].dirty_high))export_actor(&actors[i],into_guest);
    --synchronizing_views;
}
static void clear_outputs(void)
{
    unsigned i;
    for(i=0;i<actor_count;++i) {
        struct Actor* a=&actors[i];
        if(a->dirty_high)memset(a->dirty+a->dirty_low,0,a->dirty_high-a->dirty_low);
        a->dirty_low=a->dirty_high=0;
    }
}
static void before_native(void) { export_all(0); clear_outputs(); }
static void after_native(void)
{
    unsigned i,j;
    /* Native adapters may emit numeric outputs into an original Fighter
     * pointer. Preserve only bytes actually written by those adapters while
     * retaining every other change made by the native engine/callbacks. */
    for(i=0;i<actor_count;++i)if(actors[i].object) {
        struct Actor* a=&actors[i];
        for(j=a->dirty_low;j<a->dirty_high;++j)if(a->dirty[j])
            m3d_vm_copy_out(saved_outputs[i]+j,a->view+j,1);
    }
    /* Any native helper may change another fighter. Invalidate all snapshots,
     * but materialize only views actually read by the next guest callback. */
    for(i=0;i<actor_count;++i)if(actors[i].object)actors[i].stale=1;
    ++synchronizing_views;
    for(i=0;i<actor_count;++i)if(actors[i].object && actors[i].dirty_high) {
        struct Actor* a=&actors[i];
        export_actor(a,1);
        for(j=a->dirty_low;j<a->dirty_high;++j)if(a->dirty[j])
            m3d_vm_copy_in(a->view+j,saved_outputs[i]+j,1);
        export_actor(a,0);
        a->stale=0;
    }
    --synchronizing_views;
    clear_outputs();
}
static uint32_t call_words(HSD_GObj* object,uint32_t target,const uint32_t* args,unsigned count)
{
    struct Actor* a=actor(object);
    uint32_t result;
    struct Actor* previous=active_actor;
    active_actor=a;
    after_native();
    result=m3d_vm_call(a->index,target,args,count);
    before_native();
    active_actor=previous;
    return result;
}
static uint32_t diddy_release_targets[2];
static void original_diddy_release(unsigned which,HSD_GObj* first,HSD_GObj* second,uint32_t arg5,uint32_t arg6)
{
    if(m3d_FighterIs3D(first->user_data))ftCo_CaptureReleaseJoint(first,second);
    uint32_t args[4]={object_handle(first),object_handle(second),arg5,arg6};
    after_native();
    m3d_vm_call_original(1,diddy_release_targets[which],args,4);
    before_native();
    if(getenv("MELEE3D_NATIVE_CAPTURE_AUDIT"))fprintf(stderr,"M3D CAPTURE DIDDY RELEASE kind=%u first=%u second=%u\n",which,((Fighter*)first->user_data)->player_idx,((Fighter*)second->user_data)->player_idx);
}
static void diddy_break_release(HSD_GObj* a,HSD_GObj* b,uint32_t c,uint32_t d) { original_diddy_release(0,a,b,c,d); }
static void diddy_throw_release(HSD_GObj* a,HSD_GObj* b,uint32_t c,uint32_t d) { original_diddy_release(1,a,b,c,d); }
static uint32_t lucas_collision_target,lucas_launch_target;
static float guest_float(uint32_t at){uint32_t bits=m3d_vm_read32(at);float f;memcpy(&f,&bits,4);return f;}
static void guest_float_set(uint32_t at,float f){uint32_t bits;memcpy(&bits,&f,4);m3d_vm_write32(at,bits);}
static uint32_t lucas_thunder_collision(HSD_GObj* object)
{
    after_native();uint32_t v=actor(object)->view,arg=object_handle(object);
    uint32_t head=m3d_vm_read32(v+0x2244),result;
    if(!m3d_FighterIs3D(object->user_data)||!head){result=m3d_vm_call_original(3,lucas_collision_target,&arg,1);before_native();return result;}
    HSD_GObj* source=m3d_native_object(head,1);uint32_t p=m3d_items_view(source)+0xdfc;
    Vec3 original={guest_float(p),guest_float(p+4),guest_float(p+8)};
    Fighter* fp=object->user_data;float dx=original.x-fp->cur_pos.x,dz=original.z-fp->cur_pos.z;
    /* Feed the original rectangular section its radial horizontal distance.
     * Native hit thresholds and timers remain intact. */
    /* The donor's initial latch waits for separation on BOTH 2D axes. Its
     * upward spawn normally supplies that; a horizontal 3D loop never does.
     * Rearm once outside the same native body volume on either axis. */
    float target_y=fp->cur_pos.y+3+5*fp->x34_scale.y;
    if(m3d_vm_read32(v+0x2340)==1&&
       (hypotf(dx,dz)>=7.333333f||fabsf(original.y-target_y)>=12.333333f))m3d_vm_write32(v+0x2340,0);
    guest_float_set(p,fp->cur_pos.x+copysignf(hypotf(dx,dz),dx));
    result=m3d_vm_call_original(3,lucas_collision_target,&arg,1);

    guest_float_set(p,original.x);
    if(result){guest_float_set(v+0x2350,original.x);guest_float_set(v+0x2354,original.y);guest_float_set(v+0x2358,original.z);}
    before_native();return result;
}
static void lucas_thunder_launch(HSD_GObj* object,uint32_t direction,uint32_t airborne)
{
    after_native();Fighter* fp=object->user_data;uint32_t v=actor(object)->view;
    float saved=guest_float(direction);
    if(m3d_FighterIs3D(fp)){
        float dx=fp->cur_pos.x-guest_float(v+0x2350),dz=fp->cur_pos.z-guest_float(v+0x2358),horizontal=hypotf(dx,dz);
        if(horizontal>.0001f)m3d_SetLane(fp,dx/horizontal,dz/horizontal);
        guest_float_set(direction,horizontal);
    }
    uint32_t args[3]={object_handle(object),direction,airborne};
    m3d_vm_call_original(3,lucas_launch_target,args,3);guest_float_set(direction,saved);before_native();
}
static void call(HSD_GObj* object,uint32_t target,unsigned extra,int has_extra)
{
    uint32_t args[2]={object_handle(object),extra};
    call_words(object,target,args,has_extra ? 2 : 1);
}
uint32_t m3d_akaneia_call(void* owner,uint32_t target,const uint32_t* args,unsigned count)
{
    return call_words(owner,target,args,count);
}
/* Original custom grabs temporarily replace common state 275 with a source
 * character's motion row. Keep native callback pointers typed and retain the
 * selected original targets on each victim after the shared row is restored. */
#define COMMON_SWAP_STATE 275
#define COMMON_SWAP_VIEW (0x803c2800u+COMMON_SWAP_STATE*32u)
static uint32_t common_row_targets[5];
static struct { HSD_GObj* object; uint32_t targets[5]; } common_captures[GM_MAX_PLAYERS];
static void common_capture_event(HSD_GObj* object,unsigned which)
{
    for(unsigned i=0;i<GM_MAX_PLAYERS;++i)if(common_captures[i].object==object) {
        if(!common_captures[i].targets[which])m3d_vm_fail("Missing original common-state callback");
        call(object,common_captures[i].targets[which],0,0); return;
    }
    m3d_vm_fail("Original common-state callback has no live victim");
}
static void common_anim(HSD_GObj* object) { common_capture_event(object,0); }
static void common_input(HSD_GObj* object) { common_capture_event(object,1); }
static void common_phys(HSD_GObj* object) { common_capture_event(object,2); }
static void common_coll(HSD_GObj* object) { common_capture_event(object,3); }
static void common_cam(HSD_GObj* object) { common_capture_event(object,4); }
static HSD_GObjEvent common_dispatch[5]={common_anim,common_input,common_phys,common_coll,common_cam};
static void change_original_motion(HSD_GObj* object,FtMotionId state,MotionFlags flags,float start,float speed,float blend,HSD_GObj* source)
{
    unsigned i,slot=GM_MAX_PLAYERS;
    MotionState* row=&ftData_MotionStateList[COMMON_SWAP_STATE];
    HSD_GObjEvent callbacks[5]={row->anim_cb,row->input_cb,row->phys_cb,row->coll_cb,row->cam_cb};
    int dynamic=0;
    for(i=0;i<GM_MAX_PLAYERS;++i) {
        if(common_captures[i].object==object) { slot=i; break; }
        if(!common_captures[i].object)slot=i;
    }
    if(state==COMMON_SWAP_STATE)for(i=0;i<5;++i)if(callbacks[i]==common_dispatch[i])dynamic=1;
    if(dynamic) {
        if(slot==GM_MAX_PLAYERS)m3d_vm_fail("Native custom capture capacity exhausted");
        common_captures[slot].object=object;
        for(i=0;i<5;++i)common_captures[slot].targets[i]=callbacks[i]==common_dispatch[i] ? common_row_targets[i] : 0;
    } /* Retain the last targets through native state-exit cleanup. */
    Fighter_ChangeMotionState(object,state,flags,start,speed,blend,source);
}
static int observe_common_motion(uint32_t address,size_t size,int writing)
{
    MotionState* row;
    unsigned offset,at,state;
    HSD_GObjEvent* callbacks[5];
    uint32_t base;
    if(address<0x803c2800 || address>=0x803c2800+ftCo_MS_Count*32u)return 0;
    state=(address-0x803c2800)/32; base=0x803c2800+state*32; offset=address-base;
    if(writing && state!=COMMON_SWAP_STATE)m3d_vm_fail("Only the original temporary capture row may be changed");
    row=&ftData_MotionStateList[state];
    callbacks[0]=&row->anim_cb; callbacks[1]=&row->input_cb; callbacks[2]=&row->phys_cb; callbacks[3]=&row->coll_cb; callbacks[4]=&row->cam_cb;
    if(size>32-offset)m3d_vm_fail("Original common motion row crosses its bounds");
    for(at=offset&~3u;at<offset+size;at+=4) {
        uint32_t bits=writing ? m3d_vm_read32(base+at) : 0;
        if(at==0) { if(writing)row->anim_id=(int32_t)bits; else bits=row->anim_id; }
        else if(at==4) { if(writing)row->x4_flags=bits; else bits=row->x4_flags; }
        else if(at==8) { if(writing)row->x8._=bits; else bits=row->x8._; }
        else {
            unsigned index=(at-12)/4;
            if(writing) {
                void (*native)(void)=m3d_native_callback_decode(bits);
                common_row_targets[index]=bits;
                *callbacks[index]=native ? (HSD_GObjEvent)native : bits ? common_dispatch[index] : NULL;
            } else bits=*callbacks[index]==common_dispatch[index] ? common_row_targets[index] :
                m3d_native_callback_encode((void(*)(void))*callbacks[index]);
        }
        if(!writing)m3d_vm_write32(base+at,bits);
    }
    return 1;
}
/* Results/demo fighters use the 14-row demo motion table (ftData_803C52A0).
 * Diddy's original onLoad reads and patches it. Seed a guest copy from the
 * native rows once (callbacks encoded as for the common table); later guest
 * reads and writes use that copy, and the native demo table stays original. */
static int observe_demo_motion(uint32_t address,size_t size,int writing)
{
    static int seeded;
    const uint32_t start=0x803c52a0,rows=14;
    if(address<start || address>=start+rows*32u)return 0;
    if(address+size>start+rows*32u)m3d_vm_fail("Demo motion access crosses its bounds");
    if(!seeded) {
        seeded=1;
        for(uint32_t at=0;at<rows*32u;at+=4) {
            MotionState* row=&ftData_803C52A0[at/32];unsigned word=(at%32)/4;uint32_t bits;
            if(word==0)bits=(uint32_t)row->anim_id;else if(word==1)bits=row->x4_flags;else if(word==2)bits=row->x8._;
            else {
                HSD_GObjEvent cb=word==3?row->anim_cb:word==4?row->input_cb:word==5?row->phys_cb:word==6?row->coll_cb:row->cam_cb;
                bits=cb?m3d_native_callback_encode((void(*)(void))cb):0;
            }
            m3d_vm_write32(start+at,bits);
        }
    }
    (void)writing;
    return 1;
}
static struct CollisionCallback {
    HSD_GObj* owner;
    uint32_t target;
    struct CollisionCallback* previous;
} *collision_callback;
static void collision_event(HSD_GObj* object)
{
    if(!collision_callback || object!=collision_callback->owner)
        m3d_vm_fail("Collision callback escaped its synchronous native scope");
    call(object,collision_callback->target,0,0);
}
static void collision_run(HSD_GObj* object,uint32_t target,void (*helper)(HSD_GObj*,HSD_GObjEvent))
{
    struct CollisionCallback scope={object,target,collision_callback};
    if(!target)m3d_vm_fail("Missing original collision callback");
    collision_callback=&scope;
    helper(object,collision_event);
    collision_callback=scope.previous;
}
static void collision_floor(HSD_GObj* object,uint32_t callback) { collision_run(object,callback,ft_80082C74); }
static void collision_ledge(HSD_GObj* object,uint32_t callback) { collision_run(object,callback,ft_80083A48); }
static void collision_fall(HSD_GObj* object,uint32_t callback) { collision_run(object,callback,ft_8008403C); }
/* mpCheckFloor has five FPRs, eight GPRs and a ninth word at sp+8.
 * Preserve that explicit MWCC EABI rather than treating outputs as host structs. */
static struct FloorFilter { void* owner;uint32_t target;struct FloorFilter* previous; } *floor_filter;
static bool original_floor_filter(HSD_GObj* object,int line)
{
    if(!floor_filter)m3d_vm_fail("Floor filter escaped its synchronous scope");
    uint32_t args[2]={m3d_akaneia_object_export(object,1),(uint32_t)line};
    return m3d_akaneia_call(floor_filter->owner,floor_filter->target,args,2)!=0;
}
static void collision_walljump(HSD_GObj* object,uint32_t filter,uint32_t callback)
{
    if(!filter||!callback)m3d_vm_fail("Missing original wall-jump collision callbacks");
    struct FloorFilter floor_scope={object,filter,floor_filter};
    struct CollisionCallback event_scope={object,callback,collision_callback};
    floor_filter=&floor_scope;collision_callback=&event_scope;
    ft_800831CC(object,original_floor_filter,collision_event);
    collision_callback=event_scope.previous;floor_filter=floor_scope.previous;
    static int logged;if(!logged++)fprintf(stderr,"M3D COLLISION WALLJUMP PASS\n");
}
static void floor_vector(uint32_t guest,const Vec3* vector)
{
    if(!guest)return;
    const float values[3]={vector->x,vector->y,vector->z};
    for(unsigned i=0;i<3;++i) { uint32_t bits;memcpy(&bits,&values[i],4);m3d_vm_write32(guest+i*4,bits); }
}
/* MSL strcmp over guest strings (bounded). */
static uint32_t guest_strcmp(gw_ppc_ctx* cpu)
{
    uint32_t a=cpu->gpr[3],b=cpu->gpr[4];
    for(unsigned i=0;i<4096;i++) {
        unsigned char x,y;m3d_vm_copy_out(&x,a+i,1);m3d_vm_copy_out(&y,b+i,1);
        if(x!=y)return (uint32_t)((int)x-(int)y);
        if(!x)return 0;
    }
    m3d_vm_fail("Unterminated guest string in strcmp");return 0;
}
static uint32_t original_check_floor(gw_ppc_ctx* cpu)
{
    Vec3 position={0},normal={0};int line=-1;u32 flags=0;
    uint32_t callback=cpu->gpr[10];
    /* Tails CPU_SpecialS omits the unused final argument when filter==NULL:
     * sp+8 is its Vec3 output buffer, not a GObj. Read the optional stack
     * argument only on the callback path that actually consumes it. */
    uint32_t last=callback ? m3d_vm_read32(cpu->gpr[1]+8):0;
    HSD_GObj* object=last ? m3d_native_object(last,1):NULL;
    struct FloorFilter scope={m3d_akaneia_current_actor(),callback,floor_filter};
    floor_filter=&scope;
    bool hit=mpCheckFloor((float)cpu->fpr[1].d,(float)cpu->fpr[2].d,
        (float)cpu->fpr[3].d,(float)cpu->fpr[4].d,(float)cpu->fpr[5].d,
        cpu->gpr[3] ? &position:NULL,cpu->gpr[4] ? &line:NULL,
        cpu->gpr[5] ? &flags:NULL,cpu->gpr[6] ? &normal:NULL,
        (int32_t)cpu->gpr[7],(int32_t)cpu->gpr[8],(int32_t)cpu->gpr[9],
        callback ? original_floor_filter:NULL,object);
    floor_filter=scope.previous;
    if(hit) {
        floor_vector(cpu->gpr[3],&position);floor_vector(cpu->gpr[6],&normal);
        if(cpu->gpr[4])m3d_vm_write32(cpu->gpr[4],(uint32_t)line);
        if(cpu->gpr[5])m3d_vm_write32(cpu->gpr[5],flags);
    }
    static int reported;
    if(!reported++)fprintf(stderr,"M3D FLOOR EABI PASS stack_object=%08x filter=%08x hit=%d\n",last,callback,hit);
    return hit;
}
static uint32_t original_check_multiple(gw_ppc_ctx* cpu)
{
    Vec3 position={0},normal={0};int line=-1;u32 flags=0;
    bool hit=mpCheckMultiple((float)cpu->fpr[1].d,(float)cpu->fpr[2].d,
        (float)cpu->fpr[3].d,(float)cpu->fpr[4].d,
        cpu->gpr[3]?&position:NULL,cpu->gpr[4]?&line:NULL,
        cpu->gpr[5]?&flags:NULL,cpu->gpr[6]?&normal:NULL,
        cpu->gpr[7],(int32_t)cpu->gpr[8],(int32_t)cpu->gpr[9]);
    if(hit) {
        floor_vector(cpu->gpr[3],&position);floor_vector(cpu->gpr[6],&normal);
        if(cpu->gpr[4])m3d_vm_write32(cpu->gpr[4],(uint32_t)line);
        if(cpu->gpr[5])m3d_vm_write32(cpu->gpr[5],flags);
    }
    static int reported;
    if(!reported++)fprintf(stderr,"M3D MULTIPLE COLLISION EABI PASS checks=%u hit=%d\n",cpu->gpr[7],hit);
    return hit;
}
static unsigned asset_bucket(uint32_t handle) {return ((handle>>8)*2654435761u)&4095u;}
static struct Asset* asset_find(uint32_t handle) {
    for(unsigned n=asset_heads[asset_bucket(handle)];n;n=assets[n-1].next)
        if(assets[n-1].handle==handle)return &assets[n-1];
    return NULL;
}
static void asset_retire(struct Asset* asset) {
    unsigned index=(unsigned)(asset-assets)+1;
    unsigned* link=&asset_heads[asset_bucket(asset->handle)];
    while(*link && *link!=index)link=&assets[*link-1].next;
    if(!*link)m3d_vm_fail("Native asset identity missing from live index");
    *link=asset->next;
    m3d_native_unbind_object(asset->handle);m3d_guest_retire(asset->handle,0x100);
    asset->pointer=NULL;asset->next=0;asset_live--;
}
static struct Asset* asset_acquire(void* pointer,unsigned kind,uint32_t owner) {
    unsigned i;
    for(i=0;i<asset_count && assets[i].pointer;i++){}
    if(i==sizeof assets/sizeof assets[0])m3d_vm_fail("Native scene-object live registry exhausted");
    if(i==asset_count)asset_count++;
    struct Asset* asset=&assets[i];unsigned h;
    asset->pointer=pointer;asset->kind=kind;asset->owner=owner;
    /* Storage slots may recycle; external handles never do. */
    asset->handle=m3d_guest_identity(0x100);h=asset_bucket(asset->handle);
    asset->next=asset_heads[h];asset_heads[h]=i+1;
    m3d_native_bind_object(asset->handle,pointer,kind);
    asset_allocations++;asset_live++;if(asset_live>asset_peak)asset_peak=asset_live;
    if(asset_allocations%512==0)fprintf(stderr,"M3D ASSET LIFETIME allocations=%u live=%u peak=%u slots=%u\n",asset_allocations,asset_live,asset_peak,asset_count);
    return asset;
}
void m3d_akaneia_joint_removed(void* pointer) {
    if(!m3d_akaneia_enabled() || !pointer)return;
    for(unsigned i=0;i<asset_count;i++)if(assets[i].pointer==pointer && assets[i].kind==3)asset_retire(&assets[i]);
}
static uint32_t result_object(void* pointer,unsigned kind)
{
    unsigned i;
    if(!pointer)return 0;
    if(kind==11)return m3d_scene_animation(pointer);
    if(kind==17)return m3d_scene_camera(pointer);
    if(kind==2) {
        Fighter* fp=pointer;
        for(i=0;i<actor_count;++i)if(actors[i].object && actors[i].fighter==fp)return actors[i].view;
        result_object(fp->gobj,1);
        return m3d_targets_view(fp->gobj);
    }
    if((kind>=14 && kind<=16) || kind==18 || kind==19)return m3d_scene_material(pointer,kind);
    if(kind==1) {
        for(i=0;i<actor_count;++i)if(actors[i].object==pointer)return actors[i].handle;
        for(i=0;i<auxiliary_count;++i)if(auxiliary[i].object==pointer)return auxiliary[i].handle;
    } else for(i=0;i<asset_count;++i)if(assets[i].pointer==pointer && assets[i].kind==kind)return assets[i].handle;
    if(!active_actor)m3d_vm_fail("New native object requires a live lifecycle adapter");
    if(kind==1) {
        HSD_GObj* object=pointer;
        for(i=0;i<actor_count;++i)if(actors[i].object==object)return actors[i].handle;
        for(i=0;i<auxiliary_count;++i)if(auxiliary[i].object==object)return auxiliary[i].handle;
        for(i=0;i<auxiliary_count && auxiliary[i].object;++i) {}
        if(i==256)m3d_vm_fail("Auxiliary object live registry exhausted");
        if(i==auxiliary_count)++auxiliary_count;
        auxiliary[i].object=object; auxiliary[i].owner=active_actor;
        auxiliary[i].handle=m3d_guest_identity(0x100);
        uint32_t handle=auxiliary[i].handle;
        m3d_native_bind_object(handle,object,1);
        m3d_guest_view(handle,0x40);
        m3d_guest_field(handle,0x18);m3d_guest_field(handle+0x18,8);m3d_guest_field(handle+0x28,8);
        if(object->classifier==HSD_GOBJ_CLASS_ITEM)m3d_items_track(object);
        if(object->classifier==HSD_GOBJ_CLASS_FIGHTER)m3d_targets_track(object);
        return handle;
    }
    if(kind!=3 && kind!=4 && kind!=13)m3d_vm_fail("Returned native object requires a live lifecycle adapter");
    for(i=0;i<asset_count;++i)
        if(assets[i].pointer==pointer && assets[i].kind==kind)return assets[i].handle;
    struct Asset* asset=asset_acquire(pointer,kind,kind==13 ? 0 : asset_owner_override ? asset_owner_override : active_actor->handle);
    if(kind==3) {
        m3d_guest_view(asset->handle,0x88);
        m3d_guest_field(asset->handle+8,0x14);
        m3d_guest_field(asset->handle+0x1c,0x58);
        m3d_guest_field(asset->handle+0x7c,4);
    }
    return asset->handle;
}
uint32_t m3d_akaneia_object_export(void* object,unsigned kind)
{
    unsigned i;
    if(!object)return 0;
    if(kind==1)for(i=0;i<actor_count;++i)if(actors[i].object==object)return actors[i].handle;
    return result_object(object,kind);
}
uint32_t m3d_akaneia_owned_export(void* object,unsigned kind,void* owner)
{
    uint32_t previous=asset_owner_override;
    asset_owner_override=m3d_akaneia_object_export(owner,1);
    uint32_t result=object ? result_object(object,kind):0;
    asset_owner_override=previous;return result;
}
void* m3d_akaneia_current_actor(void) { return active_actor ? active_actor->object:NULL; }
void m3d_akaneia_item_created(void* object,void* owner)
{
    struct Actor* previous=active_actor;
    if(!m3d_akaneia_enabled())return;
    if(owner)active_actor=actor(owner);
    result_object(object,1);
    active_actor=previous;
}
uint32_t m3d_akaneia_joint_export(void* joint,void* root)
{
    unsigned i;
    uint32_t saved=asset_owner_override,result;
    if(!joint)return 0;
    for(i=0;i<asset_count;++i)if(assets[i].pointer==root && assets[i].kind==3)break;
    if(i==asset_count)m3d_vm_fail("Joint traversal has no registered owning root");
    asset_owner_override=assets[i].owner;
    result=result_object(joint,3);
    asset_owner_override=saved;
    return result;
}
/* Diagnostic: real HSD allocations must retire at actual release, including
 * storage reused by transient charge-effect joint trees. */
void m3d_akaneia_asset_lifetime_probe(void* object)
{
    struct Actor* previous=active_actor;
    active_actor=actor(object);
    unsigned baseline=0,allocations=0;
    for(unsigned i=0;i<asset_count;i++)baseline+=assets[i].pointer!=NULL;
    uint32_t last=0;
    for(unsigned batch=0;batch<40;batch++) {
        HSD_JObj* nodes[96];
        for(unsigned i=0;i<96;i++) {
            nodes[i]=HSD_JObjAlloc();
            uint32_t handle=result_object(nodes[i],3);
            if(last && handle<=last)m3d_vm_fail("Released joint reused an old guest identity");
            if(m3d_native_object(handle,3)!=nodes[i])m3d_vm_fail("Live joint identity does not match native storage");
            last=handle;allocations++;
        }
        for(unsigned i=0;i<96;i++)HSD_JObjRemoveAll(nodes[i]);
        unsigned live=0;
        for(unsigned i=0;i<asset_count;i++)live+=assets[i].pointer!=NULL;
        if(live!=baseline)m3d_vm_fail("Released joints remain in the native scene-object registry");
    }
    active_actor=previous;
    fprintf(stderr,"M3D ASSET LIFETIME PASS allocations=%u live=%u batches=40\n",allocations,baseline);
}
static uint32_t archive_handle(HSD_Archive* archive)
{
    unsigned i;
    if(!archive)return 0;
    for(i=0;i<asset_count;++i)if(assets[i].pointer==archive && assets[i].kind==5)return assets[i].handle;
    return asset_acquire(archive,5,0)->handle;
}
static void event(HSD_GObj* object,unsigned slot,unsigned extra,int has_extra)
{
    struct Actor* a=actor(object);
    uint32_t target=m3d_vm_slot(a->index,slot);
    uint64_t bit=UINT64_C(1)<<slot;
    if(target && !(a->active_events&bit)) {
        /* Original overrides may call their common engine entry again.
         * GD/m-ex suppress recursive dispatch of the same event; the native
         * helper still performs its ordinary work on the nested entry. */
        a->active_events|=bit;
        if(!(a->seen_events&bit)) {
            a->seen_events|=bit;
            fprintf(stderr,"M3D LIVE EVENT slot=%u kind=%d event=%u target=%08x\n",a->fighter->player_idx,a->fighter->kind,slot,target);
        }
        call(object,target,extra,has_extra);
        a->active_events&=~bit;
    }
}
#define EVENT(name,slot) static void name(HSD_GObj* object) { event(object,slot,0,0); }
EVENT(on_respawn,1)
static void on_destroy(HSD_GObj* object)
{
    struct Actor* a=actor(object);
    unsigned i;
    event(object,2,0,0);
    for(i=0;i<auxiliary_count;++i)if(auxiliary[i].owner==a && auxiliary[i].object && auxiliary[i].object->classifier!=HSD_GOBJ_CLASS_FIGHTER) {
        if(auxiliary[i].object->classifier==HSD_GOBJ_CLASS_ITEM)Item_8026A8EC(auxiliary[i].object);
        else free_object(auxiliary[i].object);
    }
    for(i=0;i<asset_count;++i)if(assets[i].owner==a->handle && assets[i].pointer) {
        asset_retire(&assets[i]);
    }
    m3d_hitboxes_removed(a->object);
    m3d_native_unbind_object(a->handle); m3d_native_unbind_object(a->view);
    m3d_native_unbind_object(a->view+0x6f0);
    m3d_native_unbind_object(a->view+0x408); m3d_native_unbind_object(a->view+0x488); m3d_native_unbind_object(a->view+0x508);
    m3d_guest_retire(a->handle,0x10000); a->object=NULL; a->fighter=NULL;
}
EVENT(special_n,4) EVENT(special_na,5) EVENT(special_s,6) EVENT(special_sa,7)
EVENT(special_hi,8) EVENT(special_hia,9) EVENT(special_lw,10) EVENT(special_lwa,11)
EVENT(on_absorb,12) EVENT(item_invisible,14) EVENT(item_visible,15)
EVENT(head_item,19) EVENT(head_remove,20) EVENT(knockback_enter,21) EVENT(knockback_exit,22)
EVENT(on_frame,23) EVENT(on_state,24)
void m3d_akaneia_reapply(void* object) { event(object,25,0,0); }
int m3d_akaneia_event(void* pointer,unsigned slot)
{
    HSD_GObj* object=pointer;
    Fighter* fp;
    uint32_t target;
    if(!m3d_akaneia_enabled() || !object || !(fp=object->user_data) || fp->kind<33 || fp->kind>=40)return 0;
    target=m3d_vm_slot(fp->kind-33,slot);
    if(!target || (actor(object)->active_events&(UINT64_C(1)<<slot)))return 0;
    event(object,slot,0,0); return 1;
}
static void pickup(HSD_GObj* object,bool flag) { event(object,13,flag,1); }
static void release(HSD_GObj* object,bool flag) { event(object,16,flag,1); }
static void catch_item(HSD_GObj* object,bool flag) { event(object,17,flag,1); }
static void drop(HSD_GObj* object,bool flag) { event(object,18,flag,1); }
static void model_render(HSD_GObj* object,int argument,Mtx matrix)
{
    struct Actor* a=actor(object);
    uint32_t scratch,args[3],target=m3d_vm_slot(a->index,26);
    unsigned i;
    if(!target)return;
    if(!matrix) {
        /* The ordinary fighter render path deliberately supplies NULL when
         * no extra view transform is needed. Preserve that original ABI. */
        args[0]=object_handle(object); args[1]=(uint32_t)argument; args[2]=0;
        call_words(object,target,args,3); return;
    }
    if(a->matrix_depth==8)m3d_vm_fail("Model-render numeric scratch budget exceeded");
    scratch=a->view+0x8000+(a->matrix_depth++)*64;
    for(i=0;i<12;++i) { uint32_t word; memcpy(&word,&matrix[0][0]+i,4); m3d_vm_write32(scratch+i*4,word); }
    args[0]=object_handle(object); args[1]=(uint32_t)argument; args[2]=scratch;
    call_words(object,target,args,3);
    for(i=0;i<12;++i) { uint32_t word=m3d_vm_read32(scratch+i*4); memcpy(&matrix[0][0]+i,&word,4); }
    --a->matrix_depth;
}

#define CALLBACK_FIELDS(X) \
 X(0x2190,grab_cb,0) X(0x2194,x2194,1) \
 X(0x219c,input_cb,2) X(0x21a0,anim_cb,3) X(0x21a4,phys_cb,4) X(0x21a8,coll_cb,5) X(0x21ac,cam_cb,6) \
 X(0x21b0,accessory1_cb,7) X(0x21b4,accessory2_cb,8) X(0x21b8,accessory3_cb,9) X(0x21bc,accessory4_cb,10) \
 X(0x21c0,deal_dmg_cb,11) X(0x21c4,shield_hit_cb,12) X(0x21c8,reflect_hit_cb,13) X(0x21cc,x21CC,14) \
 X(0x21d0,hitlag_cb,15) X(0x21d4,pre_hitlag_cb,16) X(0x21d8,post_hitlag_cb,17) X(0x21dc,take_dmg_cb,18) \
 X(0x21e0,death1_cb,19) X(0x21e4,death2_cb,20) X(0x21e8,death3_cb,21) X(0x21ec,x21EC,22) \
 X(0x21f0,take_dmg_2_cb,23) X(0x21f4,hurtbox_detect_cb,24) X(0x21f8,x21F8,25)
#define DECLARE_CALLBACK(offset,member,index) \
 static void callback_##member(HSD_GObj* object) { struct Actor* a=actor(object); call(object,a->callback[index],0,0); }
CALLBACK_FIELDS(DECLARE_CALLBACK)
static void grabbed_callback(HSD_GObj* victim,HSD_GObj* source)
{
    struct Actor* a=actor(source);
    uint32_t args[2]={m3d_akaneia_object_export(victim,1),m3d_akaneia_object_export(source,1)};
    call_words(source,a->callback[31],args,2);
}
/* Diddy's original grounded stick entry passes its GObj to the original
 * Fighter* helper. Accept only registered fighter identities and apply the
 * intended grab mask to Fighter, rather than reproducing an out-of-object write. */
static void original_grab_flags(uint32_t identity,int16_t flags)
{
    unsigned i;
    for(i=0;i<actor_count;++i)if(actors[i].object && (identity==actors[i].handle || identity==actors[i].view)) {
        ftCommon_8007E2F4(actors[i].fighter,flags); return;
    }
    if(m3d_targets_grab_flags(identity,flags))return;
    m3d_vm_fail("Grab flags require a registered fighter identity");
}
static void create_grab(Fighter* fp,int16_t flags,uint32_t grab,uint32_t unknown,uint32_t grabbed)
{
    struct Actor* a=actor(fp->gobj);
    void (*first)(void)=m3d_native_callback_decode(grab);
    void (*second)(void)=m3d_native_callback_decode(unknown);
    void (*victim)(void)=m3d_native_callback_decode_typed(grabbed,1,M3D_VOID,2);
    a->callback[0]=grab; a->callback[1]=unknown; a->callback[31]=grabbed;
    ftCommon_8007E2D0(fp,flags,first ? (HSD_GObjEvent)first : grab ? callback_grab_cb : NULL,
        second ? (HSD_GObjEvent)second : unknown ? callback_x2194 : NULL,
        victim ? (HSD_GObjInteraction)victim : grabbed ? grabbed_callback : NULL);
}
static void create_reflector(HSD_GObj* object,uint32_t descriptor,uint32_t callback)
{
    struct Actor* a=actor(object);
    ReflectDesc data;
    void (*native)(void)=m3d_native_callback_decode(callback);
    m3d_vm_copy_out(&data,descriptor,sizeof data);
    if(data.x0_bone_id<0 || (unsigned)data.x0_bone_id>=a->part_count)
        m3d_vm_fail("Reflector descriptor exceeds the native fighter's bone array");
    a->callback[13]=callback;
    ftColl_CreateReflectHit(object,&data,native ? (HSD_GObjEvent)native : callback ? callback_reflect_hit_cb : NULL);
}
static void create_absorber(HSD_GObj* object,uint32_t descriptor)
{
    struct Actor* a=actor(object);
    AbsorbDesc data;
    m3d_vm_copy_out(&data,descriptor,sizeof data);
    if(data.x0_bone_id<0 || (unsigned)data.x0_bone_id>=a->part_count)
        m3d_vm_fail("Absorber descriptor exceeds the native fighter's bone array");
    ftColl_CreateAbsorbHit(object,&data);
}

static void word(uint32_t address,void* host,int into_guest)
{
    uint32_t value;
    if(into_guest) { memcpy(&value,host,4); m3d_vm_write32(address,value); }
    else { value=m3d_vm_read32(address); memcpy(host,&value,4); }
}
static void words(uint32_t address,void* host,size_t size,int into_guest)
{
    static int scalar=-1,check;
    static unsigned long long blocks,checked;
    static int log_tick=-1;
    uint32_t buffer[256];
    unsigned i;
    if(size%4)m3d_vm_fail("Non-word native scalar field");
    if(scalar<0){const char* mode=getenv("MELEE3D_NATIVE_WORD_TRANSFER");scalar=mode&&!strcmp(mode,"scalar");check=getenv("MELEE3D_NATIVE_WORD_CHECK")!=NULL;}
    if(scalar || size<=4 || size>sizeof buffer) {
        for(i=0;i<size;i+=4)word(address+i,(unsigned char*)host+i,into_guest);
        return;
    }
    /* Named numeric blocks have one exported field extent. Convert the same
     * words in a temporary buffer, then validate/copy that extent once. Native
     * pointers and callbacks still use their individual typed adapters. */
    if(into_guest)memcpy(buffer,host,size);
    else m3d_vm_copy_out(buffer,address,size);
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    for(i=0;i<size/4;i++)buffer[i]=__builtin_bswap32(buffer[i]);
#endif
    if(into_guest)m3d_vm_copy_in(address,buffer,size);
    else memcpy(host,buffer,size);
    ++blocks;
    if(check) {
        /* The scalar reader is the oracle. Suppress extra snapshot refreshes
         * while checking already transferred bytes, not native move callbacks. */
        ++synchronizing_views;
        for(i=0;i<size;i+=4){uint32_t native;memcpy(&native,(unsigned char*)host+i,4);
            if(native!=m3d_vm_read32(address+i))m3d_vm_fail("Batched numeric block differs from scalar transfer");}
        --synchronizing_views;++checked;
    }
    if(check && m3d_match_frame%120==0 && log_tick!=m3d_match_frame){log_tick=m3d_match_frame;
        fprintf(stderr,"M3D WORD TRANSFER tick=%d blocks=%llu verified=%llu\n",m3d_match_frame,blocks,checked);}
}
static void object_header(HSD_GObj* object,uint32_t base,int into_guest)
{
    unsigned char header[8]={(unsigned char)(object->classifier>>8),(unsigned char)object->classifier,
        object->p_link,object->gx_link,object->p_priority,object->render_priority,object->obj_kind,object->user_data_kind};
    if(into_guest)m3d_vm_copy_in(base,header,8);
    else {
        unsigned char proposed[8]; m3d_vm_copy_out(proposed,base,8);
        if(memcmp(header,proposed,8))m3d_vm_fail("Object headers require a managed native API");
    }
}
static struct { HSD_Archive* archive; uintptr_t host; uint32_t guest,size; } item_windows[64];
static unsigned item_window_count;
static uint32_t guest_data_pointer(const void* pointer)
{
    unsigned i;
    uintptr_t p=(uintptr_t)pointer;
    if(!p)return 0;
    for(i=0;i<7;++i) {
        uintptr_t base=(uintptr_t)native_archives[i];
        if(base && p>=base && p-base<archive_sizes[i])return 0x80b00000+i*0x80000+(uint32_t)(p-base);
    }
    for(i=0;i<archive_view_count;++i) {
        if(!archive_views[i].native)continue;
        uintptr_t base=(uintptr_t)archive_views[i].native->data;
        if(p>=base && p-base<archive_views[i].size)return archive_views[i].guest+(uint32_t)(p-base);
    }
    /* Ordinary map items (random drops) carry ItCo attribute data, which
     * fighter modules read through inline helpers (heavy/hold kind). The
     * whole archive exceeds the guest heap, so mirror a bounded read-only
     * window per referenced structure. Pointer slots inside a window are
     * cleared: dereferencing one fails closed instead of reading host data. */
    HSD_Archive* common=lbDvd_8001819C(lbLang_IsSettingUS() ? "ItCo.usd" : "ItCo.dat");
    if(common && p>=(uintptr_t)common->data && p-(uintptr_t)common->data<common->header.data_size) {
        for(i=0;i<item_window_count;++i)if(item_windows[i].archive==common && p>=item_windows[i].host && p-item_windows[i].host<item_windows[i].size)
            return item_windows[i].guest+(uint32_t)(p-item_windows[i].host);
        if(item_window_count==64)m3d_vm_fail("Common item data window budget exhausted");
        uint32_t offset=(uint32_t)(p-(uintptr_t)common->data),size=common->header.data_size-offset;
        if(size>0x100)size=0x100;
        uint32_t guest=m3d_vm_alloc(size),cleared=0;
        m3d_vm_copy_in(guest,(void*)p,size);
        for(unsigned j=0;j<common->header.nb_reloc;++j){uint32_t at=common->reloc_info[j].offset;
            if(at>=offset&&at+4<=offset+size){m3d_vm_write32(guest+(at-offset),0);cleared++;}}
        item_windows[item_window_count++]=(__typeof__(item_windows[0])){common,p,guest,size};
        fprintf(stderr,"M3D ITEM DATA VIEW offset=%x size=%x guest=%08x pointers_cleared=%u\n",offset,size,guest,cleared);
        return guest;
    }
    return m3d_guest_encode_buffer(pointer);
}
static void* native_data_pointer(uint32_t pointer)
{
    unsigned i;
    if(!pointer)return NULL;
    for(i=0;i<7;++i) {
        uint32_t base=0x80b00000+i*0x80000;
        if(pointer>=base && pointer-base<archive_sizes[i] && native_archives[i])
            return native_archives[i]+pointer-base;
    }
    for(i=0;i<archive_view_count;++i)
        if(archive_views[i].native && pointer>=archive_views[i].guest && pointer-archive_views[i].guest<archive_views[i].size)
            return archive_views[i].native->data+pointer-archive_views[i].guest;
    for(i=0;i<item_window_count;++i)
        if(pointer>=item_windows[i].guest && pointer-item_windows[i].guest<item_windows[i].size)
            return (void*)(item_windows[i].host+(pointer-item_windows[i].guest));
    if(pointer<0x80000000u || (uint64_t)pointer+1>UINT64_C(0x80000000)+gw_mem1_size)
        m3d_vm_fail("Decoded data pointer is outside the guest namespace");
    return m3d_guest_address((void*)(uintptr_t)pointer,1);
}
uint32_t m3d_akaneia_guest_data(const void* pointer) { return guest_data_pointer(pointer); }
void* m3d_akaneia_native_data(uint32_t pointer) { return native_data_pointer(pointer); }
static bool color_animation(ColorOverlay* overlay,uint32_t table,int index,int priority)
{
    if(index<0 || index>4095 || overlay->x28_colanim.i<0 || overlay->x28_colanim.i>4095)
        m3d_vm_fail("Color-animation index outside bounded table");
    m3d_guest_address((void*)(uintptr_t)table,8u*(1u+(unsigned)(index>overlay->x28_colanim.i ? index : overlay->x28_colanim.i)));
    return lb_800144C8(overlay,native_data_pointer(table),index,priority);
}
static int original_cpu_attack(Fighter* fp,Fighter* target,uint32_t table)
{
    unsigned count;
    if(table) {
        for(count=0;count<=32;++count) {
            m3d_guest_address((void*)(uintptr_t)(table+count*0x24),0x24);
            if(!m3d_vm_read32(table+count*0x24))break;
        }
        if(count==33)m3d_vm_fail("Original CPU attack list exceeds native capacity");
    }
    return ftCo_800B4AB0(fp,target,native_data_pointer(table));
}
static uint32_t cpu_command_handle(struct Actor* a)
{
    Fighter* fp=a->fighter;
    uintptr_t p=(uintptr_t)fp->cpu.csP,base=(uintptr_t)fp->cpu.buffer;
    if(!p)return 0;
    if(p>=base && p-base<sizeof fp->cpu.buffer)return a->view+0x1edc+(uint32_t)(p-base);
    /* Immutable native CPU command scripts are opaque identities. Guest code
     * may compare them; interpreting/replacing their contents needs an adapter. */
    struct Actor* previous=active_actor;
    active_actor=a;
    uint32_t value=result_object(fp->cpu.csP,13);
    active_actor=previous;
    return value;
}
/* Export named runtime fields, never native struct byte offsets. On-disc
 * attributes remain big-endian and therefore share their byte representation. */
/* Held/related item references may name ordinary map items (random drops),
 * which have no guest identity until a module first sees them. Register
 * them as this fighter's auxiliary objects; removal retires the view. */
static uint32_t held_handle(struct Actor* a,HSD_GObj* object)
{
    if(!object)return 0;
    struct Actor* previous=active_actor;if(!active_actor)active_actor=a;
    uint32_t handle=result_object(object,1);
    active_actor=previous;return handle;
}
static void export_actor(struct Actor* a,int into_guest)
{
    Fighter* fp=a->fighter;
    uint32_t v=a->view, value;
    unsigned index;
    unsigned char flags[0x14]={0};
    object_header(a->object,a->handle,into_guest);
    if(into_guest)m3d_vm_write32(a->handle+0x18,process_handle(a->object->proc));
    else if(m3d_vm_read32(a->handle+0x18)!=process_handle(a->object->proc))
        m3d_vm_fail("Original module changed native process-list ownership");
    if(into_guest)m3d_vm_write32(a->handle+0x2c,v);
    else if(m3d_vm_read32(a->handle+0x2c)!=v)m3d_vm_fail("Original module changed fighter userdata ownership");
    if(into_guest) {
        struct Actor* previous=active_actor;
        active_actor=a;
        m3d_vm_write32(a->handle+0x28,result_object(a->object->hsd_obj,3));
        active_actor=previous;
    } else {
        struct Actor* previous=active_actor;
        uint32_t root;
        active_actor=a; root=result_object(a->object->hsd_obj,3); active_actor=previous;
        if(m3d_vm_read32(a->handle+0x28)!=root)m3d_vm_fail("Original module changed an unbound fighter model root");
    }
#define SCALAR(off,member) word(v+off,&fp->member,into_guest)
#define WORDS(off,member) words(v+off,&fp->member,sizeof(fp->member),into_guest)
    if(into_guest)m3d_vm_write32(v,object_handle(a->object));
    else if(m3d_vm_read32(v)!=object_handle(a->object))m3d_vm_fail("Original module changed fighter object identity");
    SCALAR(4,kind); SCALAR(8,x8_spawnNum);
    if(into_guest)m3d_vm_copy_in(v+12,&fp->player_idx,1); else m3d_vm_copy_out(&fp->player_idx,v+12,1);
    SCALAR(0x10,motion_id); SCALAR(0x14,anim_id); SCALAR(0x18,x18);
    /* These original globals are compared by the modules to distinguish
     * gameplay and demo fighters. They remain opaque identities until a
     * typed motion-table adapter is registered; dereferencing fails closed. */
    if(into_guest) {
        if(fp->x1C_actionStateList==ftData_MotionStateList)value=0x803c2800;
        else if(fp->x1C_actionStateList==ftData_803C52A0)value=0x803c52a0;
        else m3d_vm_fail("Unbound native common-motion table identity");
        m3d_vm_write32(v+0x1c,value);
        m3d_vm_write32(v+0x20,m3d_vm_slot(a->index,3));
        m3d_vm_write32(v+0x24,m3d_vm_read32(m3d_vm_data(a->index)+0xc));
        m3d_vm_write32(v+0x28,m3d_vm_read32(m3d_vm_data(a->index)+0x10));
    } else {
        value=m3d_vm_read32(v+0x1c);
        if(value==0x803c2800)fp->x1C_actionStateList=ftData_MotionStateList;
        else if(value==0x803c52a0)fp->x1C_actionStateList=ftData_803C52A0;
        /* Results/demo fighter (Diddy) installed its own copy of the demo table:
         * keep the native demo rows, which drive the standard victory poses. */
        else if(fp->x1C_actionStateList==ftData_803C52A0) {
            static uint32_t logged;
            if(logged!=value){logged=value;fprintf(stderr,"M3D DEMO MOTION TABLE guest=%08x kept native\n",value);}
            m3d_vm_write32(v+0x1c,0x803c52a0);
        }
        else m3d_vm_fail("Unbound modified common-motion table");
        if(m3d_vm_read32(v+0x20)!=m3d_vm_slot(a->index,3) ||
           m3d_vm_read32(v+0x24)!=m3d_vm_read32(m3d_vm_data(a->index)+0xc) ||
           m3d_vm_read32(v+0x28)!=m3d_vm_read32(m3d_vm_data(a->index)+0x10))
            m3d_vm_fail("Original module changed an unbound native motion-table pointer");
    }
    SCALAR(0x2c,facing_dir); SCALAR(0x30,facing_dir1); WORDS(0x34,x34_scale);
    WORDS(0x2c4,x2C4);
    WORDS(0x74,x74_self_accel); WORDS(0x80,self_vel); WORDS(0x8c,x8c_kb_vel);
    WORDS(0x98,x98_atk_shield_kb); WORDS(0xa4,xA4_unk_vel);
    WORDS(0xb0,cur_pos); WORDS(0xbc,prev_pos); WORDS(0xc8,pos_delta); WORDS(0xd4,xD4_unk_vel);
    SCALAR(0xe0,ground_or_air); SCALAR(0xe4,xE4_ground_accel_1); SCALAR(0xe8,xE8_ground_accel_2);
    SCALAR(0x1a98,cpu.level);
    SCALAR(0x3e8,x3E4_fighterCmdScript.frame_count);
    SCALAR(0xec,gr_vel); SCALAR(0xf0,xF0_ground_kb_vel); SCALAR(0xf4,xF4_ground_attacker_shield_kb_vel);
    WORDS(0xf8,xF8_playerNudgeVel); SCALAR(0x100,x100);
    if(into_guest)m3d_vm_copy_in(v+0x110,&fp->co_attrs,sizeof(fp->co_attrs));
    else m3d_vm_copy_out(&fp->co_attrs,v+0x110,sizeof(fp->co_attrs));
    if(into_guest)m3d_vm_write32(v+0x10c,m3d_vm_data(a->index));
    else if(m3d_vm_read32(v+0x10c)!=m3d_vm_data(a->index))m3d_vm_fail("Original module changed native fighter-data ownership");
    if(into_guest) {
        m3d_vm_write32(v+0x2cc,guest_data_pointer(fp->x2CC));
        m3d_vm_write32(v+0x2d0,guest_data_pointer(fp->x2D0));
    } else {
        fp->x2CC=native_data_pointer(m3d_vm_read32(v+0x2cc));
        fp->x2D0=native_data_pointer(m3d_vm_read32(v+0x2d0));
    }
    if(into_guest) {
        uint32_t ext=m3d_vm_read32(m3d_vm_data(a->index)+4);
        if(fp->dat_attrs==fp->dat_attrs_backup)value=v+0x4000;
        else if(!fp->dat_attrs)value=0;
        else if(fp->dat_attrs==DP(void,fp->ft_data->ext_attr))value=ext;
        else m3d_vm_fail("Special-attribute pointer has no live mapping");
        m3d_vm_write32(v+0x2d4,value); m3d_vm_write32(v+0x2d8,v+0x4000);
    } else {
        value=m3d_vm_read32(v+0x2d4);
        if(value==v+0x4000)fp->dat_attrs=fp->dat_attrs_backup;
        else if(!value)fp->dat_attrs=NULL;
        else if(value==m3d_vm_read32(m3d_vm_data(a->index)+4))fp->dat_attrs=DP(void,fp->ft_data->ext_attr);
        else m3d_vm_fail("Original callback returned an unmapped attribute pointer");
        if(m3d_vm_read32(v+0x2d8)!=v+0x4000)m3d_vm_fail("Original callback changed attribute allocation ownership");
    }
    WORDS(0x2324,bury_grkind);
    WORDS(0x2328,bury_timer_1); WORDS(0x232c,bury_timer_2); WORDS(0x2330,x2330); WORDS(0x2338,x2338);
    WORDS(0x620,input); SCALAR(0x894,cur_anim_frame); SCALAR(0x898,x898_unk);
    if(into_guest) {
        m3d_vm_copy_in(v+0x670,&fp->active_timer,3); m3d_vm_copy_in(v+0x673,&fp->active_sticky,3);
        m3d_vm_copy_in(v+0x676,&fp->active_duration,3); m3d_vm_copy_in(v+0x679,&fp->activity_timer,3);
        m3d_vm_copy_in(v+0x67c,&fp->x67C,16);
    } else {
        m3d_vm_copy_out(&fp->active_timer,v+0x670,3); m3d_vm_copy_out(&fp->active_sticky,v+0x673,3);
        m3d_vm_copy_out(&fp->active_duration,v+0x676,3); m3d_vm_copy_out(&fp->activity_timer,v+0x679,3);
        m3d_vm_copy_out(&fp->x67C,v+0x67c,16);
    }
    WORDS(0x68c,x68C_transNPos); WORDS(0x698,x698); WORDS(0x6a4,x6A4_transNOffset); WORDS(0x6b0,x6B0);
    SCALAR(0x6bc,lstick_angle); WORDS(0x6c0,x6C0); WORDS(0x6cc,x6CC); WORDS(0x6d8,x6D8); WORDS(0x6e4,x6E4);
    WORDS(0x6f4,coll_data.cur_pos); WORDS(0x700,coll_data.prev_pos);
    WORDS(0x70c,coll_data.last_pos); WORDS(0x718,coll_data.x28_vec);
    SCALAR(0x728,coll_data.x38); SCALAR(0x72c,coll_data.floor_skip);
    SCALAR(0x730,coll_data.ledge_id_right); SCALAR(0x734,coll_data.ledge_id_left);
    SCALAR(0x738,coll_data.joint_id_skip); SCALAR(0x73c,coll_data.joint_id_only);
    SCALAR(0x740,coll_data.x50); SCALAR(0x744,coll_data.ledge_snap_x);
    SCALAR(0x748,coll_data.ledge_snap_y); SCALAR(0x74c,coll_data.ledge_snap_height);
    SCALAR(0x750,coll_data.lstick_x); WORDS(0x754,coll_data.x64_ecb);
    WORDS(0x774,coll_data.desired_ecb); WORDS(0x794,coll_data.ecb);
    WORDS(0x7b4,coll_data.prev_ecb); WORDS(0x7d4,coll_data.xE4_ecb);
    SCALAR(0x814,coll_data.ecb_source.x124); SCALAR(0x818,coll_data.ecb_source.x128);
    SCALAR(0x81c,coll_data.ecb_source.x12C); SCALAR(0x820,coll_data.x130_flags);
    SCALAR(0x824,coll_data.env_flags); SCALAR(0x828,coll_data.prev_env_flags); SCALAR(0x82c,coll_data.x13C);
    WORDS(0x830,coll_data.contact); WORDS(0x83c,coll_data.floor);
    WORDS(0x850,coll_data.left_facing_wall); WORDS(0x864,coll_data.right_facing_wall); WORDS(0x878,coll_data.ceiling);
    words(v+0x182c,&fp->dmg.x182c_behavior,0x3c,into_guest);
    SCALAR(0x1960,x1960_vibrateMult); SCALAR(0x1964,x1964); SCALAR(0x196c,hitlag_mul); SCALAR(0x1970,unk_msid);
    {
        struct Actor* previous=active_actor; active_actor=a;
        /* Non-CPU fighters (results-screen demo poses) never initialise the
         * CPU target fields; export only targets that are live fighters. */
        if(into_guest) { m3d_vm_write32(v+0x1acc,result_object(live_fighter(fp->cpu.x44),2)); m3d_vm_write32(v+0x1ad0,result_object(live_fighter(fp->cpu.x48),2)); }
        else { fp->cpu.x44=m3d_native_object(m3d_vm_read32(v+0x1acc),2); fp->cpu.x48=m3d_native_object(m3d_vm_read32(v+0x1ad0),2); }
        active_actor=previous;
    }
    WORDS(0x1adc,cpu.x54);
    WORDS(0x1a70,x1A70); WORDS(0x1a7c,x1A7C);
    /* Wolf's original reflector-hit callback faces the direction provided
     * by native collision. Entry-only checks never read this hit-time field. */
    SCALAR(0x1a2c,ReflectAttr.x1A2C_reflectHitDirection);
    SCALAR(0x1988,x1988);
    SCALAR(0x1a4c,grab_timer);
    SCALAR(0x1b04,cpu.x7C); SCALAR(0x1ed4,cpu.command_duration);
    if(into_guest)m3d_vm_write32(v+0x1ed8,cpu_command_handle(a));
    else if(m3d_vm_read32(v+0x1ed8)!=cpu_command_handle(a))m3d_vm_fail("CPU script ownership requires a native command helper");
    SCALAR(0x2064,x2064_ledgeCooldown); SCALAR(0x2068,x2068_attackID);
    {
        struct Actor* previous=active_actor;
        active_actor=a;
#define GRAB_OBJECT(offset,member) if(into_guest)m3d_vm_write32(v+offset,m3d_akaneia_object_export(live_gobj(fp->member),1)); else fp->member=m3d_native_object(m3d_vm_read32(v+offset),1);
        GRAB_OBJECT(0x1a58,victim_gobj) GRAB_OBJECT(0x1a5c,x1A5C) GRAB_OBJECT(0x1a60,target_item_gobj)
#undef GRAB_OBJECT
        active_actor=previous;
    }
    if(into_guest) { unsigned char jumps[2]={fp->x1968_jumpsUsed,fp->x1969_walljumpUsed}; m3d_vm_copy_in(v+0x1968,jumps,2); }
    else { unsigned char jumps[2]; m3d_vm_copy_out(jumps,v+0x1968,2); fp->x1968_jumpsUsed=jumps[0]; fp->x1969_walljumpUsed=jumps[1]; }
    if(into_guest) {
        struct Actor* previous=active_actor;
        active_actor=a;
        m3d_vm_write32(v+0x810,fp->coll_data.ecb_source.kind==ECBSource_JObj ?
                      result_object(fp->coll_data.ecb_source.x4.x0.x10C_joint[5],3) : 0);
        active_actor=previous;
    } else {
        value=m3d_vm_read32(v+0x810);
        if(fp->coll_data.ecb_source.kind==ECBSource_JObj)
            fp->coll_data.ecb_source.x4.x0.x10C_joint[5]=m3d_native_object(value,3);
        else if(value)m3d_vm_fail("Original module changed an incompatible ECB source");
    }
    if(into_guest)m3d_vm_write32(v+0x5e8,a->parts_view);
    else if(m3d_vm_read32(v+0x5e8)!=a->parts_view)m3d_vm_fail("Original module changed native bone-array ownership");
    if(into_guest)m3d_vm_copy_in(v+0x5f4,fp->x5F4_arr,sizeof fp->x5F4_arr);
    else m3d_vm_copy_out(fp->x5F4_arr,v+0x5f4,sizeof fp->x5F4_arr);
    {
        unsigned char bytes[4];
        if(into_guest) { bytes[0]=fp->pad_port; bytes[1]=fp->costume_id; bytes[2]=fp->sub_color; bytes[3]=fp->team;
            m3d_vm_copy_in(v+0x618,bytes,4); }
        else { m3d_vm_copy_out(bytes,v+0x618,4); fp->pad_port=bytes[0]; fp->costume_id=bytes[1]; fp->sub_color=bytes[2]; fp->team=bytes[3]; }
    }
    SCALAR(0x89c,frame_speed_mul); SCALAR(0x8a0,x8A0_unk); SCALAR(0x8a4,x8A4_animBlendFrames);
    SCALAR(0x8a8,x8A8_anim_frame);
    if(into_guest) {
        struct Actor* previous=active_actor;active_actor=a;
        m3d_vm_write32(v+0x8ac,result_object(fp->x8AC_animSkeleton,3));active_actor=previous;
    } else if(m3d_native_object(m3d_vm_read32(v+0x8ac),3)!=fp->x8AC_animSkeleton)
        m3d_vm_fail("Original module changed blend-skeleton ownership");
    WORDS(0x2200,cmd_vars);
    if(into_guest) {
        unsigned char flags=fp->x21FC_flag.byte;
        m3d_vm_copy_in(v+0x21fc,&flags,1); m3d_vm_write32(v+0x594,fp->x594.x594_s32);
    } else {
        unsigned char flags; m3d_vm_copy_out(&flags,v+0x21fc,1); fp->x21FC_flag.byte=flags;
        fp->x594.x594_s32=m3d_vm_read32(v+0x594);
    }
    if(into_guest) {
        m3d_vm_write32(v+0x1974,held_handle(a,live_gobj(fp->item_gobj)));
        m3d_vm_write32(v+0x1978,held_handle(a,live_gobj(fp->x1978)));
        m3d_vm_write32(v+0x197c,held_handle(a,live_gobj(fp->x197C)));
        m3d_vm_write32(v+0x1980,held_handle(a,live_gobj(fp->x1980)));
        m3d_vm_write32(v+0x1984,held_handle(a,live_gobj(fp->x1984_heldItemSpec)));
    } else {
        fp->item_gobj=m3d_native_object(m3d_vm_read32(v+0x1974),1);
        fp->x1978=m3d_native_object(m3d_vm_read32(v+0x1978),1);
        fp->x197C=m3d_native_object(m3d_vm_read32(v+0x197c),1);
        fp->x1980=m3d_native_object(m3d_vm_read32(v+0x1980),1);
        fp->x1984_heldItemSpec=m3d_native_object(m3d_vm_read32(v+0x1984),1);
    }
    WORDS(0x2174,x2174);
    if(into_guest)m3d_vm_write32(v+0x2210,m3d_ThrowFlagsToGuest(fp));
    else m3d_ThrowFlagsFromGuest(fp,m3d_vm_read32(v+0x2210));
    SCALAR(0x2214,cmd_timer);
    if(!into_guest)m3d_vm_copy_out(flags,v+0x2218,sizeof flags);
#define M3D_FLAG(off,bit,width,member) \
    if(into_guest) { \
        unsigned b; for(b=0;b<width;++b) flags[off-0x2218+(bit+b)/8] |= \
            ((fp->member>>(width-1-b))&1) << (7-(bit+b)%8); \
    } else { \
        unsigned b,flag=0; for(b=0;b<width;++b)flag=(flag<<1)|((flags[off-0x2218+(bit+b)/8]>>(7-(bit+b)%8))&1); \
        fp->member=flag; \
    }
#include "m3d_live_flags.inc"
#undef M3D_FLAG
    if(into_guest)m3d_vm_copy_in(v+0x2218,flags,sizeof flags);
#define SYNC_CALLBACK(off,member,i) \
    if(into_guest) { \
        if(fp->member!=callback_##member)a->callback[i]=m3d_native_callback_encode((void(*)(void))fp->member); \
        m3d_vm_write32(v+off,a->callback[i]); \
    } else { \
        void (*native)(void); value=m3d_vm_read32(v+off); a->callback[i]=value; \
        native=m3d_native_callback_decode(value); \
        fp->member=!value ? NULL : native ? (HSD_GObjEvent)native : callback_##member; \
    }
    CALLBACK_FIELDS(SYNC_CALLBACK)
    if(into_guest) {
        if(fp->grabbed_cb!=grabbed_callback)a->callback[31]=m3d_native_callback_encode_typed((void(*)(void))fp->grabbed_cb,1,M3D_VOID,2);
        m3d_vm_write32(v+0x2198,a->callback[31]);
    } else {
        void (*native)(void);
        a->callback[31]=m3d_vm_read32(v+0x2198);
        native=m3d_native_callback_decode_typed(a->callback[31],1,M3D_VOID,2);
        fp->grabbed_cb=native ? (HSD_GObjInteraction)native : a->callback[31] ? grabbed_callback : NULL;
    }
    {
        unsigned char bytes[4];
        if(into_guest) { bytes[0]=fp->x1A68>>8; bytes[1]=fp->x1A68; bytes[2]=fp->x1A6A>>8; bytes[3]=fp->x1A6A; m3d_vm_copy_in(v+0x1a68,bytes,4); }
        else { m3d_vm_copy_out(bytes,v+0x1a68,4); fp->x1A68=(bytes[0]<<8)|bytes[1]; fp->x1A6A=(bytes[2]<<8)|bytes[3]; }
    }
    (void)index;
#undef SCALAR
#undef WORDS
}

static void rewrite_motions(int kind,void* archive,unsigned size,int demo)
{
    unsigned char* lo=archive;
    unsigned char* hi=lo+size;
    ftData* data=gFtDataList[kind];
    struct Fighter_WaitAnimData* rows=DP(struct Fighter_WaitAnimData,demo ? data->x14 : data->xC);
    unsigned char* end=hi;
    unsigned i,bound=demo ? m3d_characters[kind-33].demo_bound : m3d_characters[kind-33].main_bound;
    unsigned limit=demo ? bound : ftData_Table_Unk0[kind].count;
    if(limit>bound)limit=bound;
    DiscU32* landmarks=(DiscU32*)data;
    if(!rows)return;
    if((unsigned char*)rows<lo || (unsigned char*)rows>=hi)m3d_vm_fail("Motion table outside native archive");
    if((uint64_t)((unsigned char*)rows-lo)+bound*sizeof(*rows)>size)m3d_vm_fail("Exact motion-table extent exceeds native archive");
    end=(unsigned char*)rows+bound*sizeof(*rows);
    if((unsigned char*)data>(unsigned char*)rows && (unsigned char*)data<end)end=(unsigned char*)data;
    for(i=0;i<sizeof(*data)/4;++i) {
        unsigned char* pointer=DP(unsigned char,landmarks[i].v);
        if(pointer>(unsigned char*)rows && pointer<end && pointer>=lo)end=pointer;
    }
    for(i=0;i<limit;++i) {
        struct Fighter_WaitAnimData* row=&rows[i];
        unsigned char *name,*script;
        if((unsigned char*)(row+1)>end)break;
        name=DP(unsigned char,row->x0); script=DP(unsigned char,row->xC);
        if(!name && !script && !row->x4 && !row->x8)continue;
        if((name && (name<lo || name>=hi)) || !script || script<lo || script>=hi)break;
        row->x10_animCurrFlags=(row->x10_animCurrFlags & ~0x3f) | kind;
    }
    if(demo)ftData_UnkIntPairs[kind].count=i;
    else if(i!=(unsigned)ftData_Table_Unk0[kind].count) {
        /* m-ex metadata can describe more rows than the archive contains.
         * Keep the archive's measured extent authoritative; never rewrite or
         * cache the adjacent article/hand/model data as if it were motions. */
        fprintf(stderr,"M3D LIVE ANIMATION BOUND kind=%d declared=%u actual=%u\n",kind,limit,i);
        ftData_Table_Unk0[kind].count=i;
    }
    fprintf(stderr,"M3D LIVE ANIMATIONS kind=%d demo=%d rows=%u\n",kind,demo,i);
}

static void bind_actor(HSD_GObj* object)
{
    struct Actor* a;
    Fighter* fp=object->user_data;
    uint32_t v;
    unsigned i;
    static const struct { unsigned offset,size; } fields[]={
        {0,12},{12,1},{0x10,0x1c},{0x2c,20},{0x74,0x90},{0x10c,0x188},{0x2c4,8},{0x2cc,16},
        {0x3e8,4},{0x594,4},{0x5e8,4},{0x5f4,0x18},{0x618,4},{0x620,0x50},{0x670,0x80},
        {0x6f4,0x30},{0x728,0xcc},{0x810,0x7c},{0x894,28},
        {0x182c,0x3c},{0x1960,0xa},{0x196c,8},{0x1974,0x18},{0x1a2c,4},{0x1a4c,4},{0x1a58,12},{0x1a68,4},{0x1a70,0x18},{0x1a98,4},{0x1acc,8},{0x1adc,8},{0x1b04,4},{0x1ed4,8},{0x2064,8},{0x2174,12},{0x2190,12},{0x219c,0x60},{0x21fc,1},{0x2200,0x2c},
        {0x222c,0xf8},{0x2324,0x1c},{0x2340,0xac},
    };
    unsigned slot;for(slot=0;slot<actor_count&&actors[slot].object;slot++) {}
    if(slot==GM_MAX_PLAYERS || fp->kind<33 || fp->kind>=40)m3d_vm_fail("Invalid live added-fighter registration");
    if(slot==actor_count)actor_count++;
    a=&actors[slot];memset(a,0,sizeof *a);a->object=object;a->fighter=fp;a->index=fp->kind-33;
    a->handle=m3d_guest_identity(0x10000);a->view=a->handle+0x1000;a->stale=1;
    v=a->view;
    m3d_native_bind_object(a->handle,object,1); m3d_native_bind_object(v,fp,2);
    m3d_native_bind_object(v+0x6f0,&fp->coll_data,8);
    m3d_native_bind_object(v+0x408,&fp->x408,10);
    m3d_native_bind_object(v+0x488,&fp->x488,10);
    m3d_native_bind_object(v+0x508,&fp->x508,10);
    m3d_guest_view(a->handle,0x40); m3d_guest_field(a->handle,0x18); m3d_guest_field(a->handle+0x18,4); m3d_guest_field(a->handle+0x28,8);
    m3d_guest_view(v,0x3000);
    m3d_hitboxes_track(object,v);
    for(i=0;i<sizeof fields/sizeof fields[0];++i)m3d_guest_field(v+fields[i].offset,fields[i].size);
    m3d_guest_region_host(v+0x4000,0x424,fp->dat_attrs_backup);
    m3d_guest_region_host(v+0x1edc,sizeof fp->cpu.buffer,fp->cpu.buffer);
    m3d_guest_field(v+0x1edc,sizeof fp->cpu.buffer);
    m3d_guest_region_host(v+0x222c,0xf8,&fp->u);
    m3d_guest_region_host(v+0x2340,0xac,&fp->mv);
    m3d_guest_region(v+0x8000,0x200);
    {
        struct Actor* previous=active_actor;
        FighterPartsTable* parts=DP(FighterPartsTable,ftPartsTable[fp->kind].v);
        unsigned j;
        if(!parts || parts->parts_num>MAX_FT_PARTS)m3d_vm_fail("Invalid native bone-array extent");
        a->parts_view=v+0x6000;
        /* Native storage includes reserved accessory entries beyond the
         * skeleton's authored count. Original m-ex modules attach transient
         * grab/tether joints there, so expose the real allocated capacity. */
        a->part_count=MAX_FT_PARTS;
        m3d_guest_view(a->parts_view,MAX_FT_PARTS*0x10);
        active_actor=a;
        for(j=0;j<MAX_FT_PARTS;++j) {
            m3d_guest_field(a->parts_view+j*0x10,4);
            m3d_vm_write32(a->parts_view+j*0x10,result_object(fp->parts[j].joint,3));
        }
        active_actor=previous;
    }
    memset(&fp->u,0,sizeof fp->u); fp->dat_attrs=NULL;
    fprintf(stderr,"M3D LIVE BIND slot=%u kind=%d internal=%d object=%08x\n",fp->player_idx,fp->kind,m3d_akaneia_internal(fp->kind),a->handle);
}
static void on_load(HSD_GObj* object)
{
    bind_actor(object);
    event(object,0,0,0);
    if(getenv("MELEE3D_NATIVE_OUTPUT_FIXTURE")) {
        struct Actor* a=actor(object);
        Vec3 saved=a->fighter->self_vel;
        uint32_t args[1]={a->view+0x80};
        a->fighter->self_vel=(Vec3){3,4,0};
        call_words(object,0x8000d2ec,args,1);
        if(fabsf(a->fighter->self_vel.x-.6f)>1e-6f || fabsf(a->fighter->self_vel.y-.8f)>1e-6f || a->fighter->self_vel.z!=0)
            m3d_vm_fail("Numeric adapter output did not reach the live native fighter");
        a->fighter->self_vel=saved;
        fprintf(stderr,"M3D LIVE OUTPUT PASS slot=%u\n",a->fighter->player_idx);
    }
    fprintf(stderr,"M3D LIVE ONLOAD PASS slot=%u kind=%d\n",((Fighter*)object->user_data)->player_idx,((Fighter*)object->user_data)->kind);
}
static uint32_t article_kind(uint32_t kind,uint32_t index)
{
    uint32_t fighter=m3d_vm_read32(m3d_vm_metadata()+8),row,ids,count;
    int internal=m3d_akaneia_internal((int)kind);
    if(internal<0 || internal>=41)m3d_vm_fail("Article owner kind outside m-ex metadata");
    row=m3d_vm_read32(fighter+0x4c)+internal*8;
    count=m3d_vm_read32(row); ids=m3d_vm_read32(row+4);
    if(index>=count)m3d_vm_fail("Article index outside owning fighter's metadata");
    {
        unsigned char value[2]; m3d_vm_copy_out(value,ids+index*2,2);
        return ((unsigned)value[0]<<8)|value[1];
    }
}
static void index_article(uint32_t kind,uint32_t desc,uint32_t index)
{
    uint32_t global=article_kind(kind,index),base;
    unsigned i;
    if(kind<33 || kind>=40 || global<237)m3d_vm_fail("Invalid original added-fighter article registration");
    i=kind-33; base=0x80b00000+i*0x80000;
    if(!native_archives[i] || desc<base || desc-base>archive_sizes[i]-0x18)
        m3d_vm_fail("Article descriptor outside its live native archive");
    for(i=0;i<article_count;++i)if(articles[i].global==(int)global)break;
    if(i==article_count) { if(article_count==64)m3d_vm_fail("Article registry exhausted"); ++article_count; }
    articles[i].guest=desc; articles[i].native=native_archives[kind-33]+desc-base; articles[i].global=global;
    m3d_items_index(global,articles[i].native,kind-33,index);
    fprintf(stderr,"M3D LIVE ARTICLE owner=%u index=%u global=%u descriptor=%08x\n",kind,index,global,desc);
}
static uint32_t get_article(HSD_GObj* object,uint32_t index)
{
    return article_kind(((Fighter*)object->user_data)->kind,index);
}
static int compare_words(const void* a,const void* b)
{
    uint32_t x=*(const uint32_t*)a,y=*(const uint32_t*)b; return x>y ? 1 : x<y ? -1 : 0;
}
static void object_links(HSD_GObj* object,uint32_t base,uint32_t address,size_t size,int writing)
{
    unsigned at,offset=address-base;
    for(at=offset&~3u;at<offset+size;at+=4) {
        HSD_GObj* pointer=at==8 ? object->next : at==12 ? object->prev : at==16 ? object->next_gx : object->prev_gx;
        uint32_t handle=m3d_akaneia_object_export(pointer,1);
        if(writing) { if(m3d_vm_read32(base+at)!=handle)m3d_vm_fail("Object list links require managed queue APIs"); }
        else m3d_vm_write32(base+at,handle);
    }
}
void m3d_akaneia_archive_named(const char* name,void* pointer)
{
    if(!m3d_akaneia_enabled()||!name||!pointer)return;
    HSD_Archive* archive=pointer;unsigned source;
    for(source=0;source<archive_source_count;source++)if(!strcmp(name,archive_sources[source].name))break;
    if(source==archive_source_count) {
        if(source==1024||strlen(name)>=sizeof archive_sources[source].name)m3d_vm_fail("Archive source catalogue capacity");
        strcpy(archive_sources[source].name,name);archive_sources[source].view=-1;archive_source_count++;
    }
    if(archive_sources[source].native==archive)return;
    /* Arena storage may now hold another resource. Never dereference its old
     * archive wrapper just because the allocator reused the same address. */
    for(unsigned i=0;i<archive_source_count;i++)if(i!=source&&archive_sources[i].native==archive) {
        if(archive_sources[i].view>=0)archive_views[archive_sources[i].view].native=NULL;
        archive_sources[i].native=NULL;
    }
    archive_sources[source].native=archive;
    if(archive_sources[source].view>=0) {
        struct ArchiveView* view=&archive_views[archive_sources[source].view];
        if(view->size!=archive->header.data_size||view->relocation_count!=archive->header.nb_reloc)m3d_vm_fail("Reloaded resource layout changed");
        view->native=archive;
    }
}
void m3d_akaneia_archive_removed(void* pointer)
{
    if(!m3d_akaneia_enabled()||!pointer)return;
    HSD_Archive* archive=pointer;
    for(unsigned i=0;i<archive_source_count;i++)if(archive_sources[i].native==archive)archive_sources[i].native=NULL;
    for(unsigned i=0;i<archive_view_count;i++)if(archive_views[i].native==archive)archive_views[i].native=NULL;
    for(unsigned i=0;i<7;i++)if(native_archives[i]==archive->data){native_archives[i]=NULL;archive_sizes[i]=0;}
}
void m3d_akaneia_common_loaded(void* archive)
{
    if(m3d_akaneia_enabled())bind_archive_view(archive);
}
/* Metadata slots recycle, but guest identities never resurrect old objects.
 * Own-actor accesses dominate VM calls and resolve without a roster scan. */
static struct Actor* actor_address(uint32_t address) {
    if(address<0x82000000u||address>=0x84000000u)return NULL;
    if(active_actor&&active_actor->object&&address>=active_actor->handle&&address-active_actor->handle<0x10000)return active_actor;
    for(unsigned i=0;i<actor_count;i++)if(actors[i].object&&address>=actors[i].handle&&address-actors[i].handle<0x10000)return &actors[i];
    return NULL;
}
/* Results scene: added fighters' original code reads the retail layout of
 * the results globals (lbl_8046E3AC, e.g. Sonic's "did he lose" check reads
 * player_standings[slot].is_big_loser). Serve a read-only retail-layout image:
 * header (0x28 bytes), then MatchEnd with six 0xA8-byte standings. */
#define M3D_RESULTS_GUEST 0x8046e3acu
#define M3D_RESULTS_SIZE 0x2300u
static void put16(unsigned char* p,unsigned v){p[0]=v>>8;p[1]=v;}
static void put32(unsigned char* p,uint32_t v){p[0]=v>>24;p[1]=v>>16;p[2]=v>>8;p[3]=v;}
static void results_view(void)
{
    static unsigned char image[M3D_RESULTS_SIZE];
    lbl_8046E3AC_t* r=&lbl_8046E3AC;MatchEnd* me=&r->match_end;
    memset(image,0,sizeof image);
    image[0]=*(unsigned char*)r;
    for(int i=0;i<4;i++){image[1+i]=r->player_flags[i];put16(image+6+2*i,r->x6[i]);image[0x0e + i]=r->variant[i];
        put32(image+0x14+4*i,(uint32_t)r->char_kind[i]);image[0x24+i]=r->costume_override[i];}
    unsigned char* m=image+0x28;
    put32(m,me->x0);m[4]=me->outcome;m[5]=me->match_kind;m[6]=me->is_teams;m[7]=me->x7;put32(m+8,me->frame_count);
    m[0x0c]=(unsigned char)me->sd_penalty;m[0x0d]=me->n_winners;m[0x0e]=me->n_team_winners;m[0x0f]=me->loser;
    for(int i=0;i<6;i++)m[0x10 + i]=me->winners[i];
    for(int i=0;i<6;i++) {
        struct MatchPlayerData* d=&me->player_standings[i];unsigned char* e=m+0x58+i*0xa8;
        e[0]=d->pkind;e[1]=(unsigned char)d->ckind;e[2]=(unsigned char)d->ftkind;e[3]=d->x3_u.x3;e[4]=d->x4;
        e[5]=d->is_big_loser;e[6]=d->is_small_loser;e[7]=d->team;e[8]=(unsigned char)d->stocks;e[9]=d->x9;
        put16(e+0x0a,d->self_destructs);put16(e+0x0c,d->percent);put16(e+0x0e,d->xE);
        for(int k=0;k<6;k++)put16(e+0x10+2*k,d->kills[k]);
        put32(e+0x1c,(uint32_t)d->x1C);put32(e+0x20,d->x20);put32(e+0x24,(uint32_t)d->x24);put32(e+0x28,d->x28);put32(e+0x2c,(uint32_t)d->score);
    }
    m3d_vm_copy_in(M3D_RESULTS_GUEST,image,sizeof image);
}
/* Guest collision rows contain synthetic addresses, never host pointers.
 * Lucas's tether reads both CollLine.flags and inner->lo_flags. Refresh the
 * pointer-free MapLine record from the current live 3D slice on every read. */
static int observe_collision_line(uint32_t address,size_t size,int writing)
{
    const uint32_t rows=0x80ad0000,inner=0x80a80000,capacity=16384;
    if(address==0x804d64bc&&size==4){
        if(writing)m3d_vm_fail("Original module changed collision-line ownership");
        m3d_vm_write32(address,rows);return 1;
    }
    bool row=address>=rows&&address<rows+capacity*8;
    bool record=address>=inner&&address<inner+capacity*16;
    if(!row&&!record)return 0;
    unsigned stride=row?8:16,index=(address-(row?rows:inner))/stride,at=(address-(row?rows:inner))%stride;
    MapCollData* data=mpLib_8004D164();CollLine* line=mpGetGroundCollLine();
    if(writing||!size||size>stride-at)m3d_vm_fail("Unbound collision-line field/write");
    if(!data||!line||index>=(unsigned)data->line_count)m3d_vm_fail("Collision-line index outside live stage");
    if(record){
        if(!line[index].inner)m3d_vm_fail("Missing live collision-line record");
        m3d_vm_copy_in(inner+index*16,line[index].inner,sizeof(MapLine));
        static int logged;if(!logged++)fprintf(stderr,"M3D COLLISION SURFACE PASS index=%u live_slice=1\n",index);
    }else{
        /* Mixed pointer/flags reads are not part of the guest ABI. */
        if(at<4){if(at+size>4)m3d_vm_fail("Cross-field collision-line read");m3d_vm_write32(rows+index*8,line[index].inner?inner+index*16:0);}
        else m3d_vm_write32(rows+index*8+4,line[index].flags);
    }
    return 1;
}
static void observe_archive(uint32_t address,size_t size,int writing)
{
    if(address>=M3D_RESULTS_GUEST && address<M3D_RESULTS_GUEST+M3D_RESULTS_SIZE) {
        if(writing)m3d_vm_fail("Original module wrote the native results globals");
        results_view();return;
    }
    unsigned i;struct Actor* mapped_actor=actor_address(address);
    if(observe_common_motion(address,size,writing))return;
    if(observe_demo_motion(address,size,writing))return;
    if(observe_collision_line(address,size,writing))return;
    if(!writing && !synchronizing_views && mapped_actor && mapped_actor->stale) {
        struct Actor* a=mapped_actor;
        if((address>=a->view && address-a->view<sizeof a->dirty && !(address-a->view>=0x222c && address-a->view<0x2324)) ||
           (address>=a->handle && address-a->handle<0x40)) {
            ++synchronizing_views;
            export_actor(a,1);
            --synchronizing_views;
            a->stale=0;
        }
    }
    if(writing && !synchronizing_views && mapped_actor) {
        struct Actor* a=mapped_actor;
        if(address>=a->view && address-a->view<sizeof a->dirty && !(address-a->view>=0x222c && address-a->view<0x2324) && size<=sizeof a->dirty-(address-a->view)) {
            unsigned offset=address-a->view;
            if(!a->dirty_high || offset<a->dirty_low)a->dirty_low=offset;
            if(offset+size>a->dirty_high)a->dirty_high=offset+size;
            memset(a->dirty+offset,1,size);
        }
    }
    if(address>=0x804d64fc && address<0x804d6500) {
        if(writing)m3d_vm_fail("Original module changed native CPU data ownership");
        m3d_vm_write32(0x804d64fc,0x80a40000); return;
    }
    if(address>=0x80a40000 && address<0x80a40028) {
        unsigned at=(address-0x80a40000)&~3u;
        if(writing)m3d_vm_fail("CPU table ownership requires native initialization");
        for(;at<address-0x80a40000+size;at+=4) {
            if(at<4 || at>0x20)m3d_vm_fail("Unbound native CPU root field");
            m3d_vm_write32(0x80a40000+at,0x80a41000+(at/4-1)*0x100);
        }
        return;
    }
    if(address>=0x80a41000 && address<0x80a41800) {
        unsigned table_index=(address-0x80a41000)/0x100,offset=(address-0x80a41000)%0x100;
        DiscU32* root=(DiscU32*)Fighter_804D64FC;
        DiscU32* table;
        unsigned at;
        if(!root || !(table=DP(DiscU32,root[table_index+1].v)))m3d_vm_fail("Native CPU table is not initialized");
        if(offset>=Ft_Kind_Max*4 || size>Ft_Kind_Max*4-offset)m3d_vm_fail("CPU table index exceeds native fighter capacity");
        for(at=offset&~3u;at<offset+size;at+=4) {
            uint32_t slot=0x80a41000+table_index*0x100+at;
            if(table_index==7) {
                if(writing)table[at/4].v=m3d_vm_read32(slot);
                else m3d_vm_write32(slot,table[at/4].v);
            } else {
                if(writing)table[at/4].v=pc_encode_dp(native_data_pointer(m3d_vm_read32(slot)));
                else m3d_vm_write32(slot,guest_data_pointer(DP(void,table[at/4].v)));
            }
        }
        return;
    }
    if(address>=0x804d7848 && address<0x804d784c) {
        unsigned char kinds[4]={HSD_GObj_FogKind,HSD_GObj_JObjKind,HSD_GObj_LightKind,HSD_GObj_CameraKind};
        if(writing)m3d_vm_fail("Original module changed native object type tags");
        m3d_vm_copy_in(0x804d7848,kinds,4); return;
    }
    if(address>=0x804d6d28 && address<0x804d6d2c) {
        if(writing)m3d_vm_fail("Original module changed common item-data ownership");
        m3d_vm_write32(0x804d6d28,0x80a20000); return;
    }
    if(address>=0x80a20000 && address<0x80a20000+sizeof(ItemCommonData)) {
        if(writing || !it_804D6D28)m3d_vm_fail("Invalid access to native common item constants");
        m3d_vm_copy_in(0x80a20000,it_804D6D28,sizeof(ItemCommonData)); return;
    }
    if(address>=0x804d782c && address<0x804d7830) {
        if(writing)m3d_vm_fail("Original module changed native object-list ownership");
        m3d_vm_write32(0x804d782c,0x80a18000); return;
    }
    if(address>=0x80a18000 && address<0x80a18100) {
        unsigned at=(address-0x80a18000)&~3u;
        if(writing)m3d_vm_fail("Original module changed native object-list heads");
        for(;at<address-0x80a18000+size;at+=4) {
            unsigned link=at/4;
            if(link>HSD_GObjLibInitData.p_link_max)m3d_vm_fail("Object-list index exceeds native list capacity");
            m3d_vm_write32(0x80a18000+at,m3d_akaneia_object_export(HSD_GObjPLinkHead[link],1));
        }
        return;
    }
    if(mapped_actor && address>=mapped_actor->handle+8 && address<mapped_actor->handle+0x18) {
        object_links(mapped_actor->object,mapped_actor->handle,address,size,writing); return;
    }
    for(i=0;i<auxiliary_count;++i)if(auxiliary[i].object && address>=auxiliary[i].handle+8 && address<auxiliary[i].handle+0x18) {
        object_links(auxiliary[i].object,auxiliary[i].handle,address,size,writing); return;
    }
    if(address>=0x804d6554 && address<0x804d6558) {
        if(writing)m3d_vm_fail("Original module changed shared fighter-data ownership");
        m3d_vm_write32(0x804d6554,0x80a10000); return;
    }
    if(address>=0x80a10000 && address<0x80a10000+sizeof(ftCommonData)) {
        /* A pointer-free DISC_STRUCT: preserve the actual native constants in
         * their original byte order. No guessed or zero-filled globals. */
        if(writing)m3d_vm_fail("Original module attempted to mutate shared fighter constants");
        if(!p_ftCommonData)m3d_vm_fail("Native common fighter data is not loaded");
        m3d_vm_copy_in(0x80a10000,p_ftCommonData,sizeof(ftCommonData)); return;
    }
    if(m3d_akaneia_effect_observe(address,size,writing))return;
    if(m3d_items_observe(address,size,writing))return;
    if(m3d_targets_observe(address,size,writing))return;
    if(m3d_scene_observe(address,size,writing))return;
    if(m3d_hitboxes_observe(address,size,writing))return;
    unsigned index;
    for(index=0;index<process_count;index++)if(processes[index].native&&address>=processes[index].handle&&address-processes[index].handle<0x18)break;
    if(index<process_count) {
        unsigned offset=address-processes[index].handle;
        HSD_GObjProc* proc=processes[index].native;
        if(offset<12) {
            HSD_GObjProc** pointer=offset<4 ? &proc->child : offset<8 ? &proc->next : &proc->prev;
            uint32_t at=processes[index].handle+(offset&~3u);
            if(writing) {
                uint32_t handle=m3d_vm_read32(at); unsigned j;
                for(j=0;j<process_count;++j)if(processes[j].handle==handle && processes[j].native)break;
                if(handle && j==process_count)m3d_vm_fail("Unregistered native process link");
                *pointer=handle ? processes[j].native : NULL;
            } else m3d_vm_write32(at,process_handle(*pointer));
        } else if(offset<14) {
            unsigned char bytes[2];
            if(writing) {
                m3d_vm_copy_out(bytes,processes[index].handle+12,2);
                if(bytes[0]!=proc->s_link)m3d_vm_fail("Process priority changes need native queue management");
                proc->flags_1=bytes[1]>>7; proc->flags_2=(bytes[1]>>6)&1;
                proc->flags_3=(bytes[1]>>4)&3; proc->flags_4=(bytes[1]>>2)&3;
            } else {
                bytes[0]=proc->s_link; bytes[1]=(proc->flags_1<<7)|(proc->flags_2<<6)|(proc->flags_3<<4)|(proc->flags_4<<2);
                m3d_vm_copy_in(processes[index].handle+12,bytes,2);
            }
        } else if(offset<20) {
            if(writing && m3d_vm_read32(processes[index].handle+16)!=object_handle(proc->gobj))
                m3d_vm_fail("Original module changed process owner");
            if(!writing)m3d_vm_write32(processes[index].handle+16,object_handle(proc->gobj));
        } else {
            if(writing) {
                void (*native)(void);
                processes[index].callback=m3d_vm_read32(processes[index].handle+20);
                native=m3d_native_callback_decode(processes[index].callback);
                proc->on_invoke=native ? (HSD_GObjEvent)native : processes[index].callback ? process_callback : NULL;
            } else {
                if(proc->on_invoke!=process_callback)processes[index].callback=m3d_native_callback_encode((void(*)(void))proc->on_invoke);
                m3d_vm_write32(processes[index].handle+20,processes[index].callback);
            }
        }
        return;
    }
    for(i=0;i<auxiliary_count;++i)if(auxiliary[i].object && address>=auxiliary[i].handle &&
        address-auxiliary[i].handle<0x40) {
        HSD_GObj* object=auxiliary[i].object;
        struct Actor* previous=active_actor;
        uint32_t base=auxiliary[i].handle,value;
        unsigned j;
        active_actor=auxiliary[i].owner;
        if(address<base+8) {
            object_header(object,base,!writing);
        } else if(address==base+0x1c) {
            uint32_t identity=0;
            if(object->render_cb==it_8026EECC)identity=0x8026eecc;
            else if(object->render_cb==render_callback) {
                for(j=0;j<renderer_count;++j)if(renderers[j].object==object) { identity=renderers[j].callback; break; }
            } else if(object->render_cb)m3d_vm_fail("Unbound native render callback identity");
            if(writing && m3d_vm_read32(base+0x1c)!=identity)m3d_vm_fail("Render callback changes require managed GX link API");
            if(!writing)m3d_vm_write32(base+0x1c,identity);
        } else if(address<base+0x1c) {
            if(writing && m3d_vm_read32(base+0x18)!=process_handle(object->proc))m3d_vm_fail("Original module changed auxiliary process ownership");
            if(!writing)m3d_vm_write32(base+0x18,process_handle(object->proc));
        } else if(address<base+0x2c) {
            if(object->classifier==HSD_GOBJ_CLASS_EFFECT || object->classifier==HSD_GOBJ_CLASS_ITEM || object->classifier==HSD_GOBJ_CLASS_FIGHTER) {
                uint32_t saved_owner=asset_owner_override;
                asset_owner_override=base;
                if(writing)object->hsd_obj=m3d_native_object(m3d_vm_read32(base+0x28),3);
                else m3d_vm_write32(base+0x28,result_object(object->hsd_obj,3));
                asset_owner_override=saved_owner;
                active_actor=previous; return;
            }
            if(object->hsd_obj)m3d_vm_fail("Auxiliary object needs a typed native payload adapter");
            if(writing && m3d_vm_read32(base+0x28))m3d_vm_fail("Auxiliary object needs a typed native payload adapter");
            if(!writing)m3d_vm_write32(base+0x28,0);
        } else {
            if(object->classifier==HSD_GOBJ_CLASS_ITEM || object->classifier==HSD_GOBJ_CLASS_FIGHTER) {
                uint32_t identity=object->classifier==HSD_GOBJ_CLASS_ITEM ? m3d_items_view(object) : m3d_targets_view(object);
                if(writing && m3d_vm_read32(base+0x2c)!=identity)m3d_vm_fail("Original module changed item userdata ownership");
                if(!writing)m3d_vm_write32(base+0x2c,identity);
                active_actor=previous; return;
            }
            if(object->classifier==HSD_GOBJ_CLASS_EFFECT) {
                uint32_t identity=m3d_akaneia_effect_identity(object->user_data);
                if(writing && m3d_vm_read32(base+0x2c)!=identity)m3d_vm_fail("Original module changed effect userdata ownership");
                if(!writing)m3d_vm_write32(base+0x2c,identity);
                active_actor=previous; return;
            }
            if(writing) {
                value=m3d_vm_read32(base+0x2c);
                for(j=0;j<actor_count;++j)if(actors[j].object && actors[j].view==value)break;
                object->user_data=j<actor_count ? actors[j].fighter : native_data_pointer(value);
            } else {
                for(j=0;j<actor_count;++j)if(actors[j].object && actors[j].fighter==object->user_data)break;
                m3d_vm_write32(base+0x2c,j<actor_count ? actors[j].view : guest_data_pointer(object->user_data));
            }
        }
        active_actor=previous; return;
    }
    if(mapped_actor && address>=mapped_actor->parts_view &&
        address-mapped_actor->parts_view<mapped_actor->part_count*0x10) {
        struct Actor* a=mapped_actor;
        struct Actor* previous=active_actor;
        unsigned index=(address-a->parts_view)/0x10;
        uint32_t at=a->parts_view+index*0x10;
        active_actor=a;
        if(writing)a->fighter->parts[index].joint=m3d_native_object(m3d_vm_read32(at),3);
        else m3d_vm_write32(at,result_object(a->fighter->parts[index].joint,3));
        active_actor=previous;
        return;
    }
    struct Asset* observed_asset=asset_find(address&~255u);
    if(observed_asset) {
        unsigned index=(unsigned)(observed_asset-assets);
        unsigned offset=address-observed_asset->handle;
        if(assets[index].kind==3 && assets[index].pointer) {
            HSD_JObj* joint=assets[index].pointer;
            unsigned at;
            for(at=offset&~3u;at<offset+size;at+=4) {
                uint32_t guest=assets[index].handle+at;
                if(at>=8 && at<=0x10) {
                    HSD_JObj** pointer=at==8 ? &joint->next : at==12 ? &joint->parent : &joint->child;
                    if(writing)*pointer=m3d_native_object(m3d_vm_read32(guest),3);
                    else {
                        uint32_t saved_owner=asset_owner_override;
                        asset_owner_override=assets[index].owner;
                        m3d_vm_write32(guest,result_object(*pointer,3));
                        asset_owner_override=saved_owner;
                    }
                } else if(at==0x14)word(guest,&joint->flags,!writing);
                else if(at==0x18) {
                    if(joint->flags & ((1u<<14)|(1u<<5)))m3d_vm_fail("Joint payload is a spline or particle list, not a display object");
                    if(writing && m3d_vm_read32(guest)!=m3d_scene_material(joint->u.dobj,14))m3d_vm_fail("Original module replaced display-object ownership");
                    if(!writing)m3d_vm_write32(guest,m3d_scene_material(joint->u.dobj,14));
                }
                else if(at==0x7c) {
                    if(writing && m3d_vm_read32(guest)!=m3d_scene_animation(joint->aobj))m3d_vm_fail("Original module replaced joint animation ownership");
                    if(!writing)m3d_vm_write32(guest,m3d_scene_animation(joint->aobj));
                }
                else if(at>=0x1c && at<0x2c)word(guest,(char*)&joint->rotate+at-0x1c,!writing);
                else if(at>=0x2c && at<0x38)word(guest,(char*)&joint->scale+at-0x2c,!writing);
                else if(at>=0x38 && at<0x44)word(guest,(char*)&joint->translate+at-0x38,!writing);
                else if(at>=0x44 && at<0x74)word(guest,(char*)&joint->mtx+at-0x44,!writing);
                else m3d_vm_fail("Unbound original joint field");
            }
            return;
        }
    }
    for(i=0;i<archive_view_count;++i) {
        struct ArchiveView* a=&archive_views[i];
        uint32_t offset,low=0,high=a->relocation_count,j;
        unsigned char* mirror;
        if(address<a->guest || address-a->guest>=a->size)continue;
        if(!a->native)m3d_vm_fail("Unloaded native archive view");
        offset=address-a->guest;
        if(size>a->size-offset)m3d_vm_fail("Native archive access crosses its registered extent");
        mirror=m3d_guest_address((void*)(uintptr_t)address,size);
        if(writing)memcpy(a->native->data+offset,mirror,size);
        else memcpy(mirror,a->native->data+offset,size);
        while(low<high) {
            uint32_t mid=low+(high-low)/2;
            if((uint64_t)a->relocations[mid]+4<=offset)low=mid+1; else high=mid;
        }
        for(j=low;j<a->relocation_count && a->relocations[j]<(uint64_t)offset+size;++j) {
            uint32_t at=a->relocations[j];
            DiscU32* native=(DiscU32*)(a->native->data+at);
            if(writing)native->v=pc_encode_dp(native_data_pointer(m3d_vm_read32(a->guest+at)));
            else m3d_vm_write32(a->guest+at,guest_data_pointer(DP(void,native->v)));
        }
        return;
    }
}
static void bind_archive_view(HSD_Archive* archive)
{
    unsigned i,j;
    struct ArchiveView* view;
    unsigned char* mirror;
    for(i=0;i<archive_view_count;++i)if(archive_views[i].native==archive)return;
    if(archive_view_count==sizeof archive_views/sizeof archive_views[0] || !archive || archive->header.data_size>0x100000)
        m3d_vm_fail("Costume archive exceeds the bounded native-view budget");
    for(unsigned source=0;source<archive_source_count;source++)if(archive_sources[source].native==archive) {
        if(archive_sources[source].view>=0){archive_views[archive_sources[source].view].native=archive;return;}
        archive_sources[source].view=archive_view_count;break;
    }
    view=&archive_views[archive_view_count];
    view->native=archive; view->size=archive->header.data_size;
    view->relocation_count=archive->header.nb_reloc;
    if(view->relocation_count>view->size/4)m3d_vm_fail("Invalid native archive relocation count");
    view->relocations=malloc(view->relocation_count*sizeof(uint32_t));
    if(view->relocation_count && !view->relocations)m3d_vm_fail("Cannot allocate archive relocation view");
    for(j=0;j<view->relocation_count;++j) {
        view->relocations[j]=archive->reloc_info[j].offset;
        if(view->relocations[j]>view->size-4)m3d_vm_fail("Native archive relocation outside its data");
    }
    qsort(view->relocations,view->relocation_count,sizeof(uint32_t),compare_words);
    view->guest=m3d_vm_alloc(view->size);
    mirror=m3d_guest_address((void*)(uintptr_t)view->guest,view->size);
    memcpy(mirror,archive->data,view->size);
    ++archive_view_count;
    /* Rebase data pointers once, retaining the native archive's representation.
     * Subsequent reads/writes translate only the touched bytes and relocations. */
    for(j=0;j<view->relocation_count;++j) {
        uint32_t at=view->relocations[j];
        DiscU32* native=(DiscU32*)(archive->data+at);
        uint32_t value=__builtin_bswap32(guest_data_pointer(DP(void,native->v)));
        memcpy(mirror+at,&value,4);
    }
}
static uint32_t costume_runtime(void)
{
    static int initialized;
    static unsigned char protected_lists[Ft_Kind_Max];
    unsigned kind,costume;
    const uint32_t base=0x80600000;
    if(!initialized) { m3d_guest_region(base,0x10000); initialized=1; }
    for(kind=0;kind<Ft_Kind_Max;++kind) {
        struct UnkCostumeList* list=&CostumeListsForeachCharacter[kind];
        uint32_t entries=base+0x1000+kind*0x400;
        if(!list->numCostumes || !list->costume_list)continue;
        if(list->numCostumes>32)m3d_vm_fail("Costume list exceeds native-view budget");
        m3d_vm_write32(base+kind*8,entries);
        m3d_vm_copy_in(base+kind*8+4,&list->numCostumes,1);
        if(!protected_lists[kind]) {
            m3d_guest_view(entries,list->numCostumes*0x18);
            for(costume=0;costume<list->numCostumes;++costume)m3d_guest_field(entries+costume*0x18+0x14,4);
            protected_lists[kind]=1;
        }
        for(costume=0;costume<list->numCostumes;++costume) {
            HSD_Archive* archive=list->costume_list[costume].x14_archive;
            m3d_vm_write32(entries+costume*0x18+0x14,archive_handle(archive));
        }
    }
    return base;
}
static uint32_t archive_public(HSD_Archive* archive,uint32_t symbol)
{
    char name[128]; unsigned i;
    for(i=0;i<sizeof name;++i) { m3d_vm_copy_out(&name[i],symbol+i,1); if(!name[i])break; }
    if(i==sizeof name)m3d_vm_fail("Unterminated original archive symbol name");
    /* Models and textures remain native. Mirror only archives whose public
     * data the original move code actually asks to read. */
    if(archive)bind_archive_view(archive);
    return guest_data_pointer(HSD_ArchiveGetPublicAddress(archive,name));
}
static uint32_t get_data(uint32_t id)
{
    uint32_t root=m3d_vm_metadata(),fighter=m3d_vm_read32(root+8);
    if(id==8)return costume_runtime();
    if(id==16)return root;
    if(id>=12 && id<=15)return m3d_vm_read32(fighter+(id-12)*4);
    m3d_vm_fail("Unbound m-ex runtime data table"); return 0;
}
static void process_callback(HSD_GObj* object)
{
    unsigned i;
    for(i=0;i<process_count;++i)if(processes[i].native==HSD_GObj_CurrentInvokedProc) {
        struct Actor* a=actor(object);
        bool custom_cpu=object==a->object && (processes[i].callback==m3d_vm_symbol(a->index,"MexCPU_ProcCustom") ||
            processes[i].callback==m3d_vm_symbol(a->index,"MexCPU_ProcSpoof"));
        bool began=custom_cpu && m3d_CpuBegin(a->fighter);
        call(object,processes[i].callback,0,0);
        m3d_CpuEnd(a->fighter,began);
        return;
    }
    m3d_vm_fail("Native scheduler invoked an unregistered guest process");
}
static uint32_t new_process(HSD_GObjProc* native,uint32_t callback)
{
    unsigned i;for(i=0;i<process_count&&processes[i].native;i++){}
    if(i==512 || !native)m3d_vm_fail("Native process registry exhausted/invalid");
    processes[i].native=native; processes[i].owner=native->gobj;
    processes[i].callback=callback; processes[i].handle=m3d_guest_identity(0x100);
    if(i==process_count)++process_count;
    m3d_guest_view(processes[i].handle,0x18);
    m3d_guest_field(processes[i].handle,12); m3d_guest_field(processes[i].handle+12,2);
    m3d_guest_field(processes[i].handle+16,8);
    return processes[i].handle;
}
static uint32_t process_handle(HSD_GObjProc* native)
{
    unsigned i;
    if(!native)return 0;
    for(i=0;i<process_count;++i)if(processes[i].native==native)return processes[i].handle;
    if(native->on_invoke==process_callback)m3d_vm_fail("Unregistered original process callback");
    return new_process(native,m3d_native_callback_encode((void(*)(void))native->on_invoke));
}
void m3d_akaneia_process_removed(void* native)
{
    unsigned i;
    if(!m3d_akaneia_enabled())return;
    for(i=0;i<process_count;++i)if(processes[i].native==native) {
        processes[i].native=NULL; m3d_guest_retire(processes[i].handle,0x100); return;
    }
}
static uint32_t setup_process(HSD_GObj* object,uint32_t callback,uint8_t priority)
{
    uint32_t handle;
    if(!callback)m3d_vm_fail("Invalid original process callback");
    handle=new_process(HSD_GObj_SetupProc(object,process_callback,priority),callback);
    fprintf(stderr,"M3D LIVE PROC slot=%u callback=%08x priority=%u\n",actor(object)->fighter->player_idx,callback,priority);
    return handle;
}
static void remove_process(uint32_t handle)
{
    unsigned i;
    for(i=0;i<process_count;++i)if(processes[i].handle==handle && processes[i].native)break;
    if(i==process_count)m3d_vm_fail("Unregistered/stale guest process removal");
    HSD_GObjProc_RemoveProc(processes[i].native);
}
static void render_callback(HSD_GObj* object,intptr_t pass)
{
    unsigned i;
    for(i=0;i<renderer_count;++i)if(renderers[i].object==object) {
        if(pass<0 || (uint64_t)pass>UINT32_MAX)m3d_vm_fail("Native render pass exceeds original ABI");
        call(object,renderers[i].callback,(uint32_t)pass,1); return;
    }
    m3d_vm_fail("Unregistered original render callback");
}
static void setup_render(HSD_GObj* object,uint32_t callback,uint8_t link,uint8_t priority)
{
    unsigned i;
    for(i=0;i<renderer_count;++i)if(renderers[i].object==object)break;
    if(i==renderer_count) {
        for(i=0;i<renderer_count&&renderers[i].object;i++){}
        if(i==64)m3d_vm_fail("Original render callback registry exhausted");
        if(i==renderer_count)++renderer_count;
    }
    renderers[i].object=object; renderers[i].callback=callback;
    GObj_SetupGXLink(object,render_callback,link,priority);
    fprintf(stderr,"M3D LIVE RENDER slot=%u callback=%08x\n",actor(object)->fighter->player_idx,callback);
}
static void draw_common(HSD_GObj* object,uint32_t pass) { ftDrawCommon_80080E18(object,pass); }
static void free_object(HSD_GObj* object)
{
    unsigned i;
    for(i=0;i<auxiliary_count;++i)if(auxiliary[i].object==object) {
        HSD_GObjFree(object); return;
    }
    for(i=0;i<actor_count;++i)if(actors[i].object==object) { HSD_GObjFree(object); return; }
    m3d_vm_fail("Unregistered/stale native object destruction");
}
void m3d_akaneia_object_removed(void* object)
{
    unsigned i;
    if(!m3d_akaneia_enabled())return;
    m3d_akaneia_effect_removed(object,0);
    m3d_items_removed(object);
    m3d_targets_removed(object);
    for(i=0;i<GM_MAX_PLAYERS;++i)if(common_captures[i].object==object)common_captures[i].object=NULL;
    for(i=0;i<auxiliary_count;++i)if(auxiliary[i].object==object) {
        unsigned j;
        for(j=0;j<asset_count;++j)if(assets[j].pointer && assets[j].owner==auxiliary[i].handle) {
            asset_retire(&assets[j]);
        }
        m3d_native_unbind_object(auxiliary[i].handle); m3d_guest_retire(auxiliary[i].handle,0x100);
        auxiliary[i].object=NULL;
    }
    for(i=0;i<renderer_count;++i)if(renderers[i].object==object)renderers[i].object=NULL;
}
/* HSD discards entire scene arenas without invoking every object's destructor.
 * Retire bridge metadata at that same boundary, without touching discarded host
 * storage or replaying guest destruction callbacks into the next scene. */
void m3d_akaneia_scene_reset(void)
{
    if(!m3d_akaneia_enabled())return;
    m3d_targets_scene_reset();m3d_items_scene_reset();
    m3d_akaneia_effect_scene_reset();m3d_scene_reset();
    for(unsigned i=0;i<actor_count;i++)if(actors[i].object) {
        struct Actor* a=&actors[i];m3d_hitboxes_removed(a->object);
        m3d_native_unbind_object(a->handle);m3d_native_unbind_object(a->view);
        m3d_native_unbind_object(a->view+0x6f0);
        m3d_native_unbind_object(a->view+0x408);m3d_native_unbind_object(a->view+0x488);m3d_native_unbind_object(a->view+0x508);
        m3d_guest_retire(a->handle,0x10000);a->object=NULL;a->fighter=NULL;
    }
    for(unsigned i=0;i<auxiliary_count;i++)if(auxiliary[i].object) {
        m3d_native_unbind_object(auxiliary[i].handle);m3d_guest_retire(auxiliary[i].handle,0x100);auxiliary[i].object=NULL;
    }
    for(unsigned i=0;i<process_count;i++)if(processes[i].native)m3d_akaneia_process_removed(processes[i].native);
    for(unsigned i=0;i<asset_count;i++)if(assets[i].pointer)asset_retire(&assets[i]);
    memset(renderers,0,sizeof renderers);memset(common_captures,0,sizeof common_captures);active_actor=NULL;
}
void m3d_akaneia_loaded(int kind,void* archive,unsigned size)
{
    if(kind<33 || kind>=40)return;
    native_archives[kind-33]=archive; archive_sizes[kind-33]=size;
    rewrite_motions(kind,archive,size,0); rewrite_motions(kind,archive,size,1);
}
static void move_callback(HSD_GObj* object,unsigned which)
{
    struct Actor* a=actor(object);
    int state=a->fighter->motion_id-a->fighter->x18;
    uint32_t table=m3d_vm_slot(a->index,3),target;
    if(state<0 || (unsigned)state>=move_counts[a->index])m3d_vm_fail("Added fighter motion callback outside registered table");
    target=m3d_vm_read32(table+state*32+12+which*4);
    if(target)call(object,target,0,0);
}
static void move_anim(HSD_GObj* object) { move_callback(object,0); }
static void move_input(HSD_GObj* object) { move_callback(object,1); }
static void move_phys(HSD_GObj* object) { move_callback(object,2); }
static void move_coll(HSD_GObj* object) { move_callback(object,3); }
static void move_cam(HSD_GObj* object) { move_callback(object,4); }

/* Only native-like drift phases, not the active recovery attack itself. */
int m3d_akaneia_air_drift(Fighter* fp)
{
    if(fp->kind<33||fp->kind>=40||!initialized)return 0;
    unsigned index=fp->kind-33;uint32_t target=0;
    if(fp->phys_cb==move_phys) {
        int state=fp->motion_id-fp->x18;
        if(state<0||(unsigned)state>=move_counts[index])return 0;
        target=m3d_vm_read32(m3d_vm_slot(index,3)+state*32+20);
    } else if(fp->phys_cb==callback_phys_cb) {
        struct Actor* a=actor(fp->gobj);target=a->callback[4];
    }
    if(!target)return 0;
    for(unsigned i=0;i<8;i++)if(drift_physics[index][i]==target)return 1;
    return 0;
}

void m3d_akaneia_init(void)
{
    unsigned i,j;
    const char* root;
    if(initialized || !m3d_akaneia_enabled())return;
    initialized=1; root=getenv("MELEE3D_AKANEIA_FILES");
    if(!root || !*root)m3d_vm_fail("Local Akaneia files directory is required");
    m3d_vm_init();
    {
        char path[4096]; snprintf(path,sizeof path,"%s/MxDt.dat",root); m3d_vm_load_metadata(path);
    }
    {
        const struct M3dNativeCall copy={0x800031f4,(void(*)(void))memcpy,M3D_BUFFER,3,
                                       {M3D_BUFFER,M3D_BUFFER,M3D_SIZE},{2,2,-1}};
        const struct M3dNativeCall clear={0x80003100,(void(*)(void))memset,M3D_BUFFER,3,
                                        {M3D_BUFFER,M3D_I32,M3D_SIZE},{2,-1,-1}};
        const struct M3dNativeCall camera={0x800761c8,(void(*)(void))ftCamera_UpdateCameraBox,M3D_VOID,1,
                                         {M3D_OBJECT},{-1},{1}};
        const struct M3dNativeCall move={0x80323938,(void(*)(void))memmove,M3D_BUFFER,3,
            {M3D_BUFFER,M3D_BUFFER,M3D_SIZE},{2,2,-1}};
        const struct M3dNativeCall floor_query={0x8004f008,(void(*)(void))original_check_floor,M3D_U32,1,{M3D_CONTEXT},{-1}};
        m3d_native_register(&floor_query);
        const struct M3dNativeCall compare={0x803258e8,(void(*)(void))guest_strcmp,M3D_U32,1,{M3D_CONTEXT},{-1}};
        m3d_native_register(&compare);
        const struct M3dNativeCall multiple_query={0x80051ec8,(void(*)(void))original_check_multiple,M3D_U32,1,{M3D_CONTEXT},{-1}};
        m3d_native_register(&multiple_query);
        m3d_native_register(&move);
        m3d_native_register(&copy); m3d_native_register(&clear); m3d_native_register(&camera);
        {
            const struct M3dNativeCall floor={0x80082c74,(void(*)(void))collision_floor,M3D_VOID,2,
                {M3D_OBJECT,M3D_U32},{-1,-1},{1,0}};
            const struct M3dNativeCall ledge={0x80083a48,(void(*)(void))collision_ledge,M3D_VOID,2,
                {M3D_OBJECT,M3D_U32},{-1,-1},{1,0}};
            const struct M3dNativeCall fall={0x8008403c,(void(*)(void))collision_fall,M3D_VOID,2,
                {M3D_OBJECT,M3D_U32},{-1,-1},{1,0}};
            m3d_native_register(&floor); m3d_native_register(&ledge); m3d_native_register(&fall);
            const struct M3dNativeCall walljump={0x800831cc,(void(*)(void))collision_walljump,M3D_VOID,3,
                {M3D_OBJECT,M3D_U32,M3D_U32},{-1,-1,-1},{1,0,0}};
            m3d_native_register(&walljump);
            {
                const struct M3dNativeCall reflect={0x8007b23c,(void(*)(void))create_reflector,M3D_VOID,3,
                    {M3D_OBJECT,M3D_U32,M3D_U32},{-1,-1,-1},{1,0,0}};
                const struct M3dNativeCall absorb={0x8007b2c4,(void(*)(void))create_absorber,M3D_VOID,2,
                    {M3D_OBJECT,M3D_U32},{-1,-1},{1,0}};
                m3d_native_register(&reflect); m3d_native_register(&absorb);
            }
        }
        {
            const struct M3dNativeCall index={0x803d7058,(void(*)(void))index_article,M3D_VOID,3,
                                            {M3D_U32,M3D_U32,M3D_U32},{-1,-1,-1}};
            const struct M3dNativeCall item_id={0x803d7088,(void(*)(void))get_article,M3D_U32,2,
                                              {M3D_OBJECT,M3D_U32},{-1,-1},{1,0}};
            const struct M3dNativeCall data={0x803d7094,(void(*)(void))get_data,M3D_U32,1,
                                           {M3D_U32},{-1}};
            m3d_native_register(&index); m3d_native_register(&item_id); m3d_native_register(&data);
            {
                const struct M3dNativeCall proc={0x8038fd54,(void(*)(void))setup_process,M3D_U32,3,
                                                {M3D_OBJECT,M3D_U32,M3D_U8},{-1,-1,-1},{1,0,0}};
                const struct M3dNativeCall remove={0x8038fe24,(void(*)(void))remove_process,M3D_VOID,1,
                                                  {M3D_U32},{-1}};
                const struct M3dNativeCall alloc={0x8037f1e4,(void(*)(void))m3d_vm_alloc,M3D_U32,1,
                                                 {M3D_U32},{-1}};
                const struct M3dNativeCall calloc_call={0x803d706c,(void(*)(void))m3d_vm_alloc,M3D_U32,1,
                                                       {M3D_U32},{-1}};
                const struct M3dNativeCall free_call={0x8037f1b0,(void(*)(void))m3d_vm_free,M3D_VOID,1,
                                                     {M3D_U32},{-1}};
                m3d_native_register(&proc); m3d_native_register(&remove);
                m3d_native_register(&alloc); m3d_native_register(&calloc_call); m3d_native_register(&free_call);
                {
                    const struct M3dNativeCall gx={0x8039069c,(void(*)(void))setup_render,M3D_VOID,4,
                        {M3D_OBJECT,M3D_U32,M3D_U8,M3D_U8},{-1,-1,-1,-1},{1,0,0,0}};
                    const struct M3dNativeCall draw={0x80080e18,(void(*)(void))draw_common,M3D_VOID,2,
                        {M3D_OBJECT,M3D_U32},{-1,-1},{1,0}};
                    const struct M3dNativeCall public_address={0x80380358,(void(*)(void))archive_public,M3D_U32,2,
                        {M3D_OBJECT,M3D_U32},{-1,-1},{5,0}};
                    m3d_native_register(&gx); m3d_native_register(&draw);
                    m3d_native_register(&public_address);
                    {
                        const struct M3dNativeCall destroy={0x80390228,(void(*)(void))free_object,M3D_VOID,1,
                            {M3D_OBJECT},{-1},{1}};
                        m3d_native_register(&destroy);
                    }
                }
            }
        }
    }
    m3d_native_sync(before_native,after_native);
    m3d_native_result_handler(result_object);
    m3d_guest_region(0x804d6554,4);
    m3d_guest_region(M3D_RESULTS_GUEST,M3D_RESULTS_SIZE);
    m3d_guest_region(0x804d64bc,4);
    m3d_guest_view(0x80ad0000,0x20000);
    m3d_guest_field(0x80ad0000,0x20000);
    m3d_guest_view(0x80a80000,0x40000);m3d_guest_field(0x80a80000,0x40000);
    m3d_guest_region(0x804d64fc,4);
    m3d_guest_view(0x80a40000,0x28); m3d_guest_field(0x80a40004,0x20);
    for(i=0;i<8;++i) { m3d_guest_view(0x80a41000+i*0x100,0x100); m3d_guest_field(0x80a41000+i*0x100,Ft_Kind_Max*4); }
    m3d_guest_region(0x804d7848,4);
    m3d_guest_region(0x804d6d28,4); m3d_guest_region(0x80a20000,sizeof(ItemCommonData));
    m3d_guest_region(0x804d782c,4); m3d_guest_region(0x80a18000,0x100);
    m3d_guest_region(0x80a10000,sizeof(ftCommonData));
    m3d_guest_view(0x803c2800,ftCo_MS_Count*32u); m3d_guest_field(0x803c2800,ftCo_MS_Count*32u);
    m3d_guest_view(0x803c52a0,14*32u); m3d_guest_field(0x803c52a0,14*32u);
    m3d_guest_observer(observe_archive);
    m3d_bind_engine();
    {
        const struct M3dNativeCall color={0x800144c8,(void(*)(void))color_animation,M3D_U8,4,
            {M3D_OBJECT,M3D_U32,M3D_I32,M3D_I32},{-1,-1,-1,-1},{10,0,0,0}};
        m3d_native_register(&color);
        const struct M3dNativeCall sound={0x80088510,(void(*)(void))ft_80088510,M3D_VOID,4,
            {M3D_OBJECT,M3D_I32,M3D_U8,M3D_U8},{-1,-1,-1,-1},{2,0,0,0}};
        m3d_native_register(&sound);
        const struct M3dNativeCall attack_id={0x80089824,(void(*)(void))ft_80089824,M3D_VOID,1,{M3D_OBJECT},{-1},{1}};
        m3d_native_register(&attack_id);
        const struct M3dNativeCall grab={0x8007e2d0,(void(*)(void))create_grab,M3D_VOID,5,
            {M3D_OBJECT,M3D_I16,M3D_U32,M3D_U32,M3D_U32},{-1,-1,-1,-1,-1},{2,0,0,0,0}};
        m3d_native_register(&grab);
        const struct M3dNativeCall mask={0x8007e2f4,(void(*)(void))original_grab_flags,M3D_VOID,2,{M3D_U32,M3D_I16},{-1,-1}};
        m3d_native_register(&mask);
    }
    const struct M3dNativeCall cpu_attack={0x800b4ab0,(void(*)(void))original_cpu_attack,M3D_I32,3,
        {M3D_OBJECT,M3D_OBJECT,M3D_U32},{-1,-1,-1},{2,2,0}};
    m3d_native_register(&cpu_attack);
    const struct M3dNativeCall state={0x800693ac,(void(*)(void))change_original_motion,M3D_VOID,7,
        {M3D_OBJECT,M3D_I32,M3D_U32,M3D_F32,M3D_F32,M3D_F32,M3D_OBJECT},
        {-1,-1,-1,-1,-1,-1,-1},{1,0,0,0,0,0,1}};
    m3d_native_register(&state);
    const struct M3dNativeCall descriptor={0x80085fd4,(void(*)(void))m3d_targets_motion,M3D_U32,2,
        {M3D_OBJECT,M3D_I32},{-1,-1},{2,0}};
    m3d_native_register(&descriptor);
    m3d_bind_math();
    m3d_bind_effects();
    m3d_bind_items();
    m3d_bind_scene();
    for(i=0;i<7;++i) {
        char path[4096];
        const M3dCharacter* c=&m3d_characters[i];
        snprintf(path,sizeof path,"%s/%s",root,c->file);
        m3d_vm_load(i,path,c->symbol);
    }
    {
        const char* names[2]={"SpecialS_BreakDetach","SpecialS_ThrowDetach"};
        void (*adapters[2])(HSD_GObj*,HSD_GObj*,uint32_t,uint32_t)={diddy_break_release,diddy_throw_release};
        for(unsigned n=0;n<2;++n) {
            diddy_release_targets[n]=m3d_vm_symbol(1,names[n]);
            if(!diddy_release_targets[n])m3d_vm_fail("Missing original Diddy release symbol");
            const struct M3dNativeCall hook={diddy_release_targets[n],(void(*)(void))adapters[n],M3D_VOID,4,
                {M3D_OBJECT,M3D_OBJECT,M3D_U32,M3D_U32},{-1,-1,-1,-1},{1,1,0,0}};
            m3d_native_register(&hook);
        }
        lucas_collision_target=m3d_vm_symbol(3,"Lucas_CheckForPKTCollision");
        lucas_launch_target=m3d_vm_symbol(3,"AS_LucasPKHit");
        if(!lucas_collision_target||!lucas_launch_target)m3d_vm_fail("Missing original Lucas thunder symbols");
        const struct M3dNativeCall collision={lucas_collision_target,(void(*)(void))lucas_thunder_collision,M3D_U32,1,{M3D_OBJECT},{-1},{1}};
        const struct M3dNativeCall launch={lucas_launch_target,(void(*)(void))lucas_thunder_launch,M3D_VOID,3,{M3D_OBJECT,M3D_U32,M3D_U32},{-1,-1,-1},{1,0,0}};
        m3d_native_register(&collision);m3d_native_register(&launch);
    }
    const char* drift_names[7][8]={
        {"SpecialHiFall_Phys","SpecialAirSEnd_Phys","SpecialAirLwEnd_Phys"},
        {0}, {0},
        {"SpecialHi_Fall_Phys"},
        {"SpecialNCancel_Phys","SpecialAirSEnd_Phys","SpecialAirLwEnd_Phys"},
        {"SpecialAirNEnd_Phys"},
        {"SpecialHi_Exhaust_Phys","SpecialHi_Cancel_Phys","SpecialAirS_End_Phys","SpecialAirLwEnd_Phys"}
    };
    for(i=0;i<7;i++)for(j=0;j<8&&drift_names[i][j];j++){
        drift_physics[i][j]=m3d_vm_symbol(i,drift_names[i][j]);
        if(!drift_physics[i][j])m3d_vm_fail("Missing original recovery drift physics");
    }
    m3d_roster_tables();
    for(i=0;i<7;++i) {
        const M3dCharacter* c=&m3d_characters[i];
        uint32_t table=m3d_vm_slot(i,3);
        uint32_t end=m3d_vm_symbol_end(i,table);
        int kind=c->kind;
        if(!table)m3d_vm_fail("Added fighter has no original motion table");
        if(end<=table || (end-table)%32 || (end-table)/32>64)
            m3d_vm_fail("Original motion table has an invalid exact symbol extent");
        move_counts[i]=(end-table)/32;
        for(j=0;j<move_counts[i];++j) {
            MotionState* m=&moves[i][j];
            uint32_t at=table+j*32;
            int anim=(int)m3d_vm_read32(at);
            m->anim_id=anim; m->x4_flags=m3d_vm_read32(at+4); m->x8._=m3d_vm_read32(at+8);
            HSD_GObjEvent fallback[5]={move_anim,move_input,move_phys,move_coll,move_cam};
            HSD_GObjEvent* fields[5]={&m->anim_cb,&m->input_cb,&m->phys_cb,&m->coll_cb,&m->cam_cb};
            for(unsigned k=0;k<5;k++){
                uint32_t target=m3d_vm_read32(at+12+k*4);
                /* Preserve the real native behavior identity when a row uses
                 * an exactly typed engine callback. Custom PPC callbacks
                 * retain the checked interpreter path. */
                HSD_GObjEvent native=(HSD_GObjEvent)m3d_native_event_pointer(target,1);
                *fields[k]=target ? (native ? native:fallback[k]):NULL;
            }
        }
        ftData_CharacterStateTables[kind]=moves[i];
        ftData_OnLoad[kind]=on_load; ftData_OnDeath[kind]=on_respawn;
        ftData_OnUserDataRemove[kind]=on_destroy;
        ftData_SpecialN[kind]=special_n; ftData_SpecialAirN[kind]=special_na;
        ftData_SpecialS[kind]=special_s; ftData_SpecialAirS[kind]=special_sa;
        ftData_SpecialHi[kind]=special_hi; ftData_SpecialAirHi[kind]=special_hia;
        ftData_SpecialLw[kind]=special_lw; ftData_SpecialAirLw[kind]=special_lwa;
        if(m3d_vm_slot(i,12))ftData_OnAbsorb[kind]=on_absorb;
        if(m3d_vm_slot(i,13))ftData_OnItemPickupExt[kind]=pickup;
        if(m3d_vm_slot(i,14))ftData_OnItemInvisible[kind]=item_invisible;
        if(m3d_vm_slot(i,15))ftData_OnItemVisible[kind]=item_visible;
        if(m3d_vm_slot(i,16))ftData_OnItemDropExt[kind]=release;
        if(m3d_vm_slot(i,17))ftData_OnItemPickup[kind]=catch_item;
        if(m3d_vm_slot(i,18))ftData_OnItemDrop[kind]=drop;
        if(m3d_vm_slot(i,19))ftData_UnkMotionStates1[kind]=head_item;
        if(m3d_vm_slot(i,20))ftData_UnkMotionStates2[kind]=head_remove;
        if(m3d_vm_slot(i,23))ftData_UnkMotionStates3[kind]=on_frame;
        if(m3d_vm_slot(i,24))ftData_UnkMotionStates4[kind]=on_state;
        if(m3d_vm_slot(i,25))ftKindCalcIndiviParamTable[kind]=(HSD_GObjEvent)m3d_akaneia_reapply;
        if(m3d_vm_slot(i,21))ftData_OnKnockbackEnter[kind]=knockback_enter;
        if(m3d_vm_slot(i,22))ftData_OnKnockbackExit[kind]=knockback_exit;
        if(m3d_vm_slot(i,26))ftData_UnkMtxFunc0[kind]=model_render;
        for(j=27;j<46;++j)if(m3d_vm_slot(i,j) && j!=32 && j!=33 && j!=34 && j!=35 && j!=36 && j!=41 && j!=43 && j!=44)
            fprintf(stderr,"M3D LIVE MISSING HOOK kind=%d slot=%u\n",kind,j);
        fprintf(stderr,"M3D LIVE REGISTER name=%s kind=%d internal=%d motions=%u\n",c->name,kind,c->internal,move_counts[i]);
    }
}
