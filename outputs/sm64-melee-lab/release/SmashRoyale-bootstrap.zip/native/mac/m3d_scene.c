/* SPDX-License-Identifier: GPL-3.0-or-later
 * Native animation objects used by original character/effect callbacks.
 * Each allocation receives a fresh guest identity; actual HSD free retires it.
 */
#include "m3d_scene.h"
#include "m3d_akaneia.h"
#include "m3d_vm.h"
#include "m3d_guest_memory.h"
#include "m3d_native_calls.h"
#include <sysdolphin/baselib/aobj.h>
#include <sysdolphin/baselib/cobj.h>
#include <string.h>
#include <stdio.h>
#include <sysdolphin/baselib/dobj.h>
#include <sysdolphin/baselib/mobj.h>
#include "m3d_scene_pool.h"
static M3dScenePool scene_pool;
static M3dSceneRow* scene_row(void* pointer,unsigned kind) {
    M3dSceneRow* row=m3d_scene_pool_pointer(&scene_pool,pointer,kind);if(row)return row;
    row=m3d_scene_pool_acquire(&scene_pool,pointer,kind,m3d_guest_identity(0x100));
    if(!row)m3d_vm_fail("Native scene live identity capacity exhausted");
    m3d_native_bind_object(row->handle,pointer,kind);
    if(scene_pool.allocations%512==0)fprintf(stderr,"M3D SCENE LIFETIME allocations=%u live=%u peak=%u retired=%u\n",scene_pool.allocations,scene_pool.live,scene_pool.peak,scene_pool.retirements);
    return row;
}
static void scene_removed(void* pointer) {
    if(!m3d_akaneia_enabled()||!pointer)return;
    for(unsigned i=0;i<scene_pool.count;i++){M3dSceneRow* row=&scene_pool.rows[i];if(row->pointer==pointer){
        m3d_native_unbind_object(row->handle);m3d_guest_retire(row->handle,0x100);m3d_scene_pool_release(&scene_pool,row);}}
}
void m3d_scene_reset(void) {
    for(unsigned i=0;i<scene_pool.count;i++)if(scene_pool.rows[i].pointer)scene_removed(scene_pool.rows[i].pointer);
}
uint32_t m3d_scene_animation(void* pointer) {
    if(!pointer)return 0;M3dSceneRow* old=m3d_scene_pool_pointer(&scene_pool,pointer,11);if(old)return old->handle;
    M3dSceneRow* row=scene_row(pointer,11);m3d_guest_view(row->handle,0x1c);m3d_guest_field(row->handle,0x14);return row->handle;
}
void m3d_scene_animation_removed(void* pointer){scene_removed(pointer);}
static int material_observe(M3dSceneRow*,uint32_t,size_t,int);
static int camera_observe(M3dSceneRow*,uint32_t,size_t,int);
int m3d_scene_observe(uint32_t address,size_t size,int writing) {
    if(address<0x82000000||address>=0x84000000)return 0;
    M3dSceneRow* row=m3d_scene_pool_find(&scene_pool,address&~255u);if(!row)return 0;
    if(row->kind==17)return camera_observe(row,address,size,writing);
    if(row->kind!=11)return material_observe(row,address,size,writing);
    HSD_AObj* object=row->pointer;unsigned offset=address-row->handle;
    if(offset>=20||size>20-offset)m3d_vm_fail("Unbound native animation pointer field");
    for(unsigned at=offset&~3u;at<offset+size;at+=4){uint32_t bits;
        void* field=at==0?(void*)&object->flags:at==4?(void*)&object->curr_frame:at==8?(void*)&object->rewind_frame:at==12?(void*)&object->end_frame:(void*)&object->framerate;
        if(writing){bits=m3d_vm_read32(row->handle+at);memcpy(field,&bits,4);}else{memcpy(&bits,field,4);m3d_vm_write32(row->handle+at,bits);}}
    return 1;
}

#include <melee/lb/lbspdisplay.h>
#include <sysdolphin/baselib/jobj.h>
static int joint_indices(HSD_JObj* root,uint32_t output,int a,int b,int c,int d,int e,int f)
{
    int indices[6]={a,b,c,d,e,f},found;
    unsigned count;
    HSD_JObj* results[6]={0};
    for(count=0;count<6 && indices[count]!=-1;++count)
        if(indices[count]<0 || indices[count]>4095)m3d_vm_fail("Invalid joint traversal index");
    if(count==6)m3d_vm_fail("Joint traversal requires stack-vararg adapter beyond five indices");
    if(output)m3d_guest_address((void*)(uintptr_t)output,count*4);
    found=lb_80011E24(root,output ? results : NULL,a,b,c,d,e,f,-1);
    if(output && root)for(unsigned i=0;i<count;++i)
        m3d_vm_write32(output+4*i,m3d_akaneia_joint_export(results[i],root));
    return found;
}
static void joint_add_anims(HSD_JObj* joint,uint32_t anim,uint32_t material,uint32_t shape)
{
    HSD_JObjAddAnimAll(joint,m3d_akaneia_native_data(anim),m3d_akaneia_native_data(material),m3d_akaneia_native_data(shape));
}
static void foreach_request(HSD_JObj* joint,uint32_t type,uint32_t mask,uint32_t callback,uint32_t format,uint32_t word0,uint32_t word1,double frame)
{
    /* Original Sonic synchronises its run-effect animation to the fighter's
     * command frame. This is a promoted float vararg, not an integer slot. */
    if(type==JOBJ_TYPE) {
        if(callback==0x8036410c && format==AOBJ_ARG_AF) {
            HSD_ForeachAnim(joint,JOBJ_TYPE,mask,HSD_AObjReqAnim,AOBJ_ARG_AF,frame);return;
        }
        if(callback==0x8036530c && format==AOBJ_ARG_AF) {
            HSD_ForeachAnim(joint,JOBJ_TYPE,mask,HSD_AObjSetRate,AOBJ_ARG_AF,frame);return;
        }
        /* The original run-effect pause sequence encodes SetRate(0) as
         * AOV,0,0 in integer vararg slots (not a promoted floating argument).
         * Normalize only that verified zero tuple; never feed a stale FPR or
         * invoke a native callback through the incompatible AOV signature. */
        if(callback==0x8036530c && format==AOBJ_ARG_AOV && word0==0 && word1==0) {
            HSD_ForeachAnim(joint,JOBJ_TYPE,mask,HSD_AObjSetRate,AOBJ_ARG_AF,0.0);
            static int reported;if(!reported++)fprintf(stderr,"M3D SCENE FOREACH RATE PASS format=6 rate=0\n");return;
        }
        if(callback==0x8036414c && format==AOBJ_ARG_AOV && word0==0 && word1==0) {
            HSD_ForeachAnim(joint,JOBJ_TYPE,mask,HSD_AObjStopAnim,AOBJ_ARG_AOV,NULL);return;
        }
    }
    fprintf(stderr,"M3D SCENE FOREACH REJECT type=%u mask=%x callback=%08x format=%u words=%x,%x\n",type,mask,callback,format,word0,word1);
    m3d_vm_fail("Unbound original ForeachAnim callback/type/format");
}
void m3d_bind_scene(void)
{
    const struct M3dNativeCall indices={0x80011e24,(void(*)(void))joint_indices,M3D_I32,8,
        {M3D_OBJECT,M3D_U32,M3D_I32,M3D_I32,M3D_I32,M3D_I32,M3D_I32,M3D_I32},
        {-1,-1,-1,-1,-1,-1,-1,-1},{3,0,0,0,0,0,0,0}};
    const struct M3dNativeCall anim={0x8036fb5c,(void(*)(void))joint_add_anims,M3D_VOID,4,
        {M3D_OBJECT,M3D_U32,M3D_U32,M3D_U32},{-1,-1,-1,-1},{3,0,0,0}};
    const struct M3dNativeCall foreach={0x80364c08,(void(*)(void))foreach_request,M3D_VOID,8,
        {M3D_OBJECT,M3D_U32,M3D_U32,M3D_U32,M3D_U32,M3D_U32,M3D_U32,M3D_F64},{-1,-1,-1,-1,-1,-1,-1,-1},{3,0,0,0,0,0,0,0}};
    m3d_native_register(&foreach);
    m3d_native_register(&indices); m3d_native_register(&anim);
}

/* Display-object/material views. RGBA bytes retain their byte order while
 * float values use scalar conversion; native pointers never enter guest RAM. */
uint32_t m3d_scene_material(void* pointer,unsigned kind) {
    if(!pointer)return 0;if(kind<14||kind>19||kind==17)m3d_vm_fail("Invalid native material kind");
    M3dSceneRow* old=m3d_scene_pool_pointer(&scene_pool,pointer,kind);if(old)return old->handle;
    uint32_t handle=scene_row(pointer,kind)->handle;
    m3d_guest_view(handle,kind==14?0x18:kind==15?0x20:kind==18?0xac:kind==19?0x20:20);
    if(kind==14){m3d_guest_field(handle+4,8);m3d_guest_field(handle+0x10,8);}
    else if(kind==15)m3d_guest_field(handle+4,12);
    else if(kind==18){m3d_guest_field(handle+8,4);m3d_guest_field(handle+0xa8,4);}
    else if(kind==19)m3d_guest_field(handle+0x10,12);
    else m3d_guest_field(handle,20);
    return handle;
}
void m3d_scene_material_removed(void* pointer){scene_removed(pointer);}
static int material_observe(M3dSceneRow* row,uint32_t address,size_t size,int writing) {
    unsigned offset=address-row->handle,at;
    for(at=offset&~3u;at<offset+size;at+=4) {
        uint32_t guest=row->handle+at,bits=writing ? m3d_vm_read32(guest) : 0,identity=0;
        void* scalar=NULL;
        if(row->kind==14) {
            HSD_DObj* object=row->pointer;
            if(at==4)identity=m3d_scene_material(object->next,14);
            else if(at==8)identity=m3d_scene_material(object->mobj,15);
            else if(at==0x10)identity=m3d_scene_animation(object->aobj);
            else if(at==0x14)scalar=&object->flags;
            else m3d_vm_fail("Unbound native display-object field");
        } else if(row->kind==15) {
            HSD_MObj* object=row->pointer;
            if(at==4)scalar=&object->rendermode;
            else if(at==8)identity=m3d_scene_material(object->tobj,18);
            else if(at==12)identity=m3d_scene_material(object->mat,16);
            else m3d_vm_fail("Unbound native material-object field");
        } else if(row->kind==18) {
            HSD_TObj* object=row->pointer;
            if(at==8)identity=m3d_scene_material(object->next,18);
            else if(at==0xa8)identity=m3d_scene_material(object->tev,19);
            else m3d_vm_fail("Unbound native texture-object field");
        } else if(row->kind==19) {
            HSD_TObjTev* object=row->pointer;
            if(at<0x10 || at>=0x1c)m3d_vm_fail("Unbound native texture-combiner field");
            unsigned char* color=(unsigned char*)&object->konst+at-0x10;
            if(writing)for(unsigned j=0;j<4;++j)color[j]=bits>>(24-8*j);
            else { bits=0; for(unsigned j=0;j<4;++j)bits=(bits<<8)|color[j]; m3d_vm_write32(guest,bits); }
            continue;
        } else {
            HSD_Material* object=row->pointer;
            if(at>=20)m3d_vm_fail("Unbound native material value");
            if(at<12) {
                unsigned char* color=(unsigned char*)object+at;
                if(writing)for(unsigned j=0;j<4;++j)color[j]=bits>>(24-8*j);
                else { bits=0; for(unsigned j=0;j<4;++j)bits=(bits<<8)|color[j]; m3d_vm_write32(guest,bits); }
                continue;
            }
            scalar=at==12 ? (void*)&object->alpha : (void*)&object->shininess;
        }
        if(scalar) { if(writing)memcpy(scalar,&bits,4); else memcpy(&bits,scalar,4); }
        else { if(writing && bits!=identity)m3d_vm_fail("Original module replaced material ownership"); bits=identity; }
        if(!writing)m3d_vm_write32(guest,bits);
    }
    return 1;
}

/* Original trail renderers read the current camera's view matrix directly.
 * Keep it borrowed and read-only, with a fresh identity after native release. */
uint32_t m3d_scene_camera(void* pointer) {
    if(!pointer)return 0;M3dSceneRow* old=m3d_scene_pool_pointer(&scene_pool,pointer,17);if(old)return old->handle;
    uint32_t handle=scene_row(pointer,17)->handle;m3d_guest_view(handle,0x8c);m3d_guest_field(handle+0x54,48);return handle;
}
void m3d_scene_camera_removed(void* pointer){scene_removed(pointer);}
static int camera_observe(M3dSceneRow* row,uint32_t address,size_t size,int writing) {
    unsigned offset=address-row->handle,at;
    if(writing || offset<0x54 || offset>=0x84 || size>0x84-offset)m3d_vm_fail("Unbound original camera field/write");
    for(at=offset&~3u;at<offset+size;at+=4) {
        uint32_t bits; memcpy(&bits,(char*)((HSD_CObj*)row->pointer)->view_mtx+at-0x54,4);
        m3d_vm_write32(row->handle+at,bits);
    }
    return 1;
}
