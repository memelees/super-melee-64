/* SDL's semantic positions stay fixed; printed labels follow the pad family. */
#pragma once
#include <SDL3/SDL_gamepad.h>
#include <string>

static inline bool m3d_PlayStation(SDL_GamepadType t) {
    return t==SDL_GAMEPAD_TYPE_PS3||t==SDL_GAMEPAD_TYPE_PS4||t==SDL_GAMEPAD_TYPE_PS5;
}
static inline bool m3d_Nintendo(SDL_GamepadType t) {
    return t==SDL_GAMEPAD_TYPE_NINTENDO_SWITCH_PRO||t==SDL_GAMEPAD_TYPE_NINTENDO_SWITCH_JOYCON_LEFT||
           t==SDL_GAMEPAD_TYPE_NINTENDO_SWITCH_JOYCON_RIGHT||t==SDL_GAMEPAD_TYPE_NINTENDO_SWITCH_JOYCON_PAIR;
}
static inline std::string m3d_ButtonLabel(SDL_GamepadType type,SDL_GamepadButton button) {
    switch(SDL_GetGamepadButtonLabelForType(type,button)) {
    case SDL_GAMEPAD_BUTTON_LABEL_A:return "A";
    case SDL_GAMEPAD_BUTTON_LABEL_B:return "B";
    case SDL_GAMEPAD_BUTTON_LABEL_X:return "X";
    case SDL_GAMEPAD_BUTTON_LABEL_Y:return "Y";
    case SDL_GAMEPAD_BUTTON_LABEL_CROSS:return "Cross";
    case SDL_GAMEPAD_BUTTON_LABEL_CIRCLE:return "Circle";
    case SDL_GAMEPAD_BUTTON_LABEL_SQUARE:return "Square";
    case SDL_GAMEPAD_BUTTON_LABEL_TRIANGLE:return "Triangle";
    default:break;
    }
    switch(button) {
    case SDL_GAMEPAD_BUTTON_SOUTH:return "Bottom face button";
    case SDL_GAMEPAD_BUTTON_EAST:return "Right face button";
    case SDL_GAMEPAD_BUTTON_WEST:return "Left face button";
    case SDL_GAMEPAD_BUTTON_NORTH:return "Top face button";
    case SDL_GAMEPAD_BUTTON_LEFT_SHOULDER:return m3d_PlayStation(type)?"L1":m3d_Nintendo(type)?"L":"LB";
    case SDL_GAMEPAD_BUTTON_RIGHT_SHOULDER:return m3d_PlayStation(type)?"R1":m3d_Nintendo(type)?"R":"RB";
    case SDL_GAMEPAD_BUTTON_START:return m3d_PlayStation(type)?"Options / Start":m3d_Nintendo(type)?"+":"Start";
    case SDL_GAMEPAD_BUTTON_BACK:return m3d_PlayStation(type)?"Share / Select":m3d_Nintendo(type)?"-":"Back";
    case SDL_GAMEPAD_BUTTON_DPAD_UP:return "D-pad up";
    case SDL_GAMEPAD_BUTTON_DPAD_DOWN:return "D-pad down";
    case SDL_GAMEPAD_BUTTON_DPAD_LEFT:return "D-pad left";
    case SDL_GAMEPAD_BUTTON_DPAD_RIGHT:return "D-pad right";
    default:{const char* s=SDL_GetGamepadStringForButton(button);return s?s:"Unbound";}
    }
}
static inline std::string m3d_AxisLabel(SDL_GamepadType type,SDL_GamepadAxis axis) {
    switch(axis) {
    case SDL_GAMEPAD_AXIS_LEFT_TRIGGER:return m3d_PlayStation(type)?"L2":m3d_Nintendo(type)?"ZL":"LT";
    case SDL_GAMEPAD_AXIS_RIGHT_TRIGGER:return m3d_PlayStation(type)?"R2":m3d_Nintendo(type)?"ZR":"RT";
    case SDL_GAMEPAD_AXIS_LEFTX:return "Left stick horizontal";
    case SDL_GAMEPAD_AXIS_LEFTY:return "Left stick vertical";
    case SDL_GAMEPAD_AXIS_RIGHTX:return "Right stick horizontal";
    case SDL_GAMEPAD_AXIS_RIGHTY:return "Right stick vertical";
    default:return "Unbound";
    }
}
