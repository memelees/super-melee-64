/* SPDX-License-Identifier: GPL-3.0-or-later
 * Exact-input Theater. Seeking reboots through the launcher and re-simulates
 * every saved tick; no pointer-bearing memory snapshot or movie is a replay.
 * Camera, playback cadence and movie output never become gameplay inputs.
 */
#include "m3d_theater.h"
#include "m3d_theater_timing.h"
#include "world/m3d.h"
#include <pc/net.h>
#include <melee/gm/gm_1A3F.h>
#include <melee/gm/types.h>
#include <melee/cm/camera.h>
#include <melee/if/forward.h>
#include <sysdolphin/baselib/controller.h>
#include <sysdolphin/baselib/sislib.h>
#include <sysdolphin/baselib/gobj.h>
#include <sysdolphin/baselib/gobjgxlink.h>
#include <sysdolphin/baselib/state.h>
#include <sysdolphin/baselib/tev.h>
#include <dolphin/pad.h>
#include <dolphin/os.h>
#include <SDL3/SDL_timer.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

static FILE* file;
static int initialized,watching,paused,ended,exporting,options,row,help,hud_hidden;
static void theater_hud(void);
static unsigned ticks,views,previous,total,seek_tick,clip_in,clip_out,quarter=4;
static unsigned last_camera_view,last_camera_video=~0u;
static HSD_PadStatus live;
static HSD_Text* legend;
static int labels[10],shadows[10];
static HSD_CObj* rendered_camera;
static Vec3 gameplay_eye,gameplay_interest;
static float gameplay_fov,gameplay_near,gameplay_far,gameplay_aspect;
static Vec3 movie_eye,movie_interest;
static float movie_fov=45,camera_yaw,camera_pitch;
static int camera_ready,last_fight,menu_armed=1,seek_reported;
static unsigned flow_views;
static Uint64 last_clock;
static double accumulator;
extern struct GameSceneInfo* gm_804D6720;
typedef struct {unsigned checksum;int camera_tick;float yaw;} WorldFrame;
int m3d_theater_viewing(void){return getenv("MELEE3D_THEATER_PLAY")!=NULL;}
int m3d_theater_finished(void){return ended;}
static float theater_deadzone(float value){float a=fabsf(value);return a<.2f?0:copysignf((a-.2f)/.8f,value);}
static unsigned number(const char* key,unsigned fallback){
 const char* e=getenv(key);if(!e)return fallback;char* end;unsigned long n=strtoul(e,&end,10);
 if(!*e||*end||n>60*60*60*6u){fprintf(stderr,"M3D THEATER FAIL option %s\n",key);exit(2);}return n;
}
static int fighting(void){return gm_804D6720&&(gm_804D6720->scene_kind==GS_VS||gm_804D6720->scene_kind==GS_SUDDEN_DEATH);}
static void close_file(void){if(file){fclose(file);file=NULL;}}
static void setup(void){
 if(initialized)return;initialized=1;watching=m3d_theater_viewing();
 const char* path=getenv(watching?"MELEE3D_THEATER_PLAY":"MELEE3D_THEATER_RECORD");if(!path)return;
 file=fopen(path,watching?"rb":"wb");if(!file){fprintf(stderr,"M3D THEATER FAIL open\n");exit(2);}
 atexit(close_file);setvbuf(file,NULL,_IOFBF,65536);char magic[4];
 if(watching){
  if(fread(magic,4,1,file)!=1||memcmp(magic,"BMT1",4)){fprintf(stderr,"M3D THEATER FAIL header\n");exit(2);}
  long offset=ftell(file);fseek(file,0,SEEK_END);long size=ftell(file);fseek(file,offset,SEEK_SET);
  if(size<4||(size-4)%sizeof(WorldFrame)){fprintf(stderr,"M3D THEATER FAIL truncated\n");exit(2);}
  total=(size-4)/sizeof(WorldFrame);seek_tick=number("MELEE3D_THEATER_SEEK",0);if(seek_tick>total)seek_tick=total;
  paused=number("MELEE3D_THEATER_PAUSED",0)!=0;clip_in=number("MELEE3D_THEATER_CLIP_IN",0);
  clip_out=number("MELEE3D_THEATER_CLIP_OUT",total);if(clip_in>total)clip_in=total;if(clip_out>total)clip_out=total;
  const char* speed=getenv("MELEE3D_THEATER_SPEED");float value=speed?strtof(speed,NULL):1;
  quarter=value==.25f?1:value==.5f?2:4;exporting=getenv("MELEE3D_THEATER_EXPORT")!=NULL;
  if(exporting&&(clip_out<=clip_in||seek_tick!=clip_in)){fprintf(stderr,"M3D THEATER FAIL clip range\n");exit(2);}
  const char* camera=getenv("MELEE3D_THEATER_CAMERA");
  if(camera&&sscanf(camera,"%f %f %f %f %f %f %f",&movie_eye.x,&movie_eye.y,&movie_eye.z,&movie_interest.x,&movie_interest.y,&movie_interest.z,&movie_fov)==7){
   float v[]={movie_eye.x,movie_eye.y,movie_eye.z,movie_interest.x,movie_interest.y,movie_interest.z,movie_fov};
   for(int i=0;i<7;i++)if(!isfinite(v[i])||fabsf(v[i])>1000000)exit(2);
   if(movie_fov<5||movie_fov>140)exit(2);camera_ready=1;
  }
  fprintf(stderr,"M3D THEATER LOAD ticks=%u seek=%u speed=%.2f clip=%u..%u export=%d\n",total,seek_tick,quarter/4.f,clip_in,clip_out,exporting);
 }else fwrite("BMT1",4,1,file);
}
void m3d_theater_toggle(void){if(m3d_theater_viewing()){paused=!paused;fprintf(stderr,"M3D THEATER %s tick=%u\n",paused?"PAUSE":"PLAY",ticks);}}
void m3d_theater_end(void){ended=paused=1;fprintf(stderr,"M3D THEATER END ticks=%u\n",ticks);}
void m3d_theater_scene_reset(void){legend=NULL;rendered_camera=NULL;}
void m3d_theater_sync(void){
 setup();if(!file)return;int fight=fighting();
 if(fight&&!last_fight)fprintf(stderr,"M3D THEATER MATCH tick=%u\n",ticks);last_fight=fight;
 WorldFrame frame={fight?m3d_WorldChecksum():0,m3d_match_frame,m3d_CameraGetYaw()};
 if(watching){
  WorldFrame saved;if(fread(&saved,sizeof saved,1,file)!=1){m3d_theater_end();return;}
  if(!isfinite(saved.yaw)||saved.camera_tick<0){fprintf(stderr,"M3D THEATER FAIL invalid frame\n");exit(2);}
  if(frame.checksum!=saved.checksum){fprintf(stderr,"M3D THEATER DIVERGED tick=%u saved=%08x actual=%08x\n",ticks,saved.checksum,frame.checksum);exit(2);}
  m3d_match_frame=saved.camera_tick;m3d_CameraSetYaw(saved.yaw);
 }else {if(fwrite(&frame,sizeof frame,1,file)!=1)exit(2);if(ticks%60==0)fflush(file);}
 ticks++;if(watching&&ticks%120==0)fprintf(stderr,"M3D THEATER VERIFIED ticks=%u hash=%08x\n",ticks,frame.checksum);
}
void m3d_theater_input(void* pointer,int frame)
{
    if(!m3d_theater_viewing()&&getenv("MELEE3D_NATIVE_PAUSE_QUIT_CHECK")){
        static unsigned quit_tick;
        PADStatus* p=pointer;memset(p,0,4*sizeof *p);for(int i=1;i<4;i++)p[i].err=PAD_ERR_NO_CONTROLLER;
        if(gm_804D6720&&gm_804D6720->scene_kind==GS_VS){
            unsigned q=++quit_tick;
            if(q==600){p->button=PAD_BUTTON_START;fprintf(stderr,"M3D PAUSE QUIT INPUT pause\n");}
            if(q==720){p->button=PAD_TRIGGER_L|PAD_TRIGGER_R|PAD_BUTTON_A|PAD_BUTTON_START;fprintf(stderr,"M3D PAUSE QUIT INPUT quit\n");}
        }else if(frame%90==30)p->button=PAD_BUTTON_START;
        return;
    }
    if(m3d_theater_viewing()){
        int intr=OSDisableInterrupts();
        if(!HSD_PadLibData.qcount)HSD_PadLibData.qcount=1;
        OSRestoreInterrupts(intr);return;
    }
    if(!getenv("MELEE3D_THEATER_INPUT_CHECK"))return;
    PADStatus* p=pointer;memset(p,0,4*sizeof *p);for(int i=1;i<4;i++)p[i].err=PAD_ERR_NO_CONTROLLER;
    if(gm_804D6720&&gm_804D6720->scene_kind!=GS_VS&&gm_804D6720->scene_kind!=GS_SUDDEN_DEATH){if(frame%180==120)p->button=PAD_BUTTON_START;return;}
    if(frame<200)return;unsigned t=(frame-200)%240;
    if(t<70){p->stickX=30;p->stickY=55;}
    if(t==85||t==110)p->button=PAD_BUTTON_A;
    if(t==130)p->button=PAD_BUTTON_X;
    if(t>=145&&t<150)p->substickX=70;
    if(t==175)p->button=PAD_BUTTON_B|PAD_BUTTON_UP;
    if(frame==700||frame==740)p->button=PAD_BUTTON_START;
}

static void request(const char* action,unsigned target){
 const char* path=getenv("MELEE3D_THEATER_CONTROL");if(!path)return;
 char temporary[4096];if(snprintf(temporary,sizeof temporary,"%s.tmp",path)>=(int)sizeof temporary)exit(2);
 FILE* f=fopen(temporary,"w");if(!f)exit(2);
 fprintf(f,"action %s\ntick %u\nin %u\nout %u\nspeed %.2f\npaused %d\ncamera %.9g %.9g %.9g %.9g %.9g %.9g %.9g\n",
  action,target,clip_in,clip_out,quarter/4.f,paused||options,movie_eye.x,movie_eye.y,movie_eye.z,movie_interest.x,movie_interest.y,movie_interest.z,movie_fov);
 if(fclose(f)||rename(temporary,path))exit(2);
 fprintf(stderr,"M3D THEATER REQUEST action=%s tick=%u clip=%u..%u speed=%.2f\n",action,target,clip_in,clip_out,quarter/4.f);exit(75);
}
static unsigned shifted(unsigned value,int delta){long n=(long)value+delta;return n<0?0:n>(long)total?total:(unsigned)n;}
static void speed_change(int direction){quarter=direction<0?(quarter==4?2:1):(quarter==1?2:4);fprintf(stderr,"M3D THEATER SPEED %.2f tick=%u\n",quarter/4.f,ticks);}
int m3d_theater_poll(void){
 if(!m3d_theater_viewing())return 0;setup();
 // Presentation token, not simulation time: held/slow/encoder-wait frames
 // must redraw the terrain even when no recorded logic tick advances.
 m3d_camera_frame++;
 if(rendered_camera){
  HSD_CObjSetEyePosition(rendered_camera,&gameplay_eye);HSD_CObjSetInterest(rendered_camera,&gameplay_interest);
  HSD_CObjSetFov(rendered_camera,gameplay_fov);HSD_CObjSetNear(rendered_camera,gameplay_near);HSD_CObjSetFar(rendered_camera,gameplay_far);HSD_CObjSetAspect(rendered_camera,gameplay_aspect);rendered_camera=NULL;
 }
 PADStatus raw[4];PADRead(raw);PADStatus* p=&raw[0];views++;
 if(getenv("MELEE3D_THEATER_CHECK")){
  memset(p,0,sizeof *p);if(views==420||views==600)p->button=PAD_BUTTON_START;
  if(views>=430&&views<480)p->stickX=70;if(views>=480&&views<530)p->substickX=60;
  if(views>=530&&views<580)p->button=PAD_BUTTON_UP;
 }
 if(getenv("MELEE3D_THEATER_FLOW_CHECK")&&fighting()&&ticks>=seek_tick){
  memset(p,0,sizeof *p);unsigned v=++flow_views;
  if(v==20||v==35)p->button=PAD_BUTTON_START;
  if(v==25)p->button=PAD_BUTTON_X;if(v==95)p->button=PAD_BUTTON_Y;
  if(v==105)p->button=PAD_BUTTON_A;if(v==115||v==135)p->stickX=-80;
  if(v==125)p->stickY=-80;
 }
 if(ticks>=seek_tick&&!seek_reported){seek_reported=1;fprintf(stderr,"M3D THEATER SEEK COMPLETE tick=%u\n",ticks);}
 unsigned pressed=p->button&~previous;previous=p->button;
 if(pressed&PAD_BUTTON_B){if(exporting){fprintf(stderr,"M3D THEATER EXPORT CANCELLED\n");exit(0);}if(help)help=0;else if(options)options=0;else exit(0);}
 if(!exporting&&ticks>=seek_tick){
  if(pressed&PAD_BUTTON_START)m3d_theater_toggle();
  if(pressed&PAD_BUTTON_A){
   if(help)help=0;
   else if(!options){options=1;row=0;menu_armed=1;}
   else if(row==0)options=0;
   else if(row==1)request("seek",ticks);
   else if(row==2)clip_in=ticks;
   else if(row==3)clip_out=ticks;
   else if(row==4&&clip_out>clip_in)request("export",ticks);
   else if(row==5)exit(0);
   else if(row==6)help=1;
  }
  if(options&&!help){
   int direction=(pressed&PAD_BUTTON_LEFT)||p->stickX<-45?-1:(pressed&PAD_BUTTON_RIGHT)||p->stickX>45?1:0;
   int vertical=p->stickY>45?-1:p->stickY<-45?1:0;
   if((direction||vertical)&&menu_armed){menu_armed=0;
    if(vertical)row=(row+vertical+7)%7;
    else if(row==0)speed_change(direction);
    else if(row==1)request("seek",shifted(ticks,direction*300));
    else if(row==2)clip_in=shifted(clip_in,direction*60);
    else if(row==3)clip_out=shifted(clip_out,direction*60);
   }else if(!direction&&!vertical)menu_armed=1;
  }else if(!options){
   if(pressed&PAD_BUTTON_DOWN)hud_hidden=!hud_hidden;
   if(pressed&PAD_BUTTON_LEFT)request("seek",shifted(ticks,-300));
   if(pressed&PAD_BUTTON_RIGHT)request("seek",shifted(ticks,300));
   if(pressed&PAD_BUTTON_X)clip_in=ticks;
   if(pressed&PAD_BUTTON_Y)clip_out=ticks;
  }
 }
 memset(&live,0,sizeof live);if(!options){
  live.button=p->button;live.trigger=pressed;live.nml_stickX=p->stickX/80.f;live.nml_stickY=p->stickY/80.f;
  live.nml_subStickX=p->substickX/80.f;live.nml_subStickY=p->substickY/80.f;
  live.nml_analogR=(p->button&PAD_BUTTON_UP)?1:0;live.nml_analogL=p->triggerLeft/255.f;
 }
 if(getenv("MELEE3D_THEATER_CHECK")&&views==590)fprintf(stderr,"M3D THEATER HOLD tick=%u views=%u\n",ticks,views);
 if(exporting){
  m3d_TheaterVideoBegin();
  int status=m3d_TheaterVideoState();if(status<0){fprintf(stderr,"M3D THEATER EXPORT FAIL write\n");exit(2);}
  unsigned count=m3d_TheaterVideoFrames(),limit=m3d_theater_film_frames(clip_in,clip_out,quarter);
  if(count>=limit){fprintf(stderr,"M3D THEATER EXPORT DONE frames=%u speed=%.2f ticks=%u..%u\n",count,quarter/4.f,clip_in,clip_out);exit(0);}
  return 0;
 }
 theater_hud();
 if(ticks<seek_tick)return 0;
 return paused||options||ended;
}
int m3d_theater_steps(int original){
 if(!m3d_theater_viewing())return original;setup();
 /* Flush hardware catch-up batches: replay supplies its own complete samples. */
 HSD_PadFlushQueue(HSD_PAD_FLUSH_QUEUE_LEAVE1);
 if(exporting){
  unsigned frame=m3d_TheaterVideoFrames();
  unsigned target=m3d_theater_film_tick(clip_in,frame,quarter);
  if(ticks>=target||ended)return 0;unsigned delta=target-ticks;
  return delta>32?32:(int)delta;
 }
 if(ticks<seek_tick){unsigned delta=seek_tick-ticks;last_clock=0;accumulator=0;return delta>32?32:(int)delta;}
 Uint64 now=SDL_GetTicksNS();if(!last_clock)last_clock=now;
 double elapsed=(now-last_clock)/1000000000.;last_clock=now;
 if(!original||paused||options||ended){accumulator=0;return 0;}
 /* Bounded catch-up after a window drag; simulation actions are still exact. */
 accumulator+=fmin(elapsed,.1)*15*quarter;int count=(int)accumulator;if(count>6)count=6;
 accumulator-=count;return count;
}
void m3d_theater_capture(void){
 if(!m3d_theater_viewing()||!exporting)return;
 unsigned n=m3d_TheaterVideoFrames(),limit=m3d_theater_film_frames(clip_in,clip_out,quarter);
 if(n<limit&&ticks==m3d_theater_film_tick(clip_in,n,quarter))m3d_TheaterVideoCapture(n);
}
static void text_line(int i,float y,float size){
 shadows[i]=HSD_SisLib_803A6B98(legend,25,y+1," ");labels[i]=HSD_SisLib_803A6B98(legend,24,y," ");
 HSD_SisLib_803A7548(legend,shadows[i],size,size);HSD_SisLib_803A7548(legend,labels[i],size,size);
 GXColor dark={0,0,0,235};HSD_SisLib_803A74F0(legend,shadows[i],&dark);
}
static void show(int i,const char* text,int gold){
 HSD_SisLib_803A70A0(legend,shadows[i],"%s",text);HSD_SisLib_803A70A0(legend,labels[i],"%s",text);
 GXColor c=gold?(GXColor){255,212,52,255}:(GXColor){245,247,255,255};HSD_SisLib_803A74F0(legend,labels[i],&c);
}
void m3d_theater_camera(void* pointer){
 if(!m3d_theater_viewing()||!m3d_StageIs3D())return;HSD_CObj* camera=pointer;
 rendered_camera=camera;HSD_CObjGetEyePosition(camera,&gameplay_eye);HSD_CObjGetInterest(camera,&gameplay_interest);
 gameplay_fov=HSD_CObjGetFov(camera);gameplay_near=HSD_CObjGetNear(camera);gameplay_far=HSD_CObjGetFar(camera);gameplay_aspect=HSD_CObjGetAspect(camera);
 if(!camera_ready&&ticks<seek_tick)return;
 if(!camera_ready){movie_eye=gameplay_eye;movie_interest=gameplay_interest;movie_fov=gameplay_fov;camera_ready=1;}
 if(last_camera_view!=views&&ticks>=seek_tick&&(!exporting||last_camera_video!=m3d_TheaterVideoFrames())){
  if(live.trigger&PAD_TRIGGER_Z){movie_eye=gameplay_eye;movie_interest=gameplay_interest;movie_fov=gameplay_fov;}
  Vec3 d={movie_interest.x-movie_eye.x,movie_interest.y-movie_eye.y,movie_interest.z-movie_eye.z};
  camera_yaw=atan2f(d.x,d.z);camera_pitch=atan2f(d.y,hypotf(d.x,d.z));
  camera_yaw-=theater_deadzone(live.nml_subStickX)*.035f;camera_pitch+=theater_deadzone(live.nml_subStickY)*.03f;
  camera_pitch=fmaxf(-1.48f,fminf(1.48f,camera_pitch));float side=theater_deadzone(live.nml_stickX)*4,forward=theater_deadzone(live.nml_stickY)*4;
  movie_eye.x+=-side*cosf(camera_yaw)+forward*sinf(camera_yaw);movie_eye.z+=side*sinf(camera_yaw)+forward*cosf(camera_yaw);
  movie_eye.y+=4*(fmaxf(live.nml_analogR,(live.button&PAD_TRIGGER_R)?1:0)-fmaxf(live.nml_analogL,(live.button&PAD_TRIGGER_L)?1:0));
  movie_interest=(Vec3){movie_eye.x+sinf(camera_yaw)*cosf(camera_pitch)*100,movie_eye.y+sinf(camera_pitch)*100,movie_eye.z+cosf(camera_yaw)*cosf(camera_pitch)*100};
  last_camera_view=views;last_camera_video=m3d_TheaterVideoFrames();
 }
 HSD_CObjSetEyePosition(camera,&movie_eye);HSD_CObjSetInterest(camera,&movie_interest);HSD_CObjSetFov(camera,movie_fov);HSD_CObjSetNear(camera,1);HSD_CObjSetFar(camera,16384);
}
/* Melee's native Camera Mode uses HSD widgets and an on-demand display
 * (gmCamera_801A2798). Keep that clean-screen pattern without installing its
 * P4 snapshot/memory-card state machine into recorded-match playback. */
static void hud_quad(float x,float y,float w,float h,GXColor c){
 GXBegin(GX_QUADS,GX_VTXFMT0,4);
 GXPosition3f32(x,-y,0);GXColor4u8(c.r,c.g,c.b,c.a);
 GXPosition3f32(x+w,-y,0);GXColor4u8(c.r,c.g,c.b,c.a);
 GXPosition3f32(x+w,-y-h,0);GXColor4u8(c.r,c.g,c.b,c.a);
 GXPosition3f32(x,-y-h,0);GXColor4u8(c.r,c.g,c.b,c.a);GXEnd();
}
static void hud_graphics(HSD_GObj* object,intptr_t pass){
 (void)object;if(pass!=2||exporting||(hud_hidden&&!options))return;
 HSD_CObj* camera=HSD_CObjGetCurrent();if(!camera)return;
 HSD_StateInvalidate(HSD_STATE_ALL);HSD_StateInitTev();
 GXSetFog(GX_FOG_NONE,0,0,0,0,(GXColor){0,0,0,255});
 GXSetNumTexGens(0);GXSetNumChans(1);GXSetNumTevStages(1);
 GXSetTevOrder(GX_TEVSTAGE0,GX_TEXCOORD_NULL,GX_TEXMAP_NULL,GX_COLOR0A0);GXSetTevOp(GX_TEVSTAGE0,GX_PASSCLR);
 GXSetChanCtrl(GX_COLOR0A0,GX_DISABLE,GX_SRC_REG,GX_SRC_VTX,0,GX_DF_NONE,GX_AF_NONE);
 GXSetBlendMode(GX_BM_BLEND,GX_BL_SRCALPHA,GX_BL_INVSRCALPHA,GX_LO_NOOP);
 GXSetZMode(GX_DISABLE,GX_ALWAYS,GX_DISABLE);GXSetZCompLoc(GX_ENABLE);
 GXSetAlphaCompare(GX_ALWAYS,0,GX_AOP_AND,GX_ALWAYS,0);GXSetColorUpdate(GX_ENABLE);GXSetAlphaUpdate(GX_DISABLE);GXSetCullMode(GX_CULL_NONE);
 GXClearVtxDesc();GXSetVtxDesc(GX_VA_POS,GX_DIRECT);GXSetVtxDesc(GX_VA_CLR0,GX_DIRECT);
 GXSetVtxAttrFmt(GX_VTXFMT0,GX_VA_POS,GX_POS_XYZ,GX_F32,0);GXSetVtxAttrFmt(GX_VTXFMT0,GX_VA_CLR0,GX_CLR_RGBA,GX_RGBA8,0);
 GXLoadPosMtxImm(HSD_CObjGetViewingMtxPtrDirect(camera),0);GXSetCurrentMtx(0);
 GXColor gold={255,212,52,255},white={245,247,255,255};
 hud_quad(20,411,600,51,(GXColor){5,12,27,222});hud_quad(20,411,600,1,gold);
 if(paused||options||ended){hud_quad(34,424,3,11,white);hud_quad(40,424,3,11,white);}
 else {GXBegin(GX_TRIANGLES,GX_VTXFMT0,3);GXPosition3f32(34,-424,0);GXColor4u8(245,247,255,255);GXPosition3f32(44,-430,0);GXColor4u8(245,247,255,255);GXPosition3f32(34,-436,0);GXColor4u8(245,247,255,255);GXEnd();}
 hud_quad(34,448,572,3,(GXColor){104,113,130,255});
 float scale=total?572.f/total:0;
 if(clip_out>clip_in)hud_quad(34+clip_in*scale,448,(clip_out-clip_in)*scale,3,gold);
 hud_quad(34+ticks*scale-1,444,3,11,white);
 hud_quad(34+clip_in*scale,446,2,7,gold);hud_quad(34+clip_out*scale-2,446,2,7,gold);
 if(options){
  hud_quad(146,166,348,223,(GXColor){5,12,27,242});hud_quad(146,166,348,2,gold);
  if(!help)hud_quad(157,207+row*23,326,22,(GXColor){71,79,100,210});
 }
 HSD_StateInvalidate(HSD_STATE_ALL);HSD_StateInitTev();
}
static void theater_hud(void){
 if(exporting)return;
 int sis=HSD_SisLib_804D1124[2]?2:HSD_SisLib_804D1124[0]?0:-1;
 if(!legend&&sis>=0){
  /* A dedicated native text canvas survives every replay scene's own UI,
   * and isolates the timeline from other scenes' camera render masks. */
  int canvas=HSD_SisLib_803A611C(sis,NULL,HSD_GOBJ_CLASS_UI,15,0,62,1,25);
  legend=HSD_SisLib_803A6754(sis,canvas);legend->default_kerning=1;
  HSD_GObj* panel=GObj_Create(HSD_GOBJ_CLASS_UI,15,0);GObj_SetupGXLink(panel,hud_graphics,62,0);
  text_line(0,421,.34f);text_line(1,421,.30f);text_line(2,178,.43f);
  for(int i=0;i<7;i++)text_line(i+3,211+i*23,.34f);
  /* Native SIS glyphs include a 24-pixel baseline below their anchor. */
  HSD_SisLib_803A746C(legend,labels[0],52,421-24);HSD_SisLib_803A746C(legend,shadows[0],53,422-24);
  HSD_SisLib_803A746C(legend,labels[1],535,421-24);HSD_SisLib_803A746C(legend,shadows[1],536,422-24);
  for(int i=2;i<10;i++){float y=(i==2?178:211+(i-3)*23)-24;HSD_SisLib_803A746C(legend,labels[i],166,y);HSD_SisLib_803A746C(legend,shadows[i],167,y+1);}
 }
 if(!legend)return;
 for(int i=0;i<10;i++)show(i,"",0);
 if(hud_hidden&&!options)return;
 char line[256];unsigned sec=ticks/60;
 snprintf(line,sizeof line,"%02u:%02u / %02u:%02u   %.2gx%s",sec/60,sec%60,total/3600,(total/60)%60,quarter/4.,ticks<seek_tick?"   SEEKING":ended?"   END":"");show(0,line,0);show(1,"A: Menu",0);
 if(!options)return;show(2,help?"CONTROLS":"THEATER",1);
 const char* controls[]={"Left stick: Move camera","Right stick: Look","L1 / L2: Up / Down","Start: Pause / Play","D-pad Left / Right: Seek 5s","X / Y: Clip In / Out","Z: Reset   D-pad Down: Hide"};
 const char* names[]={"Playback speed","Seek 5 seconds","Clip In","Clip Out","Save video clip","Recordings","Controls"};
 for(int i=0;i<7;i++){
  if(help){show(i+3,controls[i],0);continue;}
  unsigned t=i==2?clip_in:clip_out;
  if(i==0)snprintf(line,sizeof line,"%s       %.2gx",names[i],quarter/4.);
  else if(i==2||i==3)snprintf(line,sizeof line,"%s          %02u:%02u.%02u",names[i],t/3600,(t/60)%60,(t%60)*100/60);
  else snprintf(line,sizeof line,"%s",names[i]);show(i+3,line,row==i);
 }
}
