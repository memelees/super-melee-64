/* SPDX-License-Identifier: GPL-3.0-or-later
 * m-ex relative effects, using the native engine's real effect banks.
 * Behavior adapted from GurekamDhillon/melee (GPL-2.0-or-later),
 * pc-port f5662df, efSync_MexSpawn; originally m-ex Effect Expansion.
 * Numeric/typed arguments cross the ABI explicitly. Unknown signatures and
 * copied-fighter/item ownership stop the laboratory instead of hiding effects.
 */
#include "m3d_akaneia.h"
#include "m3d_items.h"
#include <melee/it/types.h>
#include "m3d_guest_memory.h"
#include "m3d_native_calls.h"
#include "m3d_vm.h"
#include "m3d_scene_pool.h"
#include <melee/ef/efasync.h>
#include <melee/ef/eflib.h>
#include <melee/ef/efsync.h>
#include <melee/ft/types.h>
#include <melee/lb/lb_00B0.h>
#include <melee/lb/lb_00F9.h>
#include <sysdolphin/baselib/gobj.h>
#include <sysdolphin/baselib/generator.h>
#include <sysdolphin/baselib/jobj.h>
#include <sysdolphin/baselib/psstructs.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

struct EffectBank {
    int kind,bank;
    const char *file,*symbol;
    unsigned count[2];
    const unsigned char* types[2];
};
#include "m3d_effect_data.inc"
static struct { void *pointer,*object; HSD_GObj* owner; uint32_t handle,callback,updates; int particle; } handles[4096];
static unsigned handle_count;
static M3dScenePool effect_pool;

static int resolve(int id,HSD_GObj* object,int* final_id,int* particle)
{
    unsigned i,index;
    int kind;
    if(!object || id<5000 || id>=7000)m3d_vm_fail("Custom effect requires a bound fighter/item bank (5000..6999)");
    if(object->classifier==HSD_GOBJ_CLASS_FIGHTER)kind=((Fighter*)object->user_data)->kind;
    else if(object->classifier==HSD_GOBJ_CLASS_ITEM)kind=m3d_items_fighter_kind(((Item*)object->user_data)->kind);
    else { m3d_vm_fail("Custom effect has no fighter/item owner"); return 0; }
    for(i=0;i<7;++i)if(banks[i].kind==kind)break;
    if(i==7)m3d_vm_fail("Custom effect requested by an unregistered fighter kind");
    *particle=id>=6000; index=id%1000;
    if(index>=banks[i].count[*particle])m3d_vm_fail("Custom effect exceeds its original behavior table");
    efAsync_LoadSync(banks[i].bank);
    if(!efAsync_DatEntries[banks[i].bank].data)m3d_vm_fail("Custom native effect bank did not load");
    *final_id=banks[i].bank*1000+index;
    return banks[i].types[*particle][index];
}

/* Native callers (including native subaction code) pass native pointers.
 * The bridge below first converts original pointers into typed arguments. */
void* m3d_akaneia_effect_sync(int id,HSD_GObj* object,va_list args)
{
    int final_id,particle,type=resolve(id,object,&final_id,&particle);
    EF_Effect* effect=NULL;
    HSD_Generator* generator;
    HSD_JObj* joint;
    Vec3 pos;
    float facing;
    if(particle) {
        switch(type) {
        case 0: return efLib_CreateGenerator(final_id,va_arg(args,Vec3*));
        case 1: case 2: case 3:
            pos=*va_arg(args,Vec3*); facing=*va_arg(args,float*);
            return efLib_CreateGenerator_Translate_FacingDir(final_id,&pos,facing);
        case 5:
            generator=hsd_8039EFAC(0,final_id/1000,final_id,va_arg(args,HSD_JObj*));
            if(generator)generator->size*=((HSD_JObj*)object->hsd_obj)->scale.x;
            return generator;
        case 6: return efLib_CreateGenerator_AppSRT_SetFacingDir(final_id,args);
        case 7: return efLib_CreateGenerator_Attach_Scale(final_id,args,object);
        default: m3d_vm_fail("Unsupported original particle placement behavior");
        }
    }
    switch(type) {
    case 0: case 2:
        effect=efLib_Create_Attach_Pos(final_id,object,va_arg(args,Vec3*));
        facing=*va_arg(args,float*);
        if(effect)HSD_JObjSetRotationZ(effect->gobj->hsd_obj,facing);
        break;
    case 1:
        effect=efLib_Create_Attach_Pos(final_id,object,va_arg(args,Vec3*));
        if(effect)HSD_JObjSetScale(effect->gobj->hsd_obj,&((HSD_JObj*)object->hsd_obj)->scale);
        break;
    case 3:
        joint=va_arg(args,HSD_JObj*); lb_8000B1CC(joint,NULL,&pos);
        effect=efLib_Create_Attach_Pos(final_id,object,&pos);
        if(effect) {
            HSD_JObjSetRotationY(effect->gobj->hsd_obj,0);
            HSD_JObjSetRotationZ(effect->gobj->hsd_obj,joint->rotate.z);
        }
        break;
    case 4:
        pos=*va_arg(args,Vec3*); facing=*va_arg(args,float*);
        effect=efLib_Create_Attach_Pos(final_id,object,&pos);
        if(effect) {
            HSD_JObjSetRotationY(effect->gobj->hsd_obj,facing<0 ? -M_PI_2 : M_PI_2);
            HSD_JObjSetScale(effect->gobj->hsd_obj,&((HSD_JObj*)object->hsd_obj)->scale);
        }
        break;
    case 5: effect=efLib_Create_Attach_Scale(final_id,object,va_arg(args,HSD_JObj*)); break;
    case 6: effect=efLib_Create_AttachChild_Scale(final_id,object,va_arg(args,HSD_JObj*)); break;
    default: m3d_vm_fail("Unsupported original model effect placement behavior");
    }
    if(object->classifier==HSD_GOBJ_CLASS_FIGHTER) {
        ((Fighter*)object->user_data)->pre_hitlag_cb=efLib_PauseAll;
        ((Fighter*)object->user_data)->post_hitlag_cb=efLib_ResumeAll;
    } else {
        ((Item*)object->user_data)->entered_hitlag=efLib_PauseAll;
        ((Item*)object->user_data)->exited_hitlag=efLib_ResumeAll;
    }
    return effect;
}

static uint32_t original_sync(int32_t id,HSD_GObj* object,uint32_t arg,uint32_t extra)
{
    int final_id,particle,type;
    if(id>=0 && (id<0x250 || id/1000==30)) { final_id=id; particle=1; type=0; }
    /* Lucas's projectile OnDestroy requests the ordinary position-only
     * effect 0x421. efAsync_Dispatch maps it to common particle 0x3f. */
    else if(id==0x421) { final_id=0x3f; particle=1; type=0; }
    /* Lucas's PK Thunder rocket hitting a surface uses the retail landing
     * burst, with a world position and surface angle. It is a model effect,
     * not a relative custom-bank ID or a position-only particle. */
    else if(id==0x406) { final_id=4; particle=0; type=2; }
    else type=resolve(id,object,&final_id,&particle);
    int follows=particle ? type>=5 : type==3 || type>=5;
    int needs_extra=particle ? type==1 || type==2 || type==3 || type==6 : type==0 || type==2 || type==4;
    Vec3 pos;
    float parameter=0;
    void *argument,*result;
    unsigned i;
    if(follows)argument=m3d_native_object(arg,3);
    else {
        uint32_t bits[3];
        for(i=0;i<3;++i)bits[i]=m3d_vm_read32(arg+4*i);
        memcpy(&pos,bits,sizeof pos); argument=&pos;
    }
    if(needs_extra) { uint32_t bits=m3d_vm_read32(extra); memcpy(&parameter,&bits,4); }
    result=efSync_Spawn(id,object,argument,&parameter);
    if(!result)return 0;
    for(i=0;i<handle_count;++i)if(handles[i].pointer==result && handles[i].particle==particle)return handles[i].handle;
    M3dSceneRow* row=m3d_scene_pool_acquire(&effect_pool,result,particle?7:6,m3d_guest_identity(0x100));
    if(!row)m3d_vm_fail("Original effect live identity capacity exhausted");
    i=(unsigned)(row-effect_pool.rows);if(i>=handle_count)handle_count=i+1;
    memset(&handles[i],0,sizeof handles[i]);handles[i].pointer=result;handles[i].particle=particle;
    handles[i].owner=object;
    handles[i].object=particle ? result : ((EF_Effect*)result)->gobj;
    handles[i].handle=row->handle;
    m3d_native_bind_object(handles[i].handle,result,particle ? 7 : 6);
    /* Opaque typed identity for native helpers; direct struct access needs an
     * explicit field adapter and therefore fails closed at present. */
    m3d_guest_view(handles[i].handle,0x100);
    if(!particle)m3d_guest_field(handles[i].handle,0x2c);
    else m3d_guest_field(handles[i].handle+0x4c,4);
    fprintf(stderr,"M3D LIVE EFFECT kind=%d id=%d native_id=%d particle=%d handle=%08x\n",
            !object ? -1 : object->classifier==HSD_GOBJ_CLASS_FIGHTER ? ((Fighter*)object->user_data)->kind : m3d_items_fighter_kind(((Item*)object->user_data)->kind),id,final_id,particle,handles[i].handle);
    return handles[i].handle;
}
uint32_t m3d_akaneia_effect_identity(void* effect)
{
    unsigned i;
    if(!effect)return 0;
    for(i=0;i<handle_count;++i)if(handles[i].pointer==effect && !handles[i].particle)return handles[i].handle;
    m3d_vm_fail("Unregistered native effect identity"); return 0;
}
static void update_effect(EF_Effect* effect)
{
    unsigned i;
    for(i=0;i<handle_count;++i)if(handles[i].pointer==effect && !handles[i].particle) {
        uint32_t args[1]={handles[i].handle};
        if(++handles[i].updates==1)fprintf(stderr,"M3D LIVE EFFECT UPDATE handle=%08x callback=%08x\n",handles[i].handle,handles[i].callback);
        m3d_akaneia_call(handles[i].owner,handles[i].callback,args,1); return;
    }
    m3d_vm_fail("Unregistered original effect update");
}
int m3d_akaneia_effect_observe(uint32_t address,size_t size,int writing)
{
    unsigned index,offset,i;
    EF_Effect* effect;
    if(address<0x82000000 || address>=0x84000000)return 0;
    M3dSceneRow* row=m3d_scene_pool_find(&effect_pool,address&~255u);if(!row)return 0;
    index=(unsigned)(row-effect_pool.rows);offset=address-row->handle;
    if(!handles[index].pointer)m3d_vm_fail("Stale original effect view");
    if(handles[index].particle) {
        /* Original recoveries orient their existing particle generator on
         * contact. Preserve that float without exporting native pointers or
         * pretending the opaque generator has the EF_Effect layout. */
        if(offset!=0x4c || size!=4)m3d_vm_fail("Unbound original generator field");
        HSD_Generator* generator=handles[index].pointer;
        uint32_t bits;
        if(writing) {bits=m3d_vm_read32(address);memcpy(&generator->angle,&bits,4);}
        else {memcpy(&bits,&generator->angle,4);m3d_vm_write32(address,bits);}
        static int logged;
        if(!logged++){fprintf(stderr,"M3D GENERATOR ANGLE PASS read_write=%d\n",writing);}
        return 1;
    }
    if(offset>=0x2c || size>0x2c-offset)
        m3d_vm_fail("Unbound original effect field");
    effect=handles[index].pointer;
    for(i=offset&~3u;i<offset+size;i+=4) {
        uint32_t at=handles[index].handle+i,bits=writing ? m3d_vm_read32(at) : 0;
        if(i==0) {
            if(writing)effect->next=m3d_native_object(bits,6);
            else bits=m3d_akaneia_effect_identity(effect->next);
        } else if(i==4 || i==8 || i==12) {
            void** pointer=i==4 ? (void**)&effect->gobj : i==8 ? (void**)&effect->parent_gobj : (void**)&effect->attach_jobj;
            unsigned kind=i==12 ? 3 : 1;
            if(writing) {
                void* proposed=m3d_native_object(bits,kind);
                /* parent_gobj is a non-owning attachment. Trail callbacks
                 * deliberately clear it to let an effect expire independently.
                 * The effect's own allocated GObj remains lifetime-managed. */
                if(i==4 && proposed!=*pointer)m3d_vm_fail("Original module changed effect object ownership");
                *pointer=proposed;
            } else bits=m3d_akaneia_object_export(*pointer,kind);
        } else if(i==0x10) {
            if(writing) {
                void (*native)(void)=m3d_native_callback_decode_kind(bits,6);
                handles[index].callback=bits;
                effect->update=native ? (EF_UpdateFn)native : bits ? update_effect : NULL;
            } else {
                if(effect->update!=update_effect)handles[index].callback=m3d_native_callback_encode_kind((void(*)(void))effect->update,6);
                bits=handles[index].callback;
            }
        } else if(i==0x14) {
            if(writing)effect->user_data=bits ? m3d_guest_address((void*)(uintptr_t)bits,1) : NULL;
            else bits=m3d_guest_encode_buffer(effect->user_data);
        } else if(i<0x24) {
            float* value=&effect->params.x+(i-0x18)/4;
            if(writing)memcpy(value,&bits,4); else memcpy(&bits,value,4);
        } else if(i==0x24) {
            if(writing) { effect->lifetime=bits>>16; effect->expire_flags=(bits>>8)&255; effect->scale_flags=bits&255; }
            else bits=((uint32_t)effect->lifetime<<16)|((uint32_t)(unsigned char)effect->expire_flags<<8)|(unsigned char)effect->scale_flags;
        } else {
            if(writing) { effect->state_flags=bits>>24; effect->is_async=bits>>16; effect->stored_alpha_variant=bits>>8; effect->x2B=bits; }
            else bits=((uint32_t)effect->state_flags<<24)|((uint32_t)effect->is_async<<16)|((uint32_t)(unsigned char)effect->stored_alpha_variant<<8)|(unsigned char)effect->x2B;
        }
        if(!writing)m3d_vm_write32(at,bits);
    }
    return 1;
}
void m3d_akaneia_effect_removed(void* object,int particle)
{
    unsigned i;
    if(!m3d_akaneia_enabled())return;
    for(i=0;i<handle_count;++i)if(handles[i].object==object && handles[i].particle==particle) {
        m3d_native_unbind_object(handles[i].handle); m3d_guest_retire(handles[i].handle,0x100);
        m3d_scene_pool_release(&effect_pool,&effect_pool.rows[i]);
        handles[i].pointer=handles[i].object=NULL;
    }
}
void m3d_akaneia_effect_scene_reset(void)
{
    for(unsigned i=0;i<handle_count;i++)if(handles[i].object)m3d_akaneia_effect_removed(handles[i].object,handles[i].particle);
}
static void original_async(HSD_GObj* object,uint32_t head,uint32_t kind,uint32_t id,HSD_JObj* joint,uint32_t arg,uint32_t extra,uint32_t third)
{
    Fighter* fp=m3d_native_object(head-0x60c,2);
    Vec3 pos={0}; float one=0,two=0; uint32_t bits;
    if(!object || object->classifier!=HSD_GOBJ_CLASS_FIGHTER || fp!=object->user_data)
        m3d_vm_fail("Queued effect head does not belong to its fighter");
    if(kind==2 || kind==5 || kind==6 || kind==7 || kind==8) {
        for(unsigned i=0;i<3;++i) { bits=m3d_vm_read32(arg+4*i); memcpy((char*)&pos+4*i,&bits,4); }
    } else if(kind==3 || kind==4) { bits=m3d_vm_read32(arg); memcpy(&one,&bits,4); }
    if(kind==5 || kind==6) { bits=m3d_vm_read32(extra); memcpy(&one,&bits,4); }
    if(kind==6) { bits=m3d_vm_read32(third); memcpy(&two,&bits,4); }
    switch(kind) {
    case 0: case 1: efAsync_Spawn(object,&fp->x60C,kind,id,joint); break;
    case 3: case 4: efAsync_Spawn(object,&fp->x60C,kind,id,joint,&one); break;
    case 2: case 7: case 8: efAsync_Spawn(object,&fp->x60C,kind,id,joint,&pos); break;
    case 5: efAsync_Spawn(object,&fp->x60C,kind,id,joint,&pos,&one); break;
    case 6: efAsync_Spawn(object,&fp->x60C,kind,id,joint,&pos,&one,&two); break;
    default: m3d_vm_fail("Unknown queued-effect placement kind");
    }
}
static void original_hit_burst(uint32_t position,int count,float scale,float speed,float angle)
{
    uint32_t bits[3];Vec3 native;
    for(unsigned i=0;i<3;i++)bits[i]=m3d_vm_read32(position+4*i);
    memcpy(&native,bits,sizeof native);
    lb_800119DC(&native,count,scale,speed,angle);
}
void m3d_bind_effects(void)
{
    unsigned i;
    const struct M3dNativeCall sync={0x8005fddc,(void(*)(void))original_sync,M3D_U32,4,
        {M3D_I32,M3D_OBJECT,M3D_U32,M3D_U32},{-1,-1,-1,-1},{0,1,0,0}};
    const struct M3dNativeCall rotate={0x8005e3a0,(void(*)(void))efLib_Cb_SetRotYZ_FromFighter,M3D_VOID,1,
        {M3D_OBJECT},{-1},{6}};
    for(i=0;i<7;++i) {
        EF_DAT_Entry* entry=&efAsync_DatEntries[banks[i].bank];
        if(entry->data || entry->ef_DAT_file)m3d_vm_fail("Custom effect bank would overwrite a native bank");
        entry->ef_DAT_file=(char*)banks[i].file; entry->effDataTable_name=(char*)banks[i].symbol;
    }
    const struct M3dNativeCall async={0x800676f0,(void(*)(void))original_async,M3D_VOID,8,
        {M3D_OBJECT,M3D_U32,M3D_U32,M3D_U32,M3D_OBJECT,M3D_U32,M3D_U32,M3D_U32},
        {-1,-1,-1,-1,-1,-1,-1,-1},{1,0,0,0,3,0,0,0}};
    m3d_native_register(&async);
    m3d_native_register(&sync);
    m3d_native_register(&rotate);
    const struct M3dNativeCall burst={0x800119dc,(void(*)(void))original_hit_burst,M3D_VOID,5,
        {M3D_U32,M3D_I32,M3D_F32,M3D_F32,M3D_F32},{-1,-1,-1,-1,-1}};
    m3d_native_register(&burst);
}
