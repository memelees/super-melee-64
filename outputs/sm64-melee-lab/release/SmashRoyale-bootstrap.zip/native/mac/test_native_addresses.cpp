/* SPDX-License-Identifier: GPL-3.0-or-later
 * Check the real port's descriptor address encoding at expanded ARAM bounds. */
#include "pc/disc.h"
#include "pc/pc.h"
#include <cassert>
#include <cstdio>
#include <initializer_list>
uintptr_t OSBaseAddress=UINT64_C(0x380000000);
static const void* registered;
extern "C" uint32_t pc_register_ext_ptr(const void* p) { registered=p; return 1; }
extern "C" void* pc_resolve_ext_ptr(uint32_t id) { return id==1 ? const_cast<void*>(registered) : nullptr; }
int main()
{
    assert(PC_ARAM_SIZE == 128u*1024*1024);
    assert(PC_MEM1_SIZE == 96u*1024*1024);
    assert(PC_IS_ARAM_ADDR((void*)(uintptr_t)0x07fffffc));
    assert((uintptr_t)pc_resolve_dp(0x07fffffc)==0x07fffffc);
    assert(!PC_IS_ARAM_ADDR((void*)(uintptr_t)0x10000000));
    for (uintptr_t offset : {uintptr_t(0x1000001),uintptr_t(0x2000001),uintptr_t(0x3ffffff),uintptr_t(0x7ffffff)}) {
        const void* p=reinterpret_cast<void*>(offset);
        assert(PC_IS_ARAM_ADDR(p));
        assert(pc_encode_dp(p)==offset);
        assert(pc_resolve_dp(pc_encode_dp(p))==p);
    }
    const void* native=reinterpret_cast<void*>(UINT64_C(0x123456789));
    uint32_t encoded=pc_encode_dp(native);
    assert(encoded==0x7f000001u);
    assert(pc_resolve_dp(encoded)==native);
    assert(!PC_IS_ARAM_ADDR(native));
    const void* mem1=reinterpret_cast<void*>(OSBaseAddress+0x123456);
    assert(pc_resolve_dp(pc_encode_dp(mem1))==mem1);
    const void* upper=reinterpret_cast<void*>(OSBaseAddress+PC_MEM1_SIZE-4);
    assert(pc_resolve_dp(pc_encode_dp(upper))==upper);
    assert(!pc_resolve_dp(0));
    puts("M3D NATIVE ADDRESS PASS expanded_aram_external_pointer_mem1");
}
