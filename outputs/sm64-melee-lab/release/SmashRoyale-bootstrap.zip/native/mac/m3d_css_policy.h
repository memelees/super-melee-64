/* SPDX-License-Identifier: GPL-3.0-or-later
 * Character choices are preferences; Random is resolved per match, never an
 * empty player slot. Local deterministic shuffling does not consume game RNG. */
#ifndef M3D_CSS_POLICY_H
#define M3D_CSS_POLICY_H
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>
#include <ctype.h>
#define M3D_CSS_RANDOM (-1)
static const int m3d_css_characters[]={8,2,0,1,4,5,6,19,11,12,14,13,16,17,15,10,7,9,18,21,22,20,24,3,25,23,34,35,36,37,38,39,40};
typedef struct {int human,costume,cpu;} M3dCssPreferences;
static int m3d_css_valid_character(int c){if(c==M3D_CSS_RANDOM)return 1;for(unsigned i=0;i<33;i++)if(m3d_css_characters[i]==c)return 1;return 0;}
static uint32_t m3d_css_next(uint32_t* state){uint32_t n=*state?*state:0x9e3779b9u;n^=n<<13;n^=n>>17;n^=n<<5;return *state=n;}
static int m3d_css_costume(int color,int count){return count>0&&color>=0?color%count:0;}
static unsigned m3d_css_cpu_costume(unsigned ordinal,unsigned variants,unsigned reserved,unsigned offset){
 if(!variants)return 0;unsigned available[32],count=0;
 for(unsigned c=0;c<variants&&c<32;c++)if(!(reserved&(1u<<c)))available[count++]=c;
 if(count){unsigned index=ordinal%variants;if(index<count)return available[(index+offset)%count];}
 return (ordinal+offset)%variants;
}
static int m3d_css_read(FILE* f,M3dCssPreferences* out){M3dCssPreferences p;char line[128];
 if(!fgets(line,sizeof line,f)||!strchr(line,'\n')||strncmp(line,"CSS1 ",5))return 0;
 char* cursor=line+5;int* values[]={&p.human,&p.costume,&p.cpu};
 for(int i=0;i<3;i++){while(isspace((unsigned char)*cursor))cursor++;char* end;errno=0;long n=strtol(cursor,&end,10);if(errno||end==cursor||n<INT_MIN||n>INT_MAX||(*end&&!isspace((unsigned char)*end)))return 0;*values[i]=(int)n;cursor=end;}
 while(isspace((unsigned char)*cursor))cursor++;if(*cursor)return 0;int c;while((c=fgetc(f))!=EOF)if(!isspace((unsigned char)c))return 0;
 if(!m3d_css_valid_character(p.human)||!m3d_css_valid_character(p.cpu)||p.costume<0||p.costume>31)return 0;*out=p;return 1;}
static void m3d_css_write(FILE* f,const M3dCssPreferences* p){fprintf(f,"CSS1 %d %d %d\n",p->human,p->costume,p->cpu);}
static int m3d_css_resolve(int choice,uint32_t* state){return choice==M3D_CSS_RANDOM?m3d_css_characters[m3d_css_next(state)%33]:choice;}
static void m3d_css_fill(int out[32],const int* humans,int count,int cpu,uint32_t seed){
 int pool[33],used[41]={0};memcpy(pool,m3d_css_characters,sizeof pool);if(count<1)count=1;if(count>32)count=32;
 for(int i=32;i>0;i--){int j=m3d_css_next(&seed)%(i+1),v=pool[i];pool[i]=pool[j];pool[j]=v;}
 for(int i=0;i<count;i++){out[i]=m3d_css_resolve(humans[i],&seed);if(!m3d_css_valid_character(out[i])||out[i]<0)out[i]=38;used[out[i]]++;}
 for(int i=count;i<32;i++){int choice=cpu;if(choice==M3D_CSS_RANDOM){int best=100;for(int j=0;j<33;j++)if(used[pool[j]]<best){best=used[pool[j]];choice=pool[j];}}
 if(!m3d_css_valid_character(choice)||choice<0)choice=38;out[i]=choice;used[choice]++;}
}
#endif
