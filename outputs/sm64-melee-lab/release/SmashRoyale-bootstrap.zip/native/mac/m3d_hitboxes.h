/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef M3D_HITBOXES_H
#define M3D_HITBOXES_H
#include <stdint.h>
#include <stddef.h>
void m3d_hitboxes_track(void* object,uint32_t fighter_view);
void m3d_hitboxes_item_track(void* object,uint32_t item_view);
void m3d_hitboxes_removed(void* object);
int m3d_hitboxes_observe(uint32_t address,size_t size,int writing);
#endif
