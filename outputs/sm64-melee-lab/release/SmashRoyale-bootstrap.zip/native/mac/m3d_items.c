/* SPDX-License-Identifier: GPL-3.0-or-later
 * Original Akaneia articles -> real native engine items. No replacement move
 * logic: m-ex callbacks execute in their owner's original module context.
 * Custom range/render selection follows GD pc-port f5662df (GPL-2.0-or-later).
 */
#include "m3d_items.h"
#include "m3d_hitboxes.h"
#include <melee/it/itdraw.h>
#include "m3d_akaneia.h"
#include "m3d_vm.h"
#include "m3d_guest_memory.h"
#include "m3d_native_calls.h"
#include "world/m3d.h"
#include <melee/it/types.h>
#include <melee/ft/ftlib.h>
#include <melee/ft/types.h>
#include <melee/it/kinds/types.h>
#include <melee/it/item.h>
#include <melee/it/itgroundcoll.h>
#include <melee/it/kinds/itnesspkthundertrail.h>
#include <melee/it/kinds/itkoopaflame.h>
#include <math.h>
#include <sysdolphin/baselib/gobj.h>
#include <sysdolphin/baselib/jobj.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

static struct CustomItem {
    int global;
    Article* descriptor;
    unsigned owner,article,count;
    uint32_t targets[15];
    ItemLogicTable logic;
    ItemStateTable states[64];
} custom[64];
static unsigned custom_count;
static struct LiveItem {
    HSD_GObj* object;
    uint32_t view;
    int kind;
    bool thunder_tuned;
    uint32_t callbacks[10];
} live[256];
static unsigned live_count;

static struct CustomItem* definition(int kind)
{
    unsigned i;
    for(i=0;i<custom_count;++i)if(custom[i].global==kind)return &custom[i];
    m3d_vm_fail("Custom item kind has no indexed descriptor/logic"); return NULL;
}
static uint32_t invoke(HSD_GObj* object,uint32_t target,HSD_GObj* other,int two)
{
    uint32_t args[2]={m3d_akaneia_object_export(object,1),two ? m3d_akaneia_object_export(other,1) : 0};
    if(!target)m3d_vm_fail("Missing original custom item callback");
    return m3d_akaneia_call(object,target,args,two ? 2 : 1);
}
static uint32_t logic_event(HSD_GObj* object,unsigned slot,HSD_GObj* other,int two)
{
    struct CustomItem* d=definition(((Item*)object->user_data)->kind);
    if(getenv("MELEE3D_NATIVE_SEQUENCE") && (slot==6 || slot==9))
        fprintf(stderr,"M3D ARTICLE EVENT kind=%d event=%s\n",((Item*)object->user_data)->kind,slot==6 ? "hit":"reflect");
    if(slot==2 && getenv("MELEE3D_NATIVE_ITEM_TRACE")) {
        Item* ip=object->user_data;
        uint32_t view=m3d_items_view(object);
        fprintf(stderr,"M3D LIVE ITEM DESTROY kind=%d state=%d owner=%p secondary=%p f90=%08x f94=%08x\n",ip->kind,ip->msid,(void*)ip->owner,(void*)ip->x51C,m3d_vm_read32(view+0xf90),m3d_vm_read32(view+0xf94));
    }
    return invoke(object,d->targets[slot],other,two);
}
#define EVENT(name,slot) static void name(HSD_GObj* o) { logic_event(o,slot,NULL,0); }
#define PREDICATE(name,slot) static bool name(HSD_GObj* o) { return logic_event(o,slot,NULL,0)!=0; }
EVENT(spawned,1) EVENT(destroyed,2) EVENT(picked_up,3) EVENT(dropped,4) EVENT(thrown,5)
PREDICATE(dmg_dealt,6) PREDICATE(dmg_received,7) EVENT(entered_air,8)
PREDICATE(reflected,9) PREDICATE(clanked,10) PREDICATE(absorbed,11)
PREDICATE(shield_bounced,12) PREDICATE(hit_shield,13)
static void evt_unk(HSD_GObj* o,HSD_GObj* other) { logic_event(o,14,other,1); }
static uint32_t state_event(HSD_GObj* object,unsigned slot)
{
    Item* ip=object->user_data;
    struct CustomItem* d=definition(ip->kind);
    if(ip->msid<0 || (unsigned)ip->msid>=d->count)m3d_vm_fail("Custom item state outside its original table");
    return invoke(object,m3d_vm_read32(d->targets[0]+ip->msid*16+slot*4),NULL,0);
}
static float original_float(uint32_t at){uint32_t bits=m3d_vm_read32(at);float v;memcpy(&v,&bits,4);return v;}
static void original_float_set(uint32_t at,float v){uint32_t bits;memcpy(&bits,&v,4);m3d_vm_write32(at,bits);}
static bool lucas_thunder(Item* ip){struct CustomItem* d=definition(ip->kind);return d->owner==3&&d->article==3;}
static void tune_thunder(HSD_GObj* o)
{
    Item* ip=o->user_data;if(!m3d_StageIs3D()||!lucas_thunder(ip))return;
    for(unsigned i=0;i<live_count;i++)if(live[i].object==o&&!live[i].thunder_tuned){
        live[i].thunder_tuned=true;uint32_t v=live[i].view;
        float speed=original_float(v+0xf7c)*m3d_ThunderSpeed();
        original_float_set(v+0xf7c,speed);ip->x40_vel.x*=m3d_ThunderSpeed();ip->x40_vel.y*=m3d_ThunderSpeed();
        if(m3d_ThunderLaunch(ip,ip->owner,speed))original_float_set(v+0xf1c,0);
        ip->xD44_lifeTimer*=m3d_ThunderLifetime();ip->xD48_halfLifeTimer*=m3d_ThunderLifetime();
        /* The original constructor clears its input Z before the shared spawn
         * adapter restores depth. Seed the tail history from the repaired head. */
        for(unsigned point=0;point<24;point++){
            uint32_t p=v+0xdfc+point*12;
            original_float_set(p,ip->pos.x);original_float_set(p+4,ip->pos.y);original_float_set(p+8,ip->pos.z);
        }
        fprintf(stderr,"M3D THUNDER TUNE lucas speed=%.3f lifetime=%.1f\n",speed,ip->xD44_lifeTimer);break;
    }
}
static bool animated(HSD_GObj* o) { tune_thunder(o);return state_event(o,1)!=0; }
static void physics(HSD_GObj* o)
{
    Item* ip=o->user_data;struct CustomItem* d=definition(ip->kind);bool steered=false;Vec3 velocity={0};uint32_t v=m3d_items_view(o);
    if(m3d_StageIs3D()&&d->owner==3&&d->article==3){
        tune_thunder(o);
        HSD_GObj* owner=ip->owner;
        if(owner&&ftLib_IsFighter(owner)){
            Fighter* fp=owner->user_data;
            if((fp->motion_id==0x15f||fp->motion_id==0x163)&&original_float(v+0xf90)==0){
                const unsigned char* attrs=DP(unsigned char,ip->xC4_article_data->x4_specialAttributes);
                uint32_t bits;float degrees;memcpy(&bits,attrs+0x10,4);bits=__builtin_bswap32(bits);memcpy(&degrees,&bits,4);
                steered=m3d_ItemSteerVelocity(ip,owner,degrees*.01745329252f,original_float(v+0xf7c));velocity=ip->x40_vel;
            }
        }
    }
    state_event(o,2);
    if(steered){ip->x40_vel=velocity;original_float_set(v+0xf1c,atan2f(velocity.y,velocity.x));}
    if(m3d_StageIs3D()&&d->owner==3&&d->article>=4&&d->article<=7){
        uint32_t head=m3d_vm_read32(v+0xdd4);if(!head)return;
        HSD_GObj* source=m3d_native_object(head,1);uint32_t p=m3d_items_view(source)+0xdfc+(m3d_vm_read32(v+0xdd8)+1)*24;
        Vec3 next={original_float(p),original_float(p+4),original_float(p+8)};float pitch;
        if(m3d_ItemTrailFrame(ip,&next,&pitch))HSD_JObjSetRotationX(o->hsd_obj,-pitch);
    }
}
static bool collided(HSD_GObj* o) { return state_event(o,3)!=0; }
void m3d_items_index(int global,void* descriptor,unsigned owner,unsigned article)
{
    unsigned i;
    uint32_t table;
    struct CustomItem* d;
    for(i=0;i<custom_count;++i)if(custom[i].global==global)break;
    if(i<custom_count) {
        d=&custom[i];
        if(d->owner!=owner || d->article!=article)
            m3d_vm_fail("Conflicting custom item registration");
        if(d->descriptor==descriptor)return;
        /* A later scene (e.g. results) reloaded the fighter archive: the same
         * article now lives at a new address. Rebind it to the new data. */
    } else {
        if(custom_count==64 || global<237 || owner>=7)m3d_vm_fail("Custom item registry capacity/identity invalid");
        d=&custom[custom_count++];
    }
    d->global=global; d->descriptor=descriptor; d->owner=owner; d->article=article;
    d->count=m3d_vm_article_states(owner,article); table=m3d_vm_article(owner,article,0);
    {
        uint32_t items=m3d_vm_read32(m3d_vm_metadata()+0x1c);
        uint32_t defaults=m3d_vm_read32(items+0x10)+(global-237)*0x3c;
        for(i=0;i<15;++i) {
            uint32_t target=m3d_vm_article(owner,article,i);
            d->targets[i]=target ? target : m3d_vm_read32(defaults+i*4);
        }
        table=d->targets[0];
    }
    d->logic.states=d->states;
#define LOGIC(name,slot) if(d->targets[slot])d->logic.name=name;
    LOGIC(spawned,1) LOGIC(destroyed,2) LOGIC(picked_up,3) LOGIC(dropped,4) LOGIC(thrown,5)
    LOGIC(dmg_dealt,6) LOGIC(dmg_received,7) LOGIC(entered_air,8) LOGIC(reflected,9)
    LOGIC(clanked,10) LOGIC(absorbed,11) LOGIC(shield_bounced,12) LOGIC(hit_shield,13) LOGIC(evt_unk,14)
#undef LOGIC
    for(i=0;i<d->count;++i) {
        d->states[i].anim_id=(int32_t)m3d_vm_read32(table+i*16);
        if(m3d_vm_read32(table+i*16+4))d->states[i].animated=animated;
        if(m3d_vm_read32(table+i*16+8))d->states[i].physics_updated=physics;
        if(m3d_vm_read32(table+i*16+12))d->states[i].collided=collided;
    }
}
void* m3d_items_descriptor(int kind) { return definition(kind)->descriptor; }
void* m3d_items_logic(int kind) { return &definition(kind)->logic; }
int m3d_items_fighter_kind(int kind) { return 33+definition(kind)->owner; }
void m3d_items_validate_state(void* pointer,int state)
{
    Item* ip=((HSD_GObj*)pointer)->user_data;
    struct CustomItem* d=definition(ip->kind);
    if(state<0 || (unsigned)state>=d->count)m3d_vm_fail("Native custom item transition outside original state table");
}
uint32_t m3d_items_view(void* object)
{
    unsigned i;
    for(i=0;i<live_count;++i)if(live[i].object==object)return live[i].view;
    m3d_vm_fail("Item object has no registered native view"); return 0;
}
void m3d_items_track(void* pointer)
{
    HSD_GObj* object=pointer;
    Item* ip=object->user_data;
    unsigned i;
    uint32_t v;
    static const struct { unsigned at,size; } fields[]={
        {4,0x20},{0x24,0x94},{0xc0,0x14},{0x378,0x1a8},{0x5cc,8},
        {0xac4,4},{0xc2c,0x38},{0xc68,0x18},{0xc88,4},{0xc90,4},{0xc94,0x58},{0xcec,0x20},
        {0xd0c,0x30},{0xd3c,0x50},{0xd8c,4},{0xda8,4},{0xdac,0x28},{0xdd4,0x1fc}
    };
    for(i=0;i<live_count;++i)if(live[i].object==object)return;
    for(i=0;i<live_count && live[i].object;++i) {}
    if(i==256)m3d_vm_fail("Native item live registry exhausted");
    if(i==live_count)++live_count;
    v=m3d_guest_identity(0x1000);
    memset(&live[i],0,sizeof live[i]);live[i].object=object;live[i].kind=ip->kind;live[i].view=v;
    m3d_native_bind_object(v,ip,9);
    m3d_native_bind_object(v+0x378,&ip->x378_itemColl,8);
    m3d_native_bind_object(v+0x548,&ip->x548_colorOverlay,10);
    m3d_guest_view(v,0xfd0);
    m3d_hitboxes_item_track(object,v);
    for(i=0;i<sizeof fields/sizeof fields[0];++i)m3d_guest_field(v+fields[i].at,fields[i].size);
    /* Custom variables remain original BE words. Common item helpers must not
     * reinterpret character-private unions; expand only with typed adapters. */
    m3d_guest_region_host(v+0xdd4,0x1f8,&ip->xDD4_itemVar);
    fprintf(stderr,"M3D LIVE ITEM CREATE kind=%d view=%08x\n",ip->kind,v);
}
void m3d_items_created(void* pointer,void* owner)
{
    m3d_akaneia_item_created(pointer,owner);
}
/* Original custom destroy callbacks can clear the held flag before vanilla
 * Item destruction checks it. Release a matching special-held reference via
 * the native helper while the dying Item and its owners are still alive. */
void m3d_items_finish_destroy(void* pointer)
{
    HSD_GObj* object=pointer;
    Item* ip=object->user_data;
    HSD_GObj* owners[2]={ip->owner,ip->mex_original_owner};
    if(!m3d_akaneia_enabled() || ip->kind<237)return;
    for(unsigned i=0;i<2;++i)if(owners[i] && (!i || owners[i]!=owners[0]) && ftLib_IsFighter(owners[i]) &&
        ftLib_GetHeldSpecialItem(owners[i])==object) {
        ftLib_ClearHeldSpecialItem(owners[i]);
        fprintf(stderr,"M3D LIVE ITEM CLEAR_SPECIAL kind=%d slot=%u\n",ip->kind,((Fighter*)owners[i]->user_data)->player_idx);
    }
}
void m3d_items_removed(void* pointer)
{
    unsigned i;
    for(i=0;i<live_count;++i)if(live[i].object==pointer) {
        fprintf(stderr,"M3D LIVE ITEM REMOVE kind=%d view=%08x\n",live[i].kind,live[i].view);
        m3d_hitboxes_removed(pointer);
        m3d_native_unbind_object(live[i].view+0x548); m3d_native_unbind_object(live[i].view+0x378); m3d_native_unbind_object(live[i].view); m3d_guest_retire(live[i].view,0x1000); live[i].object=NULL;
    }
}
void m3d_items_scene_reset(void)
{
    for(unsigned i=0;i<live_count;i++)if(live[i].object)m3d_items_removed(live[i].object);
}
static unsigned live_index(HSD_GObj* object)
{
    unsigned i;
    for(i=0;i<live_count;++i)if(live[i].object==object)return i;
    m3d_vm_fail("Unregistered native item callback"); return 0;
}
#define CUSTOM_EVENT(name,index) static void custom_##name(HSD_GObj* o) { invoke(o,live[live_index(o)].callbacks[index],NULL,0); }
#define CUSTOM_PREDICATE(name,index) static bool custom_##name(HSD_GObj* o) { return invoke(o,live[live_index(o)].callbacks[index],NULL,0)!=0; }
CUSTOM_PREDICATE(animated,0) CUSTOM_EVENT(physics_updated,1) CUSTOM_PREDICATE(collided,2)
CUSTOM_EVENT(on_accessory,3) CUSTOM_PREDICATE(touched,4) CUSTOM_EVENT(entered_hitlag,5)
CUSTOM_EVENT(exited_hitlag,6) CUSTOM_PREDICATE(jumped_on,7) CUSTOM_EVENT(grab_dealt,8)
static void custom_grabbed_for_victim(HSD_GObj* o,HSD_GObj* other) { invoke(o,live[live_index(o)].callbacks[9],other,1); }
static void flags(uint32_t at,flag32* host,int writing)
{
    uint32_t v=writing ? m3d_vm_read32(at) : 0;
#define BIT(member,shift,width) if(writing)host->flags.member=(v>>shift)&((1u<<width)-1); else v|=(uint32_t)host->flags.member<<shift;
    BIT(x0,31,1)
    BIT(x1,30,1)
    BIT(x2,29,1)
    BIT(x3,28,1)
    BIT(x4,27,1)
    BIT(x5,26,1)
    BIT(x6,25,1)
    BIT(x7,24,1)
    BIT(x8,23,1)
    BIT(x9,22,1)
    BIT(xA,21,1)
    BIT(xB,20,1)
    BIT(xC,19,1)
    BIT(xD,18,1)
    BIT(xE,17,1)
    BIT(xF,13,4)
    BIT(x13,12,1)
    BIT(x14,11,1)
    BIT(x15,10,1)
    BIT(x16,9,1)
    BIT(x17,7,2)
    BIT(x19,6,1)
    BIT(x1A,5,1)
    BIT(x1B,4,1)
    BIT(x1C,3,1)
    BIT(x1D,2,1)
    BIT(x1E,1,1)
    BIT(x1F,0,1)
#undef BIT
    if(!writing)m3d_vm_write32(at,v);
}
static void scalar(uint32_t at,void* host,int writing)
{
    uint32_t value;
    if(writing) { value=m3d_vm_read32(at); memcpy(host,&value,4); }
    else { memcpy(&value,host,4); m3d_vm_write32(at,value); }
}
static void object_field(uint32_t at,HSD_GObj** host,int writing)
{
    if(writing)*host=m3d_native_object(m3d_vm_read32(at),1);
    else m3d_vm_write32(at,m3d_akaneia_object_export(*host,1));
}
static void collision_word(uint32_t at,CollData* coll,unsigned off,int writing)
{
#define COLL_RANGE(offset,member,bytes) if(off>=offset && off<offset+bytes) { scalar(at,(char*)&coll->member+off-offset,writing); return; }
    if(off==0) { object_field(at,&coll->x0_gobj,writing); return; }
    COLL_RANGE(4,cur_pos,0x30)
    if(off==0x34) {
        unsigned char b[4];
        if(writing) {
            m3d_vm_copy_out(b,at,4);
#define UNPACK(flag,byte) coll->flag.b0=b[byte]>>7; coll->flag.b1234=(b[byte]>>3)&15; coll->flag.b5=(b[byte]>>2)&1; coll->flag.b6=(b[byte]>>1)&1; coll->flag.b7=b[byte]&1;
            UNPACK(x34_flags,0) UNPACK(x35_flags,1)
#undef UNPACK
            coll->facing_dir=(b[2]<<8)|b[3];
        } else {
#define PACK(flag) ((coll->flag.b0<<7)|(coll->flag.b1234<<3)|(coll->flag.b5<<2)|(coll->flag.b6<<1)|coll->flag.b7)
            b[0]=PACK(x34_flags); b[1]=PACK(x35_flags); b[2]=coll->facing_dir>>8; b[3]=coll->facing_dir;
#undef PACK
            m3d_vm_copy_in(at,b,4);
        }
        return;
    }
    COLL_RANGE(0x38,x38,0xcc)
    if(off==0x104) { scalar(at,&coll->ecb_source.kind,writing); return; }
    if(off>=0x108 && off<0x124) {
        if(coll->ecb_source.kind==ECBSource_JObj) {
            HSD_JObj** joint=off==0x108 ? &coll->ecb_source.x4.x0.x108_joint : &coll->ecb_source.x4.x0.x10C_joint[(off-0x10c)/4];
            if(writing)*joint=m3d_native_object(m3d_vm_read32(at),3);
            else m3d_vm_write32(at,m3d_akaneia_object_export(*joint,3));
            return;
        }
        if(coll->ecb_source.kind==ECBSource_Fixed && off<0x11c) {
            scalar(at,(char*)&coll->ecb_source.x4.x0_1+off-0x108,writing); return;
        }
        m3d_vm_fail("Unbound item ECB source union field");
    }
    COLL_RANGE(0x124,ecb_source.x124,12)
    COLL_RANGE(0x130,x130_flags,0x6c)
    m3d_vm_fail("Unbound original item collision field");
#undef COLL_RANGE
}
void m3d_items_collision_word(uint32_t at,void* collision,unsigned offset,int writing)
{
    collision_word(at,collision,offset,writing);
}
int m3d_items_observe(uint32_t address,size_t size,int writing)
{
    if(m3d_hitboxes_observe(address,size,writing))return 1;
    unsigned i,at;
    Item* ip;
    uint32_t v,off;
    for(i=0;i<live_count;++i)if(live[i].object && address>=live[i].view && address-live[i].view<0xfd0)break;
    if(i==live_count)return 0;
    v=live[i].view; off=address-v; ip=live[i].object->user_data;
    if(off>=0xdd4 && off<0xfcc)return 1; /* host-backed original private bytes */
    /* Scalars are marshalled by name; native pointer expansion changes layout. */
    for(at=off&~3u;at<off+size;at+=4) {
#define WORD(offset,member) if(at==offset) { scalar(v+at,&ip->member,writing); continue; }
#define RANGE(offset,member,bytes) if(at>=offset && at<offset+bytes) { scalar(v+at,(char*)&ip->member+at-offset,writing); continue; }
#define OBJ(offset,member) if(at==offset) { object_field(v+at,&ip->member,writing); continue; }
#define ARCHIVE_FIELD(offset,member) if(at==offset) { if(writing)ip->member=m3d_akaneia_native_data(m3d_vm_read32(v+at)); else m3d_vm_write32(v+at,m3d_akaneia_guest_data(ip->member)); continue; }
        if(at>=0x378 && at<0x514) { collision_word(v+at,&ip->x378_itemColl,at-0x378,writing); continue; }
        WORD(0x514,ecb_lock)
        OBJ(4,entity) RANGE(8,x8,0x18)
        if(at==0x20) { if(writing)m3d_vm_copy_out(&ip->x20_team_id,v+at,4); else m3d_vm_copy_in(v+at,&ip->x20_team_id,4); continue; }
        RANGE(0x24,msid,0x94) WORD(0xc0,ground_or_air)
        ARCHIVE_FIELD(0xc4,xC4_article_data) ARCHIVE_FIELD(0xc8,xC8_joint) ARCHIVE_FIELD(0xcc,xCC_item_attr) ARCHIVE_FIELD(0xd0,xD0_itemStateDesc)
        OBJ(0x518,owner) OBJ(0x51c,x51C) RANGE(0x5cc,x5CC_currentAnimFrame,8)
        WORD(0xac4,xAC4_ignoreItemID)
        RANGE(0xc2c,xC2C,0x38) OBJ(0xc64,xC64_reflectGObj) RANGE(0xc68,xC68,0x18)
        WORD(0xc88,xC88) OBJ(0xc90,xC90_absorbGObj) RANGE(0xc94,xC94,0x58)
        OBJ(0xcec,xCEC_fighterGObj) OBJ(0xcf0,xCF0_itemGObj) OBJ(0xcf4,xCF4_fighterGObjUnk)
        OBJ(0xcf8,toucher) OBJ(0xcfc,xCFC) OBJ(0xd00,grab_victim) OBJ(0xd04,atk_victim)
        if(at==0xd08) { if(writing)m3d_vm_copy_out(&ip->xD08,v+at,4); else m3d_vm_copy_in(v+at,&ip->xD08,4); continue; }
        RANGE(0xd0c,xD0C,8) RANGE(0xd3c,xD3C_spinSpeed,0x50)
        if(at==0xd8c) {
            unsigned char bytes[4];
            if(writing) { m3d_vm_copy_out(bytes,v+at,4); ip->xD8C_attack_instance=(bytes[0]<<8)|bytes[1]; ip->xD8E=(bytes[2]<<8)|bytes[3]; }
            else { bytes[0]=ip->xD8C_attack_instance>>8; bytes[1]=ip->xD8C_attack_instance; bytes[2]=ip->xD8E>>8; bytes[3]=ip->xD8E; m3d_vm_copy_in(v+at,bytes,4); }
            continue;
        }
        if(at==0xd14) {
            if(writing) {
                void (*native)(void);
                live[i].callbacks[0]=m3d_vm_read32(v+at);
                native=m3d_native_callback_decode_typed(live[i].callbacks[0],1,M3D_U8,1);
                ip->animated=native ? (__typeof__(ip->animated))native : live[i].callbacks[0] ? custom_animated : NULL;
            } else {
                if(ip->animated==animated) {
                    struct CustomItem* d=definition(ip->kind);
                    if(ip->msid<0 || (unsigned)ip->msid>=d->count)m3d_vm_fail("Item callback state outside table");
                    live[i].callbacks[0]=m3d_vm_read32(d->targets[0]+ip->msid*16+4);
                } else
                if(ip->animated!=custom_animated)live[i].callbacks[0]=m3d_native_callback_encode_typed((void(*)(void))ip->animated,1,M3D_U8,1);
                m3d_vm_write32(v+at,live[i].callbacks[0]);
            }
            continue;
        }
        if(at==0xd18) {
            if(writing) {
                void (*native)(void);
                live[i].callbacks[1]=m3d_vm_read32(v+at);
                native=m3d_native_callback_decode_typed(live[i].callbacks[1],1,M3D_VOID,1);
                ip->physics_updated=native ? (__typeof__(ip->physics_updated))native : live[i].callbacks[1] ? custom_physics_updated : NULL;
            } else {
                if(ip->physics_updated==physics) {
                    struct CustomItem* d=definition(ip->kind);
                    if(ip->msid<0 || (unsigned)ip->msid>=d->count)m3d_vm_fail("Item callback state outside table");
                    live[i].callbacks[1]=m3d_vm_read32(d->targets[0]+ip->msid*16+8);
                } else
                if(ip->physics_updated!=custom_physics_updated)live[i].callbacks[1]=m3d_native_callback_encode_typed((void(*)(void))ip->physics_updated,1,M3D_VOID,1);
                m3d_vm_write32(v+at,live[i].callbacks[1]);
            }
            continue;
        }
        if(at==0xd1c) {
            if(writing) {
                void (*native)(void);
                live[i].callbacks[2]=m3d_vm_read32(v+at);
                native=m3d_native_callback_decode_typed(live[i].callbacks[2],1,M3D_U8,1);
                ip->collided=native ? (__typeof__(ip->collided))native : live[i].callbacks[2] ? custom_collided : NULL;
            } else {
                if(ip->collided==collided) {
                    struct CustomItem* d=definition(ip->kind);
                    if(ip->msid<0 || (unsigned)ip->msid>=d->count)m3d_vm_fail("Item callback state outside table");
                    live[i].callbacks[2]=m3d_vm_read32(d->targets[0]+ip->msid*16+12);
                } else
                if(ip->collided!=custom_collided)live[i].callbacks[2]=m3d_native_callback_encode_typed((void(*)(void))ip->collided,1,M3D_U8,1);
                m3d_vm_write32(v+at,live[i].callbacks[2]);
            }
            continue;
        }
        if(at==0xd20) {
            if(writing) {
                void (*native)(void);
                live[i].callbacks[3]=m3d_vm_read32(v+at);
                native=m3d_native_callback_decode_typed(live[i].callbacks[3],1,M3D_VOID,1);
                ip->on_accessory=native ? (__typeof__(ip->on_accessory))native : live[i].callbacks[3] ? custom_on_accessory : NULL;
            } else {
                if(ip->on_accessory!=custom_on_accessory)live[i].callbacks[3]=m3d_native_callback_encode_typed((void(*)(void))ip->on_accessory,1,M3D_VOID,1);
                m3d_vm_write32(v+at,live[i].callbacks[3]);
            }
            continue;
        }
        if(at==0xd24) {
            if(writing) {
                void (*native)(void);
                live[i].callbacks[4]=m3d_vm_read32(v+at);
                native=m3d_native_callback_decode_typed(live[i].callbacks[4],1,M3D_U8,1);
                ip->touched=native ? (__typeof__(ip->touched))native : live[i].callbacks[4] ? custom_touched : NULL;
            } else {
                if(ip->touched!=custom_touched)live[i].callbacks[4]=m3d_native_callback_encode_typed((void(*)(void))ip->touched,1,M3D_U8,1);
                m3d_vm_write32(v+at,live[i].callbacks[4]);
            }
            continue;
        }
        if(at==0xd28) {
            if(writing) {
                void (*native)(void);
                live[i].callbacks[5]=m3d_vm_read32(v+at);
                native=m3d_native_callback_decode_typed(live[i].callbacks[5],1,M3D_VOID,1);
                ip->entered_hitlag=native ? (__typeof__(ip->entered_hitlag))native : live[i].callbacks[5] ? custom_entered_hitlag : NULL;
            } else {
                if(ip->entered_hitlag!=custom_entered_hitlag)live[i].callbacks[5]=m3d_native_callback_encode_typed((void(*)(void))ip->entered_hitlag,1,M3D_VOID,1);
                m3d_vm_write32(v+at,live[i].callbacks[5]);
            }
            continue;
        }
        if(at==0xd2c) {
            if(writing) {
                void (*native)(void);
                live[i].callbacks[6]=m3d_vm_read32(v+at);
                native=m3d_native_callback_decode_typed(live[i].callbacks[6],1,M3D_VOID,1);
                ip->exited_hitlag=native ? (__typeof__(ip->exited_hitlag))native : live[i].callbacks[6] ? custom_exited_hitlag : NULL;
            } else {
                if(ip->exited_hitlag!=custom_exited_hitlag)live[i].callbacks[6]=m3d_native_callback_encode_typed((void(*)(void))ip->exited_hitlag,1,M3D_VOID,1);
                m3d_vm_write32(v+at,live[i].callbacks[6]);
            }
            continue;
        }
        if(at==0xd30) {
            if(writing) {
                void (*native)(void);
                live[i].callbacks[7]=m3d_vm_read32(v+at);
                native=m3d_native_callback_decode_typed(live[i].callbacks[7],1,M3D_U8,1);
                ip->jumped_on=native ? (__typeof__(ip->jumped_on))native : live[i].callbacks[7] ? custom_jumped_on : NULL;
            } else {
                if(ip->jumped_on!=custom_jumped_on)live[i].callbacks[7]=m3d_native_callback_encode_typed((void(*)(void))ip->jumped_on,1,M3D_U8,1);
                m3d_vm_write32(v+at,live[i].callbacks[7]);
            }
            continue;
        }
        if(at==0xd34) {
            if(writing) {
                void (*native)(void);
                live[i].callbacks[8]=m3d_vm_read32(v+at);
                native=m3d_native_callback_decode_typed(live[i].callbacks[8],1,M3D_VOID,1);
                ip->grab_dealt=native ? (__typeof__(ip->grab_dealt))native : live[i].callbacks[8] ? custom_grab_dealt : NULL;
            } else {
                if(ip->grab_dealt!=custom_grab_dealt)live[i].callbacks[8]=m3d_native_callback_encode_typed((void(*)(void))ip->grab_dealt,1,M3D_VOID,1);
                m3d_vm_write32(v+at,live[i].callbacks[8]);
            }
            continue;
        }
        if(at==0xd38) {
            if(writing) {
                void (*native)(void);
                live[i].callbacks[9]=m3d_vm_read32(v+at);
                native=m3d_native_callback_decode_typed(live[i].callbacks[9],1,M3D_VOID,2);
                ip->grabbed_for_victim=native ? (__typeof__(ip->grabbed_for_victim))native : live[i].callbacks[9] ? custom_grabbed_for_victim : NULL;
            } else {
                if(ip->grabbed_for_victim!=custom_grabbed_for_victim)live[i].callbacks[9]=m3d_native_callback_encode_typed((void(*)(void))ip->grabbed_for_victim,1,M3D_VOID,2);
                m3d_vm_write32(v+at,live[i].callbacks[9]);
            }
            continue;
        }
        if(at==0xda8) {
            unsigned char bytes[4];
            if(writing) { m3d_vm_copy_out(bytes,v+at,4); ip->xDA8_short=(bytes[0]<<8)|bytes[1]; ip->xDAA.xDAA_byte=bytes[2]; }
            else { bytes[0]=ip->xDA8_short>>8; bytes[1]=ip->xDA8_short; bytes[2]=ip->xDAA.xDAA_byte; bytes[3]=0; m3d_vm_copy_in(v+at,bytes,4); }
            continue;
        }
        RANGE(0xdac,xDAC_itcmd_var0,0x10)
        if(at==0xdbc) { flags(v+at,&ip->xDBC.xDBC_itcmd_var4,writing); continue; }
        WORD(0xdc0,xDC0) WORD(0xdc4,xDC4)
        if(at==0xdc8) { flags(v+at,&ip->xDC8_word,writing); continue; }
        if(at==0xdcc) {
            unsigned char b[4];
            if(writing) {
                m3d_vm_copy_out(b,v+at,4);
                ip->xDCC_flag.b0=b[0]>>7; ip->xDCC_flag.b1=(b[0]>>6)&1; ip->xDCC_flag.b2=(b[0]>>5)&1;
                ip->xDCC_flag.b3=(b[0]>>4)&1; ip->xDCC_flag.b4567=b[0]&15;
                ip->xDCD_flag.x0.b01=b[1]>>6; ip->xDCD_flag.x0.b2=(b[1]>>5)&1; ip->xDCD_flag.x0.b3=(b[1]>>4)&1;
                ip->xDCD_flag.x0.b4=(b[1]>>3)&1; ip->xDCD_flag.x0.b5=(b[1]>>2)&1;
                ip->xDCD_flag.x0.b6=(b[1]>>1)&1; ip->xDCD_flag.x0.b7=b[1]&1;
                ip->xDCE_flag.byte=b[2]; ip->xDCF_flag.byte=b[3];
            } else {
                b[0]=(ip->xDCC_flag.b0<<7)|(ip->xDCC_flag.b1<<6)|(ip->xDCC_flag.b2<<5)|(ip->xDCC_flag.b3<<4)|ip->xDCC_flag.b4567;
                b[1]=(ip->xDCD_flag.x0.b01<<6)|(ip->xDCD_flag.x0.b2<<5)|(ip->xDCD_flag.x0.b3<<4)|(ip->xDCD_flag.x0.b4<<3)|
                    (ip->xDCD_flag.x0.b5<<2)|(ip->xDCD_flag.x0.b6<<1)|ip->xDCD_flag.x0.b7;
                b[2]=ip->xDCE_flag.byte; b[3]=ip->xDCF_flag.byte;
                m3d_vm_copy_in(v+at,b,4);
            }
            continue;
        }
        if(at==0xdd0) {
            unsigned char b[4];
            if(writing) { m3d_vm_copy_out(b,v+at,4); ip->xDD0_flag.byte=b[0]; ip->xDD1_flag.byte=b[1]; ip->xDD2_flag.byte=b[2]; ip->xDD3_flag.byte=b[3]; }
            else { b[0]=ip->xDD0_flag.byte; b[1]=ip->xDD1_flag.byte; b[2]=ip->xDD2_flag.byte; b[3]=ip->xDD3_flag.byte; m3d_vm_copy_in(v+at,b,4); }
            continue;
        }
        OBJ(0xfcc,mex_original_owner)
        m3d_vm_fail("Unbound original item field");
#undef WORD
#undef RANGE
#undef OBJ
#undef ARCHIVE_FIELD
    }
    return 1;
}
static HSD_GObj* spawn(uint32_t address,int grounded)
{
    SpawnItem s={0};
    unsigned char bytes[0x4c];
    uint32_t word; unsigned i;
    m3d_vm_copy_out(bytes,address,sizeof bytes);
#define U32(at) ((uint32_t)bytes[at]<<24|(uint32_t)bytes[(at)+1]<<16|(uint32_t)bytes[(at)+2]<<8|bytes[(at)+3])
    s.x0_parent_gobj=m3d_native_object(U32(0),1); s.x4_parent_gobj2=m3d_native_object(U32(4),1);
    s.kind=U32(8); s.hold_kind=U32(12); s.x10=U32(16);
    for(i=0;i<10;++i) { word=U32(0x14+i*4); memcpy((char*)&s.pos+i*4,&word,4); }
    s.x3C_damage=(bytes[0x3c]<<8)|bytes[0x3d]; s.x3E=(bytes[0x3e]<<8)|bytes[0x3f]; s.x40=U32(0x40);
    /* UnkFlagStruct is a native bitfield union. Preserve its numeric byte
     * semantics via the same GCC scalar-storage-order representation. */
    s.x44_flag.byte=bytes[0x44]; s.x45_flag.byte=bytes[0x45]; s.x46_flag.byte=bytes[0x46]; s.x47_flag.byte=bytes[0x47];
    s.x48_ground_or_air=U32(0x48);
    {
        HSD_GObj* result=grounded==2 ? Item_8026862C(&s) : grounded ? Item_80268B5C(&s) : Item_80268B18(&s);
        if(!result)fprintf(stderr,"M3D LIVE ITEM SPAWN REFUSED kind=%d hold=%d projectiles=%d/%d\n",s.kind,s.hold_kind,Item_804A0C64.x40,Item_804A0C64.x44);
        /* These public helpers mutate only the prefunction fields. */
        m3d_vm_write32(address+0xc,s.hold_kind); m3d_vm_write32(address+0x10,s.x10); m3d_vm_write32(address+0x48,s.x48_ground_or_air);
        return result;
    }
#undef U32
}
static HSD_GObj* spawn_air(uint32_t address) { return spawn(address,0); }
static HSD_GObj* spawn_ground(uint32_t address) { return spawn(address,1); }
static HSD_GObj* spawn_direct(uint32_t address) { return spawn(address,2); }
static struct CollisionScope { HSD_GObj* object; uint32_t target; struct CollisionScope* previous; } *collision_scope;
static void collision_callback(HSD_GObj* object)
{
    if(!collision_scope || object!=collision_scope->object)m3d_vm_fail("Item collision callback escaped native scope");
    invoke(object,collision_scope->target,NULL,0);
}
#define COLLISION_VOID(name) static void bridge_##name(HSD_GObj* object,uint32_t callback) { \
    struct CollisionScope scope={object,callback,collision_scope}; collision_scope=&scope; \
    name(object,collision_callback); collision_scope=scope.previous; }
COLLISION_VOID(it_8026D62C) COLLISION_VOID(it_8026E15C) COLLISION_VOID(it_8026E414)
static bool bridge_it_8026D8A4(HSD_GObj* object,uint32_t callback)
{
    bool result;
    struct CollisionScope scope={object,callback,collision_scope}; collision_scope=&scope;
    /* The original module explicitly passes NULL when only the returned
     * support result is wanted. Preserve that opt-out, not a thunk to zero. */
    result=it_8026D8A4(object,callback ? collision_callback:NULL);
    if(!callback) {static int logged;if(!logged++)fprintf(stderr,"M3D ITEM SUPPORT NULL_CALLBACK PASS\n");}
    collision_scope=scope.previous; return result;
}
/* Stock trail animation intentionally reads a shared three-field prefix.
 * Its native union has 64-bit pointers and LE scalars; the custom article's
 * original variables retain 32-bit handles and BE words. Marshal that prefix
 * only for this native call, then restore the original private representation. */
static bool trail_animation(HSD_GObj* object)
{
    Item* ip=object->user_data;
    if(ip->kind<237)return itNesspkthundertrail_UnkMotion0_Anim(object);
    uint32_t v=m3d_items_view(object)+0xdd4;
    uint32_t head=m3d_vm_read32(v),index=m3d_vm_read32(v+4),count=m3d_vm_read32(v+8);
    unsigned char saved[sizeof ip->xDD4_itemVar];
    memcpy(saved,&ip->xDD4_itemVar,sizeof saved);
    ip->xDD4_itemVar.nesspkthundertrail.x0=m3d_native_object(head,1);
    ip->xDD4_itemVar.nesspkthundertrail.x4=(int32_t)index;
    ip->xDD4_itemVar.nesspkthundertrail.x8=count;
    bool result=itNesspkthundertrail_UnkMotion0_Anim(object);
    head=m3d_akaneia_object_export(ip->xDD4_itemVar.nesspkthundertrail.x0,1);
    index=ip->xDD4_itemVar.nesspkthundertrail.x4; count=ip->xDD4_itemVar.nesspkthundertrail.x8;
    memcpy(&ip->xDD4_itemVar,saved,sizeof saved);
    m3d_vm_write32(v,head); m3d_vm_write32(v+4,index); m3d_vm_write32(v+8,count);
    return result;
}
/* Charizard inherits this retail collision callback. Its original private
 * variables are BE words, whereas native Koopa flame logic reads native floats.
 * Preserve all unrelated private bytes, and use the actual native helper. */
static bool original_flame_collision(HSD_GObj* object)
{
    Item* ip=object->user_data;
    uint32_t v=m3d_items_view(object)+0xdd4;
    unsigned char saved[0x28];
    uint32_t words[0x28/4];
    bool result;
    _Static_assert(sizeof(itKoopaFlame_ItemVars)==0x4c,"Pointer-free original flame fields");
    memcpy(saved,&ip->xDD4_itemVar,sizeof saved);
    for(unsigned i=0;i<0x28/4;++i) { words[i]=m3d_vm_read32(v+i*4); memcpy((char*)&ip->xDD4_itemVar+i*4,&words[i],4); }
    if(!isfinite(ip->xDD4_itemVar.koopaflame.x24_angle) || fabsf(ip->xDD4_itemVar.koopaflame.x24_angle)>1000)
        m3d_vm_fail("Original flame angle is not finite/bounded");
    result=itKoopaFlame_UnkMotion0_Coll(object);
    for(unsigned i=0;i<0x28/4;++i)memcpy(&words[i],(char*)&ip->xDD4_itemVar+i*4,4);
    memcpy(&ip->xDD4_itemVar,saved,sizeof saved);
    for(unsigned i=0;i<0x28/4;++i)m3d_vm_write32(v+i*4,words[i]);
    return result;
}
static void original_item_draw(HSD_GObj* object,int32_t pass) { it_8026EECC(object,(intptr_t)pass); }
void m3d_bind_items(void)
{
    const struct M3dNativeCall draw={0x8026eecc,(void(*)(void))original_item_draw,M3D_VOID,2,{M3D_OBJECT,M3D_I32},{-1,-1},{1,0}};
    m3d_native_register(&draw);
    const struct M3dNativeCall flame={0x802ad1e4,(void(*)(void))original_flame_collision,M3D_U8,1,{M3D_OBJECT},{-1},{1}};
    m3d_native_register(&flame);
    const struct M3dNativeCall air={0x80268b18,(void(*)(void))spawn_air,M3D_OBJECT,1,{M3D_U32},{-1},{0},1};
    const struct M3dNativeCall ground={0x80268b5c,(void(*)(void))spawn_ground,M3D_OBJECT,1,{M3D_U32},{-1},{0},1};
    const struct M3dNativeCall direct={0x8026862c,(void(*)(void))spawn_direct,M3D_OBJECT,1,{M3D_U32},{-1},{0},1};
    const struct M3dNativeCall trail={0x802ac62c,(void(*)(void))trail_animation,M3D_U8,1,{M3D_OBJECT},{-1},{1}};
    m3d_native_register(&trail);
    m3d_native_register(&air); m3d_native_register(&ground); m3d_native_register(&direct);
#define COLLISION(address,name,type) { const struct M3dNativeCall call={address,(void(*)(void))bridge_##name,type,2,{M3D_OBJECT,M3D_U32},{-1,-1},{1,0}}; m3d_native_register(&call); }
    COLLISION(0x8026d62c,it_8026D62C,M3D_VOID) COLLISION(0x8026d8a4,it_8026D8A4,M3D_U8)
    COLLISION(0x8026e15c,it_8026E15C,M3D_VOID) COLLISION(0x8026e414,it_8026E414,M3D_VOID)
#undef COLLISION
}
