/* SPDX-License-Identifier: GPL-3.0-or-later
 * Bounded RIFF sampler-loop parsing shared with the native replacement mixer. */
#ifndef M3D_WAVE_LOOP_H
#define M3D_WAVE_LOOP_H
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
static uint32_t m3d_wave_u32(const uint8_t* p) {
    return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;
}
static bool m3d_wave_loop(const uint8_t* data,size_t size,size_t pcm_size,size_t frame_bytes,size_t* begin,size_t* end) {
    if(!data||size<12||!frame_bytes||memcmp(data,"RIFF",4)||memcmp(data+8,"WAVE",4))return false;
    for(size_t at=12;at<=size-8;) {
        size_t bytes=m3d_wave_u32(data+at+4);if(bytes>size-at-8)return false;
        const uint8_t* chunk=data+at+8;
        if(!memcmp(data+at,"smpl",4)&&bytes>=60&&m3d_wave_u32(chunk+28)>0&&m3d_wave_u32(chunk+40)==0) {
            uint64_t a=(uint64_t)m3d_wave_u32(chunk+44)*frame_bytes;
            uint64_t b=((uint64_t)m3d_wave_u32(chunk+48)+1)*frame_bytes;
            if(a>=b||b>pcm_size)return false;*begin=a;*end=b;return true;
        }
        size_t advance=8+bytes+(bytes&1);if(advance>size-at)return false;at+=advance;
    }
    return false;
}
#endif
