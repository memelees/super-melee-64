/* Solo pause uses the game's own pause state, UI and simulation mask. */
#ifndef M3D_PAUSE_H
#define M3D_PAUSE_H
#ifdef __cplusplus
extern "C" {
#endif
int m3d_PauseAvailable(void);
int m3d_PauseRequest(void);
int m3d_PauseRequested(void);
void m3d_PauseAccept(void);
int m3d_PauseUpdate(void* camera,int paused,int port);
int m3d_PauseApply(void* camera);
int m3d_FreeCameraUpdate(void* camera,const void* pad);
#ifdef __cplusplus
}
#endif
#endif
