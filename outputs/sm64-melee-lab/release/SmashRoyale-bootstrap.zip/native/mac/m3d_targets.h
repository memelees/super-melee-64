/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef M3D_TARGETS_H
#define M3D_TARGETS_H
#include <stdint.h>
#include <stddef.h>
uint32_t m3d_targets_motion(void* fighter,int motion);
void m3d_targets_track(void* object);
uint32_t m3d_targets_view(void* object);
int m3d_targets_observe(uint32_t address,size_t size,int writing);
void m3d_targets_removed(void* object);
void m3d_targets_scene_reset(void);
int m3d_targets_grab_flags(uint32_t identity,int16_t flags);
#endif
