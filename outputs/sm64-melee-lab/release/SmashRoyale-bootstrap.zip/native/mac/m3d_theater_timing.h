/* SPDX-License-Identifier: GPL-3.0-or-later
 * Integer cadence: quarter-speed units, 60 simulation ticks, 30 film frames.
 * Slow motion repeats presentation frames; it never removes a saved action.
 */
#ifndef M3D_THEATER_TIMING_H
#define M3D_THEATER_TIMING_H
static inline unsigned m3d_theater_film_frames(unsigned begin,unsigned end,unsigned quarter_speed)
{ return end>begin&&quarter_speed ? ((end-begin)*2+quarter_speed-1)/quarter_speed:0; }
static inline unsigned m3d_theater_film_tick(unsigned begin,unsigned frame,unsigned quarter_speed)
{ return begin+(frame*quarter_speed)/2; }
#endif
