#include "m3d_scene_pool.h"
/* SPDX-License-Identifier: GPL-3.0-or-later
 * DELFINO: execute original local Akaneia module code on Apple Silicon.
 * This probe validates the memory/call boundary; it does not spawn Sonic. */
#include "gw.h"
#include "gw_ppc.h"
#include "gw_mex_ftfunction.h"
#include "m3d_native_calls.h"
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#undef memcpy
#undef memset
#undef memcmp

void gw_log(const char* format, ...)
{
    va_list ap; va_start(ap, format); vfprintf(stderr, format, ap); va_end(ap);
    fputc('\n', stderr);
}
void gw_panic(const char* format, ...)
{
    va_list ap; va_start(ap, format); vfprintf(stderr, format, ap); va_end(ap);
    fputc('\n', stderr); exit(2);
}
void gw_prof_begin(unsigned a, unsigned b) { (void)a; (void)b; }
void gw_prof_end(void) {}
void gw_prof_counter_detail(unsigned a, unsigned b, double v) { (void)a; (void)b; (void)v; }
int gw_Geno_DefinePPCProbe(uint32_t argument) { (void)argument; return 0; }
uint32_t gw_mex_bridge_lookup(uint32_t address, int* kind) { (void)address; if (kind) *kind=0; return 0; }
uint32_t gw_mex_bridge_guest_data(uint32_t address) { (void)address; return 0; }
int gw_mex_bridge_is_native_data(uint32_t address, uint32_t size) { (void)address; (void)size; return 0; }
void GXCmd1u8(unsigned char value) { (void)value; gw_panic("GX FIFO requires the in-game renderer adapter"); }
void GXCmd1u16(unsigned short value) { (void)value; gw_panic("GX FIFO requires the in-game renderer adapter"); }
void GXCmd1u32(unsigned value) { (void)value; gw_panic("GX FIFO requires the in-game renderer adapter"); }

void* gw_DVDReadFileAlloc(const char* path, uint32_t* size)
{
    FILE* file = fopen(path, "rb");
    void* buffer;
    long length;
    if (!file) return NULL;
    fseek(file, 0, SEEK_END); length=ftell(file); rewind(file);
    if (length <= 0 || length > 16*1024*1024) { fclose(file); return NULL; }
    buffer=malloc(length);
    if (!buffer || fread(buffer, 1, length, file) != (size_t)length) { free(buffer); fclose(file); return NULL; }
    fclose(file); *size=(uint32_t)length; return buffer;
}

static gw_ppc_native_fn resolve(uint32_t address, void* context, gw_ppc_sig* signature)
{
    (void)context; (void)signature;
    gw_panic("M3D BRIDGE unsupported native call 0x%08x", address);
    return NULL;
}

static double mixed_ten(uint32_t a,uint32_t b,uint32_t c,uint32_t d,uint32_t e,uint32_t f,float g,float h,float i,float j)
{ return a+10*b+100*c+1000*d+10000*e+100000*f+g+2*h+4*i+8*j; }
static double mixed_native(float a, double b, uint32_t c) { return a + b*c; }
static float float_native(float a, uint32_t b) { return a*b; }
static int32_t narrow_native(int8_t a,int16_t b,uint8_t c,uint16_t d) { return a+b+c+d; }
struct NativeValue { float value; void* owner; };
static struct NativeValue* update_native_value(struct NativeValue* p, float amount) { p->value+=amount; return p; }
static _Bool native_predicate(struct NativeValue* value) { return value->value==5; }
static void native_interaction(struct NativeValue* self,struct NativeValue* other) { self->owner=other; }
static void bump_native_value(struct NativeValue* value) { value->value+=1; }

static uint32_t full_eabi_native(gw_ppc_ctx* context)
{
    if(context->gpr[10]!=0x77112233 || context->fpr[5].d!=12.5 ||
       gw_r32((void*)(uintptr_t)(context->gpr[1]+8))!=0xaabbccdd)
        gw_panic("M3D BRIDGE FAIL full-EABI stack/register context");
    gw_w32((void*)(uintptr_t)context->gpr[3],0x1234abcd);
    return 0x55667788;
}
static void check_floating_abi(const char* negative)
{
    const uint32_t code=0x80a00000, data=0x80a10000;
    const uint32_t words[]={0x7c0802a6,0xc0240000,0xc8440008,0x3d808000,0x618c3280,
                            0x7d8903a6,0x4e800421,0xd8240010,0x7c0803a6,0x4e800020};
    uint32_t i, args[]={3,data};
    const struct M3dNativeCall call={0x80003280,(void(*)(void))mixed_native,M3D_F64,3,
                                    {M3D_F32,M3D_F64,M3D_U32},{-1,-1,-1}};
    m3d_native_register(&call);
    m3d_guest_region(code,0x1000); m3d_guest_region(data,0x1000);
    {
        const uint32_t page=0x80b00000;uint32_t host_word=0;
        m3d_guest_region(page,0x3001);
        if(m3d_guest_address((void*)(uintptr_t)(page+0xffc),4)!=gw_mem1+page-0x80000000u+0xffc)
            gw_panic("M3D BRIDGE FAIL page backing extent");
        m3d_guest_region_host(page+16,4,&host_word);gw_w32((void*)(uintptr_t)(page+16),0x1234abcd);
        if(m3d_guest_address((void*)(uintptr_t)(page+16),4)!=&host_word ||
           memcmp(&host_word,"\x12\x34\xab\xcd",4) || gw_r32((void*)(uintptr_t)(page+16))!=0x1234abcd)
            gw_panic("M3D BRIDGE FAIL page hint hid host alias");
        m3d_guest_view(page+0x1100,0x40);m3d_guest_field(page+0x1100,4);
        gw_w32((void*)(uintptr_t)(page+0x1100),7);
        if(negative&&!strcmp(negative,"--page-field-span"))m3d_guest_address((void*)(uintptr_t)(page+0x1100),8);
        if(negative&&!strcmp(negative,"--page-cross-view"))m3d_guest_address((void*)(uintptr_t)(page+0xffe),0x104);
        if(negative&&!strcmp(negative,"--page-field"))gw_r32((void*)(uintptr_t)(page+0x1104));
        if(negative&&!strcmp(negative,"--page-unmapped"))m3d_guest_address((void*)(uintptr_t)(page+0x3001),1);
        m3d_guest_retire(page+0x2300,4);
        if(negative&&!strcmp(negative,"--page-retired"))gw_r32((void*)(uintptr_t)(page+0x2300));
        m3d_guest_retire(page,0x3001);
        puts("M3D BRIDGE ABI PASS page_hints_preserve_alias_field_extent_retirement");
    }
    {
        uint32_t base=0x80b10000,small=0,wide[2]={0},late=0;
        m3d_guest_region(base,0x100);
        for(int i=0;i<2;i++)m3d_guest_address((void*)(uintptr_t)(base+16),4);
        m3d_guest_region_host(base,4,&small);
        m3d_guest_region_host(base,8,wide);
        for(int i=0;i<3;i++) {
            if(m3d_guest_address((void*)(uintptr_t)base,4)!=&small ||
               m3d_guest_address((void*)(uintptr_t)base,8)!=wide)
                gw_panic("M3D BRIDGE FAIL translation hint changed overlapping alias precedence/extent");
        }
        m3d_guest_region_host(base+16,4,&late);
        if(m3d_guest_address((void*)(uintptr_t)(base+16),4)!=&late)
            gw_panic("M3D BRIDGE FAIL translation hint ignored new host alias");
        /* Warming a backing translation never grants permission through a
         * subsequently installed sparse view. */
        m3d_guest_address((void*)(uintptr_t)(base+32),4);
        m3d_guest_address((void*)(uintptr_t)(base+36),4);
        m3d_guest_view(base+32,16);m3d_guest_field(base+32,4);
        for(int i=0;i<2;i++)gw_r32((void*)(uintptr_t)(base+32));
        if(negative&&!strcmp(negative,"--translation-field"))gw_r32((void*)(uintptr_t)(base+36));
        if(negative&&!strcmp(negative,"--translation-span"))m3d_guest_address((void*)(uintptr_t)(base+32),8);
        m3d_guest_retire(base,0x100);
        if(negative&&!strcmp(negative,"--translation-retired"))gw_r32((void*)(uintptr_t)base);
        uint32_t cross=0x80b11ffc;unsigned char spanning[8]={0};
        m3d_guest_region(cross,8);m3d_guest_address((void*)(uintptr_t)cross,8);
        m3d_guest_region_host(cross,8,spanning);
        if(m3d_guest_address((void*)(uintptr_t)cross,8)!=spanning)
            gw_panic("M3D BRIDGE FAIL multi-page translation survived alias insertion");
        m3d_guest_retire(cross,8);
        puts("M3D BRIDGE ABI PASS exact_translation_cache_alias_extent_invalidation");
    }
    {
        gw_ppc_ctx context={0};
        struct M3dNativeCall full={0x800033b0,(void(*)(void))full_eabi_native,M3D_U32,1,{M3D_CONTEXT},{-1}};
        if(negative && !strcmp(negative,"--mixed-context")) {
            full.argument_count=2;full.arguments[1]=M3D_U32;
        }
        m3d_native_register(&full);
        context.gpr[1]=data+128;context.gpr[3]=data+64;context.gpr[10]=0x77112233;context.fpr[5].d=12.5;
        gw_w32((void*)(uintptr_t)(context.gpr[1]+8),0xaabbccdd);
        if(!m3d_native_invoke(full.guest_address,&context) || context.gpr[3]!=0x55667788 ||
           gw_r32((void*)(uintptr_t)(data+64))!=0x1234abcd)
            gw_panic("M3D BRIDGE FAIL full-EABI output/result conversion");
        puts("M3D BRIDGE ABI PASS full_eabi_context_adapter");
    }
    {
        struct NativeValue native={0};uint32_t first=0,last=0,host_word=0;
        for(unsigned generation=0;generation<10000;++generation) {
            uint32_t handle=m3d_guest_identity(0x100);
            if(!generation)first=handle;
            if(handle<=last)gw_panic("M3D BRIDGE FAIL recycled stale guest identity");
            m3d_guest_view(handle,0x40);m3d_guest_field(handle,4);
            m3d_guest_region_host(handle,4,&host_word);m3d_native_bind_object(handle,&native,1);
            gw_w32((void*)(uintptr_t)handle,generation);
            if(gw_r32((void*)(uintptr_t)handle)!=generation ||
               m3d_guest_encode_buffer(&host_word)!=handle || m3d_native_object(handle,1)!=&native)
                gw_panic("M3D BRIDGE FAIL live recycled metadata/host alias");
            if(generation==9999 && negative && !strcmp(negative,"--retired-generation"))
                m3d_guest_address((void*)(uintptr_t)first,4);
            if(generation==9999 && negative && !strcmp(negative,"--retired-object-generation"))
                m3d_native_object(first,1);
            m3d_native_unbind_object(handle);m3d_guest_retire(handle,0x100);last=handle;
        }
        puts("M3D BRIDGE ABI PASS recyclable_metadata_10000_fresh_generations");
        static M3dScenePool scene_pool;
        uint32_t previous=0;
        for(unsigned generation=0;generation<10000;generation++) {
            uint32_t handle=m3d_guest_identity(0x100);
            M3dSceneRow* row=m3d_scene_pool_acquire(&scene_pool,&native,16,handle);
            if(!row || scene_pool.live!=1 || m3d_scene_pool_find(&scene_pool,handle)!=row ||
               m3d_scene_pool_find(&scene_pool,previous) || m3d_scene_pool_pointer(&scene_pool,&native,11))
                gw_panic("M3D BRIDGE FAIL scene generation ownership");
            m3d_guest_view(handle,20);m3d_guest_field(handle,20);m3d_native_bind_object(handle,&native,16);
            gw_w32((void*)(uintptr_t)handle,generation);
            if(gw_r32((void*)(uintptr_t)handle)!=generation || m3d_native_object(handle,16)!=&native)
                gw_panic("M3D BRIDGE FAIL scene generation backing");
            m3d_native_unbind_object(handle);m3d_guest_retire(handle,0x100);m3d_scene_pool_release(&scene_pool,row);
            if(m3d_scene_pool_find(&scene_pool,handle)||scene_pool.live)gw_panic("M3D BRIDGE FAIL retired scene row revived");
            previous=handle;
        }
        if(scene_pool.count!=1||scene_pool.peak!=1||scene_pool.allocations!=10000||scene_pool.retirements!=10000)
            gw_panic("M3D BRIDGE FAIL scene live budget grew with lifetime");
        puts("M3D BRIDGE ABI PASS scene_pool_10000_fresh_generations");

    }
    for (i=0; i<sizeof words/sizeof words[0]; ++i) gw_w32((void*)(uintptr_t)(code+4*i),words[i]);
    gw_wf32((void*)(uintptr_t)data,1.25f); gw_wf64((void*)(uintptr_t)(data+8),2.5);
    gw_ppc_add_code_range(code,code+sizeof words);
    gw_ppc_call(code,args,2,0,0x81ff0000);
    if (gw_rf64((void*)(uintptr_t)(data+16))!=8.75 || m3d_native_invocations(0x80003280)!=1)
        gw_panic("M3D BRIDGE FAIL mixed float/double/integer native ABI");
    {
        const struct M3dNativeCall float_call={0x800032c0,(void(*)(void))float_native,M3D_F32,2,
                                             {M3D_F32,M3D_U32},{-1,-1}};
        m3d_native_register(&float_call);
        gw_w32((void*)(uintptr_t)(code+4*4),0x618c32c0);
        gw_ppc_call(code,args,2,0,0x81ff0000);
        if (gw_rf64((void*)(uintptr_t)(data+16))!=3.75)
            gw_panic("M3D BRIDGE FAIL single-precision native return ABI");
    }
    {
        struct NativeValue native={7.5f,NULL};
        const uint32_t object=0x801e0000;
        const uint32_t object_words[]={0x7c0802a6,0xc0240000,0x3d808000,0x618c32a0,
                                       0x7d8903a6,0x4e800421,0x7c0803a6,0x4e800020};
        const struct M3dNativeCall object_call={0x800032a0,(void(*)(void))update_native_value,M3D_OBJECT,2,
                                               {M3D_OBJECT,M3D_F32},{-1,-1},{1,0},1};
        native.owner=&native;
        m3d_native_register(&object_call);
        m3d_native_bind_object(object,&native,negative && !strcmp(negative,"--wrong-object") ? 2 : 1);
        if (negative && !strcmp(negative,"--stale-object")) m3d_native_unbind_object(object);
        if (negative && !strcmp(negative,"--reused-object")) {
            m3d_native_unbind_object(object); m3d_native_bind_object(object,&native,1);
        }
        for (i=0; i<sizeof object_words/sizeof object_words[0]; ++i)
            gw_w32((void*)(uintptr_t)(code+4*i),object_words[i]);
        args[0]=object;
        if (gw_ppc_call(code,args,2,0,0x81ff0000)!=object || native.value!=8.75f || native.owner!=&native)
            gw_panic("M3D BRIDGE FAIL typed 64-bit native object round-trip");
        m3d_native_unbind_object(object);
    }
    {
        struct NativeValue value={4,NULL};
        gw_ppc_ctx context={0};
        uint32_t gobj_callback=m3d_native_callback_encode_kind((void(*)(void))bump_native_value,1);
        uint32_t effect_callback=m3d_native_callback_encode_kind((void(*)(void))bump_native_value,6);
        if(negative && !strcmp(negative,"--wrong-callback"))m3d_native_callback_decode_kind(effect_callback,1);
        m3d_native_bind_object(0x801e0100,&value,6); context.gpr[3]=0x801e0100;
        if(gobj_callback==effect_callback || !m3d_native_invoke(effect_callback,&context) || value.value!=5 ||
           m3d_native_callback_decode_kind(effect_callback,6)!=(void(*)(void))bump_native_value)
            gw_panic("M3D BRIDGE FAIL typed callback closure round-trip");
        {
            const struct M3dNativeCall known={0x80003380,(void(*)(void))bump_native_value,M3D_VOID,1,
                {M3D_OBJECT},{-1},{6}};
            m3d_native_register(&known);
            if(m3d_native_callback_encode_kind((void(*)(void))bump_native_value,6)!=0x80003380 ||
               m3d_native_callback_decode_kind(0x80003380,6)!=(void(*)(void))bump_native_value)
                gw_panic("M3D BRIDGE FAIL original native callback identity");
        }
        {
            struct NativeValue other={0,NULL};
            uint32_t predicate=m3d_native_callback_encode_typed((void(*)(void))native_predicate,6,M3D_U8,1);
            uint32_t interaction=m3d_native_callback_encode_typed((void(*)(void))native_interaction,6,M3D_VOID,2);
            if(negative && !strcmp(negative,"--wrong-callback-result"))m3d_native_callback_decode_typed(predicate,6,M3D_VOID,1);
            if(negative && !strcmp(negative,"--wrong-callback-arity"))m3d_native_callback_decode_typed(interaction,6,M3D_VOID,1);
            m3d_native_bind_object(0x801e0200,&other,6);
            if(!m3d_native_invoke(predicate,&context) || context.gpr[3]!=1)
                gw_panic("M3D BRIDGE FAIL predicate callback return");
            context.gpr[3]=0x801e0100; context.gpr[4]=0x801e0200;
            if(!m3d_native_invoke(interaction,&context) || value.owner!=&other ||
               m3d_native_callback_decode_typed(interaction,6,M3D_VOID,2)!=(void(*)(void))native_interaction)
                gw_panic("M3D BRIDGE FAIL two-object callback contract");
            value.value=0; context.gpr[3]=0x801e0100;
            if(!m3d_native_invoke(predicate,&context) || context.gpr[3]!=0)
                gw_panic("M3D BRIDGE FAIL false predicate callback return");
            m3d_native_unbind_object(0x801e0200);
        }
        m3d_native_unbind_object(0x801e0100);
        puts("M3D BRIDGE ABI PASS typed_callback_object_contract");
    }
    {
        gw_ppc_ctx context={0};
        struct M3dNativeCall extended={0x800033a0,(void(*)(void))mixed_ten,M3D_F64,10,
            {M3D_U32,M3D_U32,M3D_U32,M3D_U32,M3D_U32,M3D_U32,M3D_F32,M3D_F32,M3D_F32,M3D_F32}};
        if(negative && (!strcmp(negative,"--too-many-gprs") || !strcmp(negative,"--too-many-fprs"))) {
            extended.argument_count=9;
            for(i=0;i<9;++i)extended.arguments[i]=!strcmp(negative,"--too-many-gprs") ? M3D_U32 : M3D_F32;
        }
        m3d_native_register(&extended);
        for(i=0;i<6;++i)context.gpr[3+i]=i+1;
        for(i=0;i<4;++i)context.fpr[1+i].d=.5+i;
        if(!m3d_native_invoke(extended.guest_address,&context) || context.fpr[1].d!=654362.5)
            gw_panic("M3D BRIDGE FAIL six integer plus four float register arguments");
        puts("M3D BRIDGE ABI PASS ten_mixed_register_arguments");
    }
    puts("M3D BRIDGE ABI PASS float_double_integer_pointer_size_return_typed_object");
    {
        const uint32_t narrow_code[]={0x7c0802a6,0x3d808000,0x618c32e0,0x7d8903a6,
                                      0x4e800421,0x7c0803a6,0x4e800020};
        uint32_t integers[]={(uint32_t)-5,(uint32_t)-300,250,50000};
        const struct M3dNativeCall narrow_call={0x800032e0,(void(*)(void))narrow_native,M3D_I32,4,
                                               {M3D_I8,M3D_I16,M3D_U8,M3D_U16},{-1,-1,-1,-1}};
        m3d_native_register(&narrow_call);
        for(i=0;i<sizeof narrow_code/sizeof narrow_code[0];++i)
            gw_w32((void*)(uintptr_t)(code+i*4),narrow_code[i]);
        if(gw_ppc_call(code,integers,4,0,0x81ff0000)!=49945)
            gw_panic("M3D BRIDGE FAIL narrow signed/unsigned native ABI");
        puts("M3D BRIDGE ABI PASS signed_unsigned_byte_halfword");
    }
    {
        unsigned char native_buffer[8]={0};
        uint32_t guest_buffer=0x80a20000;
        uint32_t copy_code[]={0x7c0802a6,0x3d808000,0x618c31f4,0x7d8903a6,
                              0x4e800421,0x7c0803a6,0x4e800020};
        uint32_t copy_args[]={guest_buffer,data,4};
        m3d_guest_region_host(guest_buffer,sizeof native_buffer,native_buffer);
        for(i=0;i<sizeof copy_code/sizeof copy_code[0];++i)
            gw_w32((void*)(uintptr_t)(code+i*4),copy_code[i]);
        if(gw_ppc_call(code,copy_args,3,0,0x81ff0000)!=guest_buffer ||
           native_buffer[0]!=0x3f || native_buffer[1]!=0xa0 || native_buffer[4])
            gw_panic("M3D BRIDGE FAIL live host buffer and guest pointer-return encoding");
        puts("M3D BRIDGE ABI PASS live_host_buffer_pointer_return");
        m3d_guest_retire(guest_buffer,sizeof native_buffer);
    }
    {
        unsigned char native_buffer[8]={1,2,3,4,5,6,7,8};
        const unsigned char expected[8]={1,1,2,3,4,5,6,7};
        const uint32_t view=0x80a20100;
        gw_ppc_ctx context={0};
        const struct M3dNativeCall move={0x80323938,(void(*)(void))memmove,M3D_BUFFER,3,
            {M3D_BUFFER,M3D_BUFFER,M3D_SIZE},{2,2,-1}};
        m3d_native_register(&move);
        m3d_guest_region_host(view,sizeof native_buffer,native_buffer);
        context.gpr[3]=view+1; context.gpr[4]=view; context.gpr[5]=7;
        if(!m3d_native_invoke(move.guest_address,&context) || context.gpr[3]!=view+1 ||
           memcmp(native_buffer,expected,sizeof expected))
            gw_panic("M3D BRIDGE FAIL overlapping native buffer move");
        m3d_guest_retire(view,sizeof native_buffer);
        puts("M3D BRIDGE ABI PASS overlapping_buffer_move");
        /* Reuse exactly the same native storage, as the engine's Item pool
         * does between attacks. Native pointer returns must use the new view. */
        const uint32_t reused=view+0x100;
        m3d_guest_region_host(reused,sizeof native_buffer,native_buffer);
        context.gpr[3]=reused+1; context.gpr[4]=reused; context.gpr[5]=7;
        if(!m3d_native_invoke(move.guest_address,&context) || context.gpr[3]!=reused+1 ||
           m3d_guest_encode_buffer(native_buffer+2)!=reused+2)
            gw_panic("M3D BRIDGE FAIL reused native buffer retained retired guest view");
        m3d_guest_retire(reused,sizeof native_buffer);
        puts("M3D BRIDGE ABI PASS reused_host_buffer_new_view");
    }
}

/* Real 64-bit host pointers never enter the PowerPC register file. Each host
 * record has its own guest gobj/fighter/data views and stable 32-bit handles. */
struct HostAttributes {
    void* identity;
    const unsigned char* source;
    unsigned char* destination;
    uint64_t guard;
};

#ifdef M3D_VM_TESTS
static int (*isa_tests[32])(void);
static const char* isa_names[32];
static unsigned isa_count, isa_failures;
void gw_test_register(const char* name, int (*test)(void))
{
    if (isa_count==32) gw_panic("ISA registry capacity exceeded");
    isa_names[isa_count]=name; isa_tests[isa_count++]=test;
}
void gw_test_fail(const char* format, ...)
{
    va_list ap; va_start(ap,format); vfprintf(stderr,format,ap); va_end(ap);
    fputc('\n',stderr); ++isa_failures;
}
int main(void)
{
    unsigned i, passed=0;
    m3d_guest_init();
    m3d_guest_region(0x80300000,0x10000); m3d_guest_region(0x81fe0000,0x20000);
    gw_ppc_tests_register();
    for (i=0; i<isa_count; ++i) {
        unsigned before=isa_failures;
        int result=isa_tests[i]();
        int success=result==0 && isa_failures==before;
        passed+=success;
        printf("%s %s\n",isa_names[i],success ? "PASS" : "FAIL");
    }
    printf("M3D ISA TESTS pass=%u fail=%u total=%u\n",passed,isa_count-passed,isa_count);
    return passed==isa_count && isa_count==6 ? 0 : 1;
}
#else
int main(int argc, char** argv)
{
    gw_ftfunction module;
    uint32_t reset=0, index, slot;
    const char* filename;
    static const struct { const char* file; unsigned internal, size; int primary; } characters[] = {
        {"PlWf.dat",27,0xd4,1}, {"PlDd.dat",28,0x100,1}, {"PlLz.dat",29,0xb0,1},
        {"PlLc.dat",30,0x13c,0}, {"PlSn.dat",31,0x148,0}, {"PlDe.dat",32,0x17c,0}, {"PlTs.dat",33,0x1a8,0},
    };
    unsigned character, size;
    struct HostAttributes host[16];
    unsigned char source[16][0x200], destination[16][0x200];
    if (argc < 2 || argc > 3) return 1;
    filename=strrchr(argv[1],'/'); filename=filename ? filename+1 : argv[1];
    for (character=0; character<7; ++character) if (!strcmp(filename,characters[character].file)) break;
    if (character==7) gw_panic("Probe requires a recognized original Akaneia character archive");
    size=characters[character].size;
    m3d_guest_init();
    m3d_guest_region(0x80800000,0x100000);
    m3d_guest_region(0x80900000,0x6000);
    m3d_guest_region(0x81fe0000,0x20000);
    {
        const struct M3dNativeCall call={0x800031F4,(void(*)(void))memcpy,M3D_BUFFER,3,
                                        {M3D_BUFFER,M3D_BUFFER,M3D_SIZE},{2,2,-1}};
        m3d_native_register(&call);
    }
    if (gw_ftfunction_load_at(argv[1], characters[character].internal, 0x80800000, 0x80900000, &module)) return 1;
    for (index=0; index<module.symbol_count; ++index)
        if (!strcmp(module.symbols[index].name, "ResetAttributes")) reset=module.symbols[index].start;
    if (!reset) gw_panic("Required original Akaneia ResetAttributes symbol absent");
    gw_ppc_set_bridge(resolve, NULL, module.code_base, module.code_base+module.code_size);
    for (slot=0; slot<16; ++slot) {
        uint32_t base=0x80010000u + slot*0x10000u;
        uint32_t object=base, fighter=base+0x1000, data=base+0x5000;
        uint32_t from=base+0x6000, to=base+0x7000, primary=base+0x7800;
        m3d_guest_region(base+0x6000,0x200); m3d_guest_region(base+0x7000,0x200); m3d_guest_region(primary,0x200);
        if (argc==3 && !strcmp(argv[2],"--bad-span")) to=fighter+0x10c;
        for (index=0; index<size; ++index) source[slot][index]=(slot*29+index*7)&255;
        if (character==0) {
            /* Wolf's original function copies its relocated inline defaults. */
            from=((gw_r32((void*)(uintptr_t)(reset+4)) & 0xffffu)<<16) +
                  (int16_t)gw_r32((void*)(uintptr_t)(reset+8));
            if (from < module.code_base || (uint64_t)from+size > (uint64_t)module.code_base+module.code_size)
                gw_panic("Wolf inline defaults outside loaded module");
            m3d_guest_memcpy(source[slot],(void*)(uintptr_t)from,size);
        }
        memset(destination[slot], 0, sizeof destination[slot]);
        host[slot]=(struct HostAttributes){&host[slot], source[slot], destination[slot], UINT64_C(0x0123456789abcdef)};
        m3d_guest_view(object, 0x40); m3d_guest_field(object+0x2c, 4);
        m3d_guest_view(fighter, 0x3000);
        m3d_guest_field(fighter+0x10c, 4); m3d_guest_field(fighter+0x2d4, 8);
        m3d_guest_field(fighter+0x22a8,4); /* Tails' multijump attribute. */
        m3d_guest_view(data, 0x60); m3d_guest_field(data+4, 4);
        gw_w32((void*)(uintptr_t)(object+0x2c), fighter);
        gw_w32((void*)(uintptr_t)(fighter+0x10c), data);
        gw_w32((void*)(uintptr_t)(data+4), from);
        gw_w32((void*)(uintptr_t)(fighter+0x2d4), characters[character].primary ? to : primary);
        gw_w32((void*)(uintptr_t)(fighter+0x2d8), characters[character].primary ? primary : to);
        if (character!=0) m3d_guest_memcpy((void*)(uintptr_t)from, host[slot].source, size);
        m3d_guest_memcpy((void*)(uintptr_t)primary, host[slot].source, size);
        if (argc==3 && !strcmp(argv[2],"--bad-field")) gw_r32((void*)(uintptr_t)(fighter+4));
        if (argc==3 && !strcmp(argv[2],"--bad-pointer")) gw_r32((void*)(uintptr_t)0xffffffffu);
        if (argc==3 && !strcmp(argv[2],"--unmapped-global")) gw_r32((void*)(uintptr_t)0x804d6d00u);
        if (argc==3 && !strcmp(argv[2],"--retired-memory")) {
            m3d_guest_retire(primary,4); gw_r32((void*)(uintptr_t)primary);
        }
        if (argc==3 && !strcmp(argv[2],"--unknown-call")) { gw_ppc_sig sig; resolve(0x80000004,NULL,&sig); }
        if (gw_ppc_call(reset, &object, 1, module.mexdata_base, 0x81ff0000)!=to)
            gw_panic("M3D BRIDGE FAIL native pointer return encoding");
        m3d_guest_memcpy(host[slot].destination, (void*)(uintptr_t)to, size);
        if (character==6 && gw_r32((void*)(uintptr_t)(fighter+0x22a8)) != gw_r32((void*)(uintptr_t)(primary+0x3c)))
            gw_panic("Tails' original callback did not export its multijump value");
    }
    for (slot=0; slot<16; ++slot) {
        if (host[slot].identity != &host[slot] || host[slot].guard != UINT64_C(0x0123456789abcdef) ||
            memcmp(host[slot].source, host[slot].destination, size))
            gw_panic("M3D BRIDGE FAIL host round-trip slot=%u", slot);
    }
    if (m3d_native_invocations(0x800031F4)!=16) gw_panic("M3D BRIDGE FAIL native callback count");
    check_floating_abi(argc==3 ? argv[2] : NULL);
    printf("M3D BRIDGE PASS original_reset_attributes character=%s host_pointer_bytes=%zu objects=16 copied_bytes=%u\n",
           filename, sizeof(void*), 16*size);
    gw_ftfunction_free(&module);
    return 0;
}
#endif
