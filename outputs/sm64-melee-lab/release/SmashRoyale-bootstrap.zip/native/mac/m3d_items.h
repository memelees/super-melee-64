/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef M3D_ITEMS_H
#define M3D_ITEMS_H
#include <stdint.h>
#include <stddef.h>
void m3d_items_index(int global, void* descriptor, unsigned owner, unsigned article);
void* m3d_items_descriptor(int kind);
void* m3d_items_logic(int kind);
int m3d_items_fighter_kind(int kind);
void m3d_items_validate_state(void* object,int state);
void m3d_items_created(void* object, void* owner);
uint32_t m3d_items_view(void* object);
void m3d_items_track(void* object);
int m3d_items_observe(uint32_t address, size_t size, int writing);
void m3d_items_removed(void* object);
void m3d_items_scene_reset(void);
void m3d_items_finish_destroy(void* object);
void m3d_items_collision_word(uint32_t at,void* collision,unsigned offset,int writing);
void m3d_bind_items(void);
#endif
