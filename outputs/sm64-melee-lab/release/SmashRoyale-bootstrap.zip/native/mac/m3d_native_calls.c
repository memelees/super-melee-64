/* SPDX-License-Identifier: GPL-3.0-or-later
 * DELFINO: typed PowerPC-to-host calls. libffi supplies the actual arm64 ABI;
 * float/double/pointer arguments never masquerade as x86 stack words. */
#include "m3d_native_calls.h"
#include "m3d_guest_memory.h"
#include "gw_ppc.h"
#if __has_include(<ffi/ffi.h>)
#include <ffi/ffi.h>
#else
#include <ffi.h>
#endif
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

extern unsigned char* gw_mem1;
extern uint32_t gw_mem1_size;
extern void gw_panic(const char*, ...);
static struct Entry {
    struct M3dNativeCall call;
    ffi_cif cif;
    ffi_type* arguments[16];
    unsigned invocations;
} entries[4096];
static unsigned entry_count;
static unsigned short call_index[8192];
static unsigned call_bucket(uint32_t address) {
    unsigned slot=(((address>>2)*2654435761u)>>19)&8191u;
    while(call_index[slot]&&entries[call_index[slot]-1].call.guest_address!=address)slot=(slot+1)&8191u;
    return slot;
}
static struct Entry* find_call(uint32_t address) {
    unsigned index=call_index[call_bucket(address)];return index?&entries[index-1]:NULL;
}
int m3d_native_is_bound(uint32_t address) { return find_call(address)!=NULL; }
static struct {
    void (*function)(void);unsigned kind,count,generation;enum M3dAbiType result;uint32_t address;
} callback_hints[512];
static struct { uint32_t handle; void* pointer; unsigned kind; } objects[4096];
static unsigned object_count;
static struct { uint32_t address; void (*function)(void); unsigned kind,count; enum M3dAbiType result; } callbacks[2048];
static unsigned callback_count;
static void (*sync_before)(void), (*sync_after)(void);
static uint32_t (*result_handler)(void*,unsigned);
void m3d_native_result_handler(uint32_t (*handler)(void*,unsigned)) { result_handler=handler; }
void m3d_native_sync(void (*before)(void), void (*after)(void))
{
    sync_before=before; sync_after=after;
}
union Value { ffi_arg word; uint32_t u; int32_t i; float f; double d; size_t size; void* pointer; };

static ffi_type* type(enum M3dAbiType value)
{
    switch (value) {
    case M3D_VOID: return &ffi_type_void;
    case M3D_U8: return &ffi_type_uint8;
    case M3D_I8: return &ffi_type_sint8;
    case M3D_U16: return &ffi_type_uint16;
    case M3D_I16: return &ffi_type_sint16;
    case M3D_U32: return &ffi_type_uint32;
    case M3D_I32: return &ffi_type_sint32;
    case M3D_F32: return &ffi_type_float;
    case M3D_F64: return &ffi_type_double;
    case M3D_SIZE: return sizeof(size_t)==8 ? &ffi_type_uint64 : &ffi_type_uint32;
    case M3D_BUFFER: case M3D_OBJECT: case M3D_CONTEXT: return &ffi_type_pointer;
    }
    gw_panic("Unknown native ABI class"); return NULL;
}

void m3d_native_bind_object(uint32_t handle, void* pointer, unsigned kind)
{
    unsigned i;
    if (!handle || !pointer || !kind) gw_panic("Invalid/exhausted native object registry");
    for (i=0; i<object_count; ++i)
        if (objects[i].handle==handle) gw_panic("Native object handle cannot be rebound; use a fresh generation");
    for(i=0;i<object_count && objects[i].pointer;++i) {}
    if(i==4096)gw_panic("Native object registry live capacity exhausted");
    objects[i].handle=handle; objects[i].pointer=pointer;
    objects[i].kind=kind;if(i==object_count)++object_count;
}
void m3d_native_unbind_object(uint32_t handle)
{
    unsigned i;
    for (i=0; i<object_count; ++i) if (objects[i].handle==handle) { objects[i].pointer=NULL; return; }
    gw_panic("Native object handle is not registered");
}
static void* object_pointer(uint32_t handle, unsigned kind)
{
    unsigned i;
    if (!handle) return NULL;
    for (i=0; i<object_count; ++i)
        if (objects[i].handle==handle) {
            if (!objects[i].pointer) gw_panic("Stale native object handle");
            if (objects[i].kind!=kind) gw_panic("Native object kind mismatch handle=0x%08x actual=%u expected=%u",handle,objects[i].kind,kind);
            return objects[i].pointer;
        }
    gw_panic("Unregistered native object handle 0x%08x kind=%u",handle,kind); return NULL;
}
void* m3d_native_object(uint32_t handle,unsigned kind) { return object_pointer(handle,kind); }
uint32_t m3d_native_callback_encode(void (*function)(void))
{
    return m3d_native_callback_encode_kind(function,1);
}
uint32_t m3d_native_callback_encode_kind(void (*function)(void),unsigned kind)
{
    return m3d_native_callback_encode_typed(function,kind,M3D_VOID,1);
}
static int callback_contract(const struct M3dNativeCall* c,unsigned kind,enum M3dAbiType result,unsigned count)
{
    unsigned i;
    if(c->result!=result || c->argument_count!=count)return 0;
    for(i=0;i<count;++i)if(c->arguments[i]!=M3D_OBJECT || c->object_kinds[i]!=kind)return 0;
    return 1;
}
uint32_t m3d_native_callback_encode_typed(void (*function)(void),unsigned kind,enum M3dAbiType result,unsigned count)
{
    unsigned i;
    struct M3dNativeCall call={0};
    if(!function)return 0;
    if(!kind || !count || count>2 || (result!=M3D_VOID && result!=M3D_U8))
        gw_panic("Unsupported native callback contract");
    uintptr_t pointer=(uintptr_t)function;
    unsigned hint=((pointer>>4)^(pointer>>21)^kind*17u^result*3u^count)&511u;
    if(callback_hints[hint].function==function&&callback_hints[hint].kind==kind&&
       callback_hints[hint].result==result&&callback_hints[hint].count==count&&
       callback_hints[hint].generation==entry_count)return callback_hints[hint].address;
    uint32_t address=0;
    /* An added original identity takes precedence over a generated callback;
     * registry generation invalidates hints when any new call is installed. */
    for(i=0;i<entry_count;++i) {
        struct M3dNativeCall* known=&entries[i].call;
        if(known->guest_address>=0x81d00000&&known->guest_address<0x81d02000)continue;
        if(known->function==function&&callback_contract(known,kind,result,count)){address=known->guest_address;break;}
    }
    if(!address)for(i=0;i<callback_count;++i)
        if(callbacks[i].function==function&&callbacks[i].kind==kind&&callbacks[i].result==result&&callbacks[i].count==count){address=callbacks[i].address;break;}
    if(address)goto remember_callback;
    if(callback_count==2048)gw_panic("Native callback registry capacity exceeded");
    call.guest_address=0x81d00000u+callback_count*4; call.function=function;
    call.result=result; call.argument_count=count;
    for(i=0;i<count;++i) { call.arguments[i]=M3D_OBJECT; call.object_kinds[i]=kind; }
    m3d_native_register(&call);
    callbacks[callback_count].address=call.guest_address; callbacks[callback_count].kind=kind;
    callbacks[callback_count].result=result; callbacks[callback_count].count=count;
    callbacks[callback_count++].function=function;
    address=call.guest_address;
remember_callback:
    callback_hints[hint].function=function;callback_hints[hint].kind=kind;
    callback_hints[hint].result=result;callback_hints[hint].count=count;
    callback_hints[hint].generation=entry_count;callback_hints[hint].address=address;
    return address;
}
void (*m3d_native_callback_decode(uint32_t address))(void)
{
    return m3d_native_callback_decode_kind(address,1);
}
void (*m3d_native_callback_decode_kind(uint32_t address,unsigned kind))(void)
{
    return m3d_native_callback_decode_typed(address,kind,M3D_VOID,1);
}
void (*m3d_native_event_pointer(uint32_t address,unsigned kind))(void)
{
    /* Optional fast path only: a nonmatching contract continues through the
     * original checked call adapter, never an untyped native callback. */
    struct Entry* entry=find_call(address);
    return entry&&callback_contract(&entry->call,kind,M3D_VOID,1)?entry->call.function:NULL;
}

void (*m3d_native_callback_decode_typed(uint32_t address,unsigned kind,enum M3dAbiType result,unsigned count))(void)
{
    unsigned i;
    i=(address-0x81d00000u)/4;
    if(address>=0x81d00000u&&i<callback_count&&callbacks[i].address==address) {
        if(callbacks[i].kind!=kind)gw_panic("Native callback object kind mismatch");
        if(callbacks[i].result!=result || callbacks[i].count!=count)gw_panic("Native callback signature mismatch");
        return callbacks[i].function;
    }
    struct Entry* entry=find_call(address);
    if(entry) {
        struct M3dNativeCall* known=&entry->call;
        if(callback_contract(known,kind,result,count))return known->function;
        /* A known engine address with another signature cannot be run as a
         * guest callback. Fail here rather than quietly miscasting it. */
        gw_panic("Native callback object kind/signature mismatch");
    }
    return NULL;
}

void m3d_native_register(const struct M3dNativeCall* call)
{
    unsigned i;
    struct Entry* e;
    if (!call || !call->function || call->argument_count>16 || entry_count==4096)
        gw_panic("Invalid or exhausted native-call registry");
    unsigned bucket=call_bucket(call->guest_address);
    if(call_index[bucket])gw_panic("Duplicate native-call address");
    {
        unsigned integers=0,floats=0;
        for(i=0;i<call->argument_count;++i) {
            if(call->arguments[i]==M3D_F32 || call->arguments[i]==M3D_F64)++floats;
            else if(call->arguments[i]!=M3D_CONTEXT)++integers;
        }
        if(integers>8 || floats>8)gw_panic("Native call exceeds guest register argument capacity");
    }
    e=&entries[entry_count++]; e->call=*call;call_index[bucket]=entry_count;
    for (i=0; i<call->argument_count; ++i) {
        int length=call->buffer_length_argument[i];
        if (call->arguments[i]==M3D_CONTEXT && (call->argument_count!=1 || i!=0 || call->result!=M3D_U32))
            gw_panic("Full-EABI context adapter requires one context and a guest word result");
        if (call->arguments[i]==M3D_VOID) gw_panic("Void native argument");
        if (call->arguments[i]==M3D_OBJECT && !call->object_kinds[i]) gw_panic("Native object argument needs an explicit kind");
        if (call->arguments[i]==M3D_BUFFER && length!=-1 &&
            (length<0 || (unsigned)length>=call->argument_count ||
             (call->arguments[length]!=M3D_SIZE && call->arguments[length]!=M3D_U32)))
            gw_panic("Invalid native buffer-length contract");
        e->arguments[i]=type(call->arguments[i]);
    }
    if(call->result==M3D_CONTEXT)gw_panic("Native context cannot escape as a result");
    if (call->result==M3D_OBJECT && !call->result_object_kind) gw_panic("Native object return needs an explicit kind");
    if (ffi_prep_cif(&e->cif,FFI_DEFAULT_ABI,call->argument_count,type(call->result),e->arguments)!=FFI_OK)
        gw_panic("Cannot prepare native-call ABI");
}

uint32_t m3d_native_current_call;
int m3d_native_invoke(uint32_t address, struct gw_ppc_ctx* cpu)
{
    unsigned i, gpr=3, fpr=1;
    union Value arguments[16]={{0}}, result={0};
    void* pointers[16];
    uint32_t buffer_guest[16]={0};
    struct Entry* e=find_call(address);
    if (!e) return 0;
    uint32_t previous_call=m3d_native_current_call;m3d_native_current_call=address;
    for (i=0; i<e->call.argument_count; ++i) {
        enum M3dAbiType t=e->call.arguments[i];
        if(t==M3D_CONTEXT) { arguments[i].pointer=cpu;pointers[i]=&arguments[i].pointer; }
        else if (t==M3D_F32 || t==M3D_F64) {
            if (fpr>8) gw_panic("Native ABI requires a stack floating-point argument adapter");
            if (t==M3D_F32) { arguments[i].f=(float)cpu->fpr[fpr++].d; pointers[i]=&arguments[i].f; }
            else { arguments[i].d=cpu->fpr[fpr++].d; pointers[i]=&arguments[i].d; }
        } else {
            if (gpr>10) gw_panic("Native ABI requires a stack integer argument adapter");
            arguments[i].u=cpu->gpr[gpr++]; pointers[i]=&arguments[i].u;
            if (t==M3D_SIZE) { arguments[i].size=arguments[i].u; pointers[i]=&arguments[i].size; }
        }
    }
    for (i=0; i<e->call.argument_count; ++i) {
        if (e->call.arguments[i]==M3D_BUFFER) {
            int length=e->call.buffer_length_argument[i];
            size_t size=length<0 ? 1 : e->call.arguments[length]==M3D_SIZE ? arguments[length].size : arguments[length].u;
            if(size && (arguments[i].u<0x80000000u || (uint64_t)arguments[i].u+size>UINT64_C(0x80000000)+gw_mem1_size))
                gw_panic("Native buffer argument is outside the guest namespace");
            buffer_guest[i]=arguments[i].u;
            m3d_guest_touch((void*)(uintptr_t)arguments[i].u,size,0);
            arguments[i].pointer=m3d_guest_address((void*)(uintptr_t)arguments[i].u,size);
            pointers[i]=&arguments[i].pointer;
        } else if (e->call.arguments[i]==M3D_OBJECT) {
            arguments[i].pointer=object_pointer(arguments[i].u,e->call.object_kinds[i]);
            pointers[i]=&arguments[i].pointer;
        }
    }
    if (sync_before) sync_before();
    ffi_call(&e->cif,e->call.function,&result,pointers); ++e->invocations;
    for(i=0;i<e->call.argument_count;++i)if(e->call.arguments[i]==M3D_BUFFER) {
        int length=e->call.buffer_length_argument[i];
        size_t size=length<0 ? 1 : e->call.arguments[length]==M3D_SIZE ? arguments[length].size : arguments[length].u;
        uint32_t guest=buffer_guest[i];
        m3d_guest_touch((void*)(uintptr_t)guest,size,1);
    }
    if (sync_after) sync_after();
    switch (e->call.result) {
    case M3D_CONTEXT: gw_panic("Native context cannot escape as a result");break;
    case M3D_VOID: break;
    case M3D_U8: case M3D_I8: case M3D_U16: case M3D_I16:
    case M3D_U32: case M3D_I32: cpu->gpr[3]=(uint32_t)result.word; break;
    case M3D_F32: cpu->fpr[1].d=result.f; break;
    case M3D_F64: cpu->fpr[1].d=result.d; break;
    case M3D_SIZE:
        if (result.size>UINT32_MAX) gw_panic("Native size result cannot fit guest word");
        cpu->gpr[3]=(uint32_t)result.size; break;
    case M3D_BUFFER:
        /* memcpy/memset return the passed buffer. Preserve its exact guest
         * identity: overlapping host aliases may describe a shorter range. */
        for(i=0;i<e->call.argument_count;++i)if(e->call.arguments[i]==M3D_BUFFER&&result.pointer==arguments[i].pointer)break;
        cpu->gpr[3]=i<e->call.argument_count?buffer_guest[i]:m3d_guest_encode_buffer(result.pointer);
        break;
    case M3D_OBJECT:
        if (!result.pointer) { cpu->gpr[3]=0; break; }
        for (i=0; i<object_count; ++i)
            if (objects[i].pointer==result.pointer && objects[i].kind==e->call.result_object_kind) break;
        if (i==object_count) {
            uint32_t handle;
            if(!result_handler)gw_panic("Native object return has no live typed handle");
            handle=result_handler(result.pointer,e->call.result_object_kind);
            if(object_pointer(handle,e->call.result_object_kind)!=result.pointer)
                gw_panic("Native object result handler did not register the returned pointer");
            cpu->gpr[3]=handle;
        } else cpu->gpr[3]=objects[i].handle;
        break;
    }
    m3d_native_current_call=previous_call;
    return 1;
}

unsigned m3d_native_invocations(uint32_t address)
{
    unsigned i;
    for (i=0; i<entry_count; ++i) if (entries[i].call.guest_address==address) return entries[i].invocations;
    return 0;
}
