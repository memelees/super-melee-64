#ifndef M3D_RESPAWN_H
#define M3D_RESPAWN_H
/* Queue bookkeeping has 32 seats; retail stage joints/offsets have six.
 * Preserve the original six placements and cycle those temporary anchors.
 * The 3D stage subsequently chooses its own collision-derived spawn point. */
static inline float m3d_respawn_offset(unsigned queue_index)
{
    static const float offsets[] = {0, 1, -1, 2, 0, 0};
    return 16.0f * offsets[queue_index % 6];
}
static inline unsigned m3d_respawn_joint(unsigned slot)
{
    return 4 + slot % 6;
}
#endif
