/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef M3D_SCENE_H
#define M3D_SCENE_H
#include <stdint.h>
#include <stddef.h>
uint32_t m3d_scene_animation(void* animation);
uint32_t m3d_scene_material(void* pointer,unsigned kind);
void m3d_scene_material_removed(void* pointer);
uint32_t m3d_scene_camera(void* pointer);
void m3d_scene_camera_removed(void* pointer);
void m3d_bind_scene(void);
void m3d_scene_reset(void);
void m3d_scene_animation_removed(void* animation);
int m3d_scene_observe(uint32_t address,size_t size,int writing);
#endif
