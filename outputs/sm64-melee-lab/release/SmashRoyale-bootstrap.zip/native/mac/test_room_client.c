/* SPDX-License-Identifier: GPL-3.0-or-later
 * Real socket client using exactly the game's I/O implementation. This is a
 * transport load test, not a replacement for rendered fighter acceptance.
 */
#include "m3d_room_io.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
int main(int argc,char** argv) {
    int frames=argc>1?atoi(argv[1]):600,seat=m3d_room_local();
    uint32_t checksum=0;uint8_t all[32*12];
    for(int f=0;f<frames;f++) {
        uint8_t pad[12]={0};pad[0]=(uint8_t)(1+seat%4);pad[2]=(uint8_t)(seat*3);pad[8]=(uint8_t)seat;
        uint32_t seed;m3d_room_exchange(pad,checksum,all,&seed);
        checksum=seed;
        for(int i=0;i<m3d_room_humans()*12;i++)checksum=(checksum^all[i])*16777619u;
        if(f>=12)for(int i=0;i<m3d_room_humans();i++)
            if(all[i*12]!=(uint8_t)(1+i%4)||all[i*12+2]!=(uint8_t)(i*3)||all[i*12+8]!=(uint8_t)i)return 2;
        if(getenv("M3D_TEST_REALTIME")){struct timespec wait={0,16666667};nanosleep(&wait,NULL);}
    }
    printf("M3D TRANSPORT PASS seat=%d frames=%d checksum=%08x\n",seat,frames,checksum);
    return 0;
}
