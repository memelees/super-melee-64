/* Native scene identities remain unchanged. Sunshine banks share FD backing. */
#ifndef M3D_STAGE_CHOICES_H
#define M3D_STAGE_CHOICES_H
#define M3D_STAGE_CHOICES 6
/* Native SSS coordinates: three columns, two rows above its title strip. */
#define M3D_STAGE_GRID_COLUMNS 3
#define M3D_STAGE_GRID_X 10.0f
#define M3D_STAGE_GRID_Y 6.8f
#define M3D_STAGE_GRID_TOP -4.5f
#define M3D_STAGE_GRID_HALF_W 3.7f
#define M3D_STAGE_GRID_HALF_H 2.6f
static inline int m3d_stage_grid_choice(int cell,unsigned available) {
    static const int order[M3D_STAGE_CHOICES]={0,3,4,5,1,2};
    for(int i=0;i<M3D_STAGE_CHOICES;i++)if(available&(1u<<order[i])) {
        if(cell--==0)return order[i];
    }
    return -1;
}
static inline int m3d_stage_grid_cell(int choice,unsigned available) {
    if(choice<0||choice>=M3D_STAGE_CHOICES||!(available&(1u<<choice)))return -1;
    for(int cell=0;cell<M3D_STAGE_CHOICES;cell++)if(m3d_stage_grid_choice(cell,available)==choice)return cell;
    return -1;
}
static inline int m3d_stage_grid_center(int choice,unsigned available,float* x,float* y) {
    int cell=m3d_stage_grid_cell(choice,available);if(cell<0)return 0;
    *x=((cell%M3D_STAGE_GRID_COLUMNS)-1)*M3D_STAGE_GRID_X;
    *y=M3D_STAGE_GRID_TOP-(cell/M3D_STAGE_GRID_COLUMNS)*M3D_STAGE_GRID_Y;
    return 1;
}
static inline int m3d_stage_grid_hit(float x,float y,unsigned available) {
    for(int cell=0;cell<M3D_STAGE_CHOICES;cell++) {
        int choice=m3d_stage_grid_choice(cell,available);float cx,cy;
        if(choice<0)break;
        m3d_stage_grid_center(choice,available,&cx,&cy);
        if(x>=cx-M3D_STAGE_GRID_HALF_W&&x<=cx+M3D_STAGE_GRID_HALF_W&&
           y>=cy-M3D_STAGE_GRID_HALF_H&&y<=cy+M3D_STAGE_GRID_HALF_H)return choice;
    }
    return -1;
}
static inline int m3d_stage_grid_step(int choice,int dx,int dy,unsigned available) {
    int cell=m3d_stage_grid_cell(choice,available),best=choice,score=1000;
    if(!dx&&!dy)return choice;
    if(cell<0)return m3d_stage_grid_choice(0,available);
    for(int i=0;i<M3D_STAGE_CHOICES;i++) {
        int candidate=m3d_stage_grid_choice(i,available);if(candidate<0)break;
        int x=i%3-cell%3,y=cell/3-i/3;
        if((dx&&x*dx<=0)||(dy&&y*dy<=0))continue;
        int value=dx?x*x+10*y*y:y*y+10*x*x;
        if(value&&value<score){score=value;best=candidate;}
    }
    return best;
}
static inline float m3d_stage_cursor_axis(float axis) {
    if(axis>.18f)return (axis- .18f)/.82f*.62f;
    if(axis<-.18f)return (axis+.18f)/.82f*.62f;
    return 0;
}
static inline float m3d_stage_cursor_clamp(float value,float limit) {
    return value < -limit ? -limit : value > limit ? limit : value;
}
static inline float m3d_stage_sunshine_kill_depth(int choice) {return choice==5?220.0f:85.0f;}
static inline int m3d_stage_choice_id(int choice) {return choice==1?9:choice==2?4:32;}
static inline int m3d_stage_choice_next_mask(int choice,int direction,unsigned available) {
    static const int order[M3D_STAGE_CHOICES]={0,3,4,5,1,2};
    if(!direction)return choice;
    int position=0;for(int i=0;i<M3D_STAGE_CHOICES;i++)if(order[i]==choice)position=i;
    for(int i=0;i<M3D_STAGE_CHOICES;i++) {
        position=(position+(direction>0?1:M3D_STAGE_CHOICES-1))%M3D_STAGE_CHOICES;
        if(available&(1u<<order[position]))return order[position];
    }
    return 0;
}
static inline int m3d_stage_choice_next(int choice,int direction,int onett,int castle) {
    return m3d_stage_choice_next_mask(choice,direction,1u|(onett?2u:0u)|(castle?4u:0u));
}
#endif
