/* DELFINO: opt-in native capacity laboratory. No canonical Dolphin hooks. */
#ifndef MELEE3D_NATIVE_LAB_H
#define MELEE3D_NATIVE_LAB_H
struct StartMeleeData;
struct Vec3;
struct Fighter;
int m3d_lab_count(void);
void m3d_lab_setup(struct StartMeleeData* start);
int m3d_lab_spawn(int slot, void* position);
void m3d_lab_tick(void);
void m3d_lab_pad(void);
void m3d_lab_pause_check(void* camera,int paused);
void m3d_lab_audio(struct Fighter* fighter,int sound,int voice);
void m3d_lab_graphics(void);
void m3d_lab_camera_render(void);
struct HSD_CObj;
int m3d_lab_atlas_camera(struct HSD_CObj* camera);
int m3d_lab_atlas_ready(void);
void m3d_lab_hit(int attacker, int victim);
const char* m3d_lab_character_name(int character);
void m3d_lab_input(struct Fighter* fighter);
enum M3dFrameStage { M3D_TRACE_PAD, M3D_TRACE_SIM, M3D_TRACE_DRAW,
    M3D_TRACE_GPU_END, M3D_TRACE_HOST, M3D_TRACE_PACE, M3D_TRACE_GPU_BEGIN,
    M3D_TRACE_STAGES };
void m3d_lab_trace_stage(int stage);
void m3d_lab_trace_tick(void);
void m3d_lab_trace_frame(unsigned frame);
#endif
