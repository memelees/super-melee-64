/* SPDX-License-Identifier: GPL-3.0-or-later
 * Keep native spheres/capsules and expanded victim histories. Guest addresses
 * identify the actual native shapes; only declared header fields are exposed.
 */
#include "m3d_hitboxes.h"
#include "m3d_vm.h"
#include "m3d_guest_memory.h"
#include "m3d_native_calls.h"
#include <melee/ft/types.h>
#include <melee/it/types.h>
#include <melee/gm/forward.h>
#include <sysdolphin/baselib/gobj.h>
#include <string.h>
static struct { HSD_GObj* owner; uint32_t view; HitCapsule* hit; } shapes[GM_MAX_PLAYERS*7+96*4];
static unsigned shape_count;
/* Two cells cover any declared 64-byte header. Rebuild at lifecycle changes,
 * so recycled rows cannot leave stale index entries. */
#define SHAPE_CAPACITY (GM_MAX_PLAYERS*7+96*4)
static int shape_heads[1024],shape_next[SHAPE_CAPACITY*2],shape_rows[SHAPE_CAPACITY*2];
static uint32_t shape_cells[SHAPE_CAPACITY*2];
static void index_shapes(void) {
    unsigned entry=0;for(unsigned i=0;i<1024;i++)shape_heads[i]=-1;
    for(unsigned i=0;i<shape_count;i++)if(shapes[i].hit) {
        uint32_t first=shapes[i].view>>6,last=(shapes[i].view+0x3f)>>6;
        for(uint32_t cell=first;cell<=last;cell++) {
            unsigned bucket=(cell*2654435761u)>>22;
            shape_cells[entry]=cell;shape_rows[entry]=i;shape_next[entry]=shape_heads[bucket];shape_heads[bucket]=entry++;
        }
    }
}
/* Conservative lifetime bounds reject unrelated code/archive reads before the
 * live shape scan. Bounds only expand; removal still clears the exact row. */
static uint32_t first_shape=UINT32_MAX,last_shape;
static void shape_bounds(uint32_t view) {
    if(view<first_shape)first_shape=view;
    if(view+0x40>last_shape)last_shape=view+0x40;
}
static unsigned vacant_shape(void)
{
    unsigned i;
    for(i=0;i<shape_count && shapes[i].hit;++i) {}
    if(i==GM_MAX_PLAYERS*7+96*4)m3d_vm_fail("Native hit-shape live registry exhausted");
    if(i==shape_count)++shape_count;
    return i;
}
void m3d_hitboxes_track(void* pointer,uint32_t view)
{
    HSD_GObj* object=pointer;
    Fighter* fp=object->user_data;
    unsigned i;
    for(i=0;i<7;++i) {
        HitCapsule* hit=i<4 ? &fp->x914[i] : i<6 ? &fp->xDF4[i-4] : &fp->x1064_thrownHitbox;
        uint32_t at=view+(i<4 ? 0x914+i*0x138 : i<6 ? 0xdf4+(i-4)*0x138 : 0x1064);
        unsigned slot=vacant_shape();
        shapes[slot].owner=object; shapes[slot].view=at; shapes[slot].hit=hit;
        m3d_native_bind_object(at,hit,12);
        m3d_guest_field(at,0x40);shape_bounds(at);
    }
    index_shapes();
}
void m3d_hitboxes_item_track(void* pointer,uint32_t view)
{
    HSD_GObj* object=pointer;
    Item* ip=object->user_data;
    for(unsigned i=0;i<4;++i) {
        uint32_t at=view+0x5d4+i*0x13c;
        unsigned slot=vacant_shape();
        shapes[slot].owner=object; shapes[slot].view=at; shapes[slot].hit=&ip->x5D4_hitboxes[i].hit;
        m3d_native_bind_object(at,&ip->x5D4_hitboxes[i].hit,12); m3d_guest_field(at,0x40);shape_bounds(at);
    }
    index_shapes();
}
void m3d_hitboxes_removed(void* object)
{
    unsigned i;
    for(i=0;i<shape_count;++i)if(shapes[i].owner==object) {
        m3d_native_unbind_object(shapes[i].view); shapes[i].owner=NULL; shapes[i].hit=NULL;
    }
    index_shapes();
}
int m3d_hitboxes_observe(uint32_t address,size_t size,int writing)
{
    unsigned i,off,at;
    if(address<first_shape || address>=last_shape)return 0;
    uint32_t cell=address>>6;unsigned bucket=(cell*2654435761u)>>22;
    i=shape_count;
    for(int entry=shape_heads[bucket];entry>=0;entry=shape_next[entry])if(shape_cells[entry]==cell) {
        unsigned row=shape_rows[entry];
        if(shapes[row].hit && address>=shapes[row].view && address-shapes[row].view<0x40){i=row;break;}
    }
    if(i==shape_count)return 0;
    off=address-shapes[i].view;
    if(size>0x40-off)m3d_vm_fail("Unbound hit-shape field or victim history");
    for(at=off&~3u;at<off+size;at+=4) {
        uint32_t bits;
        void* field=(char*)&shapes[i].hit->state+at;
        if(writing) { bits=m3d_vm_read32(shapes[i].view+at); memcpy(field,&bits,4); }
        else { memcpy(&bits,field,4); m3d_vm_write32(shapes[i].view+at,bits); }
    }
    return 1;
}
