/* Versioned, bounded preferences shared by the native menus and launcher.
 * Retail ranges come from mnmainrule / mnruleplus / mnitemsw. Physics and
 * shared CPU difficulty are Big Melee extras, with retail physics at 100%. */
#ifndef M3D_SETTINGS_H
#define M3D_SETTINGS_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <stdlib.h>
#include <limits.h>
enum {
    BMR_MODE, BMR_ITEMS, BMR_MINUTES, BMR_HUMANS, BMR_STOCKS,
    BMR_HANDICAP, BMR_DAMAGE, BMR_STAGE, BMR_STOCK_MINUTES, BMR_FRIENDLY,
    BMR_PAUSE, BMR_SCORE, BMR_SD, BMR_CPU, BMR_GRAVITY, BMR_MOVE,
    BMR_SPEED, BMR_FIELDS
};
typedef struct { int v[BMR_FIELDS]; uint32_t items; int handicap[32]; } M3dSettings;
static const int bmr_low[]={0,0,0,2,1,0,5,0,0,0,0,0,0,1,25,50,50};
static const int bmr_high[]={6,5,99,32,99,2,20,4,99,1,1,1,2,9,150,200,150};
static const int bmr_default[]={1,3,5,2,3,0,10,0,0,0,1,0,1,9,100,100,100};
static const char* const bmr_modes[]={"hill","survival","coin","battle","time","stock","bonus"};
static const char* const bmr_items[]={"off","verylow","low","medium","high","veryhigh"};
static void bmr_defaults(M3dSettings* s) {
    memcpy(s->v,bmr_default,sizeof s->v);s->items=UINT32_MAX;
    for(int i=0;i<32;i++)s->handicap[i]=9;
}
static int bmr_valid(const M3dSettings* s) {
    for(int i=0;i<BMR_FIELDS;i++)if(s->v[i]<bmr_low[i]||s->v[i]>bmr_high[i])return 0;
    for(int i=0;i<32;i++)if(s->handicap[i]<1||s->handicap[i]>9)return 0;
    return 1;
}
static int bmr_number(char** p,unsigned long long max,unsigned* out) {
    while(isspace((unsigned char)**p))++*p;
    if(!isdigit((unsigned char)**p))return 0;
    char* end;errno=0;unsigned long long n=strtoull(*p,&end,10);
    if(errno||n>max||(*end&&!isspace((unsigned char)*end)))return 0;
    *out=(unsigned)n;*p=end;return 1;
}
static int bmr_read(FILE* f,M3dSettings* out) {
    M3dSettings s;char line[2048];bmr_defaults(&s);
    if(!fgets(line,sizeof line,f)||!strchr(line,'\n'))return 0;
    char* p=line;unsigned n;
    if(!strncmp(p,"BMR2",4)&&isspace((unsigned char)p[4])) {
        p+=4;
        for(int i=0;i<BMR_FIELDS;i++){if(!bmr_number(&p,INT_MAX,&n))return 0;s.v[i]=(int)n;}
        if(!bmr_number(&p,UINT32_MAX,&n))return 0;s.items=n;
        for(int i=0;i<32;i++){if(!bmr_number(&p,9,&n))return 0;s.handicap[i]=(int)n;}
    } else {
        /* Migrate the original four-index native-menu state. */
        unsigned a,b,c,d;
        if(!bmr_number(&p,3,&a)||!bmr_number(&p,3,&b)||!bmr_number(&p,4,&c)||!bmr_number(&p,32,&d)||d<2)return 0;
        s.v[BMR_MODE]=a;s.v[BMR_ITEMS]=(int[]){0,2,3,4}[b];s.v[BMR_MINUTES]=(int[]){2,3,5,10,15}[c];s.v[BMR_HUMANS]=d;
    }
    while(isspace((unsigned char)*p))p++;if(*p)return 0;
    int ch;
    while((ch=fgetc(f))!=EOF)if(ch!='\n'&&ch!='\r')return 0;
    if(!bmr_valid(&s))return 0;*out=s;return 1;
}
static void bmr_write(FILE* f,const M3dSettings* s) {
    fputs("BMR2",f);for(int i=0;i<BMR_FIELDS;i++)fprintf(f," %d",s->v[i]);
    fprintf(f," %u",s->items);for(int i=0;i<32;i++)fprintf(f," %d",s->handicap[i]);fputc('\n',f);
}
#endif
