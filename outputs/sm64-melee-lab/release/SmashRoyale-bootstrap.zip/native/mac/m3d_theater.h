/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef M3D_THEATER_H
#define M3D_THEATER_H
#ifdef __cplusplus
extern "C" {
#endif
int m3d_theater_viewing(void);
int m3d_theater_finished(void);
int m3d_theater_poll(void);
int m3d_theater_steps(int original);
void m3d_theater_capture(void);
unsigned m3d_TheaterVideoFrames(void);
int m3d_TheaterVideoState(void);
void m3d_TheaterVideoCapture(unsigned index);
void m3d_TheaterVideoBegin(void);
void m3d_theater_sync(void);
void m3d_theater_input(void* pad,int frame);
void m3d_theater_camera(void* camera);
void m3d_theater_toggle(void);
void m3d_theater_end(void);
void m3d_theater_scene_reset(void);
unsigned m3d_WorldChecksum(void);
#ifdef __cplusplus
}
#endif
#endif
