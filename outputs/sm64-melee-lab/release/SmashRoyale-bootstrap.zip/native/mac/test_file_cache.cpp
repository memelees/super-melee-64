/* Regression against the real engine cache: Windows heap pointers can overlap
 * the numeric range used for encoded ARAM destinations. No game data needed. */
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>
#include <dolphin/ar.h>
#include <dolphin/dvd.h>
#include <pc/file_cache.h>

static std::vector<uint8_t> aram;
extern "C" uint8_t* aurora_aram_base(void) {return aram.data();}
extern "C" void OSReport(const char*,...) {}
// No DVD I/O belongs in these host/ARAM cache-boundary checks.
extern "C" BOOL DVDOpen(const char*,DVDFileInfo*) {return FALSE;}
extern "C" BOOL DVDFastOpen(s32,DVDFileInfo*) {return FALSE;}
extern "C" s32 DVDReadPrio(DVDFileInfo*,void*,s32,s32,s32) {return -1;}
extern "C" BOOL DVDClose(DVDFileInfo*) {return FALSE;}
extern "C" BOOL DVDOpenDir(const char*,DVDDir*) {return FALSE;}
extern "C" BOOL DVDReadDir(DVDDir*,DVDDirEntry*) {return FALSE;}
extern "C" BOOL DVDCloseDir(DVDDir*) {return FALSE;}

int main() {
    auto* low=static_cast<uint8_t*>(VirtualAlloc(reinterpret_cast<void*>(0x06000000),4096,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));
    if(!low||reinterpret_cast<uintptr_t>(low)>=0x08000000u){std::fprintf(stderr,"Could not reserve low host address\n");return 2;}
    aram.resize(128u*1024*1024);
    const uint8_t expected[]={0,0,0,32,0x55,0xaa,0x12,0x34};
    std::memcpy(low,expected,sizeof expected);
#ifdef M3D_CACHE_NEGATIVE_CONTROL
    pc_file_cache_put("low-host.dat",low,sizeof expected);
#else
    pc_file_cache_put_host("low-host.dat",low,sizeof expected);
#endif
    // Cached bytes are read through the original encoded ARAM destination API.
    size_t length=0;
    bool host=pc_file_cache_get("low-host.dat",reinterpret_cast<void*>(0x1000),&length)
        &&length==sizeof expected&&!std::memcmp(aram.data()+0x1000,expected,sizeof expected);
    // The existing lbFile ARAM-source path must continue to work too.
    std::memcpy(aram.data()+0x2000,expected,sizeof expected);
    pc_file_cache_put("encoded-aram.dat",reinterpret_cast<void*>(0x2000),sizeof expected);
    bool encoded=pc_file_cache_get("encoded-aram.dat",reinterpret_cast<void*>(0x3000),&length)
        &&length==sizeof expected&&!std::memcmp(aram.data()+0x3000,expected,sizeof expected);
    VirtualFree(low,0,MEM_RELEASE);
    std::printf("M3D FILE CACHE host_low=%d encoded_aram=%d\n",host,encoded);
    return host&&encoded?0:1;
}
