/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "m3d_room.h"
#include "world/m3d.h"
#include <melee/gm/types.h>
#include <melee/pl/player.h>
#include <sysdolphin/baselib/controller.h>
#include <sysdolphin/baselib/gobj.h>
#include <assert.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

HSD_PadStatus HSD_PadGameStatus[32];
HSD_PadStatus HSD_PadMasterStatus[4];
s8 pc_pad_game_raw_x[32];
HSD_GObj** HSD_GObjPLinkHead;
static u32 seed;u32* HSD_RandSeedPtr=&seed;
static int step;
int m3d_room_enabled(void){return 1;}
int m3d_room_local(void){return 31;}
int m3d_room_humans(void){return 32;}
bool m3d_StageIs3D(void){return false;}
float m3d_CameraGetYaw(void){return 1;}
HSD_GObj* Player_GetEntity(s32 slot){(void)slot;return NULL;}
Gm_PKind Player_GetPlayerSlotType(s32 slot){(void)slot;return Gm_PKind_Human;}
s32 Player_GetStocks(int slot){(void)slot;return 3;}
bool m3d_GetLane(Fighter* fp,float* x,float* z){(void)fp;*x=1;*z=0;return true;}
void m3d_room_exchange(const uint8_t input[12],uint32_t checksum,uint8_t all[32*12],uint32_t* outseed){
    (void)input;(void)checksum;memset(all,0,32*12);*outseed=123;
    for(int i=0;i<32;i++){
        all[i*12]=step%2?0:1; /* A down/up edges on every seat. */
        all[i*12+2]=(uint8_t)(int8_t)(i-31);all[i*12+3]=127;
        all[i*12+4]=(uint8_t)(int8_t)-127;all[i*12+6]=255;
        all[i*12+8]=(uint8_t)(i*7);
    }
}
int main(void){
    setenv("MELEE3D_NATIVE_LAB","32",1);
    StartMeleeData start={0};m3d_RoomSetup(&start);
    for(int i=0;i<32;i++)assert(start.players[i].slot_type==Gm_PKind_Human&&start.players[i].slot==0);
    assert(m3d_RoomIsViewer(31)&&!m3d_RoomIsViewer(0));
    for(step=0;step<4;step++){
        m3d_RoomSync();m3d_RoomPads();assert(seed==123);
        for(int i=0;i<32;i++){
            HSD_PadStatus* p=&HSD_PadGameStatus[i];
            assert(p->err==0&&p->nml_stickY==1&&p->nml_subStickX==-1&&p->nml_analogL==1);
            assert(p->button==(step%2?0:HSD_PAD_A));
            assert(p->trigger==(step%2?0:HSD_PAD_A));
            assert(p->release==(step%2?HSD_PAD_A:0));
            assert(fabsf(p->nml_stickX-(i-31)/127.f)<.00001f);
            assert(fabsf(m3d_RoomInputYaw(i,99)-i*7*256*(6.28318530718f/65536))<.0001f);
        }
    }
    puts("M3D 32 LOGICAL PADS PASS");return 0;
}
