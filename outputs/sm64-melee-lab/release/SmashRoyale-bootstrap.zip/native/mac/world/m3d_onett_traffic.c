/* Original Onett car models/items/scripts on the source city road network. */
#include "m3d.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <melee/gr/ground.h>
#include <melee/gr/gronett.h>
#include <melee/it/item.h>
#include <melee/it/types.h>
#include <melee/gr/types.h>
#include <melee/lb/lb_00B0.h>
#include <sysdolphin/baselib/gobj.h>
#include <sysdolphin/baselib/jobj.h>
#include <sysdolphin/baselib/random.h>
#include "m3d_onett_traffic_math.h"
static M3dTrafficPath paths[2];
static HSD_GObj* city_traffic;
static bool creating,mapped;
static int delay,turn_owner[2]={-1,-1};
static Vec3 virtual_position[4];
static Vec3 virtual_rotation[4];
static float previous_progress[2];
static int previous_type[2]={-1,-1};
static unsigned traffic_seed;
static u32 traffic_random;static u32* saved_random;
static void traffic_fail(const char*why){fprintf(stderr,"M3D ONETT TRAFFIC FAIL %s\n",why);abort();}
static void paths_free(void){for(int i=0;i<2;i++){free(paths[i].points);free(paths[i].distance);memset(&paths[i],0,sizeof(paths[i]));}}
static bool paths_load(void){
 paths_free();const char*dir=getenv("MELEE3D_NATIVE_ONETT_OVERLAY");if(!dir)return false;char file[4096];if(snprintf(file,sizeof file,"%s/onett.trf",dir)>=(int)sizeof file)traffic_fail("path length");FILE*f=fopen(file,"rb");if(!f)return false;char magic[4];unsigned version,count;
 if(fread(magic,1,4,f)!=4||fread(&version,4,1,f)!=1||fread(&count,4,1,f)!=1||memcmp(magic,"OTR1",4)||version!=1||count!=2)traffic_fail("header");
 for(int j=0;j<2;j++){M3dTrafficPath*p=&paths[j];if(fread(&p->count,4,1,f)!=1||p->count<2||p->count>4096)traffic_fail("path count");p->points=calloc(p->count,sizeof(Vec3));p->distance=calloc(p->count,sizeof(float));if(!p->points||!p->distance||fread(p->points,sizeof(Vec3),p->count,f)!=p->count)traffic_fail("path allocation/data");
  for(unsigned i=0;i<p->count;i++){Vec3 a=p->points[i];if(!isfinite(a.x)||!isfinite(a.y)||!isfinite(a.z)||fabsf(a.x)>20000||fabsf(a.y)>20000||fabsf(a.z)>20000)traffic_fail("finite source point");if(i){Vec3 b=p->points[i-1];float length=sqrtf((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y)+(a.z-b.z)*(a.z-b.z));if(length<.001f)traffic_fail("degenerate segment");p->distance[i]=p->distance[i-1]+length;}}
  p->length=p->distance[p->count-1];
 }if(fgetc(f)!=EOF)traffic_fail("trailing data");fclose(f);return true;
}
void m3d_OnettTrafficInit(HSD_GObj*gobj){
 if(!m3d_ReferenceOverlayActive()){city_traffic=NULL;paths_free();return;}
 if(creating){city_traffic=gobj;Ground*gp=gobj->user_data;for(int i=0;i<4;i++){HSD_JObjGetTranslation(gp->u.onettcar.car_jobjs[i],&virtual_position[i]);virtual_rotation[i]=(Vec3){HSD_JObjGetRotationX(gp->u.onettcar.car_jobjs[i]),HSD_JObjGetRotationY(gp->u.onettcar.car_jobjs[i]),HSD_JObjGetRotationZ(gp->u.onettcar.car_jobjs[i])};}return;}
 city_traffic=NULL;mapped=false;turn_owner[0]=turn_owner[1]=-1;previous_type[0]=previous_type[1]=-1;
 if(!paths_load())return;
 const char*value=getenv("MELEE_SEED");traffic_seed=value?(unsigned)strtoul(value,NULL,10):1;delay=90+(int)((traffic_seed*1664525u+1013904223u)%180);
 traffic_random=traffic_seed^0x9e3779b9u;u32* prior_seed=HSD_RandSeedPtr;HSD_RandSeedPtr=&traffic_random;creating=true;HSD_GObj*clone=grOnett_801E37F4(3);creating=false;HSD_RandSeedPtr=prior_seed;if(!clone||city_traffic!=clone)traffic_fail("source traffic clone");
 /* The original constructor registers map3 globally; the independent clone
  * must not replace the original stage callback/model lookup identity. */
 stage_info.map_gobjs[3]=gobj;
 fprintf(stderr,"M3D ONETT TRAFFIC INIT seed=%u source_generators=2 original_models_per_generator=4 new_roads=west,north-cross,east delay=%d lengths=%.2f,%.2f\n",traffic_seed,delay,paths[0].length,paths[1].length);
}
/* Isolated opt-in contact diagnostic. Only reset source scheduler start/wait
 * fields; real car callbacks, scripts, movement and hit resolution still run. */
static int traffic_probe_last[2]={-1,-1};
static bool traffic_probe_selected(HSD_GObj* gobj)
{
    if(!getenv("MELEE3D_NATIVE_ONETT_CAR_PROBE"))return true;
    int phase=(m3d_match_frame-240)/150,which=gobj==city_traffic;
    Ground* gp=gobj->user_data;
    if(m3d_match_frame<240||phase>=16||phase/8!=which) {
        for(int i=0;i<4;i++) {
            HSD_JObjSetFlagsAll(gp->u.onettcar.car_jobjs[i],JOBJ_HIDDEN);
            Item* ip=gp->u.onettcar.car_items[i]->user_data;
            if(ip->msid)Item_80268E5C(gp->u.onettcar.car_items[i],0,ITEM_ANIM_UPDATE);
        }
        return false;
    }
    return true;
}
static void traffic_probe_prepare(HSD_GObj* gobj)
{
    if(!getenv("MELEE3D_NATIVE_ONETT_CAR_PROBE"))return;
    int phase=(m3d_match_frame-240)/150,which=gobj==city_traffic;
    Ground* gp=gobj->user_data;
    if(phase==traffic_probe_last[which]) {
        /* Native B1 installs its second 400-tick wait after computing speed.
         * Shorten only that diagnostic wait; B2 still unhides/starts the car. */
        if((phase%2)&&gp->u.onettcar.state_b==2)gp->u.onettcar.timer_b=0;
        return;
    }
    traffic_probe_last[which]=phase;
    int model=(phase%8)/2,reverse=phase%2,other=(model+1)%4;
    for(int i=0;i<4;i++) {
        HSD_JObj* root=gp->u.onettcar.car_jobjs[i];
        HSD_JObjSetFlagsAll(root,JOBJ_HIDDEN);
        Item_80268E5C(gp->u.onettcar.car_items[i],0,ITEM_ANIM_UPDATE);
    }
    gp->u.onettcar.curr_car=reverse?other:model;
    gp->u.onettcar.next_car=reverse?model:other;
    gp->u.onettcar.state_a=reverse?3:1;
    gp->u.onettcar.x108=reverse?32000:0;
    gp->u.onettcar.state_b=1;gp->u.onettcar.timer_b=reverse?0:32000;
    HSD_JObj* root=gp->u.onettcar.car_jobjs[model];
    Vec3 start={reverse?-(which?400.0f:200.0f):(which?400.0f:200.0f),0,reverse?56.0f:30.0f};
    HSD_JObjSetTranslate(root,&start);HSD_JObjSetRotationX(root,0);HSD_JObjSetRotationY(root,0);HSD_JObjSetRotationZ(root,0);
    HSD_JObjSetRotationY(HSD_JObjGetChild(root),reverse?3.141592654f:0);
    fprintf(stderr,"M3D CAR PROBE SOURCE phase=%d generator=%d model=%d reverse=%d native_scheduler=1\n",phase,which,model,reverse);
}
bool m3d_OnettTrafficBegin(HSD_GObj*gobj){
 if(!m3d_ReferenceOverlayActive())return true;
 if(!traffic_probe_selected(gobj))return false;
 if(gobj!=city_traffic){traffic_probe_prepare(gobj);return true;}
 if(getenv("MELEE3D_NATIVE_ONETT_CAR_PROBE"))delay=0;
 if(delay>0){delay--;return false;}
 if(saved_random)traffic_fail("nested source random scope");saved_random=HSD_RandSeedPtr;HSD_RandSeedPtr=&traffic_random;
 if(mapped){Ground*gp=gobj->user_data;for(int i=0;i<4;i++){HSD_JObjSetTranslate(gp->u.onettcar.car_jobjs[i],&virtual_position[i]);HSD_JObjSetRotationX(gp->u.onettcar.car_jobjs[i],virtual_rotation[i].x);HSD_JObjSetRotationY(gp->u.onettcar.car_jobjs[i],virtual_rotation[i].y);HSD_JObjSetRotationZ(gp->u.onettcar.car_jobjs[i],virtual_rotation[i].z);}mapped=false;}traffic_probe_prepare(gobj);return true;
}
float m3d_OnettTrafficEdge(void*ground,float original){if(!m3d_ReferenceOverlayActive()||!city_traffic||city_traffic->user_data!=ground)return original;return m3d_traffic_virtual_edge(original,paths[original<0?0:1].length,Ground_801C0498());}
static int path_turn(Vec3 p){if(hypotf(p.x+130.5f,p.z+337.5f)<120)return 0;if(hypotf(p.x-292.5f,p.z+337.5f)<120)return 1;return-1;}
/* The original background/reverse lane uses motion0, deliberately harmless
 * to fighters on the 2D plane. In the 3D town both actual road lanes are
 * playable: arm the same model's existing native car script when visible. */
static void traffic_arm_reverse(Ground* gp)
{
    int model=gp->u.onettcar.next_car;
    if(model<0||model>=4||gp->u.onettcar.state_b!=5)return;
    HSD_JObj* root=gp->u.onettcar.car_jobjs[model];
    HSD_GObj* object=gp->u.onettcar.car_items[model];
    if(!root||!object||(root->flags&JOBJ_HIDDEN))return;
    Item* ip=object->user_data;
    if(ip->msid!=model+2)Item_80268E5C(object,model+2,ITEM_ANIM_UPDATE);
}
void m3d_OnettTrafficEnd(HSD_GObj*gobj){
 if(!m3d_ReferenceOverlayActive())return;
 if(gobj!=city_traffic){Ground* original=gobj->user_data;if(original&&original->map_id==3)traffic_arm_reverse(original);return;}
 if(delay>0)return;if(saved_random){HSD_RandSeedPtr=saved_random;saved_random=NULL;}Ground*gp=gobj->user_data;float scale=Ground_801C0498();if(scale<.001f)traffic_fail("source ground scale");
 Vec3 prior_position[4];memcpy(prior_position,virtual_position,sizeof prior_position);
 for(int i=0;i<4;i++){HSD_JObjGetTranslation(gp->u.onettcar.car_jobjs[i],&virtual_position[i]);virtual_rotation[i]=(Vec3){HSD_JObjGetRotationX(gp->u.onettcar.car_jobjs[i]),HSD_JObjGetRotationY(gp->u.onettcar.car_jobjs[i]),HSD_JObjGetRotationZ(gp->u.onettcar.car_jobjs[i])};}
 /* These are measured centers in each original model child's local geometry,
  * not replacement meshes. Native child animation/steering remains intact. */
 const float center_x[4]={1.75f,-1.25f,2.0f,-.25f};
 const float center_z[4]={.125f,.125f,.125f,-.125f};
 int types[2]={gp->u.onettcar.curr_car,gp->u.onettcar.next_car};Vec3 wanted[2],directions[2];float progress[2];bool live[2]={false,false};
 for(int path=0;path<2;path++){int i=types[path];if(i<0||i>=4)continue;HSD_JObj*root=gp->u.onettcar.car_jobjs[i];if(root->flags&JOBJ_HIDDEN)continue;Vec3 local={center_x[i],0,center_z[i]},center;lb_8000B1CC(HSD_JObjGetChild(root),&local,&center);progress[path]=m3d_traffic_progress(center.x,path==1,scale);if(!m3d_traffic_sample(&paths[path],progress[path],&wanted[path],&directions[path]))traffic_fail("source arc sample");live[path]=true;}
 /* A bus uses the opposite lane slightly while turning on source36u roads.
  * Give one source vehicle ownership of each narrow intersection at a time. */
 for(int turn=0;turn<2;turn++){int owner=turn_owner[turn];if(owner>=0&&(!live[owner]||path_turn(wanted[owner])!=turn))turn_owner[turn]=-1;for(int path=0;path<2;path++)if(live[path]&&path_turn(wanted[path])==turn&&turn_owner[turn]<0)turn_owner[turn]=path;}
 for(int path=0;path<2;path++){int i=types[path];if(!live[path])continue;HSD_JObj*root=gp->u.onettcar.car_jobjs[i];int turn=path_turn(wanted[path]);bool yielding=turn>=0&&turn_owner[turn]!=path&&previous_type[path]==i;
  if(yielding){HSD_JObjSetTranslateX(root,prior_position[i].x);progress[path]=previous_progress[path];if(!m3d_traffic_sample(&paths[path],progress[path],&wanted[path],&directions[path]))traffic_fail("yield source sample");}
  HSD_JObjGetTranslation(root,&virtual_position[i]);virtual_rotation[i]=(Vec3){HSD_JObjGetRotationX(root),HSD_JObjGetRotationY(root),HSD_JObjGetRotationZ(root)};
  Vec3 local={center_x[i],0,center_z[i]},center,origin;lb_8000B1CC(HSD_JObjGetChild(root),&local,&center);lb_8000B1CC(root,NULL,&origin);
  Vec3 placed,rotation;m3d_traffic_pose(origin,center,wanted[path],directions[path],path?1:-1,&placed,&rotation);placed.x/=scale;placed.y/=scale;placed.z/=scale;
  HSD_JObjSetTranslate(root,&placed);HSD_JObjSetRotationX(root,rotation.x);HSD_JObjSetRotationY(root,rotation.y);HSD_JObjSetRotationZ(root,rotation.z);
  if(previous_type[path]!=i)fprintf(stderr,"M3D ONETT TRAFFIC CAR path=%d model=%d seed=%u source_item=1\n",path,i,traffic_seed);
  previous_type[path]=i;previous_progress[path]=progress[path];
  if(m3d_match_frame%120==0)fprintf(stderr,"M3D ONETT TRAFFIC FRAME tick=%d path=%d model=%d progress=%.2f pos=%.2f,%.2f,%.2f yielding=%d\n",m3d_match_frame,path,i,progress[path],wanted[path].x,wanted[path].y,wanted[path].z,yielding);
 }
 /* Inactive source roots stay hidden; retain their native virtual transforms. */
 for(int i=0;i<4;i++)if(i!=types[0]&&i!=types[1]){HSD_JObjGetTranslation(gp->u.onettcar.car_jobjs[i],&virtual_position[i]);virtual_rotation[i]=(Vec3){HSD_JObjGetRotationX(gp->u.onettcar.car_jobjs[i]),HSD_JObjGetRotationY(gp->u.onettcar.car_jobjs[i]),HSD_JObjGetRotationZ(gp->u.onettcar.car_jobjs[i])};}
 traffic_arm_reverse(gp);
 mapped=true;
}
