#include "pc/m3d_room.h"
/* Native source port of the shared melee3d overlay; first stage gate: FD. */
/// melee3d: third-person orbit camera.
///
/// The vanilla camera keeps running underneath (its framing still drives
/// off-screen bubbles, culling decisions, etc.); we only replace what the
/// main CObj renders with while the game camera is in CAMERA_STANDARD.

#include "m3d.h"
#include <pc/m3d_menu.h>
#include <pc/m3d_lab.h>
#include <pc/m3d_photo.h>
#include <pc/m3d_pause.h>
#include <pc/m3d_theater.h>

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <melee/ft/inlines.h>
#include <melee/cm/types.h>
#include <melee/ft/types.h>
#include <melee/ft/kinds/ftCommon/forward.h>
#include <melee/gm/forward.h>
#include <melee/gm/gm_1A3F.h>
#include <melee/gr/forward.h>
#include <melee/pl/forward.h>
#include <melee/pl/player.h>
#include <sysdolphin/baselib/cobj.h>
#include <sysdolphin/baselib/controller.h>
#include <sysdolphin/baselib/gobj.h>

#define M3D_DEG (3.14159265f / 180.0f)

/* Selection is separate from the native stage ID: original stages and their
 * 3D variants share archives, but never implicitly enable one another. */
static int m3d_selected_stage = -1;
static bool m3d_selected_3d;
static int m3d_selected_arena;
static bool m3d_stage_active;
static bool large_fd;
bool m3d_LargeFDActive(void){return large_fd;}

bool m3d_StageMenuSupported(void)
{
    int mode = gm_GetCurrentGameMode();
    return m3d_cfg.mode3d && (mode == GM_VS || mode == GM_STAMINA_VS);
}

bool m3d_StageHas3D(int stkind)
{
    /* Add entries only after their collision and visuals support depth. */
    /* Plaza owns its imported collision; it must not depend on optional
     * legacy-stage reference tables being present in a release build. */
    return stkind==32||m3d_ReferenceSupported(stkind);
}

int m3d_StageSelect(int stkind, bool three_d)
{
    m3d_selected_3d = three_d && m3d_StageHas3D(stkind);
    m3d_selected_arena = m3d_selected_3d ? m3d_ArenaKey(stkind) : 0;
    /* Custom catalogue keys resolve to an archive with native spawn/camera
     * metadata. The selected variant survives results/rematches separately. */
    m3d_selected_stage = m3d_selected_arena ? St_Kind_Last : stkind;
    return m3d_selected_stage;
}

void m3d_StageActivate(int stkind)
{
    m3d_NativeConfigure();
    m3d_stage_active = m3d_cfg.mode3d && m3d_StageHas3D(stkind) &&
        (m3d_cfg.boot_match ||
         (m3d_StageMenuSupported() && m3d_selected_3d &&
          m3d_selected_stage == stkind));
    large_fd=m3d_stage_active&&stkind==32&&m3d_MenuLargeFD();
    m3d_DelfinoSelect(m3d_stage_active && stkind==32&&!large_fd);
    m3d_ReferenceSelect(m3d_stage_active && !m3d_DelfinoActive() ? stkind : -1);
    m3d_ArenaLoad(m3d_stage_active && stkind == St_Kind_Last ?
                  (m3d_cfg.boot_match ? m3d_cfg.arena : m3d_selected_arena) : 0);
}

bool m3d_StageIs3D(void)
{
    return m3d_cfg.mode3d && m3d_stage_active;
}

void m3d_StageDeactivate(void)
{
    m3d_DelfinoSelect(false);
    m3d_stage_active=false;large_fd=false;
    m3d_ReferenceSelect(-1);
    m3d_FightersReset();m3d_ItemsReset();m3d_CpusReset();
    m3d_ArenaLoad(0);
}

/* Tunables. Distances are in Melee world units. */
static float m3d_cam_dist = 95.0f;
static float const m3d_cam_height = 9.0f;
static float const m3d_cam_fov = 60.0f;
static float const m3d_cam_start_pitch = 12.0f * M3D_DEG;
static float const m3d_cam_yaw_speed = 2.5f * M3D_DEG;
static float const m3d_cam_pitch_speed = 1.5f * M3D_DEG;
static float const m3d_cam_pitch_min = -10.0f * M3D_DEG;
static float const m3d_cam_pitch_max = 70.0f * M3D_DEG;
static float const m3d_cam_follow = 0.25f;
static float const m3d_cam_follow_y = 0.15f;
static float const m3d_cam_deadzone = 0.15f;
static float const m3d_cam_invert_x = 1.0f; /* -1 to flip */
static float const m3d_cam_invert_y = 1.0f; /* -1 to flip */

static struct {
    int spectator_slot;
    unsigned spectator_buttons;
    int mode;         ///< 0 orbit, 1 shared Smash view, 2 nearby-combat orbit
    bool initialized; ///< yaw seeded from the vanilla camera
    bool have_target;
    bool snap_armed;
    float yaw;   ///< radians around +Y; eye sits at target + (sin, _, cos)
    float pitch; ///< radians; positive = camera above the target
    float combat_dist,render_yaw;int fit_frame;
    Vec3 target; ///< smoothed look-at point
} m3d_cam;

static Fighter* m3d_SpectatorFighter(int slot)
{
    if(slot<0||slot>=GM_MAX_PLAYERS||Player_GetPlayerSlotType(slot)==Gm_PKind_NA)return NULL;
    HSD_GObj* gobj=Player_GetEntity(slot);
    if(!gobj||GET_FIGHTER(gobj)->is_sleeping||m3d_PartyEliminated(slot))return NULL;
    return GET_FIGHTER(gobj);
}

static Fighter* m3d_LiveViewer(void)
{
    for(int slot=0;slot<GM_MAX_PLAYERS;slot++)
        if(Player_GetPlayerSlotType(slot)==Gm_PKind_Human&&m3d_RoomIsViewer(slot)) {
            Fighter* fp=m3d_SpectatorFighter(slot);
            if(fp)return fp;
        }
    return NULL;
}

bool m3d_CameraSpectating(void)
{
    if(m3d_LiveViewer())return false;
    for(int slot=0;slot<GM_MAX_PLAYERS;slot++)
        if(Player_GetPlayerSlotType(slot)==Gm_PKind_Human&&m3d_RoomIsViewer(slot))return true;
    return false;
}

static Fighter* m3d_SelectSpectator(int slot)
{
    Fighter* fp=m3d_SpectatorFighter(slot);
    if(fp&&slot!=m3d_cam.spectator_slot) {
        m3d_cam.spectator_slot=slot;
        /* A subject may be on the other side of the city: reframe directly,
         * without sweeping the camera through buildings between fighters. */
        m3d_cam.have_target=false;
        m3d_cam.fit_frame=-1;
        m3d_cam.combat_dist=130;
        fprintf(stderr,"M3D SPECTATOR TARGET slot=%d kind=%d tick=%d\n",slot,fp->kind,m3d_match_frame);
    }
    return fp;
}

static Fighter* m3d_FindPlayerFighter(void)
{
    Fighter* fp=m3d_LiveViewer();
    if(fp)return fp;
    /* Keep the chosen survivor until eliminated. Repeated render queries
     * must not choose a different temporary active object. */
    fp=m3d_SpectatorFighter(m3d_cam.spectator_slot);
    if(fp)return fp;
    for(int slot=0;slot<GM_MAX_PLAYERS;slot++) {
        fp=m3d_SelectSpectator(slot);
        if(fp)return fp;
    }
    return NULL;
}

static Fighter* m3d_CycleSpectator(int direction)
{
    for(int offset=1;offset<=GM_MAX_PLAYERS;offset++) {
        int slot=(m3d_cam.spectator_slot+direction*offset+GM_MAX_PLAYERS)%GM_MAX_PLAYERS;
        Fighter* fp=m3d_SelectSpectator(slot);
        if(fp)return fp;
    }
    return NULL;
}

static Fighter* m3d_SpectatorInput(HSD_PadStatus* pad)
{
    unsigned buttons=pad->button&(HSD_PAD_DPADLEFT|HSD_PAD_DPADRIGHT);
    unsigned pressed=buttons&~m3d_cam.spectator_buttons;
    m3d_cam.spectator_buttons=buttons;
    if(m3d_CameraSpectating()&&(pressed==HSD_PAD_DPADLEFT||pressed==HSD_PAD_DPADRIGHT))
        return m3d_CycleSpectator(pressed==HSD_PAD_DPADRIGHT?1:-1);
    return NULL;
}

Fighter* m3d_CameraSubject(void) {return m3d_FindPlayerFighter();}

static float m3d_Deadzone(float v)
{
    if (v > m3d_cam_deadzone || v < -m3d_cam_deadzone) {
        return v;
    }
    return 0.0f;
}

int m3d_match_frame;
int m3d_camera_frame;
static struct {bool active;int request;Vec3 eye;float yaw,pitch,fov;} pause_camera={.request=-1};

int m3d_PauseAvailable(void)
{
    if(!m3d_StageIs3D()||m3d_room_enabled())return 0;
    int humans=0;
    for(int i=0;i<GM_MAX_PLAYERS;i++)humans+=Player_GetPlayerSlotType(i)==Gm_PKind_Human;
    return humans==1;
}
int m3d_PauseRequest(void)
{
    if(m3d_theater_viewing()){m3d_theater_toggle();return 1;}
    if(!m3d_PauseAvailable())return 0;
    for(int i=0;i<GM_MAX_PLAYERS;i++)if(Player_GetPlayerSlotType(i)==Gm_PKind_Human){pause_camera.request=Player_GetPadPort(i);return 1;}
    return 0;
}
int m3d_PauseRequested(void){return m3d_PauseAvailable()?pause_camera.request:-1;}
void m3d_PauseAccept(void){pause_camera.request=-1;}

int m3d_PauseApply(void* pointer)
{
    if(!pause_camera.active)return 0;
    HSD_CObj* cobj=pointer;
    float cp=cosf(pause_camera.pitch);
    Vec3 aim={pause_camera.eye.x-sinf(pause_camera.yaw)*cp*100,
              pause_camera.eye.y-sinf(pause_camera.pitch)*100,
              pause_camera.eye.z-cosf(pause_camera.yaw)*cp*100};
    HSD_CObjSetEyePosition(cobj,&pause_camera.eye);HSD_CObjSetInterest(cobj,&aim);HSD_CObjSetFov(cobj,pause_camera.fov);
    HSD_CObjSetNear(cobj,1);HSD_CObjSetFar(cobj,16384);return 1;
}

int m3d_PauseUpdate(void* pointer,int paused,int port)
{
    m3d_camera_frame++;
    if(m3d_theater_viewing())return 0;
    if(!paused||!m3d_PauseAvailable()){pause_camera.active=false;return 0;}
    if(port<0||port>=4)port=0;
    return m3d_FreeCameraUpdate(pointer,&HSD_PadCopyStatus[port]);
}
int m3d_FreeCameraUpdate(void* pointer,const void* input)
{
    HSD_CObj* cobj=pointer;
    if(!pause_camera.active){
        Vec3 aim;HSD_CObjGetEyePosition(cobj,&pause_camera.eye);HSD_CObjGetInterest(cobj,&aim);pause_camera.fov=HSD_CObjGetFov(cobj);
        Vec3 d={pause_camera.eye.x-aim.x,pause_camera.eye.y-aim.y,pause_camera.eye.z-aim.z};
        pause_camera.yaw=atan2f(d.x,d.z);pause_camera.pitch=atan2f(d.y,hypotf(d.x,d.z));pause_camera.active=true;
        fprintf(stderr,"M3D PAUSE CAMERA begin eye=%.2f,%.2f,%.2f\n",pause_camera.eye.x,pause_camera.eye.y,pause_camera.eye.z);
    }
    const HSD_PadStatus* pad=input;
    pause_camera.yaw-=m3d_Deadzone(pad->nml_subStickX)*.035f;
    pause_camera.pitch-=m3d_Deadzone(pad->nml_subStickY)*.03f;
    pause_camera.pitch=fmaxf(-85*M3D_DEG,fminf(85*M3D_DEG,pause_camera.pitch));
    float side=m3d_Deadzone(pad->nml_stickX),forward=m3d_Deadzone(pad->nml_stickY),speed=pad->button&HSD_PAD_X?12:4;
    float cy=cosf(pause_camera.yaw),sy=sinf(pause_camera.yaw);
    pause_camera.eye.x+=(side*cy-forward*sy)*speed;
    pause_camera.eye.z+=(-side*sy-forward*cy)*speed;
    float up=fmaxf(pad->nml_analogR,(pad->button&HSD_PAD_R)?1:0),down=fmaxf(pad->nml_analogL,(pad->button&HSD_PAD_L)?1:0);
    pause_camera.eye.y+=(up-down)*speed;
    if(pad->trigger&HSD_PAD_Z){
        Fighter* fp=m3d_CameraSubject();
        if(fp){float p=38*M3D_DEG,yaw=m3d_CameraGetYaw();pause_camera.yaw=yaw;pause_camera.pitch=p;
            pause_camera.eye=(Vec3){fp->cur_pos.x+sinf(yaw)*cosf(p)*130,fp->cur_pos.y+9+sinf(p)*130,fp->cur_pos.z+cosf(yaw)*cosf(p)*130};}
    }
    m3d_PauseApply(cobj);return 1;
}

void m3d_MatchReset(void)
{
    pause_camera.active=false;pause_camera.request=-1;
    m3d_theater_scene_reset();
    m3d_FightersReset();
    m3d_ItemsReset();
    m3d_CpusReset();
    m3d_cam.initialized = false;
    m3d_cam.have_target = false;
    m3d_cam.spectator_slot = -1;
    m3d_cam.spectator_buttons = 0;
    m3d_cam.snap_armed = true;
    m3d_cam.yaw = 0.0f;
    m3d_cam.pitch = m3d_cam_start_pitch;
    m3d_cam_dist = 95.0f;
    m3d_match_frame = 0;
}

int m3d_CameraGetMode(void)
{
    return m3d_cam.mode;
}

void m3d_CameraSetMode(int mode)
{
    m3d_cam.mode = (m3d_DelfinoActive()||m3d_ReferenceOverlayActive())?2:mode>=0&&mode<=2?mode:0;
    m3d_cam.snap_armed=false;
    m3d_cam.combat_dist=130;m3d_cam.fit_frame=-1;
    m3d_cam.initialized = false;
    m3d_cam.have_target = false;
}

float m3d_CameraGetYaw(void)
{
    return m3d_cam.mode==1 ? 0:m3d_cam.mode==2?m3d_cam.render_yaw:m3d_cam.yaw;
}
bool m3d_CameraOwnsCStick(void) { return m3d_CameraIsActive() && m3d_cam.mode!=1 && !m3d_MoveControls(m3d_FindPlayerFighter()); }

float m3d_CameraGetPitch(void)
{
    return m3d_cam.pitch;
}

void m3d_CameraSetDist(float dist)
{
    m3d_cam_dist = dist;
}

void m3d_CameraSetPitch(float pitch)
{
    m3d_cam.pitch = pitch;
    m3d_cam.initialized = true;
}

static float m3d_CardinalYaw(float yaw)
{
    const float quarter=90*M3D_DEG;
    return roundf(yaw/quarter)*quarter;
}

void m3d_CameraRebirth(Fighter* fp)
{
    if(!m3d_cam.initialized||Player_GetPlayerSlotType(fp->player_idx)!=Gm_PKind_Human||!m3d_RoomIsViewer(fp->player_idx))return;
    m3d_cam.yaw=m3d_cam.render_yaw=m3d_CardinalYaw(m3d_cam.yaw);
    m3d_cam.have_target=false;
    m3d_cam.fit_frame=-1;
    m3d_cam.combat_dist=130;
    if(getenv("MELEE3D_NATIVE_SPAWN_CHECK"))fprintf(stderr,"M3D REBIRTH CAMERA slot=%u yaw=%.6f\n",fp->player_idx,m3d_cam.yaw);
}

void m3d_CameraSetYaw(float yaw)
{
    m3d_cam.yaw = m3d_cam.render_yaw = yaw;
    m3d_cam.initialized = true;
}

bool m3d_CameraIsActive(void)
{
    return m3d_StageIs3D() && m3d_cam.have_target;
}

static bool combat_subject(Fighter* fp,Fighter* player) {
    if(fp==player)return true;
    return !fp->is_sleeping&&fp->motion_id>=14&&hypotf(fp->cur_pos.x-player->cur_pos.x,fp->cur_pos.z-player->cur_pos.z)<120&&
        fabsf(fp->cur_pos.y-player->cur_pos.y)<80&&m3d_DelfinoVisible(&player->cur_pos,&fp->cur_pos);
}

void m3d_CameraUpdate(bool standard_mode)
{
    Fighter* fp;
    HSD_PadStatus* pad;
    Vec3 goal;
    float scale;

    m3d_match_frame++;
    m3d_LogFrame();

    if (!m3d_StageIs3D() || !standard_mode) {
        m3d_cam.have_target = false;
        return;
    }
    fp = m3d_FindPlayerFighter();
    if (fp == NULL) {
        m3d_cam.have_target = false;
        return;
    }

    m3d_lab_pad();
    /* A followed CPU may carry a virtual/sentinel pad port. Camera input
     * always belongs to the human viewer, including after their elimination. */
    int camera_port=0;
    for(int i=0;i<GM_MAX_PLAYERS;i++)if(Player_GetPlayerSlotType(i)==Gm_PKind_Human&&m3d_RoomIsViewer(i)){camera_port=m3d_room_enabled()?i:Player_GetPadPort(i);break;}
    if(camera_port<0||camera_port>=(m3d_room_enabled()?32:4))camera_port=0;
    pad = &HSD_PadGameStatus[camera_port];
    if(m3d_DelfinoActive()||m3d_ReferenceOverlayActive())m3d_cam.mode=2;
    bool spectating=m3d_CameraSpectating();
    Fighter* selected=m3d_SpectatorInput(pad);
    if(selected)fp=selected;
    if (!spectating && !m3d_DelfinoActive() && !m3d_ReferenceOverlayActive() && (pad->trigger & HSD_PAD_DPADLEFT)) {
        m3d_CameraSetMode((m3d_cam.mode+1)%3);
    }
    if (m3d_cam.mode == 1) {
        m3d_cam.have_target = true;
        return;
    }

    /* Throttle lends the right stick to the move, freezing the orbit. */
    bool move_controls=Player_GetPlayerSlotType(fp->player_idx)==Gm_PKind_Human && m3d_MoveControls(fp);
    float look_x=move_controls ? 0:pad->nml_subStickX;
    float look_y=move_controls ? 0:pad->nml_subStickY;
    const char* turning=getenv("MELEE3D_NATIVE_CAMERA_TURN");
    bool snap=turning&&!strcmp(turning,"snap");
    /* Re-arm only on a genuinely centred stick, including while a recovery
     * move borrows it. Releasing that move with a held stick cannot turn us. */
    if(fabsf(pad->nml_subStickX)<.25f&&fabsf(pad->nml_subStickY)<.25f)m3d_cam.snap_armed=true;
    else if(move_controls)m3d_cam.snap_armed=false;
    if(snap) {
        if(!move_controls&&m3d_cam.snap_armed&&fabsf(look_x)>=.65f&&fabsf(look_x)>=fabsf(look_y)) {
            m3d_cam.yaw-=(look_x>0?1:-1)*90*M3D_DEG;
            m3d_cam.snap_armed=false;
            if(getenv("MELEE3D_NATIVE_DELFINO_PROBE"))fprintf(stderr,"M3D CAMERA TURN yaw=%.6f\n",m3d_cam.yaw);
        }
    } else {
        if(m3d_cam.mode==2&&fabsf(look_x)>m3d_cam_deadzone)m3d_cam.yaw=m3d_cam.render_yaw;
        m3d_cam.yaw-=m3d_Deadzone(look_x)*m3d_cam_yaw_speed*m3d_cam_invert_x;
    }
    /* Vertical look remains available in both turn modes. */
    m3d_cam.pitch -= m3d_Deadzone(look_y) * m3d_cam_pitch_speed *
                     m3d_cam_invert_y;
    if (m3d_cam.pitch < m3d_cam_pitch_min) {
        m3d_cam.pitch = m3d_cam_pitch_min;
    }
    if (m3d_cam.pitch > m3d_cam_pitch_max) {
        m3d_cam.pitch = m3d_cam_pitch_max;
    }

    scale = fp->x34_scale.y;
    goal.x = fp->cur_pos.x;
    goal.y = fp->cur_pos.y + m3d_cam_height * scale;
    goal.z = fp->cur_pos.z;
    if(m3d_cam.mode==2) {
        Vec3 sum={0};float weight=0;
        for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];g;g=g->next){Fighter* other=GET_FIGHTER(g);
            if(other==fp||!combat_subject(other,fp))continue;
            float w=1-hypotf(other->cur_pos.x-fp->cur_pos.x,other->cur_pos.z-fp->cur_pos.z)/150;
            sum.x+=other->cur_pos.x*w;sum.y+=(other->cur_pos.y+9*other->x34_scale.y)*w;sum.z+=other->cur_pos.z*w;weight+=w;}
        if(weight>0){float blend=fminf(.35f,weight*.15f);goal.x+=(sum.x/weight-goal.x)*blend;goal.y+=(sum.y/weight-goal.y)*blend;goal.z+=(sum.z/weight-goal.z)*blend;}
    }
    if (!m3d_cam.have_target) {
        m3d_cam.target = goal;
        m3d_cam.have_target = true;
    } else {
        m3d_cam.target.x += (goal.x - m3d_cam.target.x) * m3d_cam_follow;
        m3d_cam.target.y += (goal.y - m3d_cam.target.y) * m3d_cam_follow_y;
        m3d_cam.target.z += (goal.z - m3d_cam.target.z) * m3d_cam_follow;
    }
}

static bool m3d_CameraFrames(Fighter* fp)
{
    CmSubject* box = fp->x890_cameraBox;
    return !fp->is_sleeping && box != NULL && !box->force_inactive &&
        (box->state == CmSubjectState_Active ||
         (box->state == CmSubjectState_Auto && box->was_framed));
}

/* Retain native framing, angle and FOV, then include depth in perspective
 * fitting. Only the rendered camera changes; native match rules stay live. */
static bool m3d_ApplySmashCamera(HSD_CObj* cobj)
{
    HSD_GObj* gobj;
    Vec3 eye, interest, direction, right, up;
    float native_dist, horiz, fov, aspect, tv, th, dist;
    float min_z = 1.0e20f, max_z = -1.0e20f;
    HSD_CObjGetEyePosition(cobj, &eye);
    HSD_CObjGetInterest(cobj, &interest);
    direction.x = eye.x - interest.x;
    direction.y = eye.y - interest.y;
    direction.z = eye.z - interest.z;
    native_dist = sqrtf(direction.x * direction.x +
                        direction.y * direction.y +
                        direction.z * direction.z);
    if (native_dist < 1.0f) return false;
    direction.x /= native_dist;
    direction.y /= native_dist;
    direction.z /= native_dist;
    horiz = sqrtf(direction.x * direction.x + direction.z * direction.z);
    if (horiz < 0.01f) return false;
    m3d_cam.yaw = atan2f(direction.x, direction.z);
    m3d_cam.pitch = atan2f(direction.y, horiz);
    right.x = direction.z / horiz;
    right.y = 0.0f;
    right.z = -direction.x / horiz;
    /* up = direction cross right */
    up.x = direction.y * right.z;
    up.y = horiz;
    up.z = -direction.y * right.x;
    for (gobj = HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER]; gobj != NULL;
         gobj = gobj->next)
    {
        Fighter* fp = GET_FIGHTER(gobj);
        if (!m3d_CameraFrames(fp)) continue;
        if (fp->cur_pos.z < min_z) min_z = fp->cur_pos.z;
        if (fp->cur_pos.z > max_z) max_z = fp->cur_pos.z;
    }
    if (min_z <= max_z) interest.z = (min_z + max_z) * 0.5f;
    fov = HSD_CObjGetFov(cobj);
    aspect = HSD_CObjGetAspect(cobj);
    tv = tanf(fov * M3D_DEG * 0.5f);
    if (tv < 0.05f || aspect < 0.1f) return false;
    th = tv * aspect;
    dist = native_dist > 140.0f ? native_dist : 140.0f;
    for (gobj = HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER]; gobj != NULL;
         gobj = gobj->next)
    {
        Fighter* fp = GET_FIGHTER(gobj);
        float dx, dy, dz, side, vertical, depth, needed;
        if (!m3d_CameraFrames(fp)) continue;
        dx = fp->cur_pos.x - interest.x;
        dy = fp->cur_pos.y + 9.0f * fp->x34_scale.y - interest.y;
        dz = fp->cur_pos.z - interest.z;
        side = fabsf(dx * right.x + dz * right.z) + 14.0f;
        vertical = fabsf(dx * up.x + dy * up.y + dz * up.z) + 18.0f;
        depth = dx * direction.x + dy * direction.y + dz * direction.z;
        needed = depth + side / th;
        if (needed > dist) dist = needed;
        needed = depth + vertical / tv;
        if (needed > dist) dist = needed;
    }
    eye.x = interest.x + direction.x * dist;
    eye.y = interest.y + direction.y * dist;
    eye.z = interest.z + direction.z * dist;
    HSD_CObjSetInterest(cobj, &interest);
    HSD_CObjSetEyePosition(cobj, &eye);
    HSD_CObjSetNear(cobj, 1.0f);
    HSD_CObjSetFar(cobj, 16384.0f);
    return true;
}

/* Perspective fit around the human and nearby visible fighters. The player
 * remains the anchor; distant fights never pull the camera across the Plaza. */
static float combat_fit(Vec3 focus,float yaw,float pitch,float aspect,Fighter* player) {
    Vec3 d={sinf(yaw)*cosf(pitch),sinf(pitch),cosf(yaw)*cosf(pitch)};
    Vec3 right={cosf(yaw),0,-sinf(yaw)},up={-sinf(yaw)*sinf(pitch),cosf(pitch),-cosf(yaw)*sinf(pitch)};
    float tv=tanf(65*M3D_DEG*.5f)*.82f,th=tv*aspect,needed=130;
    for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];g;g=g->next){Fighter* fp=GET_FIGHTER(g);if(!combat_subject(fp,player))continue;
        Vec3 p={fp->cur_pos.x-focus.x,fp->cur_pos.y+9*fp->x34_scale.y-focus.y,fp->cur_pos.z-focus.z};
        float depth=p.x*d.x+p.y*d.y+p.z*d.z;
        needed=fmaxf(needed,depth+(fabsf(p.x*right.x+p.z*right.z)+12)/th);
        needed=fmaxf(needed,depth+(fabsf(p.x*up.x+p.y*up.y+p.z*up.z)+18)/tv);
    }return needed;
}
static float combat_body_top(Fighter* player) {
    /* A fixed model-height marker can sit above a crouched/jumping fighter's
     * native ceiling body and demand a camera ray through the roof. */
    float top=player->coll_data.ecb.top.y;
    return isfinite(top)&&top>1?fminf(9*player->x34_scale.y,fmaxf(1,top-.5f)):9*player->x34_scale.y;
}
static bool combat_player_visible(Vec3* eye,Fighter* player) {
    if(m3d_DelfinoCameraFade())return true;
    float top=combat_body_top(player);Vec3 point=player->cur_pos;
    point.y+=fminf(4*player->x34_scale.y,top*.5f);
    if(!m3d_DelfinoViewClear(eye,&point))return false;
    point.y=player->cur_pos.y+top;return m3d_DelfinoViewClear(eye,&point);
}
static bool apply_combat_camera(HSD_CObj* cobj,Vec3 focus) {
    Fighter* player=m3d_FindPlayerFighter();if(!player)return false;
    /* Keep the landing area in view throughout a Warp Star ride. The
     * original ascent can go above the stage; framing that height hides
     * the rivals the player is trying to target. */
    if((m3d_DelfinoActive()||m3d_ReferenceOverlayActive())&&(player->motion_id==ftCo_MS_WarpStarJump||player->motion_id==ftCo_MS_WarpStarFall)) {
        Vec3 aim=player->motion_id==ftCo_MS_WarpStarJump?player->mv.co.warpstar.cur_pos:player->cur_pos;
        aim.y=10000;Vec3 ground;
        if(m3d_DelfinoFloor(&aim,&ground)) {
            ground.y+=3;
            float pitch=65*M3D_DEG,dist=220;
            Vec3 eye={ground.x+sinf(m3d_cam.yaw)*cosf(pitch)*dist,
                      ground.y+sinf(pitch)*dist,
                      ground.z+cosf(m3d_cam.yaw)*cosf(pitch)*dist};
            m3d_cam.render_yaw=m3d_cam.yaw;
            m3d_PartyCamera(&ground,&eye);
            HSD_CObjSetFov(cobj,65);HSD_CObjSetInterest(cobj,&ground);HSD_CObjSetEyePosition(cobj,&eye);
            HSD_CObjSetNear(cobj,3);HSD_CObjSetFar(cobj,16384);
            return true;
        }
    }
    Vec3 head=player->cur_pos;head.y+=combat_body_top(player);
    if(!m3d_DelfinoViewClear(&head,&focus))focus=head; // A smoothed/group focus may cross a wall.
    float pitch=fmaxf(28*M3D_DEG,fminf(65*M3D_DEG,m3d_cam.pitch));
    float aspect=fmaxf(.5f,HSD_CObjGetAspect(cobj)),wanted=combat_fit(focus,m3d_cam.yaw,pitch,aspect,player);
    if(m3d_cam.fit_frame!=m3d_match_frame){
        m3d_cam.combat_dist=wanted>m3d_cam.combat_dist?wanted:m3d_cam.combat_dist+(wanted-m3d_cam.combat_dist)*.045f;
        m3d_cam.fit_frame=m3d_match_frame;
    }
    if(m3d_DelfinoCameraFade()) {
        float delta=atan2f(sinf(m3d_cam.yaw-m3d_cam.render_yaw),cosf(m3d_cam.yaw-m3d_cam.render_yaw));
        m3d_cam.render_yaw+=delta*.18f;
        Vec3 eye={focus.x+sinf(m3d_cam.render_yaw)*cosf(pitch)*m3d_cam.combat_dist,
                  focus.y+sinf(pitch)*m3d_cam.combat_dist,
                  focus.z+cosf(m3d_cam.render_yaw)*cosf(pitch)*m3d_cam.combat_dist};
        m3d_PartyCamera(&focus,&eye);
        HSD_CObjSetFov(cobj,65);HSD_CObjSetInterest(cobj,&focus);HSD_CObjSetEyePosition(cobj,&eye);
        HSD_CObjSetNear(cobj,3);HSD_CObjSetFar(cobj,16384);
        if(m3d_match_frame%120==0){static int last=-1;if(last!=m3d_match_frame){last=m3d_match_frame;
            fprintf(stderr,"M3D CAMERA STABLE tick=%d subject=%u mode=2 viewer_port=0 yaw=%.6f fit=%.3f\n",m3d_match_frame,player->player_idx,m3d_cam.render_yaw,m3d_cam.combat_dist);}}
        return true;
    }
    Vec3 best={0};float best_score=-10,chosen_pitch=pitch,fit=m3d_cam.combat_dist,chosen_yaw=m3d_cam.yaw;
    const float offsets[]={0,-.785398163f,.785398163f,-1.570796327f,1.570796327f,3.141592654f};
    for(unsigned direction=0;direction<6;direction++)for(int attempt=0;attempt<7;attempt++){
        float p=attempt==6?0:fminf(89*M3D_DEG,pitch+attempt*12*M3D_DEG),yaw=m3d_cam.yaw+offsets[direction];
        float continuity=fabsf(atan2f(sinf(yaw-m3d_cam.render_yaw),cosf(yaw-m3d_cam.render_yaw)));
        float penalty=fabsf(offsets[direction])*.05f+attempt*.025f+continuity*.015f;
        if(1-penalty<=best_score)break;
        float dist=fmaxf(m3d_cam.combat_dist,combat_fit(focus,yaw,p,aspect,player));
        Vec3 eye={focus.x+sinf(yaw)*cosf(p)*dist,focus.y+sinf(p)*dist,focus.z+cosf(yaw)*cosf(p)*dist};
        m3d_DelfinoCamera(&focus,&eye);float available=sqrtf((eye.x-focus.x)*(eye.x-focus.x)+(eye.y-focus.y)*(eye.y-focus.y)+(eye.z-focus.z)*(eye.z-focus.z));
        float score=available/dist-penalty-(combat_player_visible(&eye,player)?0:2);if(score>best_score){best_score=score;best=eye;chosen_pitch=p;chosen_yaw=yaw;fit=dist;}
        if(available>=dist-.1f&&combat_player_visible(&eye,player))break;
    }
    // Ease back toward an unobstructed preference; never interpolate through a wall.
    float delta=atan2f(sinf(chosen_yaw-m3d_cam.render_yaw),cosf(chosen_yaw-m3d_cam.render_yaw));
    if(fabsf(delta)>.01f){float yaw=m3d_cam.render_yaw+delta*.18f;
        float dist=fmaxf(fit,combat_fit(focus,yaw,chosen_pitch,aspect,player));
        Vec3 eye={focus.x+sinf(yaw)*cosf(chosen_pitch)*dist,focus.y+sinf(chosen_pitch)*dist,focus.z+cosf(yaw)*cosf(chosen_pitch)*dist};
        m3d_DelfinoCamera(&focus,&eye);float available=sqrtf((eye.x-focus.x)*(eye.x-focus.x)+(eye.y-focus.y)*(eye.y-focus.y)+(eye.z-focus.z)*(eye.z-focus.z));
        if(available>=dist-.1f&&combat_player_visible(&eye,player)){best=eye;chosen_yaw=yaw;fit=dist;}
    }
    m3d_cam.render_yaw=chosen_yaw;
    m3d_PartyCamera(&focus,&best);
    HSD_CObjSetFov(cobj,65);HSD_CObjSetInterest(cobj,&focus);HSD_CObjSetEyePosition(cobj,&best);
    HSD_CObjSetNear(cobj,3);HSD_CObjSetFar(cobj,16384);
    if(m3d_match_frame%120==0){static int last=-1;if(last!=m3d_match_frame){last=m3d_match_frame;
        fprintf(stderr,"M3D COMBAT CAMERA tick=%d pitch=%.3f fit=%.3f available=%.3f focus=%.2f,%.2f,%.2f\n",m3d_match_frame,chosen_pitch/M3D_DEG,fit,sqrtf((best.x-focus.x)*(best.x-focus.x)+(best.y-focus.y)*(best.y-focus.y)+(best.z-focus.z)*(best.z-focus.z)),focus.x,focus.y,focus.z);}}
    return true;
}

bool m3d_CameraApply(HSD_CObj* cobj)
{
    if(m3d_lab_atlas_camera(cobj))return true;
    if(m3d_PhotoActive()) {
        Vec3 eye={0,260,1250},interest={0,140,-200};
        /* Diagnostic close-ups use the same game renderer as stage selects. */
        const char* pose=getenv("MELEE3D_NATIVE_PHOTO_CAMERA");
        if(pose) {
            Vec3 e,p;int used=0;
            if(sscanf(pose,"%f,%f,%f,%f,%f,%f%n",&e.x,&e.y,&e.z,&p.x,&p.y,&p.z,&used)==6&&!pose[used]&&
               isfinite(e.x)&&isfinite(e.y)&&isfinite(e.z)&&isfinite(p.x)&&isfinite(p.y)&&isfinite(p.z)&&
               hypotf(hypotf(e.x-p.x,e.z-p.z),e.y-p.y)>1){eye=e;interest=p;}
        }
        HSD_CObjSetEyePosition(cobj,&eye);HSD_CObjSetInterest(cobj,&interest);
        HSD_CObjSetFov(cobj,45);HSD_CObjSetAspect(cobj,64.0f/56.0f);return true;
    }
    Vec3 eye;
    Vec3 interest;
    Vec3 van_eye;
    Vec3 van_int;
    float horiz;

    if (!m3d_CameraIsActive()) {
        return false;
    }

    if (m3d_cam.mode == 1) return m3d_ApplySmashCamera(cobj);

    if (!m3d_cam.initialized) {
        float lx,lz;
        Fighter* fp=m3d_FindPlayerFighter();
        /* Opening fighters face the ring centre. Put the orbit camera behind
         * that heading, rather than inheriting the archive's 2D viewpoint. */
        if (fp && m3d_GetLane(fp,&lx,&lz)) {
            m3d_cam.yaw=atan2f(-lx*fp->facing_dir,-lz*fp->facing_dir);
        } else {
            HSD_CObjGetEyePosition(cobj, &van_eye);
            HSD_CObjGetInterest(cobj, &van_int);
            m3d_cam.yaw=atan2f(van_eye.x-van_int.x,van_eye.z-van_int.z);
        }
        if(m3d_DelfinoActive()||m3d_ReferenceOverlayActive())m3d_cam.yaw=m3d_CardinalYaw(m3d_cam.yaw);
        m3d_cam.render_yaw=m3d_cam.yaw;
        if(getenv("MELEE3D_NATIVE_SPAWN_CHECK"))fprintf(stderr,"M3D SPAWN CAMERA yaw=%.6f cardinal=1\n",m3d_cam.yaw);
        m3d_cam.pitch = m3d_cam.mode==2?38*M3D_DEG:m3d_cam_start_pitch;
        m3d_cam.initialized = true;
    }

    interest = m3d_cam.target;
    if(m3d_cam.mode==2)return apply_combat_camera(cobj,interest);
    horiz = cosf(m3d_cam.pitch) * m3d_cam_dist;
    eye.x = interest.x + sinf(m3d_cam.yaw) * horiz;
    eye.y = interest.y + sinf(m3d_cam.pitch) * m3d_cam_dist;
    eye.z = interest.z + cosf(m3d_cam.yaw) * horiz;
    m3d_DelfinoCamera(&interest,&eye);

    HSD_CObjSetFov(cobj, m3d_cam_fov);
    HSD_CObjSetInterest(cobj, &interest);
    HSD_CObjSetEyePosition(cobj, &eye);
    HSD_CObjSetNear(cobj, 1.0f);
    HSD_CObjSetFar(cobj, 16384.0f);
    return true;
}
