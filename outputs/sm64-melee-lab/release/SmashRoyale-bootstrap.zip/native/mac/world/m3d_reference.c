/* SPDX-License-Identifier: GPL-3.0-or-later
 * Authored canonical stage surfaces over native collision topology. Original
 * joint ids, line ids, flags and callbacks remain owned by the stage engine. */
#include "m3d.h"
#include "m3d_surface.h"
#include "m3d_playable_regions.h"
#include <melee/mp/mpisland.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <melee/gr/ground.h>
#include <melee/gr/stage.h>
#include <melee/mp/mplib.h>
#include <melee/mp/types.h>
#include <sysdolphin/baselib/jobj.h>
#include <sysdolphin/baselib/cobj.h>
#include <sysdolphin/baselib/random.h>
#include <sysdolphin/baselib/shadow.h>
#include <sysdolphin/baselib/tobj.h>
#include <dolphin/gx.h>
#include <melee/ft/types.h>
#ifndef _WIN32
#include <execinfo.h>
#endif

typedef struct {
    const float (*points)[2];int count;float height;int main;unsigned flags;int joint;
    float source_x[2];const float (*profile)[3];int profile_count;
    const float (*morph)[2];int morph_count;float morph_z[2];
    const unsigned short (*triangles)[3];int triangle_count;
} RefSurface;
typedef struct {int stage,count,lines,joints;const RefSurface* surfaces;const short* line_surfaces;} RefStage;
#include "m3d_reference_data.inc"
#define REF_LINES 16380
#define REF_VERTS (REF_LINES*2)
#define REF_JOINTS 128
static const RefStage* current;
static MapCollData data;
static MapLine lines[REF_LINES];
static MapLine saved_lines[REF_LINES];
static MapJoint joints[REF_JOINTS];
static DiscVec2 points[REF_VERTS];
static Vec2 saved[REF_VERTS],previous[REF_VERTS],base_points[REF_VERTS];
static short source_indices[REF_VERTS];
static unsigned saved_flags[REF_LINES];
static float scale[96];static Vec3 translation[96];
static bool slicing;
static Vec2 saved_min[REF_JOINTS],saved_max[REF_JOINTS];
static unsigned saved_joint_flags[REF_JOINTS];

/* Optional original-stage extension. Static source meshes append collision
 * identities; every original line, joint, callback and animation remains live. */
typedef struct {Vec3 p[3],n,lo,hi;int line[2];} RefOverlayTriangle;
typedef struct {Vec3 lo,hi;int first,count,left,right;} RefOverlayNode;
typedef struct {Vec3 a,b,inward;} RefOverlayLedge;
static RefOverlayLedge* overlay_ledges;
static int overlay_ledge_count;
static void overlay_build_ledges(void);
static RefOverlayTriangle* overlay_triangles;
static unsigned char* overlay_degenerate;
static RefOverlayNode* overlay_nodes;
static unsigned* overlay_order;
static int overlay_count,overlay_node_count,overlay_sort_axis,overlay_live_count;
static int overlay_live[REF_LINES];
/* Query-local successor memo. Native loops begin at typed range starts,
 * then advance from each returned stable ID + 1. Seed just those IDs in
 * O(live lines), retaining exact binary-search fallback for any other caller.
 * No triangle, line identity, ordering, flag or borrowed-scope lifetime moves. */
static unsigned short overlay_next_line[REF_LINES];
static unsigned overlay_next_epoch[REF_LINES],overlay_epoch;
static int overlay_successor_binary(int id) {
    int lo=0,hi=overlay_live_count;
    while(lo<hi){int mid=(lo+hi)/2;if(overlay_live[mid]<id)lo=mid+1;else hi=mid;}
    return lo==overlay_live_count?65535:overlay_live[lo];
}
static void overlay_successor_set(int id,int next) {
    if(id<0||id>=REF_LINES)return;
    overlay_next_line[id]=(unsigned short)next;overlay_next_epoch[id]=overlay_epoch;
}
static void overlay_successor_prepare(void) {
    if(!++overlay_epoch){memset(overlay_next_epoch,0,sizeof overlay_next_epoch);overlay_epoch=1;}
    int next=65535;
    for(int i=overlay_live_count-1;i>=0;i--){int id=overlay_live[i];overlay_successor_set(id+1,next);overlay_successor_set(id,id);next=id;}
    for(int kind=0;kind<4;kind++){int id=joints[current->joints].ranges[kind].start;overlay_successor_set(id,overlay_successor_binary(id));}
}
static int overlay_successor(int id) {
    if(id<0||id>=REF_LINES)return 65535;
    if(overlay_next_epoch[id]!=overlay_epoch)overlay_successor_set(id,overlay_successor_binary(id));
    return overlay_next_line[id];
}

/* Valid only after overlay_slice finishes building its borrowed plane.
 * End and every source selection invalidate it before another native query. */
static CollLine* overlay_scope_base;
static int overlay_scope_first,overlay_scope_end;
static unsigned overlay_scope_epoch;

static Vec3 overlay_min,overlay_max,overlay_center;
static float overlay_goop_street;
/* Optional exact source water faces; never collision floors. */
static Vec3 (*overlay_water)[3];static unsigned overlay_water_count;
static char overlay_directory[4096];
static bool overlay_initialized,overlay_replace_ground;
static M3dRegions overlay_regions;
static mpIsland overlay_islands[REF_LINES];
static struct mpIsland_80458E88_t overlay_saved_islands;
/* Only appended static overlay geometry is memoized. Original stage joints,
 * moving awnings, their transforms and complete native island lifecycle still
 * execute for every borrowed query. Keys compare exact float representations. */
#define OVERLAY_SLICE_CACHE 64
#define OVERLAY_SLICE_BUDGET (8u*1024u*1024u)
typedef struct {int id;MapLine line;Vec2 a,b;} RefOverlaySegment;
typedef struct {bool valid;float key[5];int count;RefOverlaySegment* segments;} RefOverlaySlice;
static RefOverlaySlice overlay_cache[OVERLAY_SLICE_CACHE];
static size_t overlay_cache_bytes;
static bool overlay_cache_off,overlay_cache_check;
static unsigned long long overlay_cache_requests,overlay_cache_hits,overlay_cache_checks;
static int overlay_cache_log_tick=-1;
static void overlay_cache_clear(void) {
    overlay_scope_epoch=0;
    for(int i=0;i<OVERLAY_SLICE_CACHE;i++){free(overlay_cache[i].segments);memset(&overlay_cache[i],0,sizeof overlay_cache[i]);}
    overlay_cache_bytes=0;overlay_cache_requests=overlay_cache_hits=overlay_cache_checks=0;overlay_cache_log_tick=-1;
    const char* value=getenv("MELEE3D_NATIVE_ONETT_SLICE_CACHE");overlay_cache_off=value&&(!strcmp(value,"off")||!strcmp(value,"0"));
    overlay_cache_check=getenv("MELEE3D_NATIVE_ONETT_SLICE_CHECK")!=NULL;
}

static float overlay_component(Vec3 p,int k){return k==0?p.x:k==1?p.y:p.z;}
static void overlay_fail(const char* reason){fprintf(stderr,"M3D ONETT OVERLAY FAIL %s\n",reason);abort();}
static int overlay_compare(const void* a,const void* b){RefOverlayTriangle* x=&overlay_triangles[*(const unsigned*)a],*y=&overlay_triangles[*(const unsigned*)b];float u=overlay_component(x->lo,overlay_sort_axis)+overlay_component(x->hi,overlay_sort_axis),v=overlay_component(y->lo,overlay_sort_axis)+overlay_component(y->hi,overlay_sort_axis);return u<v?-1:u>v?1:0;}
static int overlay_node(int first,int count){
 int id=overlay_node_count++;RefOverlayNode* n=&overlay_nodes[id];n->lo=(Vec3){1e20f,1e20f,1e20f};n->hi=(Vec3){-1e20f,-1e20f,-1e20f};n->first=first;n->count=count;
 for(int j=first;j<first+count;j++){RefOverlayTriangle* t=&overlay_triangles[overlay_order[j]];n->lo.x=fminf(n->lo.x,t->lo.x);n->lo.y=fminf(n->lo.y,t->lo.y);n->lo.z=fminf(n->lo.z,t->lo.z);n->hi.x=fmaxf(n->hi.x,t->hi.x);n->hi.y=fmaxf(n->hi.y,t->hi.y);n->hi.z=fmaxf(n->hi.z,t->hi.z);}
 if(count>8){Vec3 d={n->hi.x-n->lo.x,n->hi.y-n->lo.y,n->hi.z-n->lo.z};overlay_sort_axis=d.x>d.y?(d.x>d.z?0:2):(d.y>d.z?1:2);qsort(overlay_order+first,count,sizeof(unsigned),overlay_compare);int half=count/2;n->left=overlay_node(first,half);n->right=overlay_node(first+half,count-half);n->count=0;}return id;
}
static void overlay_select(int stage){
 overlay_cache_clear();
 free(overlay_ledges);overlay_ledges=NULL;overlay_ledge_count=0;
 free(overlay_water);overlay_water=NULL;overlay_water_count=0;
 m3d_regions_free(&overlay_regions);
 free(overlay_triangles);free(overlay_degenerate);free(overlay_nodes);free(overlay_order);overlay_triangles=NULL;overlay_degenerate=NULL;overlay_nodes=NULL;overlay_order=NULL;overlay_count=overlay_node_count=0;overlay_initialized=overlay_replace_ground=false;overlay_directory[0]=0;
 const char* directory=getenv(stage==32?"MELEE3D_NATIVE_LARGE_FD_OVERLAY":stage==4?"MELEE3D_NATIVE_CASTLE_OVERLAY":"MELEE3D_NATIVE_ONETT_OVERLAY");if((stage!=9&&stage!=4&&!(stage==32&&m3d_LargeFDActive()))||!directory||!*directory)return;
 const char* ground=getenv(stage==4?"MELEE3D_NATIVE_CASTLE_REPLACE_GROUND":"MELEE3D_NATIVE_ONETT_REPLACE_GROUND");overlay_replace_ground=ground&&!strcmp(ground,"1");
 if(snprintf(overlay_directory,sizeof overlay_directory,"%s",directory)>=(int)sizeof overlay_directory)overlay_fail("directory length");char path[4096];if(snprintf(path,sizeof path,"%s/%s",directory,stage==32?"final-destination.ovl":stage==4?"castle.ovl":"onett.ovl")>=(int)sizeof path)overlay_fail("path length");
 FILE* f=fopen(path,"rb");if(!f)overlay_fail("missing source collision bank");char magic[4];unsigned version,count;
 if(fread(magic,1,4,f)!=4||fread(&version,4,1,f)!=1||fread(&count,4,1,f)!=1||memcmp(magic,"OVL1",4)||version!=1||!count||count>16000)overlay_fail("header");
 if(fread(&overlay_min,sizeof(Vec3),1,f)!=1||fread(&overlay_max,sizeof(Vec3),1,f)!=1)overlay_fail("bounds");
 overlay_count=count;overlay_triangles=calloc(count,sizeof(*overlay_triangles));overlay_degenerate=calloc(count,1);overlay_nodes=calloc(count*2,sizeof(*overlay_nodes));overlay_order=calloc(count,sizeof(*overlay_order));if(!overlay_triangles||!overlay_degenerate||!overlay_nodes||!overlay_order)overlay_fail("allocation");
 for(unsigned i=0;i<count;i++){RefOverlayTriangle* t=&overlay_triangles[i];if(fread(t->p,sizeof(Vec3),3,f)!=3||fread(&t->n,sizeof(Vec3),1,f)!=1)overlay_fail("truncated triangle");t->lo=t->hi=t->p[0];float length=t->n.x*t->n.x+t->n.y*t->n.y+t->n.z*t->n.z;if(!isfinite(length)||fabsf(length-1)>.001f)overlay_fail("unit normal");for(int k=0;k<3;k++){Vec3 p=t->p[k];if(!isfinite(p.x)||!isfinite(p.y)||!isfinite(p.z))overlay_fail("finite position");t->lo.x=fminf(t->lo.x,p.x);t->lo.y=fminf(t->lo.y,p.y);t->lo.z=fminf(t->lo.z,p.z);t->hi.x=fmaxf(t->hi.x,p.x);t->hi.y=fmaxf(t->hi.y,p.y);t->hi.z=fmaxf(t->hi.z,p.z);}/* Test the actual serialized float32 positions, not the pre-pack normal.
  * Exact zero-area primitives have no rasterized/physical surface. Keep their
  * stable source/line identities, but never expose them to floor/body queries.
  * This double predicate is independently checked against rational arithmetic
  * for every triangle of the current serialized source bank; it is not a
  * universal exact predicate for arbitrary float32 exponent ranges. */
 double ux=(double)t->p[1].x-t->p[0].x,uy=(double)t->p[1].y-t->p[0].y,uz=(double)t->p[1].z-t->p[0].z;
 double vx=(double)t->p[2].x-t->p[0].x,vy=(double)t->p[2].y-t->p[0].y,vz=(double)t->p[2].z-t->p[0].z;
 overlay_degenerate[i]=(uy*vz-uz*vy)==0&&(uz*vx-ux*vz)==0&&(ux*vy-uy*vx)==0;
 t->line[0]=t->line[1]=-1;overlay_order[i]=i;}
 if(fgetc(f)!=EOF)overlay_fail("trailing data");fclose(f);overlay_node(0,count);
 unsigned discarded=0;for(unsigned i=0;i<count;i++)discarded+=overlay_degenerate[i];fprintf(stderr,"M3D ONETT SOURCE GEOMETRY triangles=%u exact_zero_area=%u stable_ids_preserved=1\n",count,discarded);
 if(stage==4) {
  if(snprintf(path,sizeof path,"%s/castle.wtr",directory)>=(int)sizeof path)overlay_fail("water path");
  FILE* water=fopen(path,"rb");
  if(water){char signature[4];unsigned water_version,water_count;
   if(fread(signature,1,4,water)!=4||fread(&water_version,4,1,water)!=1||fread(&water_count,4,1,water)!=1||memcmp(signature,"CWT1",4)||water_version!=1||!water_count||water_count>16384)overlay_fail("water header");
   overlay_water=calloc(water_count,sizeof(*overlay_water));if(!overlay_water)overlay_fail("water allocation");
   if(fread(overlay_water,sizeof(*overlay_water),water_count,water)!=water_count||fgetc(water)!=EOF)overlay_fail("water records");fclose(water);
   for(unsigned i=0;i<water_count;i++)for(int k=0;k<3;k++){Vec3 p=overlay_water[i][k];if(!isfinite(p.x)||!isfinite(p.y)||!isfinite(p.z)||fabsf(p.x)>20000||fabsf(p.y)>20000||fabsf(p.z)>20000)overlay_fail("water finite position");}
   overlay_water_count=water_count;fprintf(stderr,"M3D CASTLE WATER faces=%u source_surface=1 collision_floor=0\n",water_count);
  }
 }
 if(snprintf(path,sizeof path,"%s/%s",directory,stage==4?"castle.reg":"onett.reg")>=(int)sizeof path)overlay_fail("playable region path");int region_status=m3d_regions_load(&overlay_regions,path);if(region_status<0)overlay_fail("invalid playable region");
 if(region_status)fprintf(stderr,"M3D ONETT REGION LOAD regions=%u grounded_caps=1 airborne_height_preserved=1\n",overlay_regions.count);
 overlay_center=(Vec3){(overlay_min.x+overlay_max.x)*.5f,overlay_min.y,(overlay_min.z+overlay_max.z)*.5f};
 if(overlay_regions.count){overlay_center.x=(overlay_regions.lo[0]+overlay_regions.hi[0])*.5f;overlay_center.z=(overlay_regions.lo[1]+overlay_regions.hi[1])*.5f;}
 /* A street-level area quantile, not the lowest wall vertex or a roof at
  * the centre. This keeps the same low-ground-first progression on each map. */
 {float weights[256]={0},total=0,span=fmaxf(1,overlay_max.y-overlay_min.y);overlay_goop_street=overlay_center.y;
  for(int i=0;i<overlay_count;i++){RefOverlayTriangle* t=&overlay_triangles[i];if(overlay_degenerate[i]||t->n.y<.65f)continue;
   Vec3 a=t->p[0],b=t->p[1],c=t->p[2];float y=(a.y+b.y+c.y)/3;
   if(!m3d_regions_contains(&overlay_regions,(a.x+b.x+c.x)/3,y,(a.z+b.z+c.z)/3,true))continue;
   float area=fabsf((b.x-a.x)*(c.z-a.z)-(b.z-a.z)*(c.x-a.x))*.5f;int bin=(int)((y-overlay_min.y)/span*255);bin=bin<0?0:bin>255?255:bin;weights[bin]+=area;total+=area;}
  float cumulative=0;for(int i=0;i<256&&total>0;i++){cumulative+=weights[i];if(cumulative>=total*.25f){overlay_goop_street=overlay_min.y+span*i/255;break;}}
  fprintf(stderr,"M3D GOOP REFERENCE stage=%d street=%.2f area=%.2f\n",stage,overlay_goop_street,total);}
 overlay_build_ledges();
 fprintf(stderr,"M3D ONETT OVERLAY LOAD triangles=%d bounds=%.2f,%.2f,%.2f;%.2f,%.2f,%.2f original_stage=%d\n",overlay_count,overlay_min.x,overlay_min.y,overlay_min.z,overlay_max.x,overlay_max.y,overlay_max.z,stage);
}
bool m3d_ReferenceOverlayActive(void){return current&&(current->stage==9||current->stage==4||m3d_LargeFDActive())&&overlay_count>0;}

bool m3d_ReferenceCastleActive(void){return m3d_ReferenceOverlayActive()&&current->stage==4;}
float m3d_ReferenceOverlayPeakHeight(void){return overlay_max.y;}
float m3d_ReferenceOverlayStreetHeight(void){return overlay_goop_street;}
/* Reuse the same field clipping, original Sunshine art and native GX pass as
 * Plaza. These exact collision faces lie on the native source render mesh;
 * original moving props keep their own callbacks and are not painted here. */
void m3d_ReferenceOverlayGoop(void (*triangle)(Vec3,Vec3,Vec3,int,int)) {
    if(!m3d_ReferenceOverlayActive()||!triangle)return;
    HSD_CObj* camera=HSD_CObjGetCurrent();if(!camera)return;
    Vec3 eye;HSD_CObjGetEyePosition(camera,&eye);MtxPtr view=HSD_CObjGetViewingMtxPtr(camera);
    for(int i=0;i<overlay_count;i++) {
        RefOverlayTriangle* t=&overlay_triangles[i];if(overlay_degenerate[i]||t->n.y<-.5f)continue;
        Vec3 a=t->p[0],b=t->p[1],c=t->p[2],center={(a.x+b.x+c.x)/3,(a.y+b.y+c.y)/3,(a.z+b.z+c.z)/3},v;
        float radius=0;for(int k=0;k<3;k++){Vec3 p=t->p[k];radius=fmaxf(radius,sqrtf((p.x-center.x)*(p.x-center.x)+(p.y-center.y)*(p.y-center.y)+(p.z-center.z)*(p.z-center.z)));}
        if(!m3d_GoopMayCover(&center,radius)||hypotf(center.x-eye.x,center.z-eye.z)>1100+radius)continue;
        if(!m3d_regions_contains(&overlay_regions,center.x,center.y,center.z,true))continue;
        PSMTXMultVec(view,&center,&v);if(v.z>radius||fabsf(v.x)>-v.z*1.3f+radius||fabsf(v.y)>-v.z*.8f+radius)continue;
        Vec3 n=t->n;int axis=fabsf(n.y)>.5f?0:fabsf(n.z)>fabsf(n.x)?1:2;
        float offset=n.x*(eye.x-a.x)+n.y*(eye.y-a.y)+n.z*(eye.z-a.z)<0?-.18f:.18f;
        a.x+=n.x*offset;a.y+=n.y*offset;a.z+=n.z*offset;
        b.x+=n.x*offset;b.y+=n.y*offset;b.z+=n.z*offset;
        c.x+=n.x*offset;c.y+=n.y*offset;c.z+=n.z*offset;
        triangle(a,b,c,radius>240?6:radius>120?5:radius>60?4:radius>30?3:2,axis);
    }
}

/* The pinned Onett reference describes whole building roofs as coarse flat
 * caps (Drug Store94.5local/85.05world includes an81world tiled roof).
 * Exact static model triangles replace only these building approximations.
 * Keep original identities/joints and every callback, plus surfaces0/1 trees,
 *2/3 moving awnings and11/12 streets/terrain. Surface25 is replaced only
 * when the verified bank declares complete source-ground coverage; old banks
 * retain its original profile. Surface8 has no mapped lines;
 * retain it as well. The source-model overlay is opt-in and stage9 only. */
static bool overlay_replaces_surface(int si) {
    return m3d_ReferenceOverlayActive()&&(m3d_LargeFDActive()||current->stage==4||(si==25&&overlay_replace_ground)||(si>=4&&si<=7)||(si>=9&&si<=10)||(si>=13&&si<=24));
}
static bool overlay_mask_original(int si,CollLine* line) {
    if(!overlay_replaces_surface(si))return false;
    line->flags=(line->flags|LINE_FLAG_EMPTY)&~LINE_FLAG_ENABLED;return true;
}
static float overlay_height(int id,Vec3* p,float best){RefOverlayNode* n=&overlay_nodes[id];if(p->x<n->lo.x-.001f||p->x>n->hi.x+.001f||p->z<n->lo.z-.001f||p->z>n->hi.z+.001f||n->lo.y>p->y+.1f||n->hi.y<best)return best;
 if(!n->count){best=overlay_height(n->left,p,best);return overlay_height(n->right,p,best);}for(int i=n->first;i<n->first+n->count;i++){RefOverlayTriangle* t=&overlay_triangles[overlay_order[i]];if(overlay_degenerate&&overlay_degenerate[overlay_order[i]])continue;if(m3d_surface_kind(t->n.y)!=0)continue;float sign=0;bool inside=true;for(int k=0;k<3;k++){Vec3 a=t->p[k],b=t->p[(k+1)%3];float q=(b.x-a.x)*(p->z-a.z)-(b.z-a.z)*(p->x-a.x);if(fabsf(q)<.001f)continue;if(sign*q<0){inside=false;break;}sign=q;}if(inside){float y=t->p[0].y-(t->n.x*(p->x-t->p[0].x)+t->n.z*(p->z-t->p[0].z))/t->n.y;if(y<=p->y+.1f&&y>best)best=y;}}return best;}

/* Mesh triangulation/material seams are not ledges. Both sides must be
 * checked against the actual source floor before offering a recovery target. */
static bool overlay_ledge_supported(Vec3 q,Vec3 inward) {
 Vec3 inside={q.x+inward.x*2,q.y+4,q.z+inward.z*2};
 float y=overlay_height(0,&inside,-1e30f);
 if(fabsf(y-q.y)>4||!m3d_regions_contains(&overlay_regions,inside.x,y,inside.z,true))return false;
 Vec3 outside={q.x-inward.x*5,q.y+24,q.z-inward.z*5};
 float drop=overlay_height(0,&outside,-1e30f);
 return drop<q.y-8;
}
static void overlay_build_ledges(void) {
 /* At most four pieces per edge keeps partial T-junction boundaries useful
  * without adding any native collision lines or altering their stable IDs. */
 overlay_ledges=calloc((size_t)overlay_count*12,sizeof(*overlay_ledges));
 if(!overlay_ledges)overlay_fail("ledge allocation");
 for(int i=0;i<overlay_count;i++) {
  RefOverlayTriangle* t=&overlay_triangles[i];
  if(overlay_degenerate[i]||m3d_surface_kind(t->n.y)!=0)continue;
  Vec3 center={(t->p[0].x+t->p[1].x+t->p[2].x)/3,(t->p[0].y+t->p[1].y+t->p[2].y)/3,(t->p[0].z+t->p[1].z+t->p[2].z)/3};
  for(int edge=0;edge<3;edge++) {
   Vec3 a=t->p[edge],b=t->p[(edge+1)%3];float dx=b.x-a.x,dz=b.z-a.z,length=hypotf(dx,dz);
   if(length<1)continue;
   Vec3 inward={-dz/length,0,dx/length};
   if((center.x-a.x)*inward.x+(center.z-a.z)*inward.z<0){inward.x=-inward.x;inward.z=-inward.z;}
   int pieces=(int)ceilf(length/24);if(pieces>4)pieces=4;
   for(int piece=0;piece<pieces;piece++) {
    Vec3 u={a.x+dx*piece/pieces,a.y+(b.y-a.y)*piece/pieces,a.z+dz*piece/pieces};
    Vec3 v={a.x+dx*(piece+1)/pieces,a.y+(b.y-a.y)*(piece+1)/pieces,a.z+dz*(piece+1)/pieces};
    bool valid=true;
    for(int sample=0;sample<3;sample++) {
     float fraction=.2f+.3f*sample;Vec3 q={u.x+(v.x-u.x)*fraction,u.y+(v.y-u.y)*fraction,u.z+(v.z-u.z)*fraction};
     if(!overlay_ledge_supported(q,inward)){valid=false;break;}
    }
    if(valid)overlay_ledges[overlay_ledge_count++]=(RefOverlayLedge){u,v,inward};
   }
  }
 }
 fprintf(stderr,"M3D REFERENCE LEDGES boundaries=%d actual_drop_required=1 native_ids_unchanged=1\n",overlay_ledge_count);
}
static void overlay_nearest_ledge(Vec3* pos,Vec3* goal,float* nx,float* nz,float* best) {
 for(int i=0;i<overlay_ledge_count;i++) {
  RefOverlayLedge* edge=&overlay_ledges[i];Vec3 a=edge->a,b=edge->b;
  float dx=b.x-a.x,dz=b.z-a.z,den=dx*dx+dz*dz;
  float t=fmaxf(0,fminf(1,((pos->x-a.x)*dx+(pos->z-a.z)*dz)/den));
  Vec3 q={a.x+t*dx,a.y+t*(b.y-a.y),a.z+t*dz};
  float distance=(q.x-pos->x)*(q.x-pos->x)+(q.y-pos->y)*(q.y-pos->y)+(q.z-pos->z)*(q.z-pos->z);
  if(distance>=*best||!overlay_ledge_supported(q,edge->inward))continue;
  *best=distance;*goal=q;if(nx)*nx=edge->inward.x;if(nz)*nz=edge->inward.z;
 }
}
/* Highest exact source wave face at this horizontal point. Winding is
 * intentionally ignored: HSD water faces may use either front-face convention.
 * A solid roof below the surface protects real submerged tunnels. */
bool m3d_ReferenceOverlayWater(Vec3* p,float* surface) {
    if(!m3d_ReferenceOverlayActive()||!overlay_water_count||!p||!isfinite(p->x)||!isfinite(p->y)||!isfinite(p->z))return false;
    float water=-1e30f;
    for(unsigned i=0;i<overlay_water_count;i++) {
        Vec3 a=overlay_water[i][0],b=overlay_water[i][1],c=overlay_water[i][2];
        float bx=b.x-a.x,bz=b.z-a.z,cx=c.x-a.x,cz=c.z-a.z,den=bx*cz-bz*cx;
        if(fabsf(den)<1e-7f)continue;
        float x=p->x-a.x,z=p->z-a.z,u=(x*cz-z*cx)/den,v=(bx*z-bz*x)/den;
        if(u<-.00001f||v<-.00001f||u+v>1.00001f)continue;
        water=fmaxf(water,a.y+(b.y-a.y)*u+(c.y-a.y)*v);
    }
    if(water<-1e29f||p->y>=water-.01f)return false;
    Vec3 probe=*p;probe.y=water+.1f;
    float cover=overlay_height(0,&probe,-1e30f);
    if(cover>p->y+2)return false;
    if(surface)*surface=water;return true;
}
static bool overlay_blocked(int id,Vec3 a,Vec3 d){RefOverlayNode* n=&overlay_nodes[id];float enter=0,exit=1;for(int k=0;k<3;k++){float p=overlay_component(a,k),v=overlay_component(d,k),lo=overlay_component(n->lo,k)-.001f,hi=overlay_component(n->hi,k)+.001f;if(fabsf(v)<1e-8f){if(p<lo||p>hi)return false;}else{float x=(lo-p)/v,y=(hi-p)/v;if(x>y){float q=x;x=y;y=q;}enter=fmaxf(enter,x);exit=fminf(exit,y);if(enter>exit)return false;}}
 if(!n->count)return overlay_blocked(n->left,a,d)||overlay_blocked(n->right,a,d);for(int i=n->first;i<n->first+n->count;i++){RefOverlayTriangle* t=&overlay_triangles[overlay_order[i]];if(overlay_degenerate&&overlay_degenerate[overlay_order[i]])continue;Vec3 u={t->p[1].x-t->p[0].x,t->p[1].y-t->p[0].y,t->p[1].z-t->p[0].z},v={t->p[2].x-t->p[0].x,t->p[2].y-t->p[0].y,t->p[2].z-t->p[0].z};Vec3 p={d.y*v.z-d.z*v.y,d.z*v.x-d.x*v.z,d.x*v.y-d.y*v.x};float det=u.x*p.x+u.y*p.y+u.z*p.z;if(fabsf(det)<1e-7f)continue;Vec3 s={a.x-t->p[0].x,a.y-t->p[0].y,a.z-t->p[0].z};float x=(s.x*p.x+s.y*p.y+s.z*p.z)/det;if(x<0||x>1)continue;Vec3 q={s.y*u.z-s.z*u.y,s.z*u.x-s.x*u.z,s.x*u.y-s.y*u.x};float y=(d.x*q.x+d.y*q.y+d.z*q.z)/det;if(y<0||x+y>1)continue;float h=(v.x*q.x+v.y*q.y+v.z*q.z)/det;if(h>.001f&&h<.999f)return true;}return false;}
static bool overlay_body_blocked(int id,Vec3 a,Vec3 d,const M3dSupportPlanes* support){RefOverlayNode* n=&overlay_nodes[id];float enter=0,exit=1;for(int k=0;k<3;k++){float p=overlay_component(a,k),v=overlay_component(d,k),lo=overlay_component(n->lo,k)-.001f,hi=overlay_component(n->hi,k)+.001f;if(fabsf(v)<1e-8f){if(p<lo||p>hi)return false;}else{float x=(lo-p)/v,y=(hi-p)/v;if(x>y){float q=x;x=y;y=q;}enter=fmaxf(enter,x);exit=fminf(exit,y);if(enter>exit)return false;}}
 if(!n->count)return overlay_body_blocked(n->left,a,d,support)||overlay_body_blocked(n->right,a,d,support);for(int i=n->first;i<n->first+n->count;i++){RefOverlayTriangle* t=&overlay_triangles[overlay_order[i]];if(overlay_degenerate&&overlay_degenerate[overlay_order[i]])continue;if(m3d_support_plane_matches(support,t->n.x,t->n.y,t->n.z,t->p[0].x,t->p[0].y,t->p[0].z))continue;Vec3 u={t->p[1].x-t->p[0].x,t->p[1].y-t->p[0].y,t->p[1].z-t->p[0].z},v={t->p[2].x-t->p[0].x,t->p[2].y-t->p[0].y,t->p[2].z-t->p[0].z};Vec3 p={d.y*v.z-d.z*v.y,d.z*v.x-d.x*v.z,d.x*v.y-d.y*v.x};float det=u.x*p.x+u.y*p.y+u.z*p.z;if(fabsf(det)<1e-7f)continue;Vec3 s={a.x-t->p[0].x,a.y-t->p[0].y,a.z-t->p[0].z};float x=(s.x*p.x+s.y*p.y+s.z*p.z)/det;if(x<0||x>1)continue;Vec3 q={s.y*u.z-s.z*u.y,s.z*u.x-s.x*u.z,s.x*u.y-s.y*u.x};float y=(d.x*q.x+d.y*q.y+d.z*q.z)/det;if(y<0||x+y>1)continue;float h=(v.x*q.x+v.y*q.y+v.z*q.z)/det;if(h>.001f&&h<.999f&&!m3d_support_below_all(support,a.x+d.x*h,a.y+d.y*h,a.z+d.z*h))return true;}return false;}
static void overlay_support_planes(int id,Vec3* p,M3dSupportPlanes* supports) {
    RefOverlayNode* n=&overlay_nodes[id];if(p->x<n->lo.x-.001f||p->x>n->hi.x+.001f||p->z<n->lo.z-.001f||p->z>n->hi.z+.001f||n->lo.y>p->y+.5f||n->hi.y<p->y-.5f)return;
    if(!n->count){overlay_support_planes(n->left,p,supports);overlay_support_planes(n->right,p,supports);return;}
    for(int i=n->first;i<n->first+n->count;i++) {
        RefOverlayTriangle* t=&overlay_triangles[overlay_order[i]];if(overlay_degenerate&&overlay_degenerate[overlay_order[i]])continue;if(t->n.y<M3D_WALKABLE)continue;
        float sign=0;bool inside=true;for(int k=0;k<3;k++){Vec3 a=t->p[k],b=t->p[(k+1)%3];float q=(b.x-a.x)*(p->z-a.z)-(b.z-a.z)*(p->x-a.x);if(fabsf(q)<.001f)continue;if(sign*q<0){inside=false;break;}sign=q;}
        float y=t->p[0].y-(t->n.x*(p->x-t->p[0].x)+t->n.z*(p->z-t->p[0].z))/t->n.y;
        if(inside&&fabsf(y-p->y)<.5f)m3d_support_plane_add(supports,t->n.x,t->n.y,t->n.z,t->p[0].x,t->p[0].y,t->p[0].z);
    }
}
static void overlay_floor_intervals(int id,Vec3* a,Vec3* b,M3dFloorProfile* profile) {
    if(profile->overflow)return;RefOverlayNode* n=&overlay_nodes[id];
    if(fmaxf(a->x,b->x)<n->lo.x-.001f||fminf(a->x,b->x)>n->hi.x+.001f||fmaxf(a->z,b->z)<n->lo.z-.001f||fminf(a->z,b->z)>n->hi.z+.001f)return;
    if(!n->count){overlay_floor_intervals(n->left,a,b,profile);overlay_floor_intervals(n->right,a,b,profile);return;}
    for(int i=n->first;i<n->first+n->count;i++){RefOverlayTriangle* t=&overlay_triangles[overlay_order[i]];if(overlay_degenerate&&overlay_degenerate[overlay_order[i]])continue;
        float points[3][3];for(int k=0;k<3;k++){points[k][0]=t->p[k].x;points[k][1]=t->p[k].y;points[k][2]=t->p[k].z;}
        m3d_floor_interval(profile,a->x,a->z,b->x,b->z,points,t->n.x,t->n.y,t->n.z);
    }
}
static bool overlay_floor_profile(Vec3* a,Vec3* b,M3dSupportPlanes* supports,float* endpoint_y) {
    if(fabsf(a->x-b->x)+fabsf(a->z-b->z)<.00001f){if(endpoint_y)*endpoint_y=a->y;return supports->count>0;}
    M3dFloorProfile profile={0};overlay_floor_intervals(0,a,b,&profile);
    return m3d_floor_connected(&profile,a->x,a->y,a->z,b->x,b->z,supports,endpoint_y);
}
bool m3d_ReferenceOverlayConnectedFloor(Vec3* a,Vec3* b) {
    if(!m3d_ReferenceOverlayActive())return false;M3dSupportPlanes planes={0};overlay_support_planes(0,a,&planes);float endpoint_y=a->y;
    return planes.count&&overlay_floor_profile(a,b,&planes,&endpoint_y)&&fabsf(endpoint_y-b->y)<=.5f;
}
bool m3d_ReferenceOverlayBodyClear(Vec3* support,Vec3* a,Vec3* b) {
    if(!m3d_ReferenceOverlayActive())return true;M3dSupportPlanes planes={0};overlay_support_planes(0,support,&planes);
    overlay_floor_profile(support,a,&planes,NULL);if(fabsf(a->x-b->x)+fabsf(a->z-b->z)>.00001f)overlay_floor_profile(support,b,&planes,NULL);
    return !overlay_body_blocked(0,*a,(Vec3){b->x-a->x,b->y-a->y,b->z-a->z},&planes);
}
bool m3d_ReferenceOverlayOffsetSupported(Vec3* support,Vec3* offset,float tolerance) {
    if(!m3d_ReferenceOverlayActive())return false;M3dSupportPlanes planes={0};overlay_support_planes(0,support,&planes);
    (void)tolerance;/* Actual continuous floor coverage replaces extrapolated height tolerance. */
    return planes.count&&overlay_floor_profile(support,offset,&planes,NULL);
}
bool m3d_ReferenceOverlayViewClear(Vec3* a,Vec3* b){if(!m3d_ReferenceOverlayActive())return true;return !overlay_blocked(0,*a,(Vec3){b->x-a->x,b->y-a->y,b->z-a->z});}
int m3d_ReferenceOverlayBlast(Vec3* p){if(!m3d_ReferenceOverlayActive())return 0;if(p->y<overlay_min.y-180)return 2;if(!m3d_regions_contains(&overlay_regions,p->x,p->y,p->z,false))return p->x<overlay_center.x?-1:1;if(p->x<overlay_min.x-180||p->z<overlay_min.z-180)return -1;if(p->x>overlay_max.x+180||p->z>overlay_max.z+180)return 1;return 0;}
bool m3d_ReferenceOverlayGroundAllowed(Vec3* p){return !m3d_ReferenceOverlayActive()||m3d_regions_contains(&overlay_regions,p->x,p->y,p->z,true);}
float m3d_ReferenceOverlayExtent(Vec3* p){if(overlay_regions.count)return hypotf(fmaxf(fabsf(overlay_regions.lo[0]-p->x),fabsf(overlay_regions.hi[0]-p->x)),fmaxf(fabsf(overlay_regions.lo[1]-p->z),fabsf(overlay_regions.hi[1]-p->z)));return hypotf(fmaxf(fabsf(overlay_min.x-p->x),fabsf(overlay_max.x-p->x)),fmaxf(fabsf(overlay_min.z-p->z),fabsf(overlay_max.z-p->z)));}
void m3d_ReferenceOverlayAim(Vec3* p){*p=overlay_center;}
void m3d_ReferenceOverlayInit(void){if(!m3d_ReferenceOverlayActive()||overlay_initialized)return;overlay_initialized=true;if(overlay_water_count)m3d_WaterInit();CollLine* overlay_lines=mpGetGroundCollLine();for(int i=current->lines;i<data.line_count;i++)overlay_lines[i].flags|=LINE_FLAG_EMPTY|LINE_FLAG_ENABLED;/* Persistent static IDs stay valid; EMPTY keeps dummy geometry absent outside a borrowed plane. */stage_info.blast_zone.left=fminf(stage_info.blast_zone.left,overlay_min.x-180);stage_info.blast_zone.right=fmaxf(stage_info.blast_zone.right,overlay_max.x+180);stage_info.blast_zone.bottom=fminf(stage_info.blast_zone.bottom,overlay_min.y-180);stage_info.blast_zone.top=fmaxf(stage_info.blast_zone.top,overlay_max.y+(m3d_LargeFDActive()?800:180));m3d_DelfinoNavSelect(overlay_directory,&overlay_center);fprintf(stderr,"M3D ONETT OVERLAY INIT native_callbacks=preserved original_lines=%d original_joints=%d\n",current->lines,current->joints);}
void m3d_ReferenceOverlayZoneRadii(Vec3* center,float radii[33]){float extent=m3d_ReferenceOverlayExtent(center)+40,bins[512]={0},area=0;for(int i=0;i<overlay_count;i++){RefOverlayTriangle* t=&overlay_triangles[i];if(t->n.y<.65f)continue;Vec3 a=t->p[0],b=t->p[1],c=t->p[2];if(!m3d_regions_contains(&overlay_regions,(a.x+b.x+c.x)/3,(a.y+b.y+c.y)/3,(a.z+b.z+c.z)/3,true))continue;float weight=fabsf((b.x-a.x)*(c.z-a.z)-(b.z-a.z)*(c.x-a.x))*.5f;int bin=(int)(hypotf((a.x+b.x+c.x)/3-center->x,(a.z+b.z+c.z)/3-center->z)/extent*511);bins[bin<0?0:bin>511?511:bin]+=weight;area+=weight;}for(int n=1;n<=32;n++){float target=(n-1)*7300.f*8,covered=0;radii[n]=extent;for(int i=0;i<512;i++){covered+=bins[i];if(covered>=target){radii[n]=fmaxf(140,(i+1)*extent/512);break;}}}radii[0]=extent;fprintf(stderr,"M3D ONETT ZONE area=%.2f opening=%.2f\n",area,extent);}
static void overlay_collision(int* cursor){if(!m3d_ReferenceOverlayActive())return;if(current->joints>=REF_JOINTS||data.ranges[MapLineGroup_Dynamic].count)overlay_fail("append topology");MapJoint* joint=&joints[current->joints];memset(joint,0,sizeof(*joint));joint->vtx_start=*cursor;joint->left_bound=joint->bottom_bound=-200000;joint->right_bound=joint->top_bound=200000;int first=data.line_count;float s=Ground_801C0498();
 for(int kind=0;kind<4;kind++){joint->ranges[kind].start=data.line_count;for(int i=0;i<overlay_count;i++){RefOverlayTriangle* t=&overlay_triangles[i];int k=m3d_surface_kind(t->n.y);if(k!=kind&&!(kind==3&&k==2))continue;if(data.line_count>=REF_LINES||*cursor+2>REF_VERTS)overlay_fail("native line capacity");int id=data.line_count++;MapLine* l=&lines[id];memset(l,0,sizeof(*l));l->v0_idx=(*cursor)++;l->v1_idx=(*cursor)++;l->prev_id0=l->prev_id1=l->next_id0=l->next_id1=-1;l->hi_flags=1<<kind;l->lo_flags=kind==0?LINE_FLAG_LEDGE:0;t->line[kind==3?1:0]=id;float x=(t->p[0].x+t->p[1].x+t->p[2].x)/3,y=(t->p[0].y+t->p[1].y+t->p[2].y)/3;points[l->v0_idx].x=(x-1)/s;points[l->v0_idx].y=y/s;points[l->v1_idx].x=(x+1)/s;points[l->v1_idx].y=y/s;joint->ranges[kind].count++;}}
 joint->vtx_count=*cursor-joint->vtx_start;data.vert_count=*cursor;data.joint_count=current->joints+1;
 /* Onett has no global dynamic range. Use its spare loader range only to
  * initialise appended CollLine records; runtime joint groups remain typed. */
 data.ranges[MapLineGroup_Dynamic].start=first;data.ranges[MapLineGroup_Dynamic].count=data.line_count-first;
 fprintf(stderr,"M3D ONETT OVERLAY COLLISION appended_lines=%d appended_joint=%d original_ids_preserved=1\n",data.line_count-first,current->joints);
}
static void overlay_slice_triangle(int index,Vec3* pos,float lx,float lz,float x0,CollVtx* v,CollLine* c){if(overlay_degenerate&&overlay_degenerate[index])return;RefOverlayTriangle* t=&overlay_triangles[index];Vec3 p[6];int n=0;for(int k=0;k<3;k++){Vec3 a=t->p[k],b=t->p[(k+1)%3];float da=-(a.x-pos->x)*lz+(a.z-pos->z)*lx,db=-(b.x-pos->x)*lz+(b.z-pos->z)*lx;if(fabsf(da)<.0001f)da=0;if(fabsf(db)<.0001f)db=0;if(da==0)p[n++]=a;if(da*db<0){float f=da/(da-db);p[n++]=(Vec3){a.x+f*(b.x-a.x),a.y+f*(b.y-a.y),a.z+f*(b.z-a.z)};}}if(n<2)return;int ia=0,ib=1;float best=0;for(int j=0;j<n;j++)for(int k=j+1;k<n;k++){float dx=p[j].x-p[k].x,dy=p[j].y-p[k].y,dz=p[j].z-p[k].z,d=dx*dx+dy*dy+dz*dz;if(d>best){best=d;ia=j;ib=k;}}Vec2 a={x0+(p[ia].x-pos->x)*lx+(p[ia].z-pos->z)*lz,p[ia].y},b={x0+(p[ib].x-pos->x)*lx+(p[ib].z-pos->z)*lz,p[ib].y};float dx=a.x-b.x,dy=a.y-b.y;if(dx*dx+dy*dy<.000001f)return;
 for(int side=0;side<2;side++){int id=t->line[side];if(id<0)continue;MapLine* l=&lines[id];float dot=t->n.x*lx+t->n.z*lz;if((l->hi_flags==4&&dot<=0)||(l->hi_flags==8&&dot>=0))continue;Vec2 u=a,w=b;bool swap=(l->hi_flags==1&&u.x>w.x)||(l->hi_flags==2&&u.x<w.x)||(l->hi_flags==4&&u.y<w.y)||(l->hi_flags==8&&u.y>w.y);if(swap){Vec2 q=u;u=w;w=q;}saved_lines[id]=*l;saved_flags[id]=c[id].flags;for(int k=0;k<2;k++){int vi=k?l->v1_idx:l->v0_idx;saved[vi]=v[vi].pos;previous[vi]=v[vi].prev_pos;}v[l->v0_idx].pos=v[l->v0_idx].prev_pos=u;v[l->v1_idx].pos=v[l->v1_idx].prev_pos=w;c[id].flags=(c[id].flags|LINE_FLAG_ENABLED)&~LINE_FLAG_EMPTY;overlay_live[overlay_live_count++]=id;}
}
static void overlay_slice_node(int id,Vec3* p,float lx,float lz,float x0,CollVtx* v,CollLine* c){RefOverlayNode* n=&overlay_nodes[id];float cx=(n->lo.x+n->hi.x)*.5f-p->x,cz=(n->lo.z+n->hi.z)*.5f-p->z,rx=(n->hi.x-n->lo.x)*.5f,rz=(n->hi.z-n->lo.z)*.5f;if(fabsf(-cx*lz+cz*lx)>rx*fabsf(lz)+rz*fabsf(lx)+.001f)return;if(n->count){for(int i=n->first;i<n->first+n->count;i++)overlay_slice_triangle(overlay_order[i],p,lx,lz,x0,v,c);}else{overlay_slice_node(n->left,p,lx,lz,x0,v,c);overlay_slice_node(n->right,p,lx,lz,x0,v,c);}}
static int overlay_id_compare(const void* a,const void* b){int x=*(const int*)a,y=*(const int*)b;return(x>y)-(x<y);}
static void overlay_build_slice(Vec3* p,float lx,float lz,float x0,CollVtx* v,CollLine* c){
    overlay_live_count=0;overlay_slice_node(0,p,lx,lz,x0,v,c);
    qsort(overlay_live,overlay_live_count,sizeof(int),overlay_id_compare);
    /* Native kind walkers follow next_id0/prev_id0 without a cycle bound.
     * Endpoint tolerance alone can weld tiny overlapping source slices into
     * a cycle. Retain every segment, but only chain strictly forward in its
     * oriented axis: floors +X, ceilings -X, left/right walls -Y/+Y. Enforce
     * reciprocal one-to-one links so reverse walks are the same finite path. */
    /* A valid weld differs by less than .005 in X, so its start lies in
     * the same or adjacent one-unit X cell. Hashing those cells only changes
     * candidate enumeration; retain exact weld/progress tests and ID ties.
     * Static scratch avoids repeated compiler-inserted stack zeroing. */
    static int heads[1024],next_in_cell[REF_LINES];
    memset(heads,-1,sizeof heads);bool indexed=true;
    for(int a=0;a<overlay_live_count;a++){
        int id=overlay_live[a];MapLine* line=&lines[id];
        line->prev_id0=line->prev_id1=line->next_id0=line->next_id1=-1;
        float x=v[line->v0_idx].pos.x;
        if(!isfinite(x)||fabsf(x)>100000000.f){indexed=false;continue;}
        unsigned bucket=(unsigned)(int)floorf(x)&1023u;
        next_in_cell[id]=heads[bucket];heads[bucket]=id;
    }
    for(int a=0;a<overlay_live_count;a++){
        int i=overlay_live[a],best=-1;MapLine* line=&lines[i];
        Vec2 begin=v[line->v0_idx].pos,end=v[line->v1_idx].pos;
        bool horizontal=line->hi_flags<=2;
        float sign=(line->hi_flags==2||line->hi_flags==4)?-1.f:1.f;
        float from=sign*(horizontal?begin.x:begin.y),to=sign*(horizontal?end.x:end.y);
        if(!(to>from))continue;
        float best_distance=1e20f;
        bool local=indexed&&isfinite(end.x)&&fabsf(end.x)<=100000000.f;
        int cell=local?(int)floorf(end.x):0;
        for(int offset=local?-1:0;offset<=(local?1:0);offset++){
            unsigned bucket=(unsigned)(cell+offset)&1023u;
            for(int b=local?heads[bucket]:0;b>=0; b=local?next_in_cell[b]:(b+1<overlay_live_count?b+1:-1)){
                int j=local?b:overlay_live[b];MapLine* next=&lines[j];
                if(i==j||line->hi_flags!=next->hi_flags||next->prev_id0!=-1)continue;
                Vec2 start=v[next->v0_idx].pos,finish=v[next->v1_idx].pos;
                float next_from=sign*(horizontal?start.x:start.y),next_to=sign*(horizontal?finish.x:finish.y);
                if(!(next_to>next_from)||!(next_to>to))continue;
                float dx=end.x-start.x,dy=end.y-start.y;
                if(fabsf(dx)>=.005f||fabsf(dy)>=.005f)continue;
                float distance=dx*dx+dy*dy;
                if(distance<best_distance||(distance==best_distance&&(best<0||j<best))){best=j;best_distance=distance;}
            }
        }
        if(best>=0){line->next_id0=line->next_id1=best;lines[best].prev_id0=lines[best].prev_id1=i;}
    }
}
static void overlay_restore_slice(CollVtx* v,CollLine* c) {
    for(int k=0;k<overlay_live_count;k++){int id=overlay_live[k];MapLine* l=&lines[id];
        for(int j=0;j<2;j++){int vi=j?l->v1_idx:l->v0_idx;v[vi].pos=saved[vi];v[vi].prev_pos=previous[vi];}
        c[id].flags=saved_flags[id];lines[id]=saved_lines[id];}
}
static void overlay_apply_slice(const RefOverlaySlice* entry,CollVtx* v,CollLine* c) {
    overlay_live_count=entry->count;
    for(int k=0;k<entry->count;k++){const RefOverlaySegment* s=&entry->segments[k];int id=s->id;MapLine* l=&lines[id];
        overlay_live[k]=id;saved_lines[id]=*l;saved_flags[id]=c[id].flags;
        int a=l->v0_idx,b=l->v1_idx;saved[a]=v[a].pos;previous[a]=v[a].prev_pos;saved[b]=v[b].pos;previous[b]=v[b].prev_pos;
        *l=s->line;v[l->v0_idx].pos=v[l->v0_idx].prev_pos=s->a;v[l->v1_idx].pos=v[l->v1_idx].prev_pos=s->b;
        c[id].flags=(c[id].flags|LINE_FLAG_ENABLED)&~LINE_FLAG_EMPTY;}
}
static void overlay_evict_slice(RefOverlaySlice* entry) {
    overlay_cache_bytes-=entry->count*sizeof(*entry->segments);free(entry->segments);memset(entry,0,sizeof(*entry));
}
static void overlay_store_slice(RefOverlaySlice* entry,const float key[5],CollVtx* v) {
    overlay_evict_slice(entry);size_t bytes=overlay_live_count*sizeof(*entry->segments);
    if(bytes>OVERLAY_SLICE_BUDGET)return;
    for(int i=0;i<OVERLAY_SLICE_CACHE&&overlay_cache_bytes+bytes>OVERLAY_SLICE_BUDGET;i++)if(&overlay_cache[i]!=entry)overlay_evict_slice(&overlay_cache[i]);
    if(bytes){entry->segments=malloc(bytes);if(!entry->segments)overlay_fail("slice cache allocation");}
    entry->count=overlay_live_count;memcpy(entry->key,key,sizeof entry->key);
    for(int k=0;k<overlay_live_count;k++){int id=overlay_live[k];MapLine* l=&lines[id];entry->segments[k]=(RefOverlaySegment){id,*l,v[l->v0_idx].pos,v[l->v1_idx].pos};}
    entry->valid=true;overlay_cache_bytes+=bytes;
}
static unsigned long long overlay_hash_bytes(unsigned long long hash,const void* data,size_t size) {
    const unsigned char* p=data;for(size_t i=0;i<size;i++)hash=(hash^p[i])*1099511628211ull;return hash;
}
static unsigned long long overlay_slice_signature(CollVtx* v,CollLine* c) {
    unsigned long long hash=1469598103934665603ull;hash=overlay_hash_bytes(hash,&overlay_live_count,sizeof overlay_live_count);
    for(int k=0;k<overlay_live_count;k++){int id=overlay_live[k];MapLine* l=&lines[id];hash=overlay_hash_bytes(hash,&id,sizeof id);hash=overlay_hash_bytes(hash,l,sizeof *l);hash=overlay_hash_bytes(hash,&c[id].flags,sizeof c[id].flags);
        int vi[2]={l->v0_idx,l->v1_idx};for(int j=0;j<2;j++){hash=overlay_hash_bytes(hash,&v[vi[j]].pos,sizeof(Vec2));hash=overlay_hash_bytes(hash,&v[vi[j]].prev_pos,sizeof(Vec2));}}
    return hash;
}
static void overlay_slice(Vec3* p,float lx,float lz,float x0,CollVtx* v,CollLine* c) {
    if(!m3d_ReferenceOverlayActive())return;
    float key[5]={p->x,p->z,lx,lz,x0};unsigned hash=2166136261u;
    for(int i=0;i<5;i++){unsigned bits;memcpy(&bits,&key[i],sizeof bits);hash=(hash^bits)*16777619u;}
    RefOverlaySlice* entry=&overlay_cache[(hash^(hash>>16))&(OVERLAY_SLICE_CACHE-1)];++overlay_cache_requests;
    if(!overlay_cache_off&&entry->valid&&!memcmp(entry->key,key,sizeof key)) {
        ++overlay_cache_hits;
        if(overlay_cache_check){overlay_build_slice(p,lx,lz,x0,v,c);unsigned long long expected=overlay_slice_signature(v,c);overlay_restore_slice(v,c);overlay_apply_slice(entry,v,c);
            if(overlay_slice_signature(v,c)!=expected)overlay_fail("cached slice differs from exact rebuild");++overlay_cache_checks;}
        else overlay_apply_slice(entry,v,c);
    } else {overlay_build_slice(p,lx,lz,x0,v,c);if(!overlay_cache_off)overlay_store_slice(entry,key,v);}
    overlay_successor_prepare();
    if(m3d_match_frame%120==0&&overlay_cache_log_tick!=m3d_match_frame){overlay_cache_log_tick=m3d_match_frame;
        fprintf(stderr,"M3D ONETT SLICE CACHE tick=%d requests=%llu hits=%llu verified=%llu bytes=%zu budget=%u enabled=%d\n",m3d_match_frame,overlay_cache_requests,overlay_cache_hits,overlay_cache_checks,overlay_cache_bytes,OVERLAY_SLICE_BUDGET,!overlay_cache_off);}
 overlay_saved_islands=mpIsland_80458E88;mpIsland* floors=NULL,*ceilings=NULL;int count=0;for(int a=overlay_live_count-1;a>=0;a--){int id=overlay_live[a];MapLine* l=&lines[id];if(l->hi_flags>2)continue;mpIsland* island=&overlay_islands[count++];memset(island,0,sizeof(*island));bool floor=l->hi_flags==1;island->vtx0=floor?l->v0_idx:l->v1_idx;island->vtx1=floor?l->v1_idx:l->v0_idx;Vec2 u=v[island->vtx0].pos,w=v[island->vtx1].pos;island->pos0=(Vec3){u.x,u.y,0};island->pos1=(Vec3){w.x,w.y,0};island->line0=island->line1=id;island->joint_id=current->joints;if(floor){island->next=floors?floors:overlay_saved_islands.floors;floors=island;}else{island->next=ceilings?ceilings:overlay_saved_islands.ceilings;ceilings=island;}}
 if(floors)mpIsland_80458E88.floors=floors;if(ceilings)mpIsland_80458E88.ceilings=ceilings;
 overlay_scope_base=c;overlay_scope_first=current->lines;overlay_scope_end=data.line_count;overlay_scope_epoch=overlay_epoch;
}
unsigned m3d_ReferenceOverlayEndpointScope(int id,bool* verify) {
    unsigned epoch=overlay_scope_epoch;
    if(!epoch||id<overlay_scope_first||id>=overlay_scope_end)return 0;
    *verify=overlay_cache_check;return epoch;
}
bool m3d_ReferenceOverlayAdvanceLine(CollLine** line,int* index,int count) {
    if(!overlay_scope_epoch)return true;
    int id=*line-overlay_scope_base;if(id<overlay_scope_first)return true;
    int next=overlay_successor(id),offset=next-id;
    if(next==65535||offset>=count-*index)return false;
    *line+=offset;*index+=offset;return true;
}

/* Only callback-free scans of a complete static appended range may use this
 * cheap current-next filter. It retains stable-ID order and re-reads flags and
 * raw endpoints immediately before each visit, including after output aliases
 * changed a later line/vertex during an earlier accepted hit. No cached X
 * bounds or geometry snapshots are introduced. */
bool m3d_ReferenceOverlayFloorRange(CollLine* first,int count) {
    if(!overlay_scope_epoch||count<=0)return false;
    int id=first-overlay_scope_base;
    return id>=overlay_scope_first&&id<overlay_scope_end&&count<=overlay_scope_end-id;
}
bool m3d_ReferenceOverlayAdvanceFloor(CollLine** line,int* index,int count,float ax,float bx,int skip) {
    int id=*line-overlay_scope_base,end=id+count-*index;
    int lo=0,hi=overlay_live_count;
    while(lo<hi){int mid=(lo+hi)/2;if(overlay_live[mid]<id)lo=mid+1;else hi=mid;}
    CollVtx* vertices=mpGetGroundCollVtx();
    for(int k=lo;k<overlay_live_count;k++){
        int candidate=overlay_live[k];if(candidate>=end)return false;
        CollLine* next=&overlay_scope_base[candidate];unsigned flags=next->flags;
        if(candidate==skip||!(flags&1)||!(flags&LINE_FLAG_ENABLED)||(flags&LINE_FLAG_EMPTY))continue;
        MapLine* model=next->inner;
        float x0=vertices[model->v0_idx].pos.x,x1=vertices[model->v1_idx].pos.x;
        /* Same strict pairwise predicate as the native source-floor filter;
         * unordered NaNs always survive for the unchanged native math. */
        if((ax<x0&&bx<x0&&ax<x1&&bx<x1)||(ax>x0&&bx>x0&&ax>x1&&bx>x1))continue;
        *index+=candidate-id;*line=next;return true;
    }
    return false;
}

bool m3d_ReferenceSupported(int stage) {
    if(stage<0)return false;
    /* Castle has no coarse fallback: only its verified full mesh is playable. */
    if(stage==4){const char* p=getenv("MELEE3D_NATIVE_CASTLE_OVERLAY");if(!p||!*p)return false;}
    for(unsigned i=0;i<sizeof(ref_stages)/sizeof(*ref_stages);i++)if(ref_stages[i].stage==stage)return true;
    return false;
}
void m3d_ReferenceSelect(int stage) {
    current=NULL;slicing=false;overlay_select(stage);
    if(!m3d_ReferenceSupported(stage))return;
    for(unsigned i=0;i<sizeof(ref_stages)/sizeof(*ref_stages);i++)if(ref_stages[i].stage==stage)current=&ref_stages[i];
}
bool m3d_ReferenceActive(void) {return current!=NULL;}
void m3d_ReferenceDebug(Fighter* fp) {
    if(!current)return;
    int li=fp->coll_data.floor.index;CollLine* c=mpGetGroundCollLine();CollVtx* v=mpGetGroundCollVtx();
    fprintf(stderr,"M3D REFERENCE CONTACT stage=%d slot=%d state=%d floor=%d local=%d pos=%f,%f,%f contact=%f,%f,%f\n",current->stage,fp->player_idx,fp->motion_id,li,slicing,fp->cur_pos.x,fp->cur_pos.y,fp->cur_pos.z,fp->coll_data.contact.x,fp->coll_data.contact.y,fp->coll_data.contact.z);
    if(li>=0 && li<data.line_count)fprintf(stderr,"M3D REFERENCE LINE surface=%d flags=%x saved=%x points=%f,%f;%f,%f\n",li<current->lines?current->line_surfaces[li]:-1,c[li].flags,saved_flags[li],v[lines[li].v0_idx].pos.x,v[lines[li].v0_idx].pos.y,v[lines[li].v1_idx].pos.x,v[lines[li].v1_idx].pos.y);
#ifndef _WIN32
    void* stack[20];int n=backtrace(stack,20);backtrace_symbols_fd(stack,n,2);
#endif
}

MapCollData* m3d_ReferenceCollision(MapCollData* original) {
    if(m3d_DelfinoActive())return m3d_DelfinoCollision(original);
    if(!current)return original;
    if(!original || original->line_count!=current->lines || original->joint_count!=current->joints ||
        original->line_count>REF_LINES || original->joint_count>REF_JOINTS) {
        fprintf(stderr,"M3D LAB FAIL canonical collision topology stage=%d actual=%d,%d expected=%d,%d\n",current->stage,original?original->line_count:-1,original?original->joint_count:-1,current->lines,current->joints);abort();
    }
    data=*original;
    MapLine* source_lines=DP(MapLine,original->lines);
    MapJoint* source_joints=DP(MapJoint,original->joints);
    DiscVec2* source_points=DP(DiscVec2,original->verts);
    memcpy(lines,source_lines,current->lines*sizeof(*lines));
    memcpy(joints,source_joints,current->joints*sizeof(*joints));
    int cursor=0;
    for(int j=0;j<current->joints;j++) {
        joints[j].vtx_start=cursor;
        for(int g=0;g<MapLineGroup_Count;g++)for(int k=0;k<joints[j].ranges[g].count;k++) {
            int id=joints[j].ranges[g].start+k;
            /* A line belongs to one original joint/range. Keep its public id,
             * duplicate endpoints so unrelated depth surfaces never drag a
             * shared 2D vertex onto another platform. */
            if(cursor+2>REF_VERTS)abort();
            for(int k=0;k<2;k++) {
                int source=k ? source_lines[id].v1_idx:source_lines[id].v0_idx;
                points[cursor]=source_points[source];source_indices[cursor]=source-source_joints[j].vtx_start;
                base_points[cursor]=(Vec2){source_points[source].x,source_points[source].y};
                if(k)lines[id].v1_idx=cursor++;else lines[id].v0_idx=cursor++;
            }
        }
        joints[j].vtx_count=cursor-joints[j].vtx_start;
    }
    data.vert_count=cursor;overlay_collision(&cursor);
    DP_SET(data.verts,points);DP_SET(data.lines,lines);DP_SET(data.joints,joints);
    fprintf(stderr,"M3D REFERENCE STAGE id=%d surfaces=%d lines=%d joints=%d vertices=%d\n",current->stage,current->count,current->lines,current->joints,cursor);
    return &data;
}
static void transforms(void) {
    CollJoint* joint=mpGetGroundCollJoint();
    for(int i=0;i<current->count;i++) {
        const RefSurface* s=&current->surfaces[i];
        scale[i]=Ground_801C0498();translation[i]=(Vec3){0,0,0};
        if(s->joint>=0 && s->joint<current->joints && joint && joint[s->joint].jobj) {
            HSD_JObj* p=joint[s->joint].jobj;HSD_JObjSetupMatrix(p);
            scale[i]=p->mtx[0][0];
            translation[i]=(Vec3){p->mtx[0][3],p->mtx[1][3],p->mtx[2][3]};
        }
        if(scale[i]<=.00001f)scale[i]=Ground_801C0498();
    }
}
static void center(const RefSurface* s,float* x,float* z) {
    *x=*z=0;
    for(int i=0;i<s->count;i++){*x+=s->points[i][0];*z+=s->points[i][1];}
    *x/=s->count;*z/=s->count;
}
/* Even/odd intersections preserve gaps on concave authored polygons. Select
 * the connected interval nearest this owner; never bridge a pit. */
static bool chord(int id,Vec3* pos,float lx,float lz,float radial,float offset,float* lo,float* hi) {
    const RefSurface* s=&current->surfaces[id];float cx,cz,hits[256];int n=0;
    center(s,&cx,&cz);
    for(int i=0;i<s->count;i++) {
        int j=(i+1)%s->count;
        float ax=((s->points[i][0]-cx)*radial+cx+offset)*scale[id]+translation[id].x-pos->x;
        float az=((s->points[i][1]-cz)*radial+cz)*scale[id]+translation[id].z-pos->z;
        float bx=((s->points[j][0]-cx)*radial+cx+offset)*scale[id]+translation[id].x-pos->x;
        float bz=((s->points[j][1]-cz)*radial+cz)*scale[id]+translation[id].z-pos->z;
        float a=-ax*lz+az*lx,b=-bx*lz+bz*lx;
        if((a<=0 && b>0)||(b<=0 && a>0)) {
            float t=a/(a-b),q=(ax+t*(bx-ax))*lx+(az+t*(bz-az))*lz;
            int k=n;while(k>0 && hits[k-1]>q){hits[k]=hits[k-1];k--;}hits[k]=q;n++;
        }
    }
    if(n<2 || (n&1))return false;
    float best=1e30f;
    for(int i=0;i<n;i+=2) {
        float d=hits[i]>0 ? hits[i]:hits[i+1]<0 ? -hits[i+1]:0;
        if(d<best){best=d;*lo=hits[i];*hi=hits[i+1];}
    }
    return true;
}
static void profile(const RefSurface* s,float depth,float* radial,float* offset) {
    *radial=1;*offset=0;
    if(!s->profile_count)return;
    int j=0;
    while(j+1<s->profile_count && s->profile[j+1][0]<depth)j++;
    int k=j+1<s->profile_count ? j+1:j;
    float d=s->profile[k][0]-s->profile[j][0];
    float t=d>0 ? fmaxf(0,fminf(1,(depth-s->profile[j][0])/d)):0;
    *radial=s->profile[j][1]+t*(s->profile[k][1]-s->profile[j][1]);
    *offset=s->profile[j][2]+t*(s->profile[k][2]-s->profile[j][2])-s->profile[0][2];
}
static Vec2 source_point(int si,int vertex,float world_z) {
    const RefSurface* s=&current->surfaces[si];
    CollVtx* v=mpGetGroundCollVtx();
    Vec2 point=slicing ? saved[vertex]:v[vertex].pos;
    int index=source_indices[vertex];
    if((s->flags&32) && s->morph && index>=0 && index<s->morph_count) {
        float z=(world_z-translation[si].z)/scale[si];
        float den=s->morph_z[1]-s->morph_z[0];
        float t=den>0 ? fmaxf(0,fminf(1,(z-s->morph_z[0])/den)):0;
        point.x=(base_points[vertex].x+t*(s->morph[index][0]-base_points[vertex].x))*scale[si]+translation[si].x;
        point.y=(base_points[vertex].y+t*(s->morph[index][1]-base_points[vertex].y))*scale[si]+translation[si].y;
    }
    return point;
}
static bool floor_line(int si,int li,float z,Vec2* a,Vec2* b) {
    *a=source_point(si,lines[li].v0_idx,z);*b=source_point(si,lines[li].v1_idx,z);
    const RefSurface* surface=&current->surfaces[si];
    float authored=surface->height*scale[si]+translation[si].y;
    if(fabsf(a->y-b->y)<.1f && fabsf(a->y-authored)<scale[si])a->y=b->y=authored;
    return fabsf(a->x-b->x)>.00001f;
}
static int connected_line(int li,int other,bool next,CollLine* flags,CollVtx* v) {
    if(other<0 || other>=data.line_count)return -1;
    if(!(flags[other].flags&LINE_FLAG_ENABLED) || (flags[other].flags&(LINE_FLAG_EMPTY|LINE_FLAG_HIDDEN)))return -1;
    Vec2 a=v[next ? lines[li].v1_idx:lines[li].v0_idx].pos;
    Vec2 b=v[next ? lines[other].v0_idx:lines[other].v1_idx].pos;
    float dx=a.x-b.x,dy=a.y-b.y;
    return dx*dx+dy*dy<4 ? other:-1;
}
void m3d_ReferenceSlice(Vec3* pos,float lx,float lz,float x0) {
    CollVtx* v=mpGetGroundCollVtx();CollLine* c=mpGetGroundCollLine();
    if(!current || slicing)abort();transforms();slicing=true;
    memcpy(saved_lines,lines,current->lines*sizeof(*lines));
    for(int i=0;i<current->lines*2;i++){saved[i]=v[i].pos;previous[i]=v[i].prev_pos;}
    CollJoint* joint=mpGetGroundCollJoint();
    for(int j=0;j<data.joint_count;j++) {
        saved_min[j]=joint[j].bounding_min;saved_max[j]=joint[j].bounding_max;saved_joint_flags[j]=joint[j].flags;
        joint[j].bounding_min=(Vec2){-200000,-200000};joint[j].bounding_max=(Vec2){200000,200000};
        joint[j].flags&=~CollJoint_TooFar;
    }
    for(int li=0;li<current->lines;li++) {
        saved_flags[li]=c[li].flags;
        int si=current->line_surfaces[li];const RefSurface* s=&current->surfaces[si];
        if(overlay_mask_original(si,&c[li]))continue;
        float cx=(s->source_x[0]+s->source_x[1])*.5f,hw=(s->source_x[1]-s->source_x[0])*.5f;
        int vi[2]={lines[li].v0_idx,lines[li].v1_idx};bool hit=true;
        if(lines[li].hi_flags&1) {
            /* Floor profiles stay aligned to the world, not the fighter.
             * Intersect their source X strip with the authored XZ polygon;
             * a depth-facing player therefore sees the same roof slope. */
            Vec2 a,b;float lo=0,hi=0;
            hit=floor_line(si,li,pos->z,&a,&b) && chord(si,pos,lx,lz,1,0,&lo,&hi);
            float xmin=fminf(a.x,b.x),xmax=fmaxf(a.x,b.x);
            if(fabsf(lx)<.00001f)hit=hit && pos->x>=xmin-.001f && pos->x<=xmax+.001f;
            else {
                float t0=(xmin-pos->x)/lx,t1=(xmax-pos->x)/lx;
                lo=fmaxf(lo,fminf(t0,t1));hi=fminf(hi,fmaxf(t0,t1));hit=hit && hi-lo>.00001f;
            }
            if(fabsf(a.x-b.x)<.00001f)b.x=a.x+.01f;
            for(int k=0;k<2;k++) {
                float t=k ? hi:lo,world_x=pos->x+t*lx;
                v[vi[k]].pos=(Vec2){x0+t,a.y+(world_x-a.x)/(b.x-a.x)*(b.y-a.y)};
                v[vi[k]].prev_pos=v[vi[k]].pos;
            }
        } else for(int k=0;k<2;k++) {
            int idx=vi[k];float radial,offset,lo=0,hi=0;
            float local_y=(saved[idx].y-translation[si].y)/scale[si];
            profile(s,s->height-local_y,&radial,&offset);
            if(radial<.0001f)radial=.0001f;
            bool found=chord(si,pos,lx,lz,radial,offset,&lo,&hi);hit=hit&&found;
            float local_x=(saved[idx].x-translation[si].x)/scale[si];
            float u=hw>.0001f ? (local_x-cx-offset)/(hw*radial):0;
            u=fmaxf(-1,fminf(1,u));
            v[idx].pos.x=x0+(lo+hi)*.5f+u*(hi-lo)*.5f;
            if((lines[li].hi_flags&1) && fabsf(local_y-s->height)<1)
                v[idx].pos.y=s->height*scale[si]+translation[si].y;
            v[idx].prev_pos=v[idx].pos;
        }
        float ddx=v[vi[0]].pos.x-v[vi[1]].pos.x,ddy=v[vi[0]].pos.y-v[vi[1]].pos.y;
        if(!hit || ddx*ddx+ddy*ddy<.000001f) {
            c[li].flags=(c[li].flags|LINE_FLAG_EMPTY)&~LINE_FLAG_ENABLED;
            /* An absent face is disabled, not transported. Native cached
             * ledge/ground bookkeeping must never see a 100000-unit jump or
             * a zero-length line while transitioning into a fall. */
            for(int k=0;k<2;k++) {v[vi[k]].pos=saved[vi[k]];v[vi[k]].prev_pos=previous[vi[k]];}
        } else for(int k=0;k<2;k++) {
            int idx=vi[k];
            /* Keep the native joint/line motion in the borrowed plane. Static
             * slice shape changes are not platform motion, but discarding
             * this delta makes mpGetSpeed report zero for moving floors. */
            v[idx].prev_pos.x=v[idx].pos.x+(previous[idx].x-saved[idx].x)*lx;
            v[idx].prev_pos.y=v[idx].pos.y+previous[idx].y-saved[idx].y;
        }
    }
    /* Native next_id0/prev_id0 walks assume a permanently connected 2D
     * outline and do not check the next line's enable flag. Slice clipping
     * can remove that neighbour or split a shared vertex. Scope the graph
     * too, otherwise a valid landing can walk onto an absent floor face. */
    for(int i=0;i<current->lines;i++) {
        lines[i].prev_id0=connected_line(i,saved_lines[i].prev_id0,false,c,v);
        lines[i].next_id0=connected_line(i,saved_lines[i].next_id0,true,c,v);
        lines[i].prev_id1=connected_line(i,saved_lines[i].prev_id1,false,c,v);
        lines[i].next_id1=connected_line(i,saved_lines[i].next_id1,true,c,v);
    }
    /* Native island updates rewire complete static/dynamic/free lists.
     * Finish them before temporarily prepending our query-only islands. */
    for(int j=0;j<current->joints;j++)mpLib_8005667C(j);
    overlay_slice(pos,lx,lz,x0,v,c);
}
void m3d_ReferenceEnd(void) {
    overlay_scope_epoch=0;
    if(!slicing)return;
    CollVtx* v=mpGetGroundCollVtx();CollLine* c=mpGetGroundCollLine();
    for(int i=0;i<current->lines*2;i++){v[i].pos=saved[i];v[i].prev_pos=previous[i];}
    for(int i=0;i<current->lines;i++)c[i].flags=saved_flags[i];
    memcpy(lines,saved_lines,current->lines*sizeof(*lines));
    if(m3d_ReferenceOverlayActive())for(int j=0;j<overlay_live_count;j++) {
        int i=overlay_live[j];MapLine* l=&lines[i];for(int k=0;k<2;k++){int vi=k?l->v1_idx:l->v0_idx;v[vi].pos=saved[vi];v[vi].prev_pos=previous[vi];}
        c[i].flags=saved_flags[i];lines[i]=saved_lines[i];
    }
    CollJoint* joint=mpGetGroundCollJoint();
    for(int j=0;j<data.joint_count;j++){joint[j].bounding_min=saved_min[j];joint[j].bounding_max=saved_max[j];joint[j].flags=saved_joint_flags[j];}
    if(m3d_ReferenceOverlayActive())mpIsland_80458E88=overlay_saved_islands;
    slicing=false;for(int j=0;j<current->joints;j++)mpLib_8005667C(j);
}
static bool surface_enabled(int i) {
    if(overlay_replaces_surface(i))return false;
    CollJoint* joint=mpGetGroundCollJoint();int j=current->surfaces[i].joint;
    return j<0 || !joint || ((joint[j].flags&CollJoint_Enabled) && !(joint[j].flags&CollJoint_Hidden));
}
static bool line_enabled(int li) {
    CollLine* c=mpGetGroundCollLine();
    unsigned flags=slicing ? saved_flags[li]:c[li].flags;
    return (lines[li].hi_flags&1) && (flags&LINE_FLAG_ENABLED) && !(flags&(LINE_FLAG_HIDDEN|LINE_FLAG_EMPTY));
}
static float surface_floor(int i,Vec3* pos) {
    float lo,hi,highest=-1e30f;
    if(!surface_enabled(i) || !chord(i,pos,1,0,1,0,&lo,&hi) || lo>0 || hi<0)return highest;
    for(int k=0;k<current->lines;k++) {
        if(current->line_surfaces[k]!=i || !line_enabled(k))continue;
        Vec2 a,b;if(!floor_line(i,k,pos->z,&a,&b))continue;
        if(pos->x<fminf(a.x,b.x)-.001f || pos->x>fmaxf(a.x,b.x)+.001f)continue;
        float y=a.y+(pos->x-a.x)/(b.x-a.x)*(b.y-a.y);
        if(y<=pos->y+.1f && y>highest)highest=y;
    }
    return highest;
}
bool m3d_ReferenceFloor(Vec3* pos,Vec3* ground) {
    if(!current)return false;transforms();float highest=-1e30f;
    for(int i=0;i<current->count;i++)highest=fmaxf(highest,surface_floor(i,pos));
    if(m3d_ReferenceOverlayActive())highest=overlay_height(0,pos,highest);
    if(highest<-1e29f)return false;*ground=*pos;ground->y=highest;return true;
}
static bool nearest_ledge(Vec3* pos,Vec3* goal,float* nx,float* nz) {
    if(!current)return false;transforms();float best=1e30f;
    if(m3d_ReferenceOverlayActive())overlay_nearest_ledge(pos,goal,nx,nz,&best);
    for(int i=0;i<current->count;i++) {
        const RefSurface* s=&current->surfaces[i];
        if((s->flags&2) || !surface_enabled(i))continue;
        float area=0;
        for(int j=0;j<s->count;j++){int k=(j+1)%s->count;area+=s->points[j][0]*s->points[k][1]-s->points[k][0]*s->points[j][1];}
        for(int j=0;j<s->count;j++) {
            int k=(j+1)%s->count;
            Vec3 a={s->points[j][0]*scale[i]+translation[i].x,s->height*scale[i]+translation[i].y,s->points[j][1]*scale[i]+translation[i].z};
            Vec3 b={s->points[k][0]*scale[i]+translation[i].x,a.y,s->points[k][1]*scale[i]+translation[i].z};
            float dx=b.x-a.x,dz=b.z-a.z,den=dx*dx+dz*dz;
            if(den<.000001f)continue;
            float t=den>0 ? fmaxf(0,fminf(1,((pos->x-a.x)*dx+(pos->z-a.z)*dz)/den)):0;
            Vec3 q={a.x+t*dx,a.y,a.z+t*dz};
            float sign=area>0 ? 1:-1,len=sqrtf(den),ix=-sign*dz/len,iz=sign*dx/len;
            /* An authored edge is a usable ledge only while its native floor
             * is present. Query just inside it, including roof height. */
            Vec3 inside={q.x+ix*.05f,10000,q.z+iz*.05f};
            float y=surface_floor(i,&inside);if(y<-1e29f)continue;q.y=y;
            float dist=(q.x-pos->x)*(q.x-pos->x)+(q.y-pos->y)*(q.y-pos->y)+(q.z-pos->z)*(q.z-pos->z);
            if(dist<best){best=dist;*goal=q;if(nx)*nx=ix;if(nz)*nz=iz;}
        }
    }
    return best<1e29f;
}
bool m3d_ReferenceLedge(Vec3* pos,Vec3* goal) {return nearest_ledge(pos,goal,NULL,NULL);}
bool m3d_ReferenceInward(Vec3* pos,float* nx,float* nz) {Vec3 goal;return nearest_ledge(pos,&goal,nx,nz);}
bool m3d_ReferenceSurfacePoint(int index,Vec3* point) {
    if(!current || index<0 || index>=current->count)return false;transforms();
    float x,z;center(&current->surfaces[index],&x,&z);
    *point=(Vec3){x*scale[index]+translation[index].x,10000,z*scale[index]+translation[index].z};
    float y=surface_floor(index,point);if(y<-1e29f)return false;point->y=y;return true;
}
/* Atlas fixture only: live floor samples, inset from authored perimeter.
 * Reject the sentinel catch-all floor used by Mute City. These positions
 * illustrate collision scale; they do not certify reachability. */
int m3d_ReferenceAtlasPoints(Vec3* points,int capacity) {
    if(!current || !getenv("MELEE3D_NATIVE_GAMEPLAY_CAPTURE"))return 0;
    transforms();int n=0;
    for(int i=0;i<current->count;i++) {
        const RefSurface* s=&current->surfaces[i];float cx,cz;center(s,&cx,&cz);
        bool sentinel=false;
        for(int k=0;k<s->count;k++)if(fabsf(s->points[k][0])>2000 || fabsf(s->points[k][1])>2000)sentinel=true;
        if(sentinel || !surface_enabled(i))continue;
        /* Green Greens encodes falling/destructible block joints in these
         * flags. Keep stable terrain for a standing scale reference. */
        if(current->stage==17 && (s->flags&0xff00))continue;
        for(int k=-1;k<s->count&&n<capacity;k++) {
            float x=k<0?cx:s->points[k][0]*.82f+cx*.18f;
            float z=k<0?cz:s->points[k][1]*.82f+cz*.18f;
            Vec3 q={x*scale[i]+translation[i].x,10000,z*scale[i]+translation[i].z};
            float y=surface_floor(i,&q);if(y<-1e29f)continue;q.y=y;
            if(Stage_IsOutsideBlastZoneWithMargin(&q,15) || q.z<Stage_GetBlastZoneLeftOffset()+15 || q.z>Stage_GetBlastZoneRightOffset()-15)continue;
            bool duplicate=false;
            for(int j=0;j<n;j++)if(hypotf(q.x-points[j].x,q.z-points[j].z)<3&&fabsf(q.y-points[j].y)<3)duplicate=true;
            if(!duplicate)points[n++]=q;
        }
    }
    return n;
}
bool m3d_ReferenceMotion(int line,Vec3* point,Vec3* velocity) {
    if(!current || !slicing || line<0 || line>=data.line_count)return false;
    int a=lines[line].v0_idx,b=lines[line].v1_idx;
    /* The native mpRemap2d endpoint interpolation, before projection into a
     * fighter's plane. Carry must include motion perpendicular to that plane. */
    double dx=previous[b].x-previous[a].x,dy=previous[b].y-previous[a].y,den=dx*dx+dy*dy;
    if(den<.0001)return false;
    double t=(dx*(point->x-previous[a].x)+dy*(point->y-previous[a].y))/den;
    t=fmax(0,fmin(1,t));
    *velocity=(Vec3){(1-t)*(saved[a].x-previous[a].x)+t*(saved[b].x-previous[b].x),
                    (1-t)*(saved[a].y-previous[a].y)+t*(saved[b].y-previous[b].y),0};
    return true;
}
void m3d_ReferenceTestTranslate(int index,float dx) {
    if(!getenv("MELEE3D_NATIVE_PLATFORM") || !current || index<0 || index>=current->count)return;
    int j=current->surfaces[index].joint;CollJoint* joint=mpGetGroundCollJoint();
    if(j>=0 && joint[j].jobj)HSD_JObjSetTranslateX(joint[j].jobj,joint[j].jobj->translate.x+dx);
}

/* Render the native animated texture onto the same authored polygon/native
 * floor profiles used by collision. Triangulation is generated with ear
 * clipping, so concave courtyards do not gain phantom receivers across gaps. */
static float strip_distance(int si,int li,Vec3 p,int side) {
    Vec2 a,b;if(!floor_line(si,li,p.z,&a,&b))return -1;
    return side ? fmaxf(a.x,b.x)-p.x:p.x-fminf(a.x,b.x);
}
static int clip_strip(int si,int li,Vec3* input,int count,Vec3* output,int side) {
    int n=0;
    for(int i=0;i<count;i++) {
        Vec3 a=input[i],b=input[(i+1)%count];float da=strip_distance(si,li,a,side),db=strip_distance(si,li,b,side);
        if(da>=0)output[n++]=a;
        if((da>=0)!=(db>=0)) {float t=da/(da-db);output[n++]=(Vec3){a.x+t*(b.x-a.x),0,a.z+t*(b.z-a.z)};}
    }
    return n;
}
void m3d_ReferenceShadow(HSD_Shadow* shadow) {
    if(!current || !shadow || !shadow->texture)return;transforms();
    for(int si=0;si<current->count;si++) {
        const RefSurface* s=&current->surfaces[si];if(!surface_enabled(si))continue;
        for(int li=0;li<current->lines;li++) {
            if(current->line_surfaces[li]!=si || !line_enabled(li))continue;
            for(int ti=0;ti<s->triangle_count;ti++) {
                Vec3 p[8],q[8];
                for(int k=0;k<3;k++) {int v=s->triangles[ti][k];p[k]=(Vec3){s->points[v][0]*scale[si]+translation[si].x,0,s->points[v][1]*scale[si]+translation[si].z};}
                int n=clip_strip(si,li,p,3,q,0);if(n<3)continue;n=clip_strip(si,li,q,n,p,1);if(n<3)continue;
                float u[8],v[8],u0=1e30f,u1=-1e30f,v0=1e30f,v1=-1e30f;bool valid=true;
                for(int k=0;k<n;k++) {
                    Vec2 a,b;if(!floor_line(si,li,p[k].z,&a,&b)){valid=false;break;}p[k].y=a.y+(p[k].x-a.x)/(b.x-a.x)*(b.y-a.y)+.03f;
                    u[k]=shadow->texture->mtx[0][0]*p[k].x+shadow->texture->mtx[0][1]*p[k].y+shadow->texture->mtx[0][2]*p[k].z+shadow->texture->mtx[0][3];
                    v[k]=shadow->texture->mtx[1][0]*p[k].x+shadow->texture->mtx[1][1]*p[k].y+shadow->texture->mtx[1][2]*p[k].z+shadow->texture->mtx[1][3];
                    u0=fminf(u0,u[k]);u1=fmaxf(u1,u[k]);v0=fminf(v0,v[k]);v1=fmaxf(v1,v[k]);
                }
                if(!valid || u1<0 || u0>1 || v1<0 || v0>1)continue;
                GXBegin(GX_TRIANGLEFAN,GX_VTXFMT0,n);
                for(int k=0;k<n;k++){GXPosition3f32(p[k].x,p[k].y,p[k].z);GXColor4u8(255,255,255,255);GXTexCoord2f32(u[k],v[k]);}
                GXEnd();
            }
        }
    }
}
void m3d_ReferenceSpawn(Vec3* center_pos,float* radius) {
    if(!current)return;transforms();float best=-1;int main=current->count-1;
    for(int i=0;i<current->count;i++)if(current->surfaces[i].main){main=i;break;}
    const RefSurface* s=&current->surfaces[main];float cx,cz;center(s,&cx,&cz);
    *center_pos=(Vec3){cx*scale[main]+translation[main].x,s->height*scale[main]+translation[main].y,cz*scale[main]+translation[main].z};
    best=1e30f;
    for(int i=0;i<16;i++){float a=i*6.283185307f/16,lo,hi;if(chord(main,center_pos,sinf(a),cosf(a),1,0,&lo,&hi))best=fminf(best,fminf(-lo,hi));}
    *radius=fmaxf(5,fminf(40,best*.65f));
}

bool m3d_ReferenceDrop(Vec3* pos) {
    if(!current)return false;
    /* Overlay navigation is the playable source geometry. The native backing
     * reference can be a tiny topology placeholder (Castle), so never use its
     * bounds for map-wide item drops or fall back there on a failed query. */
    if(m3d_ReferenceOverlayActive()) {
        Vec3 near;float radius;
        if(m3d_ItemDropNear(&near,&radius)&&m3d_DelfinoNavDrop(pos,&near,radius))return true;
        return m3d_DelfinoNavDrop(pos,NULL,0);
    }
    transforms();
    float x0=1e30f,x1=-1e30f,z0=1e30f,z1=-1e30f;
    for(int i=0;i<current->count;i++) {
        const RefSurface* s=&current->surfaces[i];
        for(int j=0;j<s->count;j++) {
            float x=s->points[j][0]*scale[i]+translation[i].x,z=s->points[j][1]*scale[i]+translation[i].z;
            x0=fminf(x0,x);x1=fmaxf(x1,x);z0=fminf(z0,z);z1=fmaxf(z1,z);
        }
    }
    for(int tries=0;tries<128;tries++) {
        Vec3 p={x0+HSD_Randf()*(x1-x0),10000,z0+HSD_Randf()*(z1-z0)},g;
        if(m3d_ReferenceFloor(&p,&g)){*pos=g;pos->y+=40;return true;}
    }
    return false;
}

/* Opt-in integration probe: real native rays through independently selected
 * authored surface points, at three different headings and two match times. */
void m3d_ReferenceValidate(int tick) {
    if(!current)return;transforms();int tested=0,failed=0;
    for(int i=0;i<current->count;i++) {
        const RefSurface* s=&current->surfaces[i];float cx,cz;center(s,&cx,&cz);
        Vec3 p={cx*scale[i]+translation[i].x,s->height*scale[i]+translation[i].y+.2f,cz*scale[i]+translation[i].z},expected;
        if(!m3d_ReferenceFloor(&p,&expected))continue;

        for(int a=0;a<3;a++) {
            float lx=cosf(a*.785398163f),lz=sinf(a*.785398163f);Vec3 top=p,bottom=p,hit={0};int line=-1;u32 flags;
            bottom.y=expected.y-1;top.y=expected.y+1;
            bool began=m3d_MapBegin(&p,&p,lx,lz),ok=false;
            if(began) {
                m3d_MapToLocal(&top);m3d_MapToLocal(&bottom);
                /* This is an instantaneous geometry sample. Remap rays treat
                 * the start as a previous-frame point; a fast falling block
                 * can move that short ray entirely below the current floor. */
                ok=mpCheckAll(&hit,&line,&flags,NULL,-1,-1,top.x,top.y,bottom.x,bottom.y);
                if(ok)m3d_MapToWorld(&hit);m3d_MapEnd(&p);
            }
            tested++;ok=ok && fabsf(hit.y-expected.y)<.15f;
            if(!ok){failed++;fprintf(stderr,"M3D REFERENCE RAY FAIL stage=%d surface=%d angle=%d hit=%d line=%d expected=%.3f actual=%.3f pos=%.3f,%.3f\n",current->stage,i,a,ok,line,expected.y,hit.y,p.x,p.z);}
        }
    }
    fprintf(stderr,"M3D REFERENCE CHECK stage=%d tick=%d tested=%d failed=%d\n",current->stage,tick,tested,failed);
    if(m3d_ReferenceOverlayActive()) {
        int checked=0,errors=0,selected=0,stride=overlay_count/64+1;
        for(int i=0;i<overlay_count;i+=stride) {
            RefOverlayTriangle* t=&overlay_triangles[i];if((overlay_degenerate&&overlay_degenerate[i])||m3d_surface_kind(t->n.y)!=0)continue;
            Vec3 p={(t->p[0].x+t->p[1].x+t->p[2].x)/3,(t->p[0].y+t->p[1].y+t->p[2].y)/3+.2f,(t->p[0].z+t->p[1].z+t->p[2].z)/3},expected;
            if(!m3d_ReferenceFloor(&p,&expected))continue;selected++;
            for(int a=0;a<3;a++) {
                float lx=cosf(a*.785398163f),lz=sinf(a*.785398163f);Vec3 top=p,bottom=p,hit={0};int line=-1;u32 flags;top.y=expected.y+1;bottom.y=expected.y-1;
                bool began=m3d_MapBegin(&p,&p,lx,lz),ok=false;
                if(began){m3d_MapToLocal(&top);m3d_MapToLocal(&bottom);ok=mpCheckAll(&hit,&line,&flags,NULL,-1,-1,top.x,top.y,bottom.x,bottom.y);if(ok)m3d_MapToWorld(&hit);m3d_MapEnd(&p);}
                checked++;if(!ok||fabsf(hit.y-expected.y)>.15f){errors++;fprintf(stderr,"M3D ONETT OVERLAY RAY FAIL triangle=%d angle=%d line=%d expected=%.3f actual=%.3f pos=%.3f,%.3f\n",i,a,line,expected.y,hit.y,p.x,p.z);}
            }
        }
        fprintf(stderr,"M3D ONETT OVERLAY CHECK tick=%d tested=%d failed=%d source_floor_samples=%d\n",tick,checked,errors,selected);
    }

}
