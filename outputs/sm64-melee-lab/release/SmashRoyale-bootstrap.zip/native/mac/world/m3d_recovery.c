#include "pc/m3d_room.h"
/* SPDX-License-Identifier: GPL-3.0-or-later
 * Shared aiming boundary used at the canonical engine's recovery-vector call
 * sites (0x8059e4f4). Native moves retain their speed, duration and collisions. */
#include "m3d.h"
#include "m3d_combat_rules.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <melee/ft/types.h>
#include <melee/ft/fighter.h>
#include <melee/pl/player.h>
#include <sysdolphin/baselib/controller.h>

bool m3d_RecoveryInput(Fighter* fp) {
    if(!fp || !m3d_FighterIs3D(fp) || fp->pad_port>=(m3d_room_enabled()?32:4) || Player_GetPlayerSlotType(fp->player_idx)!=Gm_PKind_Human)return false;
    Vec2 world,cstick;bool throttle;
    if(!m3d_GetMoveInput(fp,&world,&cstick,&throttle))return false;
    float dx=world.x,dz=world.y,mag=sqrtf(dx*dx+dz*dz),phi=.785398185f;
    float cx=cstick.x,cy=cstick.y;
    if(m3d_SeparateAttackInputs()) {
        float horizontal,vertical;
        m3d_combat_spatial_aim(mag,m3d_GetVerticalInput(fp),p_ftCommonData->x218,&horizontal,&vertical);
        if(mag>=p_ftCommonData->x218)m3d_SetLane(fp,fp->facing_dir*dx/mag,fp->facing_dir*dz/mag);
        fp->input.lstick[0].x=horizontal*fp->facing_dir;
        fp->input.lstick[0].y=vertical;
        if(getenv("MELEE3D_NATIVE_RECOVERY")) {
            float lx,lz;m3d_GetLane(fp,&lx,&lz);
            fprintf(stderr,"M3D RECOVERY VECTOR slot=%d state=%d assist=0 pitch=%.5f lane=%.5f,%.5f input=%.5f,%.5f\n",fp->player_idx,fp->motion_id,atan2f(vertical,horizontal),lx,lz,fp->input.lstick[0].x,vertical);
        }
        return true;
    }
    if(m3d_CameraGetMode()==0 && !throttle)cx=cy=0;
    float cmag=sqrtf(cx*cx+cy*cy);Vec3 target,ground;int assisted=0;
    if(throttle && m3d_ReferenceActive() &&
        !m3d_ReferenceFloor(&fp->cur_pos,&ground) && m3d_ReferenceLedge(&fp->cur_pos,&target)) {
        dx=target.x-fp->cur_pos.x;dz=target.z-fp->cur_pos.z;
        float horizontal=sqrtf(dx*dx+dz*dz);
        phi=atan2f(target.y+5*fp->x34_scale.y-fp->cur_pos.y,horizontal);
        mag=1;assisted=1;
    } else if(cmag>.25f) {
        /* Canonical 0.25 deadzone, 0.75 range, atan2(Y,abs(X)); no right
         * stick means 45 degrees. Orbit mode lends it only while R is held. */
        phi=atan2f(cy,fabsf(cx));mag=fmaxf(mag,fminf(1,(cmag-.25f)/.75f));
    }
    float length=sqrtf(dx*dx+dz*dz);
    if(!assisted) {
        float left=length>=p_ftCommonData->x218 ? fminf(1,length):0;
        float right=cmag>.25f ? fminf(1,(cmag-.25f)/.75f):0;
        mag=fmaxf(left,right);if(mag==0)mag=1;
    }
    if(length>.001f)m3d_SetLane(fp,fp->facing_dir*dx/length,fp->facing_dir*dz/length);
    fp->input.lstick[0].x=mag*fp->facing_dir*cosf(phi);
    fp->input.lstick[0].y=mag*sinf(phi);
    if(getenv("MELEE3D_NATIVE_RECOVERY")) {
        float lx,lz;m3d_GetLane(fp,&lx,&lz);
        fprintf(stderr,"M3D RECOVERY VECTOR slot=%d state=%d assist=%d pitch=%.5f lane=%.5f,%.5f input=%.5f,%.5f\n",fp->player_idx,fp->motion_id,assisted,phi,lx,lz,fp->input.lstick[0].x,fp->input.lstick[0].y);
    }
    return true;
}
