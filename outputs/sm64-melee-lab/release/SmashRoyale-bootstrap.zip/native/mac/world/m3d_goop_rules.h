/* SPDX-License-Identifier: GPL-3.0-or-later
 * Deterministic Battle Royale coating. No engine pointers or rendering state.
 * Hits are accepted combat contacts, never inferred from percent changes. */
#ifndef M3D_GOOP_RULES_H
#define M3D_GOOP_RULES_H
#include <math.h>
#include <string.h>
typedef struct {float coat,exposure;int idle,clean_wait,burst_wait,bursts;} M3dGoop;
static float m3d_goop_clamp(float x){return fmaxf(0,fminf(1,x));}
/* A lopsided front reaches low ground before it climbs facades and roofs.
 * The district centre changes with the shared match seed; height is in the
 * same donor-scaled world units as collision and rendering. */
static unsigned m3d_goop_hash(unsigned n){n^=n>>16;n*=0x7feb352du;n^=n>>15;n*=0x846ca68bu;return n^(n>>16);}
static float m3d_goop_noise(float x,float z) {
    int ix=(int)floorf(x),iz=(int)floorf(z);float u=x-ix,v=z-iz,q[4];u=u*u*(3-2*u);v=v*v*(3-2*v);
    for(int k=0;k<4;k++)q[k]=(m3d_goop_hash((unsigned)(ix+(k&1))*73856093u^(unsigned)(iz+(k>>1))*19349663u)&65535)/32767.5f-1;
    return (q[0]+u*(q[1]-q[0]))*(1-v)+(q[2]+u*(q[3]-q[2]))*v;
}
static float m3d_goop_field(float x,float y,float z,float cx,float cz,float radius,float width,float street) {
    /* Fixed world-space growth ranks form fingers and disconnected early
     * patches. The ranks never animate, so a receding front cannot unpaint
     * ground. Wet highlights/UV flow animate separately. */
    float lobes=35+65*m3d_goop_noise((x+cz*.2f)*.012f,(z+cx*.2f)*.012f)+22*m3d_goop_noise(x*.043f,z*.043f);
    float advance=hypotf(x-cx,z-cz)-radius-lobes;
    float height=street+8+advance*1.25f;
    return fminf(advance/width,(height-y)/24);
}
static float m3d_goop_depth(float x,float y,float z,float cx,float cz,float radius,float width,float street) {
    return m3d_goop_clamp(m3d_goop_field(x,y,z,cx,cz,radius,width,street));
}
/* Castle is a climb from its garden to the highest tower. Keep seeded
 * district fingers on the grass early, cap every column at a shared rising
 * height, then consume the retained district too. The summit reaches full
 * depth at the end of the same contraction clock; it cannot stay clean just
 * because its XZ lies inside the final radius. */
static float m3d_goop_castle_phase(int tick,int duration) {
    return m3d_goop_clamp(((float)tick-1200)/(duration>0?(float)duration:1));
}
static float m3d_goop_castle_field(float x,float y,float z,float cx,float cz,float radius,float width,float street,float peak,int tick,int duration) {
    float phase=m3d_goop_castle_phase(tick,duration);
    float climb=m3d_goop_clamp((phase-.25f)/.75f);
    float ceiling=street-24+(fmaxf(peak,street)-street+48)*climb;
    /* Fingers can lead the rising fill on low surfaces. Their lead closes
     * before the upper roofs, so every final district reaches the summit
     * last rather than preserving a permanent clean vertical cylinder. */
    float lead=24*m3d_goop_clamp(fminf(phase/.25f,(.75f-phase)/.5f));
    float cap=(ceiling+lead-y)/24;
    float radial=m3d_goop_field(x,y,z,cx,cz,radius,width,street);
    float lag=24*m3d_goop_clamp(fminf((phase-.25f)/.125f,(.75f-phase)/.5f));
    float rank=.5f+.5f*m3d_goop_noise((x+cx*.6f)*.012f,(z+cz*.6f)*.012f);
    float fill=(ceiling-lag*rank-y)/24;
    return fminf(cap,fmaxf(radial,fill));
}
static void m3d_goop_contact(M3dGoop* attacker,M3dGoop* victim) {
    attacker->idle=victim->idle=0;
    if(!attacker->clean_wait){attacker->coat=fmaxf(0,attacker->coat-.24f);attacker->clean_wait=12;}
}
static void m3d_goop_step(M3dGoop* g,int active,int touching,float depth,int outside) {
    if(!active){memset(g,0,sizeof(*g));return;}
    if(g->clean_wait)g->clean_wait--;if(g->burst_wait)g->burst_wait--;
    if(g->idle<36000)g->idle++;
    /* 15 seconds without a hit given OR received starts coating even in the
     * clean district. Walking laps or swinging at empty air cannot reset it. */
    float idle=g->idle>900?fminf(.06f,(g->idle-900)/15000.f):0;
    float pickup=outside&&touching?(.08f+.22f*depth):0;
    g->coat=m3d_goop_clamp(g->coat+(idle+pickup)/60);
    /* Exposure belongs to the advancing hazard, not to coating: trading
     * jabs outside cannot cancel the burning/explosive edge indefinitely. */
    g->exposure=outside?fminf(30,g->exposure+(touching?1:.5f)/60):fmaxf(0,g->exposure-3.f/60);
}
static float m3d_goop_speed(const M3dGoop* g){return 1-.22f*g->coat;}
static float m3d_goop_gravity(const M3dGoop* g){return 1+.18f*g->coat;}
static float m3d_goop_burn(const M3dGoop* g,float depth,int outside){
    if(g->idle>=1920&&g->coat>=.5f)return fmaxf(2+6*depth,2+fminf(6,(g->idle-1920)/600.f));
    return outside&&(depth>.4f||g->exposure>=4)?2+6*depth:0;
}
static int m3d_goop_explosive(const M3dGoop* g,float depth,int outside,int touching){
    return !g->burst_wait&&((outside&&depth>=.95f&&g->exposure>=3&&(touching||g->exposure>=6))||(g->idle>=2700&&g->coat>=.95f));
}
static void m3d_goop_burst(M3dGoop* g){g->burst_wait=120;g->bursts++;}
#endif
