#include "pc/m3d_room.h"
#include <pc/m3d_akaneia.h>
/* Native source port of the shared melee3d overlay; first stage gate: FD. */
/// melee3d: generic 3D movement ("rotating lane") for every fighter.
///
/// Each fighter keeps Melee's original 2D simulation. We give it a lane: a
/// unit vector (lx, lz) in the XZ plane. Whatever horizontal displacement the
/// 2D sim produces along X is applied along the lane instead, so cur_pos is
/// the fighter's true world position. Facing (+-1) keeps its meaning relative
/// to the lane, so every move, special and animation works unchanged.
///
/// Nothing in here is character-specific.

#include "m3d_combat_rules.h"
#include <melee/lb/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "m3d.h"
#include <melee/pl/player.h>

#include <dolphin/os.h>
#include <math.h>
#include <melee/ft/ftparts.h>
#include <melee/ft/fighter.h>
#include <melee/ft/kinds/ftCommon/types.h>
#include <melee/ft/inlines.h>
#include <melee/ft/kinds/ftCommon/forward.h>
#include <melee/ft/kinds/ftCommon/ftCo_Attack100.h>
#include <melee/ft/kinds/ftCommon/ftCo_0A01.h>
#include <melee/ft/types.h>
#include <melee/gr/forward.h>
#include <melee/gr/ground.h>
#include <melee/gr/stage.h>
#include <melee/gr/types.h>
#include <melee/mp/mplib.h>
#include <melee/mp/types.h>
#include <sysdolphin/baselib/controller.h>
#include <sysdolphin/baselib/jobj.h>
#include <sysdolphin/baselib/gobj.h>

#define M3D_PI 3.14159265f
#define M3D_DEG (M3D_PI / 180.0f)

/* Tunables */
static float const m3d_stick_deadzone = 0.2875f;
static float const m3d_back_cos = -0.17f;          /* > ~100 deg = "back" */
static float const m3d_air_turn = 4.0f * M3D_DEG; /* per frame */
static float const m3d_attack_turn = 6.0f * M3D_DEG; /* full stick */
static float const m3d_up_tilt_y = 0.5f;           /* below tap-jump 0.5625 */
static float const m3d_flat_scale = 60.0f;

typedef struct M3dFt {
    Fighter* fp;
    float lx, lz;       ///< lane axis (unit, XZ)
    float vanilla_rot;  ///< root rotY as the 2D game set it
    int up_frames;      ///< frames the up modifier has been held
    float stick_hist[2]; ///< raw stick magnitude, last two frames
    float dyn_lx,dyn_lz;
    bool dyn_ready;
    Vec2 move_world,move_cstick;
    float move_vertical;
    bool move_throttle,move_latch;
    Vec3 platform_perp;
    bool rebirth_local;
    int aim_motion,aim_move,aim_instance,aim_slot,aim_began,aim_hit,aim_contact;
    bool aim_normal;
    float last_percent;Vec3 last_world;
    float aim_frame,aim_intent_x,aim_intent_z;
    Fighter* aim_target;
    M3dAimBudget aim;
    Vec3 launch_origin;
    bool launch_armed;
    int launch_ticks;

} M3dFt;

static M3dFt m3d_ft[GM_MAX_PLAYERS][2];
static bool spawn_ready,spawn_slots[GM_MAX_PLAYERS];
static Vec3 spawn_center,spawn_lanes[GM_MAX_PLAYERS];
static float spawn_radius;

void m3d_FightersReset(void)
{
    int i, j;
    for (i = 0; i < GM_MAX_PLAYERS; i++) {
        spawn_slots[i]=false;
        for (j = 0; j < 2; j++) m3d_ft[i][j].fp = NULL;
    }
    spawn_ready=false;
    m3d_DynamicsEnd();
}

void m3d_SpawnPoint(int slot,Vec3* pos)
{
    int i,count=0,index=0;
    float angle,sx,sz;
    if (!m3d_StageIs3D() || slot<0 || slot>=GM_MAX_PLAYERS) return;
    for (i=0;i < GM_MAX_PLAYERS;i++) if (Player_GetPlayerSlotType(i)!=Gm_PKind_NA) {
        if (i<slot) index++;
        count++;
    }
    if (!spawn_ready) {
        spawn_center.x=spawn_center.y=spawn_center.z=0;
        spawn_radius=40;
        if(m3d_ReferenceActive())m3d_ReferenceSpawn(&spawn_center,&spawn_radius);
        if (m3d_ArenaMeshActive()) m3d_ArenaMeshSpawnRing(&spawn_center,&spawn_radius);
        spawn_ready=true;
    }
    angle=count>0 ? 2*M3D_PI*index/count : 0;
    sx=sinf(angle);sz=cosf(angle);
    pos->x=spawn_center.x+(count>1 ? spawn_radius*sx : 0);
    pos->z=spawn_center.z+(count>1 ? spawn_radius*sz : 0);
    pos->y=spawn_center.y+10;
    if(m3d_DelfinoActive()||m3d_ReferenceOverlayActive())m3d_DelfinoSpawn(index,count,pos);
    spawn_lanes[slot].x=-sx;spawn_lanes[slot].z=-sz;
    if(m3d_DelfinoActive()||m3d_ReferenceOverlayActive()){Vec3 aim;m3d_DelfinoSpawnAim(&aim);float dx=aim.x-pos->x,dz=aim.z-pos->z,len=hypotf(dx,dz);if(len>1){spawn_lanes[slot].x=dx/len;spawn_lanes[slot].z=dz/len;}}
    spawn_slots[slot]=true;
}

#define M3D_MAX_VTX 32760 /* DELFINO: stable triangle line identities. */

static struct {
    bool active;
    void* owner;
    float p0x, p0z; ///< world XZ at entry
    float x0;       ///< fighter's local x at entry
    float lx, lz;   ///< lane used for this window
    int nvtx;
} m3d_loc;

static bool m3d_debug_nolocal = false;

static M3dFt* m3d_Get(Fighter* fp)
{
    M3dFt* m;

    if (!m3d_StageIs3D() || fp->player_idx >= GM_MAX_PLAYERS) {
        return NULL;
    }
    m = &m3d_ft[fp->player_idx][fp->is_sub_fighter ? 1 : 0];
    if (m->fp != fp) {
        m->fp = fp;
        m->lx = 1.0f;
        m->lz = 0.0f;
        if (spawn_slots[fp->player_idx]) {
            m->lx=spawn_lanes[fp->player_idx].x*fp->facing_dir;
            m->lz=spawn_lanes[fp->player_idx].z*fp->facing_dir;
        }
        m->vanilla_rot = (M3D_PI / 2) * fp->facing_dir;
        m->up_frames = 0;
        m->stick_hist[0] = m->stick_hist[1] = 0.0f;
        m->dyn_ready=false;
        m->move_world=m->move_cstick=(Vec2){0,0};m->move_throttle=m->move_latch=false;m->move_vertical=0;
        m->platform_perp=(Vec3){0};
        m->rebirth_local=false;
        m->aim_motion=m->aim_move=m->aim_instance=-1;m->aim_normal=false;m->aim_slot=-1;m->aim_target=NULL;m->aim=(M3dAimBudget){0};
        m->aim_frame=0;m->last_percent=0;m->launch_armed=false;m->launch_ticks=0;
    }
    return m;
}

bool m3d_FighterIs3D(Fighter* fp)
{
    return m3d_Get(fp) != NULL;
}

/// World heading of the fighter's forward, degrees (0 = +Z, 90 = +X).
float m3d_ForwardYawDeg(Fighter* fp)
{
    M3dFt* m = m3d_Get(fp);
    if (m == NULL) {
        return fp->facing_dir > 0 ? 90.0f : -90.0f;
    }
    return atan2f(fp->facing_dir * m->lx, fp->facing_dir * m->lz) / M3D_DEG;
}

bool m3d_GetLane(Fighter* fp, float* lx, float* lz)
{
    M3dFt* m = m3d_Get(fp);
    if (m == NULL) {
        return false;
    }
    *lx = m->lx;
    *lz = m->lz;
    return true;
}

void m3d_SetLane(Fighter* fp, float lx, float lz)
{
    M3dFt* m = m3d_Get(fp);
    float len = sqrtf(lx * lx + lz * lz);
    if (m == NULL || len < 0.0001f) {
        return;
    }
    m->lx = lx / len;
    m->lz = lz / len;
}

bool m3d_GetMoveInput(Fighter* fp,Vec2* world,Vec2* cstick,bool* throttle)
{
    M3dFt* m=m3d_Get(fp);if(!m)return false;
    *world=m->move_world;*cstick=m->move_cstick;*throttle=m->move_throttle;return true;
}
float m3d_GetVerticalInput(Fighter* fp){M3dFt* m=m3d_Get(fp);return m?m->move_vertical:0;}
bool m3d_MoveControls(Fighter* fp)
{
    M3dFt* m=fp ? m3d_Get(fp):NULL;
    if(!m || fp->pad_port>=(m3d_room_enabled()?32:4) || Player_GetPlayerSlotType(fp->player_idx)!=Gm_PKind_Human)return false;
    HSD_PadStatus* pad=&HSD_PadGameStatus[fp->pad_port];
    bool held=(pad->button&HSD_PAD_R) || pad->nml_analogR>.3f;
    return held && (fp->motion_id>=341 || m->move_latch);
}

/* ---- input --------------------------------------------------------------- */

static bool m3d_CanSteerGround(Fighter* fp)
{
    switch (fp->motion_id) {
    case ftCo_MS_Wait:
    case ftCo_MS_WalkSlow:
    case ftCo_MS_WalkMiddle:
    case ftCo_MS_WalkFast:
    case ftCo_MS_Dash:
    case ftCo_MS_Run:
    case ftCo_MS_RunDirect:
    case ftCo_MS_Turn:
    case ftCo_MS_TurnRun:
    case ftCo_MS_RunBrake:
    case ftCo_MS_KneeBend:
    case ftCo_MS_Squat:
    case ftCo_MS_SquatWait:
    case ftCo_MS_SquatRv:
    case ftCo_MS_Ottotto:
    case ftCo_MS_OttottoWait:
    case ftCo_MS_HammerWait:
    case ftCo_MS_HammerWalk:
    case ftCo_MS_HammerTurn:
    case ftCo_MS_HammerKneeBend:
    case ftCo_MS_HammerLanding:
        return true;
    }
    return false;
}

static bool m3d_CanSteerAir(Fighter* fp)
{
    /* Extra jumps use character motion ids but share this native physics.
     * Identify the behavior rather than enumerating character states. */
    if (fp->phys_cb == ftCo_JumpAerialF1_Phys || m3d_akaneia_air_drift(fp)) {
        return true;
    }
    switch (fp->motion_id) {
    case ftCo_MS_JumpF:
    case ftCo_MS_JumpB:
    case ftCo_MS_JumpAerialF:
    case ftCo_MS_JumpAerialB:
    case ftCo_MS_Fall:
    case ftCo_MS_FallF:
    case ftCo_MS_FallB:
    case ftCo_MS_FallAerial:
    case ftCo_MS_FallAerialF:
    case ftCo_MS_FallAerialB:
    case ftCo_MS_FallSpecial:
    case ftCo_MS_HammerJump:
    case ftCo_MS_HammerFall:
    case ftCo_MS_WarpStarFall:
        return true;
    }
    return false;
}

/// Rotate (m->lx, m->lz) toward (tx, tz) by at most max_rad.
static void m3d_TurnToward(M3dFt* m, float tx, float tz, float max_rad)
{
    float cur = atan2f(m->lx, m->lz);
    float tgt = atan2f(tx, tz);
    float d = tgt - cur;

    while (d > M3D_PI) {
        d -= 2 * M3D_PI;
    }
    while (d < -M3D_PI) {
        d += 2 * M3D_PI;
    }
    if (d > max_rad) {
        d = max_rad;
    } else if (d < -max_rad) {
        d = -max_rad;
    }
    cur += d;
    m->lx = sinf(cur);
    m->lz = cosf(cur);
}

static bool m3d_IsRunning(Fighter* fp)
{
    if (fp->ground_or_air != GA_Ground) {
        return false;
    }
    switch (fp->motion_id) {
    case ftCo_MS_Dash:
    case ftCo_MS_Run:
    case ftCo_MS_RunDirect:
    case ftCo_MS_TurnRun:
        return true;
    }
    return false;
}

/// Screen-relative attack direction, read on the frame A/B is pressed.
/// up/down = up/down moves; left/right = side moves toward that side of the
/// screen (on the ground the fighter turns to face it; in the air it's a
/// forward or back aerial depending on which way the fighter faces on
/// screen). A fresh flick is a smash; a held stick is a tilt.
static void m3d_ScreenAttack(Fighter* fp, M3dFt* m, float sx, float sy,
                             float raw_mag, bool is_b, float* out_x,
                             float* out_y)
{
    bool flick = raw_mag >= 0.8f &&
                 (m->stick_hist[0] < 0.3f || m->stick_hist[1] < 0.3f);
    bool full = flick || is_b;
    float yaw = m3d_RoomInputYaw(fp->player_idx,m3d_CameraGetYaw());
    float rx = cosf(yaw);
    float rz = -sinf(yaw);
    float side, fwd_on_screen, v;

    if (raw_mag <= m3d_stick_deadzone) {
        *out_x = 0.0f;
        *out_y = 0.0f;
        fp->input.lstick[1].x = 0.0f;
        fp->input.lstick[1].y = 0.0f;
        return;
    }
    if (sy * sy >= sx * sx) {
        if (sy > 0.0f) {
            v = full ? 1.0f : m3d_up_tilt_y;
        } else {
            v = -1.0f;
        }
        *out_x = 0.0f;
        *out_y = v;
        fp->input.lstick[1].x = 0.0f;
        fp->input.lstick[1].y = flick ? 0.0f : v; /* retain native flick history */
        return;
    }

    side = sx > 0.0f ? 1.0f : -1.0f;
    v = full ? 1.0f : 0.5f;
    fwd_on_screen = fp->facing_dir * (m->lx * rx + m->lz * rz);
    if (fp->ground_or_air == GA_Ground || fwd_on_screen * fwd_on_screen < 0.09f)
    {
        /* face that side of the screen, then a forward move */
        m->lx = fp->facing_dir * side * rx;
        m->lz = fp->facing_dir * side * rz;
        *out_x = fp->facing_dir * v;
    } else if (side * fwd_on_screen > 0.0f) {
        *out_x = fp->facing_dir * v; /* forward aerial */
    } else {
        *out_x = -fp->facing_dir * v; /* back aerial */
    }
    *out_y = 0.0f;
    fp->input.lstick[1].x = flick ? 0.0f : *out_x;
    fp->input.lstick[1].y = 0.0f;
}

static float m3d_StageCut(float half_width);

/// Use the same finite footprint as map collision for recovery orientation.
bool m3d_CpuRecoveryGoal(Fighter* fp, Vec3* target)
{
    MapCollData* cd;
    CollVtx* vtx;
    float lo, hi, center, depth, cut;
    int i;
    if (!m3d_FighterIs3D(fp) || fp->ground_or_air != GA_Air ||
        m3d_loc.active) return false;
    if(m3d_DelfinoActive()) {
        Vec3 ground;
        if(m3d_DelfinoFloor(&fp->cur_pos,&ground) && fp->cur_pos.y>=ground.y)return false;
        return m3d_DelfinoLedge(&fp->cur_pos,target,NULL,NULL);
    }
    if(m3d_ReferenceActive()) {
        Vec3 ground;
        if(m3d_ReferenceFloor(&fp->cur_pos,&ground) && fp->cur_pos.y>=ground.y)return false;
        return m3d_ReferenceLedge(&fp->cur_pos,target);
    }
    if (m3d_ArenaActive()) {
        if (!m3d_ArenaOutside(&fp->cur_pos)) return false;
        target->x = target->z = 0;
        return true;
    }
    cd = mpLib_8004D164();
    vtx = mpGetGroundCollVtx();
    if (cd == NULL || vtx == NULL || cd->vert_count <= 0) return false;
    lo = hi = vtx[0].pos.x;
    for (i = 1; i < cd->vert_count; i++) {
        if (vtx[i].pos.x < lo) lo = vtx[i].pos.x;
        if (vtx[i].pos.x > hi) hi = vtx[i].pos.x;
    }
    center = (lo + hi) * 0.5f;
    depth = m3d_cfg.flat ? 5000.0f :
            (m3d_cfg.depth > 0 ? (float) m3d_cfg.depth : (hi - lo) * 0.5f);
    cut = m3d_StageCut((hi - lo) * 0.5f);
    if (fp->cur_pos.x >= lo && fp->cur_pos.x <= hi &&
        fp->cur_pos.z >= -depth && fp->cur_pos.z <= depth &&
        (cut <= 0.0f || fabsf(fp->cur_pos.x - center) +
                       fabsf(fp->cur_pos.z) <= cut)) return false;
    target->x = center;
    target->z = 0.0f;
    return true;
}

static bool combat_assist=true,projectile_distance=true,combat_log=false,side_ko=false,di_fixed=true;
static int combat_epoch;
void m3d_CombatConfigure(void) {
    const char *a=getenv("MELEE3D_NATIVE_ASSIST"),*p=getenv("MELEE3D_NATIVE_PROJECTILES"),*d=getenv("MELEE3D_NATIVE_DI");
    combat_assist=!a||strcmp(a,"off");projectile_distance=!p||strcmp(p,"legacy");
    di_fixed=!d||strcmp(d,"legacy");combat_log=getenv("MELEE3D_NATIVE_COMBAT_LOG")!=NULL;
    side_ko=getenv("MELEE3D_NATIVE_SIDE_KO")!=NULL;combat_epoch=0;
    fprintf(stderr,"M3D COMBAT CONFIG assist=%d projectile_distance=%d di_fixed=%d side_ko=%d cap=30 startup_only=1\n",combat_assist,projectile_distance,di_fixed,side_ko);
}
bool m3d_CombatAssist(void){return combat_assist;}
bool m3d_ProjectileDistanceAssist(void){return projectile_distance;}
static float combat_rate(Fighter* fp) {
    /* Native move identities cover character-specific normal states too:
     * Peach's weapons, Ness's bat/yoyo and Game & Watch's smashes. */
    int id=fp->x2068_attackID;
    if(id>=FtMoveId_AttackDash&&id<=FtMoveId_AttackLw3)return 2.5f;
    if(id>=FtMoveId_AttackS4&&id<=FtMoveId_AttackLw4)return 3;
    if(id>=FtMoveId_AttackAirN&&id<=FtMoveId_AttackAirLw)return 2.5f;
    if(fp->motion_id==ftCo_MS_Catch||fp->motion_id==ftCo_MS_CatchDash)return 3;
    return 0;
}
static bool combat_normal(Fighter* fp) {
    int id=fp->x2068_attackID;
    return (id>=FtMoveId_Attack11&&id<=FtMoveId_AttackAirLw)||
        fp->motion_id==ftCo_MS_Catch||fp->motion_id==ftCo_MS_CatchDash;
}
bool m3d_CombatNormal(Fighter* fp){return combat_normal(fp);}
static Fighter* combat_candidate(Fighter* fp,float x,float z) {
    Fighter* best=NULL;float score=1e20f;Vec3 from=fp->cur_pos;from.y+=8;
    for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];g;g=g->next) {
        Fighter* other=GET_FIGHTER(g);
        if(other==fp||other->is_sub_fighter||other->is_sleeping||other->invisible||other->motion_id<14||
           m3d_PartyEliminated(other->player_idx)||ftCo_IsAlly(fp,other))continue;
        Vec3 goal=other->cur_pos;goal.y+=8;float dx=goal.x-from.x,dz=goal.z-from.z,len=hypotf(dx,dz);
        if(len<1||len>40||fabsf(goal.y-from.y)>24)continue;
        float dot=(dx*x+dz*z)/len;if(dot<.8660254f)continue;
        float value=len*(.6f+.4f*(1-dot)/(1-.8660254f));
        if(value<score&&m3d_SegmentClear(&from,&goal)){score=value;best=other;}
    }return best;
}
static Fighter* combat_target(Fighter* fp,M3dFt* m) {
    if(m->aim_slot<0||m->aim_slot>=GM_MAX_PLAYERS)return NULL;
    HSD_GObj* g=Player_GetEntityAtIndex(m->aim_slot,0);Fighter* t=g?GET_FIGHTER(g):NULL;
    if(t!=m->aim_target||!t||t->is_sleeping||t->invisible||t->motion_id<14||m3d_PartyEliminated(m->aim_slot)||
       ftCo_IsAlly(fp,t)||hypotf(t->cur_pos.x-fp->cur_pos.x,t->cur_pos.z-fp->cur_pos.z)>60||fabsf(t->cur_pos.y-fp->cur_pos.y)>32)return NULL;
    Vec3 a=fp->cur_pos,b=t->cur_pos;a.y+=8;b.y+=8;return m3d_SegmentClear(&a,&b)?t:NULL;
}
bool m3d_CombatTarget(Fighter* fp,Vec3* pos,bool* locked) {
    M3dFt* m=m3d_Get(fp);if(!m||!combat_assist||(combat_normal(fp)&&m->aim.overridden))return false;
    Fighter* t=combat_target(fp,m);if(!t)return false;
    *pos=t->cur_pos;*locked=combat_normal(fp);return true;
}
static bool combat_damage(Fighter* fp) {
    return (fp->motion_id>=ftCo_MS_DamageHi1&&fp->motion_id<=ftCo_MS_DamageFlyRoll)||fp->motion_id==ftCo_MS_DamageFall;
}
void m3d_CombatTick(void) {
    if(!m3d_StageIs3D())return;combat_epoch++;
    for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];g;g=g->next) {
        Fighter* fp=GET_FIGHTER(g);M3dFt* m=m3d_Get(fp);if(!m)continue;
        bool normal=combat_normal(fp),frozen=fp->dmg.x195c_hitlag_frames>0;
        bool change=m->aim_move!=(int)fp->x2068_attackID||m->aim_instance!=(int)fp->x206C_attack_instance||
            (!normal&&m->aim_motion!=(int)fp->motion_id)||
            ((fp->motion_id==ftCo_MS_Catch||fp->motion_id==ftCo_MS_CatchDash)&&m->aim_motion!=(int)fp->motion_id);
        if(change) {
            if(m->aim_motion>=14&&fp->motion_id<14)fprintf(stderr,"M3D KO EVENT tick=%d slot=%u kind=%d death_motion=%d previous_pct=%.2f previous_pos=%.2f,%.2f,%.2f\n",combat_epoch,fp->player_idx,fp->kind,fp->motion_id,m->last_percent,m->last_world.x,m->last_world.y,m->last_world.z);
            if(combat_log&&m->aim_normal)
                fprintf(stderr,"M3D AIM END slot=%u kind=%d motion=%d target=%d intended_hit=%d contact=%d turned=%.3f override=%d\n",fp->player_idx,fp->kind,m->aim_motion,m->aim_slot,m->aim_hit,m->aim_contact,m->aim.spent/M3D_DEG,m->aim.overridden);
            m->aim_move=fp->x2068_attackID;m->aim_instance=fp->x206C_attack_instance;m->aim=(M3dAimBudget){0};m->aim_hit=m->aim_contact=0;m->aim_began=combat_epoch;
            m->aim_intent_x=m->move_world.x;m->aim_intent_z=m->move_world.y;
            Fighter* target=combat_candidate(fp,fp->facing_dir*m->lx,fp->facing_dir*m->lz);
            m->aim_target=target;m->aim_slot=target?target->player_idx:-1;
            if(combat_log&&normal)fprintf(stderr,"M3D AIM BEGIN slot=%u kind=%d motion=%d target=%d human=%d distance=%.3f lateral=%.3f\n",fp->player_idx,fp->kind,fp->motion_id,m->aim_slot,Player_GetPlayerSlotType(fp->player_idx)==Gm_PKind_Human,target?hypotf(target->cur_pos.x-fp->cur_pos.x,target->cur_pos.z-fp->cur_pos.z):-1,target?fabsf(-(target->cur_pos.x-fp->cur_pos.x)*m->lz+(target->cur_pos.z-fp->cur_pos.z)*m->lx):-1);
        }
        m->aim_motion=fp->motion_id;m->aim_normal=normal;
        m->aim_frame=fp->cur_anim_frame;
        m->last_percent=fp->dmg.x1830_percent;m->last_world=fp->cur_pos;
        if(fp->is_sleeping||fp->motion_id<14||fp->victim_gobj||fp->x1A5C||m3d_PartyEliminated(fp->player_idx)) {
            m->aim_target=NULL;m->aim_slot=-1;m->aim.active=1;m->launch_armed=false;continue;
        }
        if(!normal) {
            float x=fp->facing_dir*m->lx,z=fp->facing_dir*m->lz;
            float intent=hypotf(m->move_world.x,m->move_world.y);
            if(Player_GetPlayerSlotType(fp->player_idx)==Gm_PKind_Human&&intent>m3d_stick_deadzone){x=m->move_world.x/intent;z=m->move_world.y/intent;}
            Fighter* t=combat_candidate(fp,x,z);
            m->aim_target=t;m->aim_slot=t?t->player_idx:-1;
        }
        Fighter* target=combat_target(fp,m);
        if(!target){m->aim_slot=-1;m->aim_target=NULL;}
        bool active=false;for(int i=0;i<4;i++)if(fp->x914[i].state!=HitCapsule_Disabled)active=true;
        if(normal&&active&&!m->aim.active&&combat_log)fprintf(stderr,"M3D AIM ACTIVE slot=%u motion=%d startup=%d target=%d distance=%.3f lateral=%.3f\n",fp->player_idx,fp->motion_id,combat_epoch-m->aim_began,m->aim_slot,target?hypotf(target->cur_pos.x-fp->cur_pos.x,target->cur_pos.z-fp->cur_pos.z):-1,target?fabsf(-(target->cur_pos.x-fp->cur_pos.x)*m->lz+(target->cur_pos.z-fp->cur_pos.z)*m->lx):-1);
        float rate=combat_rate(fp)*M3D_DEG;
        float delta=target?atan2f(target->cur_pos.z-fp->cur_pos.z,target->cur_pos.x-fp->cur_pos.x)-atan2f(fp->facing_dir*m->lz,fp->facing_dir*m->lx):0;
        float step=m3d_combat_turn(&m->aim,delta,rate,active,frozen||!normal||!combat_assist||!target);
        if(step){float a=atan2f(m->lz,m->lx)+step;m->lx=cosf(a);m->lz=sinf(a);}
        if(side_ko) {
            if(!combat_damage(fp)||!fp->x221C_b6){m->launch_armed=false;m->launch_ticks=0;}
            else if(!m->launch_armed&&hypotf(fp->x8c_kb_vel.x,fp->x8c_kb_vel.y)>=2.4f){m->launch_armed=true;m->launch_origin=fp->cur_pos;m->launch_ticks=0;}
            if(m->launch_armed&&!frozen&&++m->launch_ticks>360)m->launch_armed=false;
        }
    }
}
float m3d_CombatLaunchFraction(Fighter* fp) {
    M3dFt* m=m3d_Get(fp);if(!side_ko||!m||!m->launch_armed||!combat_damage(fp)||!fp->x221C_b6)return 0;
    Vec3 p=fp->cur_pos;if(m3d_MapIsActive(fp))m3d_MapToWorld(&p);
    return hypotf(p.x-m->launch_origin.x,p.z-m->launch_origin.z)/200;
}
int m3d_CombatSideKO(Fighter* fp) {
    M3dFt* m=m3d_Get(fp);if(!side_ko||!m||!m->launch_armed||!combat_damage(fp)||!fp->x221C_b6||fp->victim_gobj||fp->x1A5C)return 0;
    Vec3 world=fp->cur_pos;if(m3d_MapIsActive(fp))m3d_MapToWorld(&world);
    if(hypotf(world.x-m->launch_origin.x,world.z-m->launch_origin.z)<=200)return 0;
    m->launch_armed=false;fprintf(stderr,"M3D COMBAT SIDE KO slot=%u distance=200 actual=1\n",fp->player_idx);return 1;
}

/// AI keeps native 2D decisions; steer only its horizontal movement lane.
void m3d_CpuAim(Fighter* fp, Vec3* target)
{
    M3dFt* m = m3d_Get(fp);
    float dx, dz, len, sign;
    Vec3 recovery_goal;
    bool normal = fp->x2068_attackID >= FtMoveId_Attack11 &&
                  fp->x2068_attackID <= FtMoveId_AttackLw4;
    if(combat_assist&&combat_normal(fp))return;
    if (m == NULL || !(m3d_CanSteerGround(fp) || m3d_CanSteerAir(fp) ||
                      normal || fp->motion_id == ftCo_MS_Guard ||
                      fp->motion_id == ftCo_MS_GuardOn)) return;
    dx = target->x - fp->cur_pos.x;
    dz = target->z - fp->cur_pos.z;
    len = sqrtf(dx * dx + dz * dz);
    if (len < (m3d_DelfinoNavSteering(fp)?.5f:4.0f)) return;
    sign = dx * m->lx + dz * m->lz < 0.0f ? -1.0f : 1.0f;
    if (m3d_CpuRecoveryGoal(fp, &recovery_goal)) {
        /* Expose a chord through the stage before native recovery planning.
         * Keep special/roll/ledge lanes locked via the eligibility above. */
        m->lx = sign * dx / len;
        m->lz = sign * dz / len;
    } else if(m3d_DelfinoNavSteering(fp)) {
        /* Route corners express world direction directly. Native locomotion
         * still owns speed, braking, turns and jumps; combat keeps its aim. */
        m->lx=sign*dx/len;m->lz=sign*dz/len;
    } else {
        m3d_TurnToward(m, sign * dx / len, sign * dz / len, m3d_air_turn);
    }
}

/// Human input: camera-relative left stick -> lane steering + local stick.
bool m3d_CpuTravelPad(Fighter* fp,Vec3* goal,bool jump,bool precision)
{
    if(!(m3d_CanSteerGround(fp)||m3d_CanSteerAir(fp)||fp->motion_id==ftCo_MS_Guard||fp->motion_id==ftCo_MS_GuardOn))return false;
    float lx,lz;if(!m3d_GetLane(fp,&lx,&lz))return false;
    float dot=(goal->x-fp->cur_pos.x)*lx+(goal->z-fp->cur_pos.z)*lz;
    float distance=hypotf(goal->x-fp->cur_pos.x,goal->z-fp->cur_pos.z);
    /* Short mesh segments need walking/air braking before a corner. Full
     * deflection otherwise carries dash momentum off narrow rooftop edges. */
    int amount=precision?(distance<2?0:distance<5?(int)(48+(distance-2)*26):127):127;
    fp->cpu.lstick.x=distance<4&&fabsf(goal->y-fp->cur_pos.y)>8?0:dot<0?-amount:amount;fp->cpu.lstick.y=0;
    fp->cpu.cstick.x=fp->cpu.cstick.y=0;fp->cpu.ltrigger=fp->cpu.rtrigger=0;
    fp->cpu.buttons=jump?HSD_PAD_X:0;
    return true;
}

/// Called from Fighter_procInput after the raw sticks/triggers are read.
void m3d_RemapInput(Fighter* fp)
{
    M3dFt* m = m3d_Get(fp);
    HSD_PadStatus* pad;
    float sx, sy, yaw, cy, sn, dx, dz, mag, ux, uz, wx, wz, dot;
    float local_x = 0.0f;
    float local_y = 0.0f;
    bool up, down, attack, pivot, guard, vertical_attack;

    if (m == NULL) {
        return;
    }
    pad = &HSD_PadGameStatus[fp->pad_port];
    sx = fp->input.lstick[0].x;
    sy = fp->input.lstick[0].y;

    /* camera basis in XZ: right = (cos, -sin), forward = (-sin, -cos) */
    yaw = m3d_RoomInputYaw(fp->player_idx,m3d_CameraGetYaw());
    cy = cosf(yaw);
    sn = sinf(yaw);
    dx = sx * cy - sy * sn;
    dz = -sx * sn - sy * cy;
    mag = sqrtf(dx * dx + dz * dz);
    if (mag > 1.0f) {
        dx /= mag;
        dz /= mag;
        mag = 1.0f;
    }

    /* Recovery/controlled-item callbacks run later than input sampling. Keep
     * the raw world vector and steering ownership, as the canonical engine
     * does, rather than rereading a pad buffer renewed in another phase. */
    bool throttle_held=(pad->button&HSD_PAD_R) || pad->nml_analogR>.3f;
    if(!throttle_held)m->move_latch=false;
    else if(fp->motion_id>=341)m->move_latch=true;
    m->move_world=(Vec2){dx,dz};m->move_cstick=fp->input.cstick[0];
    m->move_throttle=throttle_held && m->move_latch;

    if(combat_assist&&combat_normal(fp)&&m->aim_motion==(int)fp->motion_id&&mag>m3d_stick_deadzone) {
        float initial=hypotf(m->aim_intent_x,m->aim_intent_z);
        if(m->stick_hist[0]<=m3d_stick_deadzone||initial<.2875f||(dx*m->aim_intent_x+dz*m->aim_intent_z)/(mag*initial)<.9945219f) {
            m->aim.overridden=1;
            if(fp->ground_or_air==GA_Air)m3d_TurnToward(m,fp->facing_dir*dx/mag,fp->facing_dir*dz/mag,m3d_attack_turn*mag);
        }
    }
    /* Vertical: L (L2) = down, D-pad up (L1) = up. Jump is X/Y only. */
    down = (pad->button & HSD_PAD_L) || pad->nml_analogL > 0.3f;
    up = (pad->button & HSD_PAD_DPADUP) != 0;
    m->move_vertical=down?-1:up?1:0;
    pivot = fp->ground_or_air == GA_Ground &&
            fp->x2068_attackID >= FtMoveId_Attack11 &&
            fp->x2068_attackID <= FtMoveId_AttackLw4;
    bool spatial=m3d_SeparateAttackInputs();
    vertical_attack=!spatial && (pad->trigger&(HSD_PAD_A|HSD_PAD_B)) && fabsf(sy)>.25f && fabsf(sy)>=fabsf(sx);
    attack = !spatial && (pad->trigger & (HSD_PAD_A | HSD_PAD_B)) && !up && !down &&
             (vertical_attack || (!m3d_IsRunning(fp) && !pivot));

    guard = fp->motion_id == ftCo_MS_GuardOn ||
            fp->motion_id == ftCo_MS_Guard ||
            fp->motion_id == ftCo_MS_GuardReflect ||
            (fp->ground_or_air == GA_Ground && fp->x221A_b7 &&
             fp->motion_id != ftCo_MS_EscapeF &&
             fp->motion_id != ftCo_MS_EscapeB);
    if(spatial && (pad->trigger&(HSD_PAD_A|HSD_PAD_B)) && mag>m3d_stick_deadzone &&
       (pivot||m3d_CanSteerGround(fp)||m3d_CanSteerAir(fp))) {
        /* The world heading and the vertical move selector are independent.
         * Facing the requested direction also makes a behind-camera punch a
         * forward attack. Do not feed a turn/run input before native attack. */
        m->lx=fp->facing_dir*dx/mag;m->lz=fp->facing_dir*dz/mag;
        bool flick=mag>=.8f&&(m->stick_hist[0]<.3f||m->stick_hist[1]<.3f);
        local_x=(up||down||pivot)?0:fp->facing_dir*((flick||(pad->trigger&HSD_PAD_B))?1:.5f);
        fp->input.lstick[1].x=flick?0:local_x;fp->input.lstick[1].y=0;
    } else if(vertical_attack && !up && !down) {
        /* Preserve the canonical button-edge vertical intent and heading,
         * including while running or finishing an existing combo. */
    } else if (guard && !up && !down && mag >= p_ftCommonData->x31C) {
        /* Native roll selection and animation, along the requested XZ lane.
         * Keep forward/back roll semantics relative to the previous facing. */
        float sign = (dx * fp->facing_dir * m->lx +
                      dz * fp->facing_dir * m->lz) < m3d_back_cos * mag
                         ? -1.0f : 1.0f;
        m->lx = sign * fp->facing_dir * dx / mag;
        m->lz = sign * fp->facing_dir * dz / mag;
        local_x = sign * fp->facing_dir * mag;
    } else if (fp->ground_or_air==GA_Air && fp->can_walljump &&
               (fp->coll_data.env_flags & (Collide_RightWallHug|Collide_LeftWallHug))) {
        /* Wall-jump inputs belong to the contact slice. Turning that slice
         * before native IASA consumes the away flick loses the wall. */
        local_x=dx*m->lx+dz*m->lz;
    } else if (pivot) {
        /* Aim the ongoing normal/combo without feeding walk/turn inputs.
         * Native attack/root motion and button-driven combos still run. */
        bool owns=combat_assist&&combat_rate(fp)>0&&m->aim_motion==(int)fp->motion_id&&m->aim_slot>=0&&!m->aim.overridden;
        if(owns&&mag>m3d_stick_deadzone) {
            float initial=hypotf(m->aim_intent_x,m->aim_intent_z);
            if(m->stick_hist[0]<=m3d_stick_deadzone||initial<.2875f||(dx*m->aim_intent_x+dz*m->aim_intent_z)/(mag*initial)<.9945219f) {m->aim.overridden=1;owns=false;}
        }
        if (mag > m3d_stick_deadzone && !owns) {
            m3d_TurnToward(m, fp->facing_dir * dx / mag,
                           fp->facing_dir * dz / mag,
                           m3d_attack_turn * mag);
        }
    } else if (attack) {
        /* the stick picks the move this frame; no steering */
    } else if (mag > m3d_stick_deadzone) {
        ux = dx / mag;
        uz = dz / mag;
        wx = fp->facing_dir * m->lx;
        wz = fp->facing_dir * m->lz;
        dot = ux * wx + uz * wz;
        if (dot > m3d_back_cos) {
            if (fp->ground_or_air == GA_Ground) {
                if (m3d_CanSteerGround(fp)) {
                    m->lx = fp->facing_dir * ux;
                    m->lz = fp->facing_dir * uz;
                }
            } else if (m3d_CanSteerAir(fp)) {
                m3d_TurnToward(m, fp->facing_dir * ux, fp->facing_dir * uz,
                               m3d_air_turn);
            }
        }
        local_x = (ux * m->lx + uz * m->lz) * mag;
    } else {
        local_x = mag > 0.0f ? (dx * m->lx + dz * m->lz) : 0.0f;
    }

    if (up) {
        m->up_frames++;
    } else {
        m->up_frames = 0;
    }
    if (down) {
        local_y = -1.0f;
    } else if (up) {
        local_y = m3d_up_tilt_y;
        if ((pad->trigger & HSD_PAD_B) ||
            ((pad->trigger & HSD_PAD_A) && m->up_frames <= 3))
        {
            local_y = 1.0f; /* up-B / up-smash */
        }
    }

    if (attack) {
        m3d_ScreenAttack(fp, m, sx, sy, sqrtf(sx * sx + sy * sy),
                         (pad->trigger & HSD_PAD_B) != 0, &local_x, &local_y);
    }
    if(di_fixed&&combat_damage(fp)&&(fp->x221C_b6||fp->dmg.x195c_hitlag_frames>0)) {
        /* Keep world along-lane DI; both vertical modifiers now reach full
         * strength during damage only. Attack/tilt selection is untouched. */
        local_x=dx*m->lx+dz*m->lz;local_y=down?-1:up?(fp->x221C_b6?1:m3d_up_tilt_y):0;
        m3d_combat_di(&local_x,&local_y);
    }
    m->stick_hist[1] = m->stick_hist[0];
    m->stick_hist[0] = sqrtf(sx * sx + sy * sy);

    fp->input.lstick[0].x = local_x;
    fp->input.lstick[0].y = local_y;
    /* L is the down modifier now; only R shields. */
    fp->input.triggers[0] = pad->nml_analogR;
}

/// Strip the modifier buttons from what the fighter sees.
u32 m3d_FilterButtons(Fighter* fp, u32 buttons)
{
    if (m3d_Get(fp) == NULL) {
        return buttons;
    }
    return buttons & ~(HSD_PAD_L | HSD_PAD_DPADUP);
}

/* ---- physics ------------------------------------------------------------- */

/// cur_pos += v, with v.x applied along the lane. Returns false if vanilla.
bool m3d_AddVel(Fighter* fp, Vec3* v)
{
    M3dFt* m = m3d_Get(fp);
    if (m == NULL) {
        return false;
    }
    if (m3d_loc.active && m3d_loc.owner == fp) {
        /* lane-local frame: plain 2D add, mapped back on exit */
        fp->cur_pos.x += v->x;
        fp->cur_pos.y += v->y;
        return true;
    }
    fp->cur_pos.x += v->x * m->lx;
    fp->cur_pos.z += v->x * m->lz + v->z;
    fp->cur_pos.y += v->y;
    return true;
}

/// After map collision: apply the lane to the root yaw.
void m3d_PostMap(Fighter* fp)
{
    M3dFt* m = m3d_Get(fp);
    if (m == NULL) {
        return;
    }
    ftPartSetRotY_Raw(fp, 0,
                      m->vanilla_rot + atan2f(m->lx, m->lz) - M3D_PI / 2);
}

static Fighter* dynamics_owner;

void m3d_DynamicsReset(Fighter* fp) {
    /* Bone loading also runs before native facing is initialised. Do not
     * create a movement record here: a zero facing would seed a zero lane. */
    if(fp->player_idx>=GM_MAX_PLAYERS)return;
    M3dFt* m=&m3d_ft[fp->player_idx][fp->is_sub_fighter?1:0];
    if(m->fp==fp)m->dyn_ready=false;
}

void m3d_DynamicsBegin(Fighter* fp)
{
    M3dFt* m=m3d_Get(fp);
    int i;
    dynamics_owner=m ? fp : NULL;
    if(!m)return;
    /* A lane can reverse sign when native facing reverses while the world
     * heading stays put. Rebase cloth by actual facing, otherwise that purely
     * internal lane swap injects a fictitious 180-degree gust. */
    float lx=m->lx*fp->facing_dir,lz=m->lz*fp->facing_dir;
    if(!m->dyn_ready) {
        /* Native bones may have been loaded before the 3D root pose or
         * replaced on respawn/transformation. Seed from the actual pose. */
        for(i=0;i<fp->dynamics_num;i++)for(struct DynamicsData* d=DP(struct DynamicsData,fp->dynamic_bone_sets[i].dyn_desc.data);d;d=d->next){
            HSD_JObj* j=d->desc.lb_unk0.jobj;HSD_JObjSetupMatrix(j);
            d->desc.lb_unk0.unk_2C=(Vec3){j->mtx[0][3],j->mtx[1][3],j->mtx[2][3]};d->desc.lb_unk0.unk_44=0;
        }
    } else {
        float c=lx*m->dyn_lx+lz*m->dyn_lz;
        float s=lz*m->dyn_lx-lx*m->dyn_lz;
        if(fabsf(s)>0.00001f || c<0.99999f)for(i=0;i<fp->dynamics_num;i++) {
            struct DynamicsData* d;
            for(d=DP(struct DynamicsData,fp->dynamic_bone_sets[i].dyn_desc.data);d;d=d->next) {
                Vec3* p=&d->desc.lb_unk0.unk_2C;
                Vec3* a=&d->desc.lb_unk0.unk_38;
                float x=p->x-fp->cur_pos.x,z=p->z-fp->cur_pos.z,ax=a->x,az=a->z;
                p->x=fp->cur_pos.x+c*x-s*z;p->z=fp->cur_pos.z+s*x+c*z;
                a->x=c*ax-s*az;a->z=s*ax+c*az;
            }
        }
    }
    m->dyn_lx=lx;m->dyn_lz=lz;m->dyn_ready=true;
}

void m3d_DynamicsEnd(void) {dynamics_owner=NULL;}
bool m3d_DynamicsActive(void) {return dynamics_owner!=NULL;}

bool m3d_DynamicsFloor(Vec3* origin,Vec3* direction,float length)
{
    Vec3 end=*origin,floor;
    float dy,h,ratio;
    if(length<0.001f)return false;
    end.x+=direction->x*length;end.z+=direction->z*length;
    end.y=origin->y+0.01f;
    if(!m3d_GroundBelow(&end,&floor) || origin->y+direction->y*length>=floor.y)return false;
    dy=(floor.y-origin->y)/length;
    if(dy < -1 || dy>1)return false;
    h=sqrtf(direction->x*direction->x+direction->z*direction->z);
    if(h<0.00001f)return false;
    ratio=sqrtf(1-dy*dy)/h;
    direction->x*=ratio;direction->z*=ratio;direction->y=dy;
    return true;
}

/// Intercepts root rotY writes from the 2D game.
float m3d_FilterRootRotY(Fighter* fp, float rot)
{
    M3dFt* m = m3d_Get(fp);
    if (m == NULL) {
        return rot;
    }
    m->vanilla_rot = rot;
    return rot + atan2f(m->lx, m->lz) - M3D_PI / 2;
}

/// Knockback direction for a fighter hit by a fighter.
///
/// Melee picks the launch side from positions along the attacker's line.
/// In 3D we keep that: the victim is launched along the attacker's forward
/// axis, toward whichever side of the attacker it is on (so forward smashes
/// send you forward and back-airs send you back). The victim's lane becomes
/// that axis and it faces the attacker (-1).
float m3d_HitDirection(Fighter* victim, Fighter* attacker, float vanilla_dir)
{
    M3dFt* m = m3d_Get(victim);
    M3dFt* a;
    float fx, fz, side;

    if (m == NULL) {
        return vanilla_dir;
    }
    a = m3d_Get(attacker);
    if(a&&combat_normal(attacker)) {a->aim_contact=1;if(a->aim_target==victim)a->aim_hit=1;}
    if(side_ko){m->launch_armed=false;m->launch_ticks=0;}
    fx = attacker->facing_dir * (a != NULL ? a->lx : 1.0f);
    fz = attacker->facing_dir * (a != NULL ? a->lz : 0.0f);
    side = (victim->cur_pos.x - attacker->cur_pos.x) * fx +
           (victim->cur_pos.z - attacker->cur_pos.z) * fz;
    if (side < 0.0f) {
        fx = -fx;
        fz = -fz;
    }
    m->lx = fx;
    m->lz = fz;
    return -1.0f;
}

/// dst takes src's lane (grabs, throws: the pair shares one line).
void m3d_CopyLane(Fighter* dst, Fighter* src)
{
    M3dFt* d = m3d_Get(dst);
    M3dFt* s = m3d_Get(src);
    if (d == NULL || s == NULL) {
        return;
    }
    d->lx = s->lx;
    d->lz = s->lz;
}

/// Vanilla: pos.x += dx, pos.z = 0. In 3D: pos += dx * lane (keeps depth).
/// Returns false when the caller should run the vanilla code.
bool m3d_OffsetX(Fighter* fp, Vec3* pos, float dx)
{
    M3dFt* m = m3d_Get(fp);
    if (m == NULL) {
        return false;
    }
    pos->x += dx * m->lx;
    pos->z += dx * m->lz;
    return true;
}

/// Grab range check distance: |dx| in 2D, horizontal distance in 3D.
float m3d_GrabDist(Fighter* a, Fighter* b, float vanilla_dx)
{
    float dx, dz;
    if (m3d_Get(a) == NULL) {
        return vanilla_dx;
    }
    dx = b->cur_pos.x - a->cur_pos.x;
    dz = b->cur_pos.z - a->cur_pos.z;
    return sqrtf(dx * dx + dz * dz);
}

/* ---- lane-local frame -------------------------------------------------------
 * The stage is treated as its 2D profile extruded along Z into a box
 * [X0,X1] x [-D,D]. While a fighter's 2D physics and map collision run, we
 * move the stage's collision vertices so the floor spans exactly the chord
 * where the fighter's lane line crosses that box, and put the fighter on
 * that line. Melee's own code then handles running off edges, ledge grabs,
 * teetering and blast zones -- along whatever direction the fighter faces.
 * Afterwards the displacement along the line is mapped back to world XZ and
 * the stage is restored.
 */

static float m3d_save_x[M3D_MAX_VTX];
static float m3d_save_px[M3D_MAX_VTX];

/// Clip the line p + t*(lx,lz) against [a0,a1] on one axis.
static bool m3d_Slab(float p, float d, float a0, float a1, float* tin,
                     float* tout)
{
    float t1, t2, tmp;
    if (d > -0.00001f && d < 0.00001f) {
        return p >= a0 && p <= a1;
    }
    t1 = (a0 - p) / d;
    t2 = (a1 - p) / d;
    if (t1 > t2) {
        tmp = t1;
        t1 = t2;
        t2 = tmp;
    }
    if (t1 > *tin) {
        *tin = t1;
    }
    if (t2 < *tout) {
        *tout = t2;
    }
    return *tin <= *tout;
}

/// Clip the line against the half-plane nx*x + nz*z <= k.
static bool m3d_HalfPlane(float px, float pz, float lx, float lz, float nx,
                          float nz, float k, float* tin, float* tout)
{
    float np = nx * px + nz * pz;
    float nl = nx * lx + nz * lz;
    float t;
    if (nl > -0.00001f && nl < 0.00001f) {
        return np <= k;
    }
    t = (k - np) / nl;
    if (nl > 0.0f) {
        if (t < *tout) {
            *tout = t;
        }
    } else if (t > *tin) {
        *tin = t;
    }
    return *tin <= *tout;
}

/// Diagonal corner cut |x| + |z| <= K (0 = none). Final Destination is an
/// octagon about as deep as it is wide.
static float m3d_StageCut(float half_width)
{
    if (stage_info.grkind == Gr_Kind_Last && !m3d_cfg.flat) {
        return half_width * 1.4142f; /* regular octagon */
    }
    return 0.0f;
}

void m3d_MapToLocal(Vec3* v)
{
    v->x = m3d_loc.x0 + (v->x - m3d_loc.p0x) * m3d_loc.lx +
           (v->z - m3d_loc.p0z) * m3d_loc.lz;
    v->z = 0.0f;
}

void m3d_MapToWorld(Vec3* v)
{
    float d = v->x - m3d_loc.x0;
    v->x = m3d_loc.p0x + d * m3d_loc.lx;
    v->z = m3d_loc.p0z + d * m3d_loc.lz;
}

static void m3d_RefreshIslands(MapCollData* cd)
{
    int j;
    for (j = 0; j < cd->joint_count; j++) {
        mpLib_8005667C(j);
    }
}

bool m3d_MapBegin(void* owner, Vec3* pos, float lx, float lz)
{
    MapCollData* cd;
    CollVtx* vtx;
    float X0, X1, Xc, D, K, tin, tout, tmid, span;
    bool hit;
    int i, n;

    if (!m3d_StageIs3D() || m3d_loc.active || m3d_debug_nolocal) {
        return false;
    }
    cd = mpLib_8004D164();
    vtx = mpGetGroundCollVtx();
    if (cd == NULL || vtx == NULL || cd->vert_count <= 0 ||
        cd->vert_count > M3D_MAX_VTX)
    {
        return false;
    }
    n = cd->vert_count;

    if(m3d_DelfinoActive()) {
        m3d_loc.lx=lx;m3d_loc.lz=lz;m3d_loc.p0x=pos->x;m3d_loc.p0z=pos->z;
        m3d_loc.x0=pos->x*lx+pos->z*lz;
        m3d_DelfinoSlice(pos,lx,lz,m3d_loc.x0);
        m3d_loc.nvtx=n;m3d_loc.active=true;m3d_loc.owner=owner;return true;
    }
    if(m3d_ReferenceActive()) {
        m3d_loc.lx=lx;m3d_loc.lz=lz;m3d_loc.p0x=pos->x;m3d_loc.p0z=pos->z;
        m3d_loc.x0=pos->x*lx+pos->z*lz;
        m3d_ReferenceSlice(pos,lx,lz,m3d_loc.x0);
        m3d_loc.nvtx=n;m3d_loc.active=true;m3d_loc.owner=owner;
        return true;
    }
    if (m3d_ArenaActive()) {
        /* Fixed floor ID across headings: native grounded/ledge state survives
         * camera turns. Both endpoints come from the imported boundary. */
        m3d_loc.lx = lx;
        m3d_loc.lz = lz;
        m3d_loc.p0x = pos->x;
        m3d_loc.p0z = pos->z;
        m3d_loc.x0 = pos->x * lx + pos->z * lz;
        if (m3d_ArenaMeshActive()) {
            m3d_ArenaMeshMap(pos, lx, lz, m3d_loc.x0);
            m3d_loc.nvtx = n;
            m3d_loc.active = true;
            m3d_loc.owner = owner;
            return true;
        }
        hit = m3d_ArenaSlice(pos, lx, lz, &tin, &tout);
        for (i = 0; i < n; i++) {
            float nx = hit ? m3d_loc.x0 + (i == 0 || i == 3 ? tin : tout)
                           : 100000.0f + vtx[i].pos.x;
            m3d_save_x[i] = vtx[i].pos.x;
            m3d_save_px[i] = vtx[i].prev_pos.x;
            vtx[i].pos.x = vtx[i].prev_pos.x = nx;
        }
        m3d_loc.nvtx = n;
        m3d_RefreshIslands(cd);
        m3d_loc.active = true;
        m3d_loc.owner = owner;
        return true;
    }

    X0 = X1 = vtx[0].pos.x;
    for (i = 1; i < n; i++) {
        if (vtx[i].pos.x < X0) {
            X0 = vtx[i].pos.x;
        }
        if (vtx[i].pos.x > X1) {
            X1 = vtx[i].pos.x;
        }
    }
    span = X1 - X0;
    if (span < 1.0f) {
        return false;
    }
    Xc = 0.5f * (X0 + X1);
    D = m3d_cfg.flat ? 5000.0f
        : (m3d_cfg.depth > 0 ? (float) m3d_cfg.depth : 0.5f * span);
    K = m3d_StageCut(0.5f * span);

    m3d_loc.lx = lx;
    m3d_loc.lz = lz;
    m3d_loc.p0x = pos->x;
    m3d_loc.p0z = pos->z;

    tin = -1.0e9f;
    tout = 1.0e9f;
    hit = m3d_Slab(pos->x, lx, X0, X1, &tin, &tout) &&
          m3d_Slab(pos->z, lz, -D, D, &tin, &tout);
    if (hit && K > 0.0f) {
        float px = pos->x - Xc, pz = pos->z;
        hit = m3d_HalfPlane(px, pz, lx, lz, 1, 1, K, &tin, &tout) &&
              m3d_HalfPlane(px, pz, lx, lz, 1, -1, K, &tin, &tout) &&
              m3d_HalfPlane(px, pz, lx, lz, -1, 1, K, &tin, &tout) &&
              m3d_HalfPlane(px, pz, lx, lz, -1, -1, K, &tin, &tout);
    }
    if (hit) {
        tmid = 0.5f * (tin + tout);
    } else {
        /* the line misses the stage: put the stage far away */
        tmid = (Xc - pos->x) * lx + (0.0f - pos->z) * lz;
    }
    m3d_loc.x0 = Xc - tmid;

    for (i = 0; i < n; i++) {
        float nx;
        m3d_save_x[i] = vtx[i].pos.x;
        m3d_save_px[i] = vtx[i].prev_pos.x;
        if (hit) {
            float t = tin + (vtx[i].pos.x - X0) / span * (tout - tin);
            nx = Xc + (t - tmid);
        } else {
            nx = vtx[i].pos.x + 100000.0f;
        }
        vtx[i].pos.x = nx;
        vtx[i].prev_pos.x = nx;
    }
    m3d_loc.nvtx = n;
    m3d_RefreshIslands(cd);

    m3d_loc.active = true;
    m3d_loc.owner = owner;
    return true;
}

static void m3d_AlignLedge(Fighter* fp, M3dFt* m)
{
    MapCollData* cd;
    CollVtx* vtx;
    float X0, X1, Xc, D, K;
    int i;
    if (fp->motion_id < ftCo_MS_CliffCatch ||
        fp->motion_id > ftCo_MS_CliffJumpQuick2)
    {
        return;
    }
    if (m3d_DelfinoActive()) {
        /* The held native line belongs to the plane in which it was caught.
         * Snapping to another nearby mesh edge can remove that line from the
         * next slice, causing repeated fall/catch entries and no animation. */
        return;
    }
    if (m3d_ReferenceActive()) {
        float nx, nz;
        if(m3d_ReferenceInward(&fp->cur_pos,&nx,&nz)) {
            m->lx=fp->facing_dir*nx;m->lz=fp->facing_dir*nz;
        }
        return;
    }
    if (m3d_ArenaActive()) {
        float nx = 0, nz = 0;
        m3d_ArenaInward(&fp->cur_pos, &nx, &nz);
        m->lx = fp->facing_dir * nx;
        m->lz = fp->facing_dir * nz;
        return;
    }
    cd = mpLib_8004D164();
    vtx = mpGetGroundCollVtx();
    if (cd == NULL || vtx == NULL || cd->vert_count <= 0 ||
        cd->vert_count > M3D_MAX_VTX)
    {
        return;
    }
    X0 = X1 = vtx[0].pos.x;
    for (i = 1; i < cd->vert_count; i++) {
        if (vtx[i].pos.x < X0) X0 = vtx[i].pos.x;
        if (vtx[i].pos.x > X1) X1 = vtx[i].pos.x;
    }
    Xc = 0.5f * (X0 + X1);
    D = m3d_cfg.flat ? 5000.0f
        : (m3d_cfg.depth > 0 ? (float) m3d_cfg.depth : 0.5f * (X1 - X0));
    K = m3d_StageCut(0.5f * (X1 - X0));
    if (fp->motion_id >= ftCo_MS_CliffCatch &&
        fp->motion_id <= ftCo_MS_CliffJumpQuick2)
    {
        /* On a ledge: the lane is the inward normal of the nearest side, so
         * the held ledge is always the end of the chord. */
        float px = fp->cur_pos.x, pz = fp->cur_pos.z;
        float best = px - X0, nx = 1.0f, nz = 0.0f, d;
        if (best < 0.0f) best = -best;
        d = X1 - px; if (d < 0.0f) d = -d;
        if (d < best) { best = d; nx = -1.0f; nz = 0.0f; }
        d = pz + D; if (d < 0.0f) d = -d;
        if (d < best) { best = d; nx = 0.0f; nz = 1.0f; }
        d = D - pz; if (d < 0.0f) d = -d;
        if (d < best) { best = d; nx = 0.0f; nz = -1.0f; }
        if (K > 0.0f) {
            float sx, sz, ax = px - Xc;
            for (sx = -1.0f; sx < 2.0f; sx += 2.0f) {
                for (sz = -1.0f; sz < 2.0f; sz += 2.0f) {
                    d = (sx * ax + sz * pz - K) * 0.7071f;
                    if (d < 0.0f) d = -d;
                    if (d < best) {
                        best = d;
                        nx = -sx * 0.7071f;
                        nz = -sz * 0.7071f;
                    }
                }
            }
        }
        m->lx = fp->facing_dir * nx;
        m->lz = fp->facing_dir * nz;
    }
}

void m3d_EnterLocal(Fighter* fp)
{
    M3dFt* m = m3d_Get(fp);
    if (m == NULL || m3d_loc.active) {
        return;
    }
    /* Capture callbacks manipulate both fighters together. Their bone queries
     * and positions must share world space; individual native collision calls
     * borrow a slice through m3d_ItemCollBegin instead. */
    if (fp->victim_gobj != NULL || fp->x1A5C != NULL) return;
    m3d_AlignLedge(fp, m);
    if (m3d_MapBegin(fp, &fp->cur_pos, m->lx, m->lz)) {
        m3d_MapToLocal(&fp->cur_pos);
        m3d_MapCollToLocal(&fp->coll_data);
        m->rebirth_local=(m3d_DelfinoActive()||m3d_ReferenceOverlayActive()) && fp->motion_id>=ftCo_MS_Rebirth && fp->motion_id<=ftCo_MS_RebirthWait;
        if(m->rebirth_local)m3d_MapToLocal(&fp->mv.co.common.x4);
    }
}

bool m3d_LocalBegin(Fighter* fp)
{
    if (m3d_loc.active) {
        return false;
    }
    m3d_EnterLocal(fp);
    return m3d_loc.active;
}

void m3d_LocalEnd(Fighter* fp, bool began)
{
    if (began) {
        m3d_ExitLocal(fp);
    }
}

bool m3d_MapIsActive(void* owner)
{
    return m3d_loc.active && m3d_loc.owner == owner;
}

void m3d_MapCollToLocal(CollData* coll)
{
    m3d_MapToLocal(&coll->cur_pos);
    m3d_MapToLocal(&coll->prev_pos);
    m3d_MapToLocal(&coll->last_pos);
    m3d_MapToLocal(&coll->contact);
}

void m3d_MapCollToWorld(CollData* coll)
{
    m3d_MapToWorld(&coll->cur_pos);
    m3d_MapToWorld(&coll->prev_pos);
    m3d_MapToWorld(&coll->last_pos);
    m3d_MapToWorld(&coll->contact);
}

void m3d_MapEnd(void* owner)
{
    MapCollData* cd;
    CollVtx* vtx;
    int i;
    if (!m3d_MapIsActive(owner)) {
        return;
    }
    if(m3d_DelfinoActive()) {
        m3d_DelfinoEnd();m3d_loc.active=false;m3d_loc.owner=NULL;return;
    }
    if(m3d_ReferenceActive()) {
        m3d_ReferenceEnd();m3d_loc.active=false;m3d_loc.owner=NULL;return;
    } else if (m3d_ArenaMeshActive()) {
        m3d_ArenaMeshEnd();
        m3d_loc.active = false;
        m3d_loc.owner = NULL;
        return;
    }
    vtx = mpGetGroundCollVtx();
    for (i = 0; i < m3d_loc.nvtx; i++) {
        vtx[i].pos.x = m3d_save_x[i];
        vtx[i].prev_pos.x = m3d_save_px[i];
    }
    cd = mpLib_8004D164();
    if (cd != NULL) {
        m3d_RefreshIslands(cd);
    }
    m3d_loc.active = false;
    m3d_loc.owner = NULL;
}

void m3d_ExitLocal(Fighter* fp)
{
    if (!m3d_MapIsActive(fp)) {
        return;
    }
    M3dFt* m=m3d_Get(fp);
    if(m->rebirth_local) {
        if(fp->motion_id>=ftCo_MS_Rebirth && fp->motion_id<=ftCo_MS_RebirthWait)m3d_MapToWorld(&fp->mv.co.common.x4);
        m->rebirth_local=false;
    }
    m3d_MapToWorld(&fp->cur_pos);
    m3d_MapCollToWorld(&fp->coll_data);
    m3d_MapEnd(fp);
    fp->cur_pos.x+=m->platform_perp.x;fp->cur_pos.z+=m->platform_perp.z;
    m->platform_perp=(Vec3){0};
}

void m3d_FloorMotion(Fighter* fp,int line,Vec3* velocity)
{
    M3dFt* m=m3d_Get(fp);Vec3 point=fp->cur_pos,world;
    if(!m || !m3d_MapIsActive(fp))return;
    m3d_MapToWorld(&point);
    if(!m3d_ReferenceMotion(line,&point,&world))return;
    velocity->x=world.x*m->lx+world.z*m->lz;velocity->y=world.y;velocity->z=0;
    m->platform_perp=(Vec3){world.x-velocity->x*m->lx,0,world.z-velocity->x*m->lz};
}

/* ---- stage ---------------------------------------------------------------- */

/// After the stage's collision is loaded: optional flat test plane.
void m3d_StageInit(void)
{
    MapCollData* cd;
    CollVtx* vtx;
    CollJoint* joints;
    int i;

    m3d_ReferenceOverlayInit();
    if (m3d_StageIs3D()) m3d_GroundMarkersInit();
    if (m3d_cfg.loaded && m3d_StageIs3D() && !m3d_debug_nolocal) {
        cd = mpLib_8004D164();
        joints = mpGetGroundCollJoint();
        if (cd != NULL && joints != NULL) {
            for (i = 0; i < cd->joint_count; i++) {
                joints[i].bounding_min.x = -200000.0f;
                joints[i].bounding_max.x = 200000.0f;
                if (m3d_ArenaMeshActive()) {
                    joints[i].bounding_min.y = -200000.0f;
                    joints[i].bounding_max.y = 200000.0f;
                }
            }
        }
    }

    if (m3d_ArenaActive() || !m3d_StageIs3D() || !m3d_cfg.flat ||
        stage_info.grkind != Gr_Kind_Last)
    {
        return; /* the flat plane is a Final Destination test mode */
    }
    cd = mpLib_8004D164();
    vtx = mpGetGroundCollVtx();
    if (cd == NULL || vtx == NULL) {
        return;
    }
    for (i = 0; i < cd->vert_count; i++) {
        vtx[i].base_pos.x *= m3d_flat_scale;
        vtx[i].pos.x *= m3d_flat_scale;
        vtx[i].prev_pos.x *= m3d_flat_scale;
    }
    for (i = 0; i < cd->joint_count; i++) {
        mpJointUpdateBounding(i);
        mpLib_8005667C(i);
    }
    Ground_801C39A0(-20000.0f);
    Ground_801C39B0(20000.0f);
    OSReport("M3D FLAT verts=%d joints=%d\n", cd->vert_count, cd->joint_count);
}

/* Imported maps need a useful top KO plane over streets as well as roofs.
 * Decorative map bounds must not add hundreds of units of launch survival. */
float m3d_ImportedBlastTop(Fighter* fp)
{
    if (!m3d_FighterIs3D(fp)) return Stage_GetBlastZoneTopOffset();
    Vec3 world = fp->cur_pos;
    if (m3d_MapIsActive(fp)) m3d_MapToWorld(&world);
    if (m3d_DelfinoActive()) return m3d_DelfinoBlastTop(&world);
    if (m3d_ReferenceOverlayActive()) {
        Vec3 floor, probe = world;
        /* Grounded downhill integration can leave the origin just below
         * its source plane for one tick. Keep the KO query above that small
         * grounding overlap; this does not move collision or the perimeter. */
        probe.y += 4.0f;
        if (m3d_ReferenceFloor(&probe, &floor))
            return floor.y + M3D_LARGE_MAP_TOP_CLEARANCE;
        /* Onett's original road datum is zero. Outside the supported town,
         * keep a finite upper plane while the perimeter owns side KOs. */
        return M3D_LARGE_MAP_TOP_CLEARANCE;
    }
    return Stage_GetBlastZoneTopOffset();
}

/* Opt-in evidence at an actual semantic grounded KO, not another KO rule. */
static void onett_boundary_ko_debug(Fighter* fp,Vec3* world) {
    static int enabled=-1;if(enabled<0)enabled=getenv("MELEE3D_NATIVE_ONETT_BRAKE_TRACE")!=NULL;
    if(!enabled)return;
    Vec3 contact=fp->coll_data.contact,probe=*world,floor={0};
    if(m3d_MapIsActive(fp))m3d_MapToWorld(&contact);
    probe.y+=4;bool supported=m3d_ReferenceFloor(&probe,&floor);
    float lx=0,lz=0;m3d_GetLane(fp,&lx,&lz);CollData* c=&fp->coll_data;
    fprintf(stderr,"M3D ONETT BOUNDARY KO DETAIL slot=%u motion=%d ga=%d world=%.6f,%.6f,%.6f local=%d input=%.6f pad=%d lane=%.6f,%.6f floor=%d floor_flags=%x normal=%.6f,%.6f,%.6f contact=%.6f,%.6f,%.6f ecb=%.6f,%.6f,%.6f,%.6f desired=%.6f,%.6f,%.6f,%.6f env=%x source_floor=%d:%.6f,%.6f,%.6f self=%.6f,%.6f,%.6f gr=%.6f\n",
        fp->player_idx,fp->motion_id,fp->ground_or_air,world->x,world->y,world->z,m3d_MapIsActive(fp),
        fp->input.lstick[0].x,fp->cpu.lstick.x,lx,lz,c->floor.index,c->floor.flags,c->floor.normal.x,c->floor.normal.y,c->floor.normal.z,
        contact.x,contact.y,contact.z,c->ecb.left.x,c->ecb.right.x,c->ecb.bottom.y,c->ecb.top.y,
        c->desired_ecb.left.x,c->desired_ecb.right.x,c->desired_ecb.bottom.y,c->desired_ecb.top.y,c->env_flags,
        supported,floor.x,floor.y,floor.z,fp->self_vel.x,fp->self_vel.y,fp->self_vel.z,fp->gr_vel);
}

int m3d_ImportedBlastSide(Fighter* fp)
{
    Vec3 world = fp->cur_pos;
    if (!m3d_FighterIs3D(fp)) return 0;
    if (m3d_MapIsActive(fp)) m3d_MapToWorld(&world);
    if(m3d_DelfinoActive()) {
        if(m3d_PartyBlast(fp))return 2;
        if(m3d_CombatSideKO(fp))return 1;
        Vec3 previous=fp->prev_pos;
        if(m3d_MapIsActive(fp))m3d_MapToWorld(&previous);
        int side=m3d_DelfinoFighterBlast(fp,&world,&previous);
        /* Feet may dip below sea level while hands hold a dry dock. Native
         * attached ledge animations own that pose. Validate the held line and
         * its landing, and end this allowance as soon as native state releases
         * the ledge (including the airborne second half of a ledge jump). */
        bool attached=(fp->motion_id>=ftCo_MS_CliffCatch&&fp->motion_id<=ftCo_MS_CliffEscapeQuick)||fp->motion_id==ftCo_MS_CliffJumpSlow1||fp->motion_id==ftCo_MS_CliffJumpQuick1;
        if(side==2&&attached&&fp->ground_or_air==GA_Air) {
            bool began=m3d_LocalBegin(fp);bool dry=false;
            M3dFt* m=m3d_Get(fp);
            if(m&&m3d_MapIsActive(fp)&&mpLib_80054ED8(fp->mv.co.cliff.ledge_id)) {
                Vec3 edge,landing,floor;
                if(fp->facing_dir>0)mpLib_80053ECC_Floor(fp->mv.co.cliff.ledge_id,&edge);else mpLib_80053DA4_Floor(fp->mv.co.cliff.ledge_id,&edge);
                m3d_MapToWorld(&edge);landing=(Vec3){edge.x+fp->facing_dir*m->lx*2,edge.y+4,edge.z+fp->facing_dir*m->lz*2};
                if(m3d_DelfinoFloor(&landing,&floor)&&fabsf(floor.y-edge.y)<=4){landing.y=floor.y+1;dry=!m3d_DelfinoBlast(&landing);}
            }
            m3d_LocalEnd(fp,began);if(dry)side=0;
        }
        const char* probe=getenv("MELEE3D_NATIVE_DELFINO_PROBE");
        if(side&&probe&&!strcmp(probe,"ledges"))fprintf(stderr,"M3D LEDGE BLAST side=%d world=%.3f,%.3f,%.3f local=%d state=%d\n",side,world.x,world.y,world.z,m3d_MapIsActive(fp),fp->motion_id);
        return side;
    }
    if(m3d_ReferenceOverlayActive()) {
        if(m3d_PartyBlast(fp))return 2;
        if(fp->ground_or_air==GA_Ground&&!m3d_ReferenceOverlayGroundAllowed(&world)){onett_boundary_ko_debug(fp,&world);return 2;}
        Vec3 previous=fp->prev_pos;
        if(m3d_MapIsActive(fp))m3d_MapToWorld(&previous);
        return m3d_DelfinoFighterBlast(fp,&world,&previous);
    }
    if(m3d_ArenaMeshActive())return m3d_ArenaMeshBlastSide(&world);
    /* Dedicated FD: mirror native horizontal blast planes into depth.
     * Always test world coordinates, even inside a scoped collision slice. */
    if(world.x>Stage_GetBlastZoneRightOffset() || world.z>Stage_GetBlastZoneRightOffset())return 1;
    if(world.x<Stage_GetBlastZoneLeftOffset() || world.z<Stage_GetBlastZoneLeftOffset())return -1;
    return 0;
}

void m3d_WorldBonePoint(HSD_JObj* root, Vec3* point)
{
    int i, j;
    for (i = 0; i < GM_MAX_PLAYERS; i++) for (j = 0; j < 2; j++) {
        Fighter* fp = m3d_ft[i][j].fp;
        Vec3 model, world;
        if (!fp || !m3d_MapIsActive(fp) || fp->gobj->hsd_obj != root) continue;
        HSD_JObjGetTranslation(root, &model);
        /* procMap temporarily translates the model to the collision lane.
         * Its rotation is already a world rotation: repair translation only,
         * rather than rotating an already-rotated bone offset a second time. */
        if (fabsf(model.x-fp->cur_pos.x) > 0.001f ||
            fabsf(model.z-fp->cur_pos.z) > 0.001f) return;
        world = model;
        m3d_MapToWorld(&world);
        point->x += world.x-model.x;
        point->z += world.z-model.z;
        return;
    }
}

/* Aim follows facing, not an unrestricted nearest-enemy search. Angular
 * precision wins over proximity; walls and targets behind the player reject. */
HSD_GObj* m3d_AimTarget(Fighter* fp, Vec3* from, float fx, float fz)
{
    HSD_GObj* gobj;
    HSD_GObj* best=NULL;
    float score=1.0e20f;
    if (!m3d_FighterIs3D(fp)) return NULL;
    for (gobj=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];gobj;gobj=gobj->next) {
        Fighter* other=gobj->user_data;
        Vec3 target=other->cur_pos;
        float dx,dz,length,dot,candidate;
        if (other==fp || other->is_sleeping || other->invisible ||
            other->motion_id<=ftCo_MS_RebirthWait || ftCo_IsAlly(fp,other)) continue;
        if (m3d_MapIsActive(other)) m3d_MapToWorld(&target);
        target.y+=8;
        dx=target.x-from->x; dz=target.z-from->z;
        length=sqrtf(dx*dx+dz*dz);
        if (length<1 || length>400 || fabsf(target.y-from->y)>80) continue;
        dot=(dx*fx+dz*fz)/length;
        if (dot<0.8660254f) continue; /* +/-30 degrees */
        candidate=(1-dot)*1000+length*0.025f;
        if (candidate<score && m3d_SegmentClear(from,&target)) {
            score=candidate; best=gobj;
        }
    }
    return best;
}
