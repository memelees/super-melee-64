/* Native source port of the shared melee3d overlay; first stage gate: FD. */
#ifndef MELEE_M3D_M3D_H
#define MELEE_M3D_M3D_H

/// melee3d: generic "3D mode" for Melee fighters plus a test harness.

#include <Runtime/platform.h>

#include <dolphin/mtx.h>
#include <dolphin/gx.h>

#include <melee/ft/forward.h>
#include <melee/it/forward.h>
#include <melee/lb/forward.h>
#include <melee/mn/forward.h>
#include <sysdolphin/baselib/forward.h>

/* Equal vertical launch clearance over large-map streets and roofs. */
#define M3D_LARGE_MAP_TOP_CLEARANCE 180.0f

/* DELFINO: opt-in local-disc mega-map preview. */
#define M3D_DELFINO_KO_CLEARANCE 280.0f
struct CollLine;
bool m3d_DelfinoActive(void);
bool m3d_DelfinoExactLines(void);
void m3d_DelfinoSelect(bool enabled);
struct MapCollData* m3d_DelfinoCollision(struct MapCollData* original);
void m3d_DelfinoInit(void);
void m3d_WaterInit(void);
void m3d_DelfinoSlice(Vec3* pos,float lx,float lz,float x0);
void m3d_DelfinoEnd(void);
bool m3d_DelfinoAdvanceLine(struct CollLine** line,int* index,int count);
bool m3d_DelfinoVisible(Vec3* a,Vec3* b);
bool m3d_DelfinoViewClear(Vec3* a,Vec3* b);
bool m3d_DelfinoNavConnectedFloor(Vec3* from,Vec3* to);
bool m3d_DelfinoNavBodyClear(Vec3* support,Vec3* a,Vec3* b);
bool m3d_DelfinoNavOffsetSupported(Vec3* support,Vec3* offset,float tolerance);
bool m3d_DelfinoFloor(Vec3* pos,Vec3* ground);
int m3d_DelfinoCrossing(Vec3* pos);
bool m3d_DelfinoLedge(Vec3* pos,Vec3* goal,float* nx,float* nz);
bool m3d_DelfinoDrop(Vec3* pos);
int m3d_DelfinoBlast(Vec3* pos);
int m3d_DelfinoFighterBlast(Fighter* fp,Vec3* pos,Vec3* previous);
float m3d_DelfinoBlastTop(Vec3* pos);
bool m3d_DelfinoCameraFade(void);
Fighter* m3d_CameraSubject(void);
bool m3d_CameraSpectating(void);
void m3d_CameraRebirth(Fighter* fp);
bool m3d_DelfinoCameraReveals(Vec3* eye,Vec3* point);
void m3d_DelfinoRenderOccluders(void);
bool m3d_DelfinoWaterProbe(int ordinal,Vec3* water,Vec3* floor);
bool m3d_DelfinoCeilingProbe(int ordinal,Vec3* ground);
void m3d_DelfinoSpawn(int slot,int count,Vec3* pos);
void m3d_DelfinoShadow(HSD_Shadow* shadow);
void m3d_DelfinoCamera(Vec3* from,Vec3* eye);
void m3d_DelfinoValidate(int tick);
void m3d_DelfinoLedgeTargetsCheck(void);
bool m3d_DelfinoLedgeProbe(int ordinal,Vec3* edge,Vec3* inward);
bool m3d_DelfinoStepProbe(int ordinal,Vec3* point,Vec3* normal,float* rise,float* run);
bool m3d_DelfinoWallProbe(int ordinal,Vec3* start,Vec3* normal,Vec3* face,float* top);
void m3d_DelfinoRebirth(Fighter* fp);
void m3d_DelfinoNavSelect(const char* directory,Vec3* center);
bool m3d_DelfinoNavSpawn(int slot,Vec3* pos);
void m3d_DelfinoNavSpawnPose(Fighter* fp, Vec3* pose);
void m3d_DelfinoNavRebirthPrepare(Fighter* fp);
void m3d_OnettTrafficInit(HSD_GObj* gobj);
bool m3d_OnettTrafficBegin(HSD_GObj* gobj);
void m3d_OnettTrafficEnd(HSD_GObj* gobj);
float m3d_OnettTrafficEdge(void* ground, float original);
Fighter* m3d_DelfinoNavTarget(Fighter* fp,Fighter* current);
bool m3d_DelfinoNavRoute(Fighter* fp,Fighter* target,Vec3* goal);
void m3d_DelfinoNavDrive(Fighter* fp);
bool m3d_DelfinoNavSteering(Fighter* fp);
void m3d_DelfinoSpawnAim(Vec3* target);
bool m3d_CpuTravelPad(Fighter* fp,Vec3* goal,bool jump,bool precision);

/* Plaza party objectives, all expressed in the unborrowed world frame. */
void m3d_PartySetup(StartMeleeData* start);
void m3d_PartyReset(void);
bool m3d_PartyActive(void);
bool m3d_PartyEliminated(int slot);
void m3d_CombatTick(void);
void m3d_CombatConfigure(void);
bool m3d_CombatAssist(void);
bool m3d_ProjectileDistanceAssist(void);
bool m3d_CombatTarget(Fighter* fp,Vec3* pos,bool* locked);
int m3d_CombatSideKO(Fighter* fp);
bool m3d_CombatNormal(Fighter* fp);
float m3d_CombatLaunchFraction(Fighter* fp);
void m3d_DelfinoZoneRadii(Vec3* center,float radii[33]);
void m3d_PartyTick(void);
void m3d_HudStock(HSD_JObj* joint);
void m3d_HudEmblem(HSD_JObj* joint);
bool m3d_HumanNamesActive(void);
float m3d_HudStockFrame(int slot);
float m3d_HudEmblemFrame(int slot,float original);
void m3d_PartyRender(void);
struct MatchEnd;
void m3d_PartyResults(struct MatchEnd* me);
void m3d_PartyResultsExit(void);
int m3d_ResultPad(int panel);
bool m3d_ResultSupported(int ckind);
const char* m3d_ResultAnimFile(int ckind);
int m3d_ResultEmblem(int ckind);
float m3d_ResultNameFrame(int ckind,float retail);
int m3d_ResultLayoutKind(int ckind);
float m3d_ResultScale(int ckind,float retail);
int m3d_ResultThemeKind(int ckind,const char** file);
bool m3d_MagnifyHidden(HSD_GObj* gobj);
bool m3d_SpatialSound(Vec3* source,u8* vol,u8* pan);
bool m3d_FighterSound(Fighter* fp,u8* vol,u8* pan);
bool m3d_ItemSound(Item* ip,u8* vol,u8* pan);
void m3d_PartyHold(Fighter* fp);
int m3d_PartyBlast(Fighter* fp);
void m3d_PartyCamera(Vec3* focus,Vec3* eye);
bool m3d_PartyGoal(Fighter* fp,Vec3* goal);
float m3d_PartyGoalRadius(void);
bool m3d_DelfinoNavObjective(int index,Vec3* pos);
bool m3d_DelfinoNavHill(int phase,int index,Vec3* pos);
float m3d_DelfinoExtent(Vec3* center);

/* ---- config (m3d.cfg on the disc root; absent = vanilla boot) ---------- */

typedef struct M3dConfig {
    bool loaded;
    int boot_match;   ///< 1: skip menus, boot a debug VS match
    int stage;        ///< StKind (0x20 = Final Destination)
    int p1;           ///< CharacterKind for port 0 (human)
    int p2;           ///< CharacterKind for slot 1 (-1 = none)
    int p3;           ///< optional idle CPU in slot 2 for targeting tests
    int p4;           ///< optional CPU in slot 3 for four-player checks
    int p2_human;     ///< 1: slot 1 is a human on port 1
    int p2_cpu_kind;  ///< 15 = do nothing, 0 = training "stop", 4 = AI
    int p2_cpu_level; ///< 1..9
    int mode3d;       ///< 1: enable dedicated 3D stages (debug boot forces 3D)
    int arena;        ///< debug boot: imported arena catalogue ID (1..6)
    int flat;         ///< 1: stretch the stage floor into a flat plane
    int log_every;    ///< log fighter state every N frames (0 = off)
    int unlock;       ///< expose the standard roster/stages without changing saves
    int camera;       ///< 0 player orbit, 1 native Smash-style framing
    int depth;        ///< stage half-depth in Z (0 = auto: square)
    char script[32];  ///< input script file for port 0 ("" = none)
} M3dConfig;

extern M3dConfig m3d_cfg;
void m3d_NativeConfigure(void);
void m3d_ApplyRuleModifiers(Fighter* fp);
bool m3d_SeparateAttackInputs(void);
bool m3d_MoveControls(Fighter* fp);
bool m3d_GetMoveInput(Fighter* fp,Vec2* world,Vec2* cstick,bool* throttle);
float m3d_GetVerticalInput(Fighter* fp);
bool m3d_RecoveryInput(Fighter* fp);
bool m3d_ItemControl(Item* ip,HSD_GObj* owner,float turn,float* x,float* y);
float m3d_ThunderSpeed(void);
float m3d_ThunderLifetime(void);
bool m3d_ItemSteerVelocity(Item* ip,HSD_GObj* owner,float turn,float speed);
bool m3d_ItemSteer3D(Item* ip,HSD_GObj* owner,float turn,float speed);
bool m3d_ThunderLaunch(Item* ip,HSD_GObj* owner,float speed);
bool m3d_ItemTrailFrame(Item* ip,Vec3* next,float* pitch);
bool m3d_ItemControlAccel(Item* ip,HSD_GObj* owner,float acceleration,float maximum);
void m3d_ReferenceValidate(int tick);
void m3d_ReferenceDebug(Fighter* fp);
bool m3d_ReferenceSupported(int stage);
void m3d_ReferenceSelect(int stage);
bool m3d_ReferenceActive(void);
bool m3d_ReferenceOverlayActive(void);
bool m3d_ReferenceOverlayWater(Vec3* pos,float* surface);
void m3d_ReferenceOverlayInit(void);
bool m3d_ReferenceOverlayViewClear(Vec3* a,Vec3* b);
bool m3d_ReferenceOverlayConnectedFloor(Vec3* from,Vec3* to);
bool m3d_ReferenceOverlayBodyClear(Vec3* support,Vec3* a,Vec3* b);
bool m3d_ReferenceOverlayOffsetSupported(Vec3* support,Vec3* offset,float tolerance);
int m3d_ReferenceOverlayBlast(Vec3* pos);
bool m3d_ReferenceOverlayGroundAllowed(Vec3* pos);
float m3d_ReferenceOverlayExtent(Vec3* pos);
bool m3d_ReferenceCastleActive(void);
float m3d_ReferenceOverlayPeakHeight(void);
float m3d_ReferenceOverlayStreetHeight(void);
void m3d_ReferenceOverlayGoop(void (*triangle)(Vec3 a,Vec3 b,Vec3 c,int level,int axis));
void m3d_ReferenceOverlayAim(Vec3* pos);
void m3d_ReferenceOverlayZoneRadii(Vec3* center,float radii[33]);
bool m3d_ReferenceOverlayAdvanceLine(struct CollLine** line,int* index,int count);
unsigned m3d_ReferenceOverlayEndpointScope(int line_id,bool* verify);
bool m3d_ReferenceOverlayFloorRange(struct CollLine* first,int count);
bool m3d_ReferenceOverlayAdvanceFloor(struct CollLine** line,int* index,int count,float ax,float bx,int skip);
struct MapCollData* m3d_ReferenceCollision(struct MapCollData* original);
void m3d_ReferenceSlice(Vec3* pos,float lx,float lz,float x0);
void m3d_ReferenceEnd(void);
bool m3d_ReferenceFloor(Vec3* pos,Vec3* ground);
bool m3d_ReferenceDrop(Vec3* pos);
bool m3d_ReferenceLedge(Vec3* pos,Vec3* goal);
bool m3d_ReferenceInward(Vec3* pos,float* nx,float* nz);
bool m3d_ReferenceSurfacePoint(int index,Vec3* point);
int m3d_ReferenceAtlasPoints(Vec3* points,int capacity);
bool m3d_ReferenceMotion(int line,Vec3* point,Vec3* velocity);
void m3d_ReferenceTestTranslate(int index,float dx);
void m3d_FloorMotion(Fighter* fp,int line,Vec3* velocity);
void m3d_ReferenceShadow(HSD_Shadow* shadow);
void m3d_ReferenceSpawn(Vec3* center,float* radius);
bool m3d_CameraOwnsCStick(void);
void ftPartSetRotY_Raw(Fighter* fp,int part_idx,float rotate_y);

/// Boot: read m3d.cfg + script. Returns true if we should boot a debug match.
bool m3d_Boot(void);
int m3d_LoadFile(const char* name, char* buf, int bufsize);

/// Fill the debug-VS StartMeleeData from the config (after vanilla defaults).
void m3d_SetupDebugMatch(StartMeleeData* start);

/// Right after HSD_PadRenewGameStatus(): scripted input injection.
void m3d_PadHook(void);

/// Frames elapsed in the current match (advanced by the camera proc).
extern int m3d_match_frame;
extern int m3d_camera_frame;

/// Per-frame logging, called once per match frame.
void m3d_LogFrame(void);

/* ---- 3D movement (m3d_move.c) ------------------------------------------ */

bool m3d_FighterIs3D(Fighter* fp);
float m3d_ForwardYawDeg(Fighter* fp);
bool m3d_GetLane(Fighter* fp, float* lx, float* lz);
void m3d_SetLane(Fighter* fp, float lx, float lz);
void m3d_RemapInput(Fighter* fp);
void m3d_CpuAim(Fighter* fp, Vec3* target);
bool m3d_CpuRecoveryGoal(Fighter* fp, Vec3* target);
bool m3d_PartyFlee(Fighter* fp);
float m3d_PartyRouteCost(Vec3 from,Vec3 to);
bool m3d_CpuBegin(Fighter* fp);
void m3d_CpuEnd(Fighter* fp, bool began);
void m3d_CpuCompanion(Fighter* fp, void (*native)(Fighter*));
bool m3d_CpuIsActive(void);
bool m3d_CpuSameFloor(Fighter* fp, Item* ip);
bool m3d_CpuIgnoreItem(Fighter* fp, Item* ip);
int m3d_CpuItemInterest(Fighter* fp, int native);
bool m3d_PickupRange(Fighter* fp, Vec3* pos, DiscVec4* offset, float xr, float yr);
int m3d_CpuFrames(Fighter* fp);
u32 m3d_FilterButtons(Fighter* fp, u32 buttons);
bool m3d_AddVel(Fighter* fp, Vec3* v);
void m3d_PostMap(Fighter* fp);
void m3d_DynamicsReset(Fighter* fp);
void m3d_DynamicsBegin(Fighter* fp);
void m3d_DynamicsEnd(void);
bool m3d_DynamicsActive(void);
bool m3d_DynamicsFloor(Vec3* origin, Vec3* direction, float length);
void m3d_EnterLocal(Fighter* fp);
void m3d_ExitLocal(Fighter* fp);
bool m3d_LocalBegin(Fighter* fp);
void m3d_LocalEnd(Fighter* fp, bool began);
float m3d_FilterRootRotY(Fighter* fp, float rot);
float m3d_HitDirection(Fighter* victim, Fighter* attacker, float vanilla_dir);
void m3d_CopyLane(Fighter* dst, Fighter* src);
bool m3d_OffsetX(Fighter* fp, Vec3* pos, float dx);
float m3d_GrabDist(Fighter* a, Fighter* b, float vanilla_dx);
void m3d_StageInit(void);
void m3d_SpawnPoint(int slot, Vec3* pos);
void m3d_ArenaMeshSpawnRing(Vec3* center, float* radius);
bool m3d_StageIs3D(void);
bool m3d_LargeFDActive(void);
bool m3d_StageHas3D(int stkind);
bool m3d_StageMenuSupported(void);
int m3d_StageSelect(int stkind, bool three_d);
void m3d_StageActivate(int stkind);
void m3d_StageDeactivate(void);
void m3d_MatchReset(void);
void m3d_FightersReset(void);
void m3d_ItemsReset(void);
void m3d_CpusReset(void);

/* ---- private imported arenas ------------------------------------------ */
bool m3d_GroundBelow(Vec3* pos, Vec3* ground);
bool m3d_SegmentClear(Vec3* from, Vec3* to);
HSD_GObj* m3d_AimTarget(Fighter* fp, Vec3* from, float fx, float fz);
int m3d_ItemAssistSlot(Item* ip);
bool m3d_RandomDrop(Vec3* pos);
/* Map-wide random item drops (3D stages): frequency option, spawn pacing,
 * live cap and diagnostics around Melee's own item spawner. */
int m3d_ItemDropFrequency(void);
int m3d_ItemDropInterval(int frames);
int m3d_ItemDropKind(int kind);
void m3d_ItemDropLimits(s32* common_cap);
void m3d_ItemDropped(HSD_GObj* item, int kind);
void m3d_ItemDropTick(void);
bool m3d_ItemDropNear(Vec3* center, float* radius);
bool m3d_DelfinoNavDrop(Vec3* pos, const Vec3* near, float radius);
bool m3d_DelfinoNavFar(const Vec3* avoid, int count, const void* zone_center, float zone_radius, Vec3* out);
bool m3d_PartyDropZone(Vec3* center, float* radius);
bool m3d_PartyRoundOver(void);
void m3d_GoopAttributes(Fighter* fp,bool rebuilt);
void m3d_GoopMaterial(Fighter* fp,HSD_TObj* textures);
bool m3d_GoopMayCover(Vec3* point,float radius);
float m3d_GoopCoverage(Vec3* point);
float m3d_GoopWater(void);
void m3d_GoopWaterMaterial(void);
float m3d_GoopField(Vec3* point);
float m3d_GoopDepth(Vec3* point);
float m3d_DelfinoStreetHeight(void);
void m3d_DelfinoGoop(void);
unsigned m3d_PartyChecksum(void);
void m3d_PlaytestHit(int attacker, int victim);
bool m3d_PartyRespawnFocus(int slot, Vec3* focus);
bool m3d_PartySurged(int slot);
int m3d_PartyBountyLeader(void);
bool m3d_ArenaMeshActive(void);
bool m3d_ArenaMeshLoad(char* filename);
struct MapCollData* m3d_ArenaMeshCollision(void);
void m3d_ArenaMeshMap(Vec3* pos, float lx, float lz, float x0);
void m3d_ArenaMeshEnd(void);
bool m3d_ArenaMeshOutside(Vec3* pos);
void m3d_ArenaMeshSpawn(Vec3* pos);
void m3d_ArenaMeshBounds(void);
int m3d_ArenaMeshBlastSide(Vec3* pos);
float m3d_ImportedBlastTop(Fighter* fp);
int m3d_ImportedBlastSide(Fighter* fp);
int m3d_ArenaShadowReceivers(void);
int m3d_ArenaShadowTexels(void);
void m3d_ArenaMeshInward(Vec3* pos, float* nx, float* nz);
int m3d_ArenaKey(int stkind);
char* m3d_ArenaLabel(int stkind, int line);
char* m3d_ArenaMusic(void);
void m3d_ArenaFilename(char* suffix, char* buffer);
void m3d_ArenaBoot(void);
bool m3d_ArenaAvailable(void);
bool m3d_ArenaActive(void);
void m3d_ArenaLoad(int id);
void m3d_ArenaVisualLoad(bool enabled);
bool m3d_ArenaVisualRender(void);
void m3d_GroundMarkersInit(void);
int m3d_GroundMarkerAlpha(int slot);
struct MapCollData* m3d_ArenaCollision(struct MapCollData* native);
void m3d_ArenaInit(void);
bool m3d_ArenaSlice(Vec3* pos, float lx, float lz, float* lo, float* hi);
bool m3d_ArenaOutside(Vec3* pos);
void m3d_ArenaInward(Vec3* pos, float* nx, float* nz);

/* ---- shared stage slice ---------------------------------------------- */
bool m3d_MapBegin(void* owner, Vec3* pos, float lx, float lz);
bool m3d_MapIsActive(void* owner);
void m3d_MapEnd(void* owner);
void m3d_MapToLocal(Vec3* pos);
void m3d_MapToWorld(Vec3* pos);
void m3d_MapCollToLocal(CollData* coll);
void m3d_MapCollToWorld(CollData* coll);

/* ---- shared items/projectiles (m3d_item.c) ---------------------------- */
bool m3d_EntityIs3D(HSD_GObj* gobj);
void m3d_WorldBonePoint(HSD_JObj* root, Vec3* point);
void m3d_RecordWorldPoint(HSD_JObj* bone, Vec3* pos);
void m3d_ItemSpawnPos(HSD_GObj* parent, Vec3* source, Vec3* dest);
void m3d_ItemPrepareSpawn(SpawnItem* spawn);
bool m3d_ItemReleasePoint(Item* ip, Vec3* point);
float m3d_ItemDeltaX(Item* ip, Vec3* from, Vec3* to);
float m3d_ItemWorldYaw(Item* ip, float native_yaw);
void m3d_ItemInit(Item* ip, HSD_GObj* parent);
void m3d_ItemForget(Item* ip);
bool m3d_ItemCollBegin(CollData* coll);
void m3d_ItemCollEnd(CollData* coll, bool began);
bool m3d_ItemRayCast(HSD_GObj* gobj, Vec3* from, Vec3* to, Vec3* normal,
                       int* line, u32* flags, int joint_only);
bool m3d_ItemAddVel(Item* ip, Vec3* v);
bool m3d_ItemQueryBegin(Item* ip);
void m3d_ItemQueryEnd(Item* ip, bool began);
float m3d_ItemQuerySide(Vec3* from, Vec3* to, float vanilla_dx);
float m3d_ItemQueryDistance(Vec3* from, Vec3* to, float vanilla_dist_sq);
void m3d_ItemQueryPoint(Vec3* point);
void m3d_ItemFighterPoint(HSD_GObj* target, Vec3* point);
void m3d_ItemQueryRecord(HSD_GObj* target);
void m3d_ItemQueryFallbackPoint(HSD_GObj* target, Vec3* point);
bool m3d_ItemQueryStats(Item* ip, int* target_slot, int* queries);
void m3d_ItemUnpose(Item* ip);
void m3d_ItemPose(Item* ip);
float m3d_ItemHitDirection(Fighter* victim, Item* ip, float vanilla_dir);
bool m3d_ItemAreaBegin(Item* ip, Vec3* target, Vec3 saved[8]);
float m3d_ItemReturnTop(Item* ip,float original);
void m3d_ItemAreaEnd(Item* ip, bool began, Vec3 saved[8]);

/* ---- camera ------------------------------------------------------------ */

/// True while the third-person camera owns the view (C-stick is camera).
bool m3d_CameraIsActive(void);

/// Once per logic frame from the camera proc.
void m3d_CameraUpdate(bool standard_mode);

/// From the camera render step; overrides the CObj when active.
bool m3d_CameraApply(HSD_CObj* cobj);

/// Camera yaw in radians (0 = camera on +Z looking toward -Z).
int m3d_CameraGetMode(void);
void m3d_CameraSetMode(int mode);
float m3d_CameraGetYaw(void);
float m3d_CameraGetPitch(void);
void m3d_CameraSetYaw(float yaw);
void m3d_CameraSetPitch(float pitch);
void m3d_CameraSetDist(float dist);

#endif
