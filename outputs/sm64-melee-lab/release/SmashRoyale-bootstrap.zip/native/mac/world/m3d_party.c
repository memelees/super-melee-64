#include "pc/m3d_room.h"
#include "pc/widescreen.h"
#include "pc/m3d_menu.h"
#include <melee/ft/ft_0D4D.h>
/* SPDX-License-Identifier: GPL-3.0-or-later
 * Native Plaza party adapter: objectives, pad-driven CPU goals, GX markers,
 * SIS HUD. Fighter combat, item simulation and stock deaths stay native. */
#include "m3d.h"
#include "m3d_party_rules.h"
#include "m3d_goop_rules.h"
#include <melee/ft/ftcoll.h>
#include <melee/ft/kinds/ftCommon/ftCo_Damage.h>
#include <melee/ft/kinds/ftCommon/inlines.h>
#include "m3d_objective.h"
#include <pc/widescreen.h>
#include <sysdolphin/baselib/tev.h>
#include <pc/m3d_akaneia.h>
#include <pc/m3d_lab.h>
#include <ctype.h>
#include <melee/ef/efsync.h>
#include <melee/ft/ftcolanim.h>
#include <melee/ft/ftlib.h>
#include <sysdolphin/baselib/random.h>
#include <melee/gm/gm_1601.h>
#include <melee/gm/gmvs.h>
#include <melee/gm/gmresult.h>
#include <melee/gm/types.h>
#include <melee/it/types.h>
#include <melee/lb/lbarchive.h>
#include <melee/lb/lbspdisplay.h>
#include <sysdolphin/baselib/jobj.h>
#include <sysdolphin/baselib/mobj.h>
#include <stdio.h>
#include <stdlib.h>
#include <melee/if/forward.h>
#include <melee/ft/types.h>
#include <melee/ft/inlines.h>
#include <melee/mn/types.h>
#include <melee/pl/player.h>
#include <sysdolphin/baselib/gobj.h>
#include <sysdolphin/baselib/sislib.h>
#include <sysdolphin/baselib/controller.h>
#include <dolphin/gx.h>
#include <melee/if/ifall.h>
#include <melee/lb/lbarchive.h>
#include <melee/sc/types.h>
#include <sysdolphin/baselib/aobj.h>
#include <sysdolphin/baselib/cobj.h>
#include <sysdolphin/baselib/dobj.h>
#include <sysdolphin/baselib/gobjgxlink.h>
#include <sysdolphin/baselib/gobjobject.h>
#include <sysdolphin/baselib/state.h>
#include <sysdolphin/baselib/tobj.h>
_Static_assert(M3D_PARTY_PLAYERS==GM_MAX_PLAYERS,"Party/player capacities must agree");
/* Complete map banks and the original Onett city overlay share objectives. */
static bool party_map_active(void) {return m3d_DelfinoActive()||m3d_ReferenceOverlayActive();}
static HSD_Archive* hud_archive;
static HSD_MatAnimJoint *stock_animation,*emblem_animation;
static bool hud_art(void) {
    if(!party_map_active()||!m3d_akaneia_enabled())return false;
    if(!hud_archive) {
        hud_archive=lbArchive_LoadArchive("M3dHud.dat");
        DiscU32* stock=HSD_ArchiveGetPublicAddress(hud_archive,"Stc_icns");
        emblem_animation=HSD_ArchiveGetPublicAddress(hud_archive,"Eblm_matanim_joint");
        if(!stock||!emblem_animation){fprintf(stderr,"M3D HUD FAIL missing Akaneia art\n");abort();}
        stock_animation=DP(HSD_MatAnimJoint,stock[1].v);
        fprintf(stderr,"M3D HUD ART ready stock_stride=%u stock_reserved=%u\n",m3d_akaneia_stock_stride(),m3d_akaneia_stock_reserved());
    }return true;
}
void m3d_HudStock(HSD_JObj* joint) {
    if(!hud_art())return;
    for(int i=1;i<=7;i++){HSD_JObj* icon=NULL;lb_80011E24(joint,&icon,i,-1);if(icon)HSD_JObjAddAnimAll(icon,NULL,stock_animation,NULL);}
}
void m3d_HudEmblem(HSD_JObj* joint) {
    if(hud_art()&&joint->child)HSD_JObjAddAnimAll(joint->child,NULL,emblem_animation,NULL);
}
float m3d_HudStockFrame(int slot) {
    if(!hud_art())return gm_80168BF8(slot);
    int kind=Player_800325C8(Player_GetPlayerCharacter(slot),false);
    return m3d_akaneia_stock_reserved()+m3d_akaneia_stock_stride()*Player_GetCostumeId(slot)+m3d_akaneia_internal(kind);
}
float m3d_HudEmblemFrame(int slot,float original) {
    if(!hud_art())return original;
    int kind=Player_800325C8(Player_GetPlayerCharacter(slot),false);
    unsigned frame=m3d_akaneia_emblem(kind);
    fprintf(stderr,"M3D HUD EMBLEM slot=%d kind=%d frame=%u\n",slot,kind,frame);
    return frame;
}
static M3dPartyRules party;
static HSD_Text* text;static int entries[5],shadows[5];static char previous[5][192];
static HSD_Text* names_text;static int name_entry[GM_MAX_PLAYERS],name_shadow[GM_MAX_PLAYERS];
static unsigned hill_arrivals[GM_MAX_PLAYERS];
static bool elevated_hill[M3D_PARTY_HILLS];
static int initialized,last_hill=-1,last_coins[GM_MAX_PLAYERS],last_alive=-1,match_players;
static M3dGoop goop[GM_MAX_PLAYERS];
static struct {Fighter* fp;float speed,gravity;} goop_attrs[GM_MAX_PLAYERS][2];
static void goop_tick(void);
static void goop_reset(void);
static int option(const char* name,int fallback,int lo,int hi);
static int goop_active(void){return initialized&&party.mode==M3D_PARTY_SURVIVAL&&party_map_active()&&!party.finished;}
static bool goop_floor(Vec3* at,Vec3* floor){return m3d_DelfinoActive()?m3d_DelfinoFloor(at,floor):m3d_ReferenceFloor(at,floor);}
static float goop_street(void){return m3d_DelfinoActive()?m3d_DelfinoStreetHeight():m3d_ReferenceOverlayStreetHeight();}
void m3d_GoopAttributes(Fighter* fp,bool rebuilt) {
    if(fp->player_idx>=GM_MAX_PLAYERS)return;
    int i=fp->player_idx,j=fp->is_sub_fighter?1:0;
    float old_speed=goop_attrs[i][j].speed,old_gravity=goop_attrs[i][j].gravity;
    if(rebuilt||goop_attrs[i][j].fp!=fp||!old_speed){old_speed=old_gravity=1;}
    float speed=goop_active()?m3d_goop_speed(&goop[i]):1,gravity=goop_active()?m3d_goop_gravity(&goop[i]):1;
    float ratio=speed/old_speed;
    float jump=(1-.1f*(goop_active()?goop[i].coat:0))/(1-(1-old_speed)/.22f*.1f);
    fp->co_attrs.jump_v_initial_velocity*=jump;fp->co_attrs.hop_v_initial_velocity*=jump;
#define GOOP_SCALE(field) fp->co_attrs.field*=ratio
    GOOP_SCALE(walk_accel_mul);GOOP_SCALE(walk_accel_base);GOOP_SCALE(walk_max_vel);
    GOOP_SCALE(slow_walk_max);GOOP_SCALE(mid_walk_point);GOOP_SCALE(fast_walk_min);
    GOOP_SCALE(dash_initial_velocity);GOOP_SCALE(dash_accel_mul);GOOP_SCALE(dash_accel_base);GOOP_SCALE(dash_max_velocity);
    GOOP_SCALE(ground_max_horizontal_velocity);GOOP_SCALE(air_drift_stick_mul);GOOP_SCALE(aerial_drift_base);GOOP_SCALE(air_drift_max);GOOP_SCALE(air_max_horizontal_velocity);
#undef GOOP_SCALE
    fp->co_attrs.gravity*=gravity/old_gravity;
    fp->co_attrs.terminal_velocity*=sqrtf(gravity/old_gravity);
    goop_attrs[i][j].fp=fp;goop_attrs[i][j].speed=speed;goop_attrs[i][j].gravity=gravity;
}
static int goop_castle_duration(void) {
    int duration=party.storm_duration;
    if(party.duration>0&&party.duration-1200<duration)duration=party.duration-1200;
    return duration>0?duration:1;
}
bool m3d_GoopMayCover(Vec3* p,float radius) {
    /* Castle's rising fill also reaches the last clean district. A radial
     * broad phase alone would silently cull the tower's visible goop. */
    return goop_active()&&(m3d_ReferenceCastleActive()||hypotf(p->x-party.storm.x,p->z-party.storm.z)+radius>party.storm_radius-55);
}
float m3d_GoopField(Vec3* p) {
    if(!goop_active())return -1;
    if(m3d_ReferenceCastleActive())return m3d_goop_castle_field(p->x,p->y,p->z,party.storm.x,party.storm.z,party.storm_radius,m3d_party_storm_width(&party),goop_street(),m3d_ReferenceOverlayPeakHeight(),party.tick,goop_castle_duration());
    return m3d_goop_field(p->x,p->y,p->z,party.storm.x,party.storm.z,party.storm_radius,m3d_party_storm_width(&party),goop_street()+2*fmaxf(0,(party.tick-5400)/60.f));
}
float m3d_GoopDepth(Vec3* p) {
    return goop_active()?m3d_goop_clamp(m3d_GoopField(p)):0;
}
/* Water mixes over the round instead of inheriting the land's hard edge.
 * One concentration for a connected sea avoids diagonal bands on the donor's
 * huge ocean triangles; its own animated texture remains visible. */
float m3d_GoopWater(void) {
    if(!goop_active())return 0;
    if(getenv("MELEE3D_NATIVE_GOOP_WATER_PROBE"))return option("MELEE3D_NATIVE_GOOP_WATER_PROBE",0,0,100)/100.f;
    float phase=m3d_goop_clamp(party.tick/10800.f);
    float closing=party.storm_start>party.storm_end+1?m3d_goop_clamp((party.storm_start-party.storm_radius)/(party.storm_start-party.storm_end)):0;
    float amount=fmaxf(phase,closing);return amount*amount*(3-2*amount);
}
float m3d_GoopCoverage(Vec3* p) {return m3d_GoopField(p)>0?1:0;}
static int ko_heal,storm_damage,last_kos[GM_MAX_PLAYERS];
static int out_tick[GM_MAX_PLAYERS],end_requested,return_ticks;
/* Survives the match scene's reset so the results scene can read it. */
static int result_order[GM_MAX_PLAYERS],result_count=-1,result_has_winner,spotlight_winner=-1;
/* The retail results scene has tables for the 26 retail characters only. */
static bool results_supported(int slot){int c=Player_GetPlayerCharacter(slot);return c<26||(c>=34&&c<=40&&m3d_akaneia_enabled());}
static M3dPartyPoint point(Vec3 p){return (M3dPartyPoint){p.x,p.y,p.z};}
static Vec3 vector(M3dPartyPoint p){return (Vec3){p.x,p.y,p.z};}
static int mode(void) {
    const char* name=getenv("MELEE3D_NATIVE_PARTY");
    if(!name||!strcmp(name,"battle"))return 0;
    if(!strcmp(name,"time"))return M3D_PARTY_TIME;if(!strcmp(name,"stock"))return M3D_PARTY_STOCK;if(!strcmp(name,"bonus"))return M3D_PARTY_BONUS;
    if(!strcmp(name,"hill"))return 1;if(!strcmp(name,"survival"))return 3;if(!strcmp(name,"coin"))return 4;
    fprintf(stderr,"M3D PARTY FAIL invalid mode\n");exit(2);
}
static int option(const char* key,int fallback,int low,int high) {
    const char* s=getenv(key);if(!s)return fallback;char* end;long n=strtol(s,&end,10);
    if(!*s||*end||n<low||n>high){fprintf(stderr,"M3D PARTY FAIL invalid %s\n",key);exit(2);}return n;
}
void m3d_PartySetup(StartMeleeData* start) {
    int m=mode();if(!m)return;
    /* Coin Battle runs Melee's own coin rules (coins from hits, half lost on a
     * KO); the party layer owns the clock, scoreboard and results. */
    start->rules.match_kind=m==3||m==M3D_PARTY_STOCK?MatchKind_Stock:m==4?MatchKind_Coin:m==M3D_PARTY_BONUS?MatchKind_Bonus:MatchKind_Time;start->rules.is_stock=m==3||m==M3D_PARTY_STOCK;
    start->rules.timer_enabled=0;start->rules.x5_0=1; // Our HUD owns round results, avoiding the four-player results scene.
    start->rules.is_teams=0;
    if(m==3)for(int i=0;i<GM_MAX_PLAYERS;i++)start->players[i].stocks=1;
}
static void text_destroy(void* p) {if(text==p)text=NULL;HSD_SisLib_803A5A2C(p);}
static void validate_text(void) {
    if(!text)return;
    for(HSD_Text* t=HSD_SisLib_804D7978;t;t=t->next)if(t==text&&t->entity&&t->entity->user_data_remove_func==text_destroy)return;
    text=NULL;
}
static void sb_reset(void);
static void br_reset(void);
static void br_roster(void);
static int objective_hill=-1,objective_phase=-1,objective_tick=-1,objective_visible;
static M3dObjectiveArrow objective_arrow;
static void objective_project(void);
static void objective_render(void);
static void names_reset(void) {
    if(names_text){for(HSD_Text* t=HSD_SisLib_804D7978;t;t=t->next)if(t==names_text){HSD_SisLib_803A5CC4(t);break;}}
    names_text=NULL;
}
static int pt_frame,persona_ready,persona_spot_tick[GM_MAX_PLAYERS],respawn_mode,bounty_on,ping_on,iso_seconds[GM_MAX_PLAYERS];
void m3d_PartyReset(void) {
    goop_reset();names_reset();match_players=0;
    objective_hill=objective_phase=objective_tick=-1;objective_visible=0;
    hud_archive=NULL;
    sb_reset();br_reset();pt_frame=0;respawn_mode=-1;bounty_on=ping_on=-1;persona_ready=0;memset(persona_spot_tick,0,sizeof persona_spot_tick);
    validate_text();if(text)HSD_SisLib_803A5CC4(text);text=NULL;
    memset(&party,0,sizeof party);initialized=0;memset(out_tick,0,sizeof out_tick);end_requested=0;return_ticks=0;last_hill=last_alive=-1;memset(last_coins,0,sizeof last_coins);memset(last_kos,0,sizeof last_kos);
}
bool m3d_PartyActive(void){return party_map_active()&&mode()!=0;}
static int stock_round(void){return party.mode==M3D_PARTY_SURVIVAL||party.mode==M3D_PARTY_STOCK||party.sudden_death;}
bool m3d_PartyEliminated(int slot){return initialized&&stock_round()&&Player_GetStocks(slot)<=0;}
static int available(int slot) {
    return Player_GetPlayerSlotType(slot)!=Gm_PKind_NA&&(!stock_round()||Player_GetStocks(slot)>0);
}
static void begin(void) {
    m3d_party_reset(&party,mode(),(mode()==M3D_PARTY_STOCK?option("MELEE3D_NATIVE_STOCK_MINUTES",0,0,99)*60:option("MELEE3D_NATIVE_ROUND_SECONDS",300,0,5940))*60,
        option("MELEE3D_NATIVE_SCORE_LIMIT",mode()==2?30:60,1,1000),
        option("MELEE3D_NATIVE_HILL_SECONDS",45,5,300)*60,
        option("MELEE3D_NATIVE_STORM_SECONDS",240,10,1800)*60);
    party.sd_penalty=option("MELEE3D_NATIVE_SD_PENALTY",1,0,2);
    Vec3 center;m3d_DelfinoSpawnAim(&center);m3d_DelfinoNavObjective(0,&center);
    if(party.mode==M3D_PARTY_SURVIVAL) {
        /* The match seed is shared by every peer. These are outdoor goals on
         * the main navigable landmass, also used by native CPU routing. */
        int district=HSD_Randi(8);
        m3d_DelfinoNavObjective(16+2*district,&center);
        fprintf(stderr,"M3D ZONE DISTRICT index=%d center=%.2f,%.2f,%.2f\n",district,center.x,center.y,center.z);
    }
    party.storm=point(center);
    /* Cover every imported surface at the outset, including offshore pillars. */
    party.storm_start=m3d_DelfinoExtent(&center)+100;party.storm_radius=party.storm_start;
    const char* zone=getenv("MELEE3D_NATIVE_ZONE");party.adaptive_zone=!zone||strcmp(zone,"legacy");
    if(party.adaptive_zone){m3d_DelfinoZoneRadii(&center,party.zone_radii);party.storm_start=party.storm_radius=party.zone_radii[0];party.storm_end=140;}
    if(party.mode==M3D_PARTY_SURVIVAL) {
        /* Random starts must all begin safely inside the first circle. The
         * district and spawn distribution must never hand out instant KOs. */
        for(int i=0;i<GM_MAX_PLAYERS;i++) {
            HSD_GObj* g=Player_GetEntityAtIndex(i,0);Fighter* f=g?GET_FIGHTER(g):NULL;
            if(!f||Player_GetPlayerSlotType(i)==Gm_PKind_NA)continue;
            Vec3 p=f->cur_pos;if(m3d_MapIsActive(f))m3d_MapToWorld(&p);
            party.storm_radius=fmaxf(party.storm_radius,m3d_party_distance(point(p),party.storm)+80);
        }
        party.storm_start=party.zone_radii[0]=party.storm_radius;
    }
    if(getenv("MELEE3D_NATIVE_STORM_PROBE")&&(!strcmp(getenv("MELEE3D_NATIVE_STORM_PROBE"),"fixture")||!strcmp(getenv("MELEE3D_NATIVE_STORM_PROBE"),"visual"))) {
        Vec3 at={819,100,-732},floor;if(!m3d_DelfinoFloor(&at,&floor))abort();
        party.storm=point(floor);party.storm_start=party.storm_end=party.storm_radius=
            !strcmp(getenv("MELEE3D_NATIVE_STORM_PROBE"),"visual")?240:60;party.adaptive_zone=0;
    }
    if(getenv("MELEE3D_NATIVE_GOOP_RADIUS")){party.storm_start=party.storm_end=party.storm_radius=option("MELEE3D_NATIVE_GOOP_RADIUS",900,0,5000);party.adaptive_zone=0;}
    if(getenv("MELEE3D_NATIVE_GOOP_COATING_PROBE"))for(int i=0;i<GM_MAX_PLAYERS;i++)goop[i].coat=option("MELEE3D_NATIVE_GOOP_COATING_PROBE",0,0,100)/100.f;
    ko_heal=option("MELEE3D_NATIVE_KO_HEAL",0,0,40);
    {const char* r=getenv("MELEE3D_NATIVE_HILL_RULE");party.hill_rule=!r||!strcmp(r,"solo")?M3D_HILL_SOLO:!strcmp(r,"shared")?M3D_HILL_SHARED:!strcmp(r,"split")?M3D_HILL_SPLIT:!strcmp(r,"brawl")?M3D_HILL_BRAWL:-1;
     if(party.hill_rule<0){fprintf(stderr,"M3D PARTY FAIL invalid MELEE3D_NATIVE_HILL_RULE\n");exit(2);}party.hill_count=1;
     /* Shared and Brawl Hill score far faster than a solo hold: first-guess limits, tuned by bot playtests. */
     if(party.mode==4&&!getenv("MELEE3D_NATIVE_SCORE_LIMIT"))party.limit=1<<30; /* Coin Battle ends on time */
     if(party.mode==1&&!getenv("MELEE3D_NATIVE_SCORE_LIMIT")){int fighters=0;for(int i=0;i<GM_MAX_PLAYERS;i++)if(Player_GetPlayerSlotType(i)!=Gm_PKind_NA)fighters++;
         /* Brawl Hill pays about 2.3 points a minute per fighter to its leader (bot playtests): 10 per fighter ends a 5-minute round near the end. */
         party.limit=party.hill_rule==M3D_HILL_BRAWL?10*(fighters<4?4:fighters):party.hill_rule==M3D_HILL_SHARED?120:60;}}
    storm_damage=option("MELEE3D_NATIVE_STORM_DAMAGE",1,0,1);
    if(getenv("MELEE3D_NATIVE_HUD_DEMO")&&party.mode==1) /* Diagnostic: a mid-round standings spread for HUD screenshots. */
        for(int i=0;i<GM_MAX_PLAYERS;i++)if(Player_GetPlayerSlotType(i)!=Gm_PKind_NA)party.score[i]=i==0?(strcmp(getenv("MELEE3D_NATIVE_HUD_DEMO"),"lead")?13:44):(i*29+7)%40;
    party.hill=point(center);initialized=1;result_count=-1;spotlight_winner=-1;
    fprintf(stderr,"M3D PARTY START mode=%d limit=%d duration=%d radius=%.2f center=%.2f,%.2f,%.2f hill_rule=%d\n",party.mode,party.limit,party.duration,party.storm_start,center.x,center.y,center.z,party.hill_rule);
}
static void hud(void) {
    validate_text();if(!HSD_SisLib_804D1124[2])return;
    if(!text) {
        int canvas=HSD_SisLib_803A611C(2,NULL,HSD_GOBJ_CLASS_UI,15,0,14,0,25);
        text=HSD_SisLib_803A6754(2,canvas);if(!text)return;text->default_kerning=1;
        if(text->entity)text->entity->user_data_remove_func=text_destroy;
        memset(previous,0,sizeof previous);
        for(int i=0;i<5;i++){
            shadows[i]=HSD_SisLib_803A6B98(text,23,14+i*18," ");
            entries[i]=HSD_SisLib_803A6B98(text,22,13+i*18," ");
            HSD_SisLib_803A7548(text,shadows[i],.4f,.4f);HSD_SisLib_803A7548(text,entries[i],.4f,.4f);
            GXColor dark={0,0,0,255},white={255,255,255,255};HSD_SisLib_803A74F0(text,shadows[i],&dark);HSD_SisLib_803A74F0(text,entries[i],&white);
        }
        fprintf(stderr,"M3D PARTY HUD ready font=2 rows=5\n");
    }
    /* Compact Survival standings and alerts use the existing native text.
     * No debug radii, timings or CPU names crowd the damage panel. */
    char lines[5][192]={{0}};int viewer=m3d_room_enabled()?m3d_room_local():0;
    /* Count roster seats, including humans and CPUs, rather than fighter
     * objects (Ice Climbers' companion is not another player). Preserve the
     * starting total when eliminated fighters or disconnected peers disappear. */
    if(!match_players)for(int i=0;i<GM_MAX_PLAYERS;i++)
        if(Player_GetPlayerSlotType(i)!=Gm_PKind_NA)match_players++;
    if(stock_round()) {
        int alive=0;for(int i=0;i<GM_MAX_PLAYERS;i++)if(available(i))alive++;
        snprintf(lines[2],192,"%d / %d LEFT",alive,match_players);
    } else snprintf(lines[2],192,"%d PLAYERS",match_players);
    if(!party.finished) {
        if(party.sudden_death)snprintf(lines[0],192,"SUDDEN DEATH");
        else if(party.mode>=M3D_PARTY_TIME){
            int left=(party.duration-party.tick+59)/60;
            if(party.duration)snprintf(lines[0],192,"%d:%02d",left/60,left%60);
            if(party.mode==M3D_PARTY_STOCK&&available(viewer))snprintf(lines[1],192,"%d STOCK%s",Player_GetStocks(viewer),Player_GetStocks(viewer)==1?"":"S");
            else if(party.mode==M3D_PARTY_TIME&&option("MELEE3D_NATIVE_SCORE_DISPLAY",0,0,1))snprintf(lines[1],192,"SCORE %d",party.score[viewer]);
        }
        if(party.mode==3) {
            if(!available(viewer))snprintf(lines[0],192,"ELIMINATED - SPECTATING");
            else if(party.outside[viewer]) {
                HSD_GObj* g=Player_GetEntityAtIndex(viewer,0);Fighter* f=g?GET_FIGHTER(g):NULL;
                Vec3 p=f?f->cur_pos:vector(party.storm);if(f&&m3d_MapIsActive(f))m3d_MapToWorld(&p);
                snprintf(lines[0],192,m3d_GoopDepth(&p)>.75f?"EXPLOSIVE GOOP - GET CLEAR!":"GOOP IS SPREADING");
            }
            int notice=m3d_party_zone_notice(&party);
            if(notice>0)snprintf(lines[1],192,"GOOP ADVANCES IN %d",notice);
            else if(notice<0)snprintf(lines[1],192,"GOOP ADVANCING");
        } /* Hill: the scoreboard below owns score, clock and hill state. */
    }
    {int you=-1;for(int i=0;i<GM_MAX_PLAYERS;i++)if(Player_GetPlayerSlotType(i)==Gm_PKind_Human&&m3d_RoomIsViewer(i)){you=i;break;}
     if(!party.finished&&you>=0&&m3d_PartySurged(you))snprintf(lines[1],192,"SURGE: DEAL DAMAGE TO STOP IT");
     else if(!party.finished&&you>=0&&m3d_PartyBountyLeader()==you)snprintf(lines[1],192,"YOU HAVE THE BOUNTY: EVERYONE CAN SEE YOU");
     else if(!party.finished&&you>=0&&ping_on>0&&iso_seconds[you]>=15)snprintf(lines[1],192,iso_seconds[you]>=20?"YOU'VE BEEN SPOTTED":"ALONE TOO LONG: YOU'LL BE SPOTTED");}
    if(!party.finished&&m3d_CameraSpectating()) {
        snprintf(lines[0],192,"SPECTATING");
        snprintf(lines[3],192,"D-PAD LEFT / RIGHT: CHANGE FIGHTER");
    }
    if(party.finished&&spotlight_winner>=0) {
        const char* name=m3d_lab_character_name(Player_GetPlayerCharacter(spotlight_winner));char upper[64]={0};
        for(int i=0;name&&name[i]&&i<63;i++)upper[i]=toupper((unsigned char)name[i]);
        snprintf(lines[0],192,"%s WINS!",upper[0]?upper:"WINNER");snprintf(lines[1],192,getenv("MELEE3D_NATIVE_RETURN_TO_MENU")?"Returning to the menu...":"Press START to finish");
    } else if(party.finished&&party.winner<0)snprintf(lines[0],192,"DRAW!");
    /* Battle Royale reads through native fighter icons and the advancing goop. */
    if(party.mode==M3D_PARTY_SURVIVAL&&!party.finished)memset(lines,0,sizeof lines);
    for(int i=0;i<5;i++)if(!lines[i][0])strcpy(lines[i]," ");
    for(int i=0;i<5;i++)if(strcmp(previous[i],lines[i])){HSD_SisLib_803A70A0(text,shadows[i],"%s",lines[i]);HSD_SisLib_803A70A0(text,entries[i],"%s",lines[i]);strcpy(previous[i],lines[i]);}
}

/* ---- King of the Hill scoreboard ----------------------------------------
 * Top centre: the four leaders' stock icons in rank order (leader largest),
 * then a divider and your own icon when you are outside the top four. Below,
 * one bar to the score limit: filled to the leader's score, with ticks for
 * second place and for you, so the lead reads as a distance. Text gives the
 * scores, the leader's margin, your rank, the clock and the hill state.
 * Icons are Melee's HUD stock icons (Akaneia frames for added fighters);
 * geometry is drawn in the same HUD camera on GX link 11. */
#define SB_ICONS 5
static HSD_GObj *sb_icon[SB_ICONS],*sb_bar;
static HSD_JObj* sb_face[SB_ICONS];static float sb_cx[SB_ICONS];
static int sb_slot[SB_ICONS],sb_order[GM_MAX_PLAYERS],sb_count,sb_you=-1,sb_you_rank=-1;
static HSD_Text* sb_text;static int sb_entry[16],sb_shadow[16];static char sb_previous[16][64];
#define SB_TEXTS 11
/* Layout in HUD units (the damage panels sit near y=-17). */
static float sb_ppu_x=10.95f,sb_ppu_y=10.95f,sb_y=21.5f,sb_spacing=3.4f,sb_bar_y=17.2f,sb_bar_half=9.5f;
static void sb_reset(void){for(int k=0;k<SB_ICONS;k++){sb_icon[k]=NULL;sb_face[k]=NULL;sb_slot[k]=-1;}sb_bar=NULL;}
static int sb_is_you(int slot){return slot>=0&&slot==sb_you;}
static void sb_rank(void) {
    sb_count=0;
    for(int i=0;i<GM_MAX_PLAYERS;i++)if(Player_GetPlayerSlotType(i)!=Gm_PKind_NA)sb_order[sb_count++]=i;
    for(int a=1;a<sb_count;a++){int x=sb_order[a],b=a;
        while(b>0){int y=sb_order[b-1];long kx=party.score[x]*60L+party.held[x],ky=party.score[y]*60L+party.held[y];
            if(kx>ky){sb_order[b]=y;b--;}else break;}
        sb_order[b]=x;}
    sb_you=-1;sb_you_rank=-1;
    for(int i=0;i<GM_MAX_PLAYERS;i++)if(Player_GetPlayerSlotType(i)==Gm_PKind_Human&&m3d_RoomIsViewer(i)){sb_you=i;break;}
    for(int r=0;r<sb_count;r++)if(sb_order[r]==sb_you)sb_you_rank=r;
}
static void sb_render_bar(HSD_GObj* gobj,intptr_t pass) {
    (void)gobj;if(pass!=0||!initialized||(party.mode!=1&&party.mode!=4)||party.finished)return;
    float limit=party.limit>0?party.limit:60;
    if(party.mode==4){limit=1;for(int i=0;i<GM_MAX_PLAYERS;i++)if(party.score[i]>limit)limit=party.score[i];limit*=1.25f;}
    HSD_StateInvalidate(-1);
    GXSetColorUpdate(GX_ENABLE);GXSetAlphaUpdate(GX_DISABLE);
    GXSetBlendMode(GX_BM_BLEND,GX_BL_SRCALPHA,GX_BL_INVSRCALPHA,GX_LO_CLEAR);
    GXSetZMode(GX_DISABLE,GX_ALWAYS,GX_DISABLE);GXSetCullMode(GX_CULL_NONE);
    GXSetAlphaCompare(GX_ALWAYS,0,GX_AOP_AND,GX_ALWAYS,0);
    GXSetNumTexGens(0);GXSetNumChans(1);GXSetNumTevStages(1);
    GXSetChanCtrl(GX_COLOR0A0,GX_DISABLE,GX_SRC_REG,GX_SRC_VTX,0,GX_DF_NONE,GX_AF_NONE);
    GXSetTevOrder(GX_TEVSTAGE0,GX_TEXCOORD_NULL,GX_TEXMAP_NULL,GX_COLOR0A0);GXSetTevOp(GX_TEVSTAGE0,GX_PASSCLR);
    GXClearVtxDesc();GXSetVtxDesc(GX_VA_POS,GX_DIRECT);GXSetVtxDesc(GX_VA_CLR0,GX_DIRECT);
    GXSetVtxAttrFmt(GX_VTXFMT0,GX_VA_POS,GX_POS_XYZ,GX_F32,0);GXSetVtxAttrFmt(GX_VTXFMT0,GX_VA_CLR0,GX_CLR_RGBA,GX_RGBA8,0);
    GXLoadPosMtxImm(HSD_CObjGetViewingMtxPtrDirect(HSD_CObjGetCurrent()),0);GXSetCurrentMtx(0);
    #define SB_QUAD(x0,y0,x1,y1,c) do{GXBegin(GX_QUADS,GX_VTXFMT0,4);\
        GXPosition3f32(x0,y0,0);GXColor4u8(c.r,c.g,c.b,c.a);GXPosition3f32(x1,y0,0);GXColor4u8(c.r,c.g,c.b,c.a);\
        GXPosition3f32(x1,y1,0);GXColor4u8(c.r,c.g,c.b,c.a);GXPosition3f32(x0,y1,0);GXColor4u8(c.r,c.g,c.b,c.a);GXEnd();}while(0)
    float x0=-sb_bar_half,x1=sb_bar_half,y=sb_bar_y,h=.32f;
    {GXColor panel={0,0,0,95};SB_QUAD(-sb_bar_half-9.4f,sb_bar_y-.9f,sb_bar_half+9.4f,sb_y+4.0f,panel);}
    GXColor track={10,10,16,150},fill={250,180,40,235},second={235,235,245,235},you={70,160,255,255},outline={0,0,0,170};
    SB_QUAD(x0-.15f,y-h-.15f,x1+.15f,y+h+.15f,outline);
    SB_QUAD(x0,y-h,x1,y+h,track);
    {GXColor cap={255,255,255,210};SB_QUAD(x1-.08f,y-h-.25f,x1+.18f,y+h+.25f,cap);}
    if(sb_count>0){float f=fminf(1,party.score[sb_order[0]]/limit);if(f>0)SB_QUAD(x0,y-h,x0+(x1-x0)*f,y+h,fill);}
    if(sb_count>1){float f=fminf(1,party.score[sb_order[1]]/limit),x=x0+(x1-x0)*f;SB_QUAD(x-.1f,y-h-.45f,x+.1f,y+h+.45f,second);}
    if(sb_you_rank>0&&sb_you_rank!=1){float f=fminf(1,party.score[sb_you]/limit),x=x0+(x1-x0)*f;SB_QUAD(x-.14f,y-h-.6f,x+.14f,y+h+.6f,you);}
    /* Underline your icon (or a divider before it when you are outside the top four). */
    for(int k=0;k<SB_ICONS;k++)if(sb_icon[k]&&sb_is_you(sb_slot[k])){
        HSD_JObj* j=GET_JOBJ(sb_icon[k]);float cx=sb_cx[k],s=j->scale.x;
        SB_QUAD(cx-1.1f*s,sb_y-1.55f*s,cx+1.1f*s,sb_y-1.3f*s,you);}
    if(sb_icon[4]&&sb_slot[4]>=0){float cx=sb_cx[4]-sb_spacing*.55f;GXColor d={255,255,255,140};SB_QUAD(cx-.06f,sb_y-1.1f,cx+.06f,sb_y+1.1f,d);}
    #undef SB_QUAD
    objective_render();
    HSD_StateInvalidate(-1);
}
static HSD_GObj* sb_make_icon(DynamicModelDesc* model,HSD_JObj** face) {
    HSD_GObj* gobj=GObj_Create(14,15,0);
    HSD_JObj* jobj=HSD_JObjLoadJoint(DP(HSD_Joint,model->joint));
    HSD_GObjObject_80390A70(gobj,HSD_GObj_JObjKind,jobj);
    GObj_SetupGXLink(gobj,HSD_GObj_JObjCallback,11,1);
    gm_8016895C(jobj,model,0);
    m3d_HudStock(jobj);
    lb_80011E24(jobj,face,1,-1);
    HSD_JObjSetFlagsAll(jobj,JOBJ_HIDDEN);
    return gobj;
}
/* Remaining opponents, in seat order. Eliminated icons disappear and the
 * survivors close the gap. Uses the same native stock art as the damage HUD,
 * including Akaneia's appended costumes; there are no proxy portraits. */
static HSD_GObj* br_icon[GM_MAX_PLAYERS];
static HSD_JObj* br_face[GM_MAX_PLAYERS];static float br_frame[GM_MAX_PLAYERS];
static int br_last_count=-1;
static void br_reset(void){memset(br_icon,0,sizeof br_icon);memset(br_face,0,sizeof br_face);br_last_count=-1;}
static void br_roster(void) {
    bool show=initialized&&party.mode==M3D_PARTY_SURVIVAL&&!party.finished;
    if(show&&!br_icon[0]) {
        DiscU32* models=NULL;lbArchive_LoadSections(*ifAll_GetArchive(),&models,"Stc_scemdls",0);
        if(!models)return;
        DynamicModelDesc* model=DP(DynamicModelDesc,models[0].v);
        for(int i=0;i<GM_MAX_PLAYERS;i++){br_icon[i]=sb_make_icon(model,&br_face[i]);br_frame[i]=-1;}
    }
    int count=0,viewer=m3d_room_enabled()?m3d_room_local():0;
    for(int i=0;i<GM_MAX_PLAYERS;i++) {
        if(!br_icon[i])continue;HSD_JObj* j=GET_JOBJ(br_icon[i]);
        HSD_JObjSetFlagsAll(j,JOBJ_HIDDEN);
        if(!show||i==viewer||!available(i))continue;
        const float scale=.72f,spacing=2.0f;
        float x=-27+(count%16)*spacing,y=21.2f-(count/16)*2.5f,ox=0,oy=0;
        for(HSD_JObj* c=br_face[i];c&&c!=j;c=c->parent){ox+=c->translate.x;oy+=c->translate.y;}
        HSD_JObjSetTranslateX(j,x-ox*scale);HSD_JObjSetTranslateY(j,y-oy*scale);
        Vec3 sc={scale,scale,scale};HSD_JObjSetScale(j,&sc);
        float frame=m3d_HudStockFrame(i);
        if(frame!=br_frame[i]){HSD_TObj* t=br_face[i]->u.dobj->mobj->tobj;
            HSD_TObjReqAnimAll(t,frame);HSD_AObjSetRate(t->aobj,0);HSD_JObjAnimAll(j);br_frame[i]=frame;}
        HSD_JObjClearFlags(br_face[i],JOBJ_HIDDEN);count++;
    }
    if(show&&count!=br_last_count){fprintf(stderr,"M3D BR ROSTER opponents=%d viewer=%d\n",count,viewer);br_last_count=count;}
}
static void sb_text_destroy(void* p){if(sb_text==p)sb_text=NULL;HSD_SisLib_803A5A2C(p);}
static void sb_set(int i,const char* s){if(!s[0])s=" ";if(strcmp(sb_previous[i],s)){HSD_SisLib_803A70A0(sb_text,sb_shadow[i],"%s",s);HSD_SisLib_803A70A0(sb_text,sb_entry[i],"%s",s);strncpy(sb_previous[i],s,63);}}
/* HUD units to the 640x480 SIS canvas (measured against the HUD camera). */
static float sb_px(float x){return 320+x*sb_ppu_x;}
static float sb_py(float y){return 240-(y+.8f)*sb_ppu_y;} /* SIS anchors at the glyph top */
static void sb_create(void) {
    DiscU32* models=NULL;
    lbArchive_LoadSections(*ifAll_GetArchive(),&models,"Stc_scemdls",0);
    if(!models){fprintf(stderr,"M3D HILL HUD FAIL no stock models\n");return;}
    DynamicModelDesc* model=DP(DynamicModelDesc,models[0].v);
    for(int k=0;k<SB_ICONS;k++){sb_icon[k]=sb_make_icon(model,&sb_face[k]);sb_slot[k]=-1;}
    sb_bar=GObj_Create(14,15,0);GObj_SetupGXLink(sb_bar,sb_render_bar,11,0);
    if(HSD_SisLib_804D1124[2]) {
        int canvas=HSD_SisLib_803A611C(2,NULL,HSD_GOBJ_CLASS_UI,15,0,14,0,25);
        sb_text=HSD_SisLib_803A6754(2,canvas);
        if(sb_text){sb_text->default_kerning=1;sb_text->default_alignment=1;
            if(sb_text->entity)sb_text->entity->user_data_remove_func=sb_text_destroy;
            GXColor dark={0,0,0,255},white={255,255,255,255};
            for(int i=0;i<SB_TEXTS;i++){sb_shadow[i]=HSD_SisLib_803A6B98(sb_text,1,1," ");sb_entry[i]=HSD_SisLib_803A6B98(sb_text,0,0," ");
                HSD_SisLib_803A74F0(sb_text,sb_shadow[i],&dark);HSD_SisLib_803A74F0(sb_text,sb_entry[i],&white);sb_previous[i][0]=0;}}
    }
    fprintf(stderr,"M3D HILL HUD ready icons=%d text=%d\n",SB_ICONS,sb_text!=NULL);
}
static void sb_place(int i,float x,float y,float scale,GXColor color) {
    if(!sb_text)return;
    HSD_SisLib_803A746C(sb_text,sb_entry[i],sb_px(x),sb_py(y));HSD_SisLib_803A746C(sb_text,sb_shadow[i],sb_px(x)+1.2f,sb_py(y)+1.2f);
    HSD_SisLib_803A7548(sb_text,sb_entry[i],scale,scale);HSD_SisLib_803A7548(sb_text,sb_shadow[i],scale,scale);
    HSD_SisLib_803A74F0(sb_text,sb_entry[i],&color);
}
static void sb_name(int slot,char* out,int size) {
    const char* name=m3d_lab_character_name(Player_GetPlayerCharacter(slot));int n=0;
    for(;name&&name[n]&&n<size-1;n++)out[n]=toupper((unsigned char)name[n]);out[n]=0;if(!n)snprintf(out,size,"P%d",slot+1);
}
static const char* sb_ordinal(int n){int t=n%100;if(t>=11&&t<=13)return "TH";switch(n%10){case 1:return "ST";case 2:return "ND";case 3:return "RD";}return "TH";}
static void scoreboard(void) {
    bool show=initialized&&(party.mode==1||party.mode==4)&&!party.finished;
    if(show&&!sb_bar)sb_create();
    if(!sb_bar)return;
    sb_rank();
    int top=sb_count<4?sb_count:4;
    int slots[SB_ICONS]={-1,-1,-1,-1,-1};
    for(int k=0;k<top;k++)slots[k]=sb_order[k];
    if(sb_you_rank>=4)slots[4]=sb_you;
    int shown=0;for(int k=0;k<SB_ICONS;k++)if(slots[k]>=0)shown++;
    const float lead_gap=.7f; /* the leader's icon is drawn larger */
    float width=(top-1)*sb_spacing+(top>1?lead_gap:0)+(slots[4]>=0?sb_spacing*1.1f:0),left=-width/2;
    GXColor white={255,255,255,255},gold={255,205,70,255},blue={120,185,255,255},grey={200,200,210,255},red={255,110,80,255},green={110,235,170,255};
    for(int k=0;k<SB_ICONS;k++){
        HSD_GObj* g=sb_icon[k];if(!g)continue;HSD_JObj* j=GET_JOBJ(g);
        if(!show||slots[k]<0){HSD_JObjSetFlagsAll(j,JOBJ_HIDDEN);sb_slot[k]=-1;continue;}
        float x=(k<4?left+k*sb_spacing:left+(top-1)*sb_spacing+sb_spacing*1.1f)+(k>0?lead_gap:0),s=k==0?1.45f:1.05f;
        /* The icon is the model's first stock child, offset from the root: cancel
         * that offset so the face itself lands at (x, sb_y) at any scale. */
        float ox=0,oy=0;for(HSD_JObj* c=sb_face[k];c&&c!=j;c=c->parent){ox+=c->translate.x;oy+=c->translate.y;}
        sb_cx[k]=x;
        HSD_JObjSetTranslateX(j,x-ox*s);HSD_JObjSetTranslateY(j,sb_y-oy*s);{Vec3 sc={s,s,s};HSD_JObjSetScale(j,&sc);}
        if(sb_slot[k]!=slots[k]){
            HSD_JObjSetFlagsAll(j,JOBJ_HIDDEN);HSD_JObjClearFlags(sb_face[k],JOBJ_HIDDEN);
            HSD_TObjReqAnimAll(sb_face[k]->u.dobj->mobj->tobj,m3d_HudStockFrame(slots[k]));
            HSD_AObjSetRate(sb_face[k]->u.dobj->mobj->tobj->aobj,0);
            HSD_JObjAnimAll(j);sb_slot[k]=slots[k];
        }
    }
    if(!sb_text)return;
    char s[64];
    if(!show){for(int i=0;i<SB_TEXTS;i++)sb_set(i,"");return;}
    /* 0-4: scores under icons */
    for(int k=0;k<SB_ICONS;k++){
        if(slots[k]<0){sb_set(k,"");continue;}
        snprintf(s,sizeof s,"%d",party.score[slots[k]]);
        sb_place(k,sb_cx[k],sb_y-(k==0?2.9f:2.45f),k==0?.46f:.4f,k==0?gold:sb_is_you(slots[k])?blue:white);sb_set(k,s);
    }
    /* 5: leader margin, right of the bar */
    int lead=sb_count>1?party.score[sb_order[0]]-party.score[sb_order[1]]:party.score[sb_order[0]];
    char name[40];sb_name(sb_order[0],name,sizeof name);
    if(sb_count>1&&lead==0)snprintf(s,sizeof s,"TIED");else snprintf(s,sizeof s,"+%d AHEAD",lead);
    sb_place(5,sb_bar_half+3.9f,sb_bar_y,.42f,lead<=0?grey:sb_order[0]==sb_you?blue:gold);sb_set(5,s);
    /* 6: your rank, left of the bar */
    if(sb_you_rank>=0){snprintf(s,sizeof s,"%d%s",sb_you_rank+1,sb_ordinal(sb_you_rank+1));sb_place(6,-sb_bar_half-2.6f,sb_bar_y,.42f,blue);}else s[0]=0;
    sb_set(6,s);
    /* 7: goal at the end of the track */
    if(party.mode==4)snprintf(s,sizeof s,"MOST COINS WINS");else snprintf(s,sizeof s,"FIRST TO %d",party.limit);sb_place(7,0,sb_bar_y-3.85f,.3f,grey);sb_set(7,s);
    /* 8: clock, 9: hill state, 10: hill relocation */
    int left_s=(party.duration-party.tick+59)/60;if(left_s<0)left_s=0;
    snprintf(s,sizeof s,"%d:%02d",left_s/60,left_s%60);sb_place(8,0,sb_bar_y-1.75f,.4f,left_s<=30?red:white);sb_set(8,s);
    if(party.mode==4){snprintf(s,sizeof s,"HIT FOR COINS, KO'D = LOSE HALF");sb_place(9,0,sb_bar_y-2.85f,.36f,gold);sb_set(9,s);}
    else if(party.hill_rule!=M3D_HILL_SOLO){
        int k=sb_you>=0?party.on_hill[sb_you]:-1,away=sb_you>=0?party.away[sb_you]:0;GXColor c=grey;
        if(k>=0){snprintf(s,sizeof s,party.hill_occupants[k]>1?"ON A HILL WITH %d OTHERS":"ON A HILL ALONE",party.hill_occupants[k]-1);c=blue;}
        else if(party.hill_rule==M3D_HILL_BRAWL&&away>=900){snprintf(s,sizeof s,"AWAY FROM THE HILLS: TAKING DAMAGE");c=red;}
        else if(party.hill_rule==M3D_HILL_BRAWL&&away>=480){snprintf(s,sizeof s,"BACK TO A HILL IN %d",(900-away+59)/60);c=red;}
        else snprintf(s,sizeof s,m3d_party_hill_total(&party)>1?"%d HILLS":"ONE HILL",m3d_party_hill_total(&party));
        sb_place(9,0,sb_bar_y-2.85f,.36f,c);sb_set(9,s);
    } else {
    if(party.occupants>1)snprintf(s,sizeof s,"CONTESTED");
    else if(party.owner>=0){char holder[40];sb_name(party.owner,holder,sizeof holder);snprintf(s,sizeof s,party.owner==sb_you?"YOU HOLD THE HILL":"%s HOLDS THE HILL",holder);}
    else snprintf(s,sizeof s,"HILL OPEN");
    sb_place(9,0,sb_bar_y-2.85f,.36f,party.occupants>1?red:party.owner==sb_you&&party.owner>=0?blue:party.owner>=0?gold:green);sb_set(9,s);
    }
    int move=party.hill_period-party.tick%party.hill_period;move=(move+59)/60;
    if(move<=10&&party.mode==1){snprintf(s,sizeof s,"HILL MOVES IN %d",move);sb_place(10,0,sb_bar_y-4.85f,.34f,red);}else s[0]=0;
    sb_set(10,s);
}


/* ---- Bot playtest telemetry (MELEE3D_NATIVE_PLAYTEST=1) -------------------
 * Once a second, one compact line with every fighter: position, percent,
 * score, hits landed, damage dealt, distance to the nearest live enemy and
 * whether they are on the objective. KOs log victim, credited attacker and
 * place. Damage dealt is credited from each percent increase to the victim's
 * native last attacker (the same field KO credit uses). */
static int pt_enabled=-1,pt_frame,pt_hits[GM_MAX_PLAYERS],pt_last_motion[GM_MAX_PLAYERS];
static float pt_dealt[GM_MAX_PLAYERS],pt_last_pct[GM_MAX_PLAYERS];
static int pt_on(void){if(pt_enabled<0)pt_enabled=getenv("MELEE3D_NATIVE_PLAYTEST")!=NULL;return pt_enabled;}
void m3d_PlaytestHit(int attacker,int victim){
    if(attacker<0||victim<0||attacker>=GM_MAX_PLAYERS||victim>=GM_MAX_PLAYERS||attacker==victim)return;
    pt_hits[attacker]++;
    if(goop_active()&&available(attacker)&&available(victim))m3d_goop_contact(&goop[attacker],&goop[victim]);
}
static Fighter* pt_fighter(int slot){HSD_GObj* g=Player_GetEntityAtIndex(slot,0);return g?GET_FIGHTER(g):NULL;}
static int pt_objective(Fighter* f);
static void pt_reset(void){pt_frame=0;memset(pt_hits,0,sizeof pt_hits);memset(pt_dealt,0,sizeof pt_dealt);for(int i=0;i<GM_MAX_PLAYERS;i++){pt_last_motion[i]=-1;pt_last_pct[i]=0;}}
static void playtest_tick(void) {
    if(!party_map_active())return;
    if(pt_frame==0){pt_reset();if(pt_on())fprintf(stderr,"M3D PT BEGIN mode=%d players=%d\n",mode(),m3d_lab_count());}
    pt_frame++;
    for(int i=0;i<GM_MAX_PLAYERS;i++){
        if(Player_GetPlayerSlotType(i)==Gm_PKind_NA)continue;
        Fighter* f=pt_fighter(i);if(!f)continue;
        float pct=f->dmg.x1830_percent;int src=f->dmg.x18c4_source_ply;
        if(pct>pt_last_pct[i]&&src>=0&&src<GM_MAX_PLAYERS&&src!=i)pt_dealt[src]+=pct-pt_last_pct[i];
        pt_last_pct[i]=pct;
        int alive=f->motion_id>=14&&!f->is_sleeping;
        if(pt_last_motion[i]>=14&&!alive){
            if(pt_on())fprintf(stderr,"M3D PT KO t=%.2f victim=%d killer=%d x=%.0f y=%.0f z=%.0f\n",pt_frame/60.0f,i,src>=0&&src<GM_MAX_PLAYERS&&src!=i?src:-1,f->cur_pos.x,f->cur_pos.y,f->cur_pos.z);
            pt_last_pct[i]=0;
        }
        pt_last_motion[i]=alive?f->motion_id:0;
    }
    if(pt_frame%60||!pt_on())return;
    char line[8192];int n=snprintf(line,sizeof line,"M3D PT S t=%d",pt_frame/60);
    if(initialized&&party.mode==1)n+=snprintf(line+n,sizeof line-n," hill=%.0f,%.0f,%.0f,%.0f occ=%d owner=%d hills=%d rule=%d",party.hill.x,party.hill.y,party.hill.z,party.hill_radius,party.occupants,party.owner,m3d_party_hill_total(&party),party.hill_rule);
    if(initialized&&party.mode==3)n+=snprintf(line+n,sizeof line-n," zone=%.0f,%.0f,%.0f",party.storm.x,party.storm.z,party.storm_radius);
    n+=snprintf(line+n,sizeof line-n," f=");
    for(int i=0;i<GM_MAX_PLAYERS&&n<(int)sizeof line-96;i++){
        if(Player_GetPlayerSlotType(i)==Gm_PKind_NA)continue;
        Fighter* f=pt_fighter(i);if(!f)continue;
        int alive=f->motion_id>=14&&!f->is_sleeping&&available(i);
        float near=1e9f;
        if(alive)for(int j=0;j<GM_MAX_PLAYERS;j++){if(j==i)continue;Fighter* o=pt_fighter(j);
            if(!o||o->is_sleeping||o->motion_id<14||!available(j))continue;
            float d=hypotf(o->cur_pos.x-f->cur_pos.x,o->cur_pos.z-f->cur_pos.z);if(d<near)near=d;}
        int score=initialized&&(party.mode==1||party.mode==2||party.mode==4)?party.score[i]:0;
        if(!initialized||party.mode==0){score=0;for(int j=0;j<GM_MAX_PLAYERS;j++)if(j!=i)score+=Player_GetKOsByPlayerIndex(i,j);}
        n+=snprintf(line+n,sizeof line-n,"%s%d:%.0f,%.0f,%.0f,%.0f,%d,%d,%.0f,%.0f,%d,%d",n>0&&line[n-1]=='='?"":";",i,
            f->cur_pos.x,f->cur_pos.y,f->cur_pos.z,f->dmg.x1830_percent,score,pt_hits[i],pt_dealt[i],near>1e8f?-1.f:near,alive?pt_objective(f):0,alive);
    }
    fprintf(stderr,"%s\n",line);
}

/* ---- Respawn near the action (MELEE3D_NATIVE_RESPAWN=action) -------------
 * Hill: beside the busiest hill. Battle: beside the biggest crowd. The route
 * graph picks a reachable outdoor point 80-170 units away, clear of enemies. */
static int respawn_mode=-1;
bool m3d_PartyRespawnFocus(int slot,Vec3* focus) {
    if(respawn_mode<0){const char* s=getenv("MELEE3D_NATIVE_RESPAWN");respawn_mode=s&&!strcmp(s,"action");}
    if(!respawn_mode||!party_map_active())return false;
    if(initialized&&party.mode==1){int best=0;for(int k=1;k<m3d_party_hill_total(&party);k++)if(party.hill_occupants[k]>party.hill_occupants[best])best=k;
        *focus=vector(m3d_party_hill_at(&party,best));return true;}
    if(initialized&&party.mode!=0)return false;
    int crowd=-1;Fighter* center=NULL;
    for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];g;g=g->next){Fighter* f=GET_FIGHTER(g);
        if(f->player_idx==slot||f->is_sleeping||f->motion_id<14||f->is_sub_fighter)continue;int n=0;
        for(HSD_GObj* h=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];h;h=h->next){Fighter* o=GET_FIGHTER(h);
            if(o!=f&&!o->is_sleeping&&o->motion_id>=14&&hypotf(o->cur_pos.x-f->cur_pos.x,o->cur_pos.z-f->cur_pos.z)<120)n++;}
        if(n>crowd){crowd=n;center=f;}}
    if(!center)return false;*focus=center->cur_pos;return true;
}
/* ---- Damage surge (MELEE3D_NATIVE_SURGE=on; Fortnite's Storm Surge) ------
 * Every 30 s after the first minute, live fighters in the bottom quarter of
 * damage dealt over that window, and under 35% of the median, take 2% a
 * second for 10 s. Active fighters having a quiet spell are spared. */
static int surge_on=-1,surge_until[GM_MAX_PLAYERS];static float surge_base[GM_MAX_PLAYERS];
static int surge_cmp(const void* a,const void* b){float x=*(const float*)a,y=*(const float*)b;return (x>y)-(x<y);}
static void surge_tick(void) {
    if(surge_on<0){const char* s=getenv("MELEE3D_NATIVE_SURGE");surge_on=s&&!strcmp(s,"on");}
    if(!surge_on||(initialized&&party.finished))return;
    if(pt_frame==1){memset(surge_until,0,sizeof surge_until);memset(surge_base,0,sizeof surge_base);}
    if(pt_frame>=3600&&pt_frame%1800==0){
        float window[GM_MAX_PLAYERS],sorted[GM_MAX_PLAYERS];int n=0;
        for(int i=0;i<GM_MAX_PLAYERS;i++){window[i]=-1;Fighter* f=pt_fighter(i);
            if(Player_GetPlayerSlotType(i)==Gm_PKind_NA||!f||f->is_sleeping||f->motion_id<14||!available(i))continue;
            window[i]=pt_dealt[i]-surge_base[i];sorted[n++]=window[i];}
        if(n>=4){qsort(sorted,n,sizeof *sorted,surge_cmp);float cut=fminf(sorted[n/4],.35f*sorted[n/2]);
            for(int i=0;i<GM_MAX_PLAYERS;i++)if(window[i]>=0&&window[i]<=cut){surge_until[i]=pt_frame+600;
                fprintf(stderr,"M3D SURGE t=%d slot=%d dealt=%.1f cut=%.1f\n",pt_frame/60,i,window[i],cut);}}
        for(int i=0;i<GM_MAX_PLAYERS;i++)surge_base[i]=pt_dealt[i];
    }
    if(pt_frame%60==0)for(int i=0;i<GM_MAX_PLAYERS;i++)if(surge_until[i]>pt_frame){Fighter* f=pt_fighter(i);
        if(!f||f->is_sleeping||f->motion_id<14)continue;f->dmg.x1830_percent=fminf(999,f->dmg.x1830_percent+2);Player_SetHPByIndex(i,0,f->dmg.x1830_percent);}
}
bool m3d_PartySurged(int slot){return slot>=0&&slot<GM_MAX_PLAYERS&&surge_until[slot]>pt_frame;}

/* ---- Leader bounty and isolation ping ------------------------------------
 * MELEE3D_NATIVE_BOUNTY=on: the sole leader (Hill points, otherwise KOs) shows
 * on everyone's off-screen bubble at any range, and CPUs prefer them as a
 * target. MELEE3D_NATIVE_PING=on: a fighter 20 s or more with no enemy within
 * 150 units shows on every bubble for 3 s out of each 10. */
static int bounty_on=-1,ping_on=-1,bounty_slot=-1,iso_seconds[GM_MAX_PLAYERS];
static int pressure_flag(const char* key){const char* s=getenv(key);return s&&!strcmp(s,"on");}
int m3d_PartyBountyLeader(void){if(bounty_on<0)bounty_on=pressure_flag("MELEE3D_NATIVE_BOUNTY");return bounty_on?bounty_slot:-1;}
static void pressure_tick(void) {
    if(bounty_on<0)bounty_on=pressure_flag("MELEE3D_NATIVE_BOUNTY");
    if(ping_on<0)ping_on=pressure_flag("MELEE3D_NATIVE_PING");
    if(pt_frame==1){bounty_slot=-1;memset(iso_seconds,0,sizeof iso_seconds);}
    if(pt_frame%60)return;
    if(bounty_on){int best=0,who=-1,tied=0;
        for(int i=0;i<GM_MAX_PLAYERS;i++){if(Player_GetPlayerSlotType(i)==Gm_PKind_NA||!available(i))continue;
            int v=initialized&&party.mode==1?party.score[i]:0;
            if(!(initialized&&party.mode==1))for(int j=0;j<GM_MAX_PLAYERS;j++)if(j!=i)v+=Player_GetKOsByPlayerIndex(i,j);
            if(v>best){best=v;who=i;tied=0;}else if(v==best&&v>0)tied=1;}
        int next=tied?-1:who;if(next!=bounty_slot&&next>=0)fprintf(stderr,"M3D BOUNTY t=%d slot=%d value=%d\n",pt_frame/60,next,best);bounty_slot=next;}
    if(ping_on)for(int i=0;i<GM_MAX_PLAYERS;i++){Fighter* f=pt_fighter(i);
        if(!f||f->is_sleeping||f->motion_id<14||!available(i)){iso_seconds[i]=0;continue;}
        bool alone=true;for(int j=0;j<GM_MAX_PLAYERS&&alone;j++){if(j==i)continue;Fighter* o=pt_fighter(j);
            if(o&&!o->is_sleeping&&o->motion_id>=14&&available(j)&&hypotf(o->cur_pos.x-f->cur_pos.x,o->cur_pos.z-f->cur_pos.z)<150)alone=false;}
        iso_seconds[i]=alone?iso_seconds[i]+1:0;}
}
static bool pressure_revealed(int slot) {
    if(slot<0||slot>=GM_MAX_PLAYERS)return false;
    if(m3d_PartyBountyLeader()==slot)return true;
    return ping_on>0&&iso_seconds[slot]>=20&&(iso_seconds[slot]-20)%10<3;
}
static int pt_objective(Fighter* f) {
    if(!initialized)return 0;
    if(party.mode==1)return m3d_party_inside(&party,point(f->cur_pos));
    if(party.mode==3)return m3d_party_distance(point(f->cur_pos),party.storm)<=party.storm_radius;
    return 0;
}
static void surge_tick(void);
static void pressure_tick(void);
void m3d_PartyTick(void) {
    m3d_CombatTick();
    playtest_tick();surge_tick();pressure_tick();
    if(!m3d_PartyActive()){if(party_map_active())hud();return;}if(!initialized)begin();
    if(getenv("MELEE3D_NATIVE_STORM_PROBE")&&(!strcmp(getenv("MELEE3D_NATIVE_STORM_PROBE"),"fixture")||!strcmp(getenv("MELEE3D_NATIVE_STORM_PROBE"),"visual"))) {
        for(int i=0;i<2;i++){HSD_GObj* g=Player_GetEntity(i);Fighter* f=g?GET_FIGHTER(g):NULL;
            if(!f||f->motion_id<14||!available(i))continue;
            int t=!strcmp(getenv("MELEE3D_NATIVE_STORM_PROBE"),"visual")?party.tick%300:party.tick;
            Vec3 p=vector(party.storm);
            p.x+=i?-20:(t<180?90:t<300?0:t<480?90:m3d_party_storm_outer(&party)+8);
            f->cur_pos=f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=p;
            f->self_vel=(Vec3){0};f->x8c_kb_vel=(Vec3){0};f->gr_vel=f->xF0_ground_kb_vel=0;
            HSD_JObjSetTranslate(g->hsd_obj,&p);
        }
    }
    if(party.finished && getenv("MELEE3D_NATIVE_RETURN_TO_MENU") && !m3d_room_enabled()) {
        if(++return_ticks>=180){fprintf(stderr,"M3D PARTY RESULTS DONE\n");fflush(stderr);exit(0);}
    }
    if(party.finished&&(spotlight_winner>=0||party.winner<0)&&!m3d_room_enabled()&&!getenv("MELEE3D_NATIVE_RETURN_TO_MENU")){
        for(int port=0;port<4;port++)if(HSD_PadCopyStatus[port].trigger&HSD_PAD_START){
            fprintf(stderr,"M3D PARTY RESULTS DONE\n");fflush(stderr);exit(0);}
    }
    if(getenv("MELEE3D_NATIVE_RULE_CHECK")&&!party.finished&&party.tick>=180&&party.tick%180==0){
        HSD_GObj* g=Player_GetEntity(1);Fighter* f=g?GET_FIGHTER(g):NULL;
        if(f&&available(1)){Vec3 p=f->cur_pos;p.y=-10000;f->cur_pos=f->prev_pos=f->coll_data.cur_pos=f->coll_data.prev_pos=f->coll_data.last_pos=p;
            fprintf(stderr,"M3D RULE CHECK fall slot=1 stocks=%d tick=%d\n",Player_GetStocks(1),party.tick);}
    }
    int hill=party.tick/party.hill_period;
    if(party.mode==1&&hill!=last_hill&&!party.finished){
        /* Mix rooftop fights with street fights. Brawl Hill keeps one hill per
         * eight fighters in play (one to four), then one for the last minute. */
        int count=1;
        if(party.hill_rule==M3D_HILL_BRAWL){int alive=0;for(int i=0;i<GM_MAX_PLAYERS;i++)if(available(i))alive++;
            count=alive/8;if(count<1)count=1;if(count>M3D_PARTY_HILLS)count=M3D_PARTY_HILLS;if(party.duration-party.tick<=3600)count=1;}
        party.hill_count=count;memset(hill_arrivals,0,sizeof hill_arrivals);
        for(int k=0;k<count;k++){Vec3 p=vector(party.hill);elevated_hill[k]=m3d_DelfinoNavHill(hill,k,&p);party.hills[k]=point(p);if(k==0)party.hill=point(p);
            fprintf(stderr,"M3D PARTY HILL index=%d hill=%d of=%d pos=%.2f,%.2f,%.2f elevated=%d\n",hill,k,count,p.x,p.y,p.z,elevated_hill[k]);}
        last_hill=hill;}
    M3dPartyBody bodies[GM_MAX_PLAYERS]={0};
    for(int i=0;i<GM_MAX_PLAYERS;i++){bodies[i].alive=available(i);bodies[i].present=Player_GetPlayerSlotType(i)!=Gm_PKind_NA;bodies[i].stocks=Player_GetStocks(i);bodies[i].damage=Player_GetDamage(i);bodies[i].self_destructs=Player_GetSelfDestructs(i);}
    for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];g;g=g->next){Fighter* f=GET_FIGHTER(g);int i=f->player_idx;
        if(i>=GM_MAX_PLAYERS||f->is_sub_fighter||f->is_sleeping||f->motion_id<14||!available(i))continue;
        bodies[i].active=1;bodies[i].pos=point(f->cur_pos);
        if(party.mode==M3D_PARTY_HILL){int k=m3d_party_hill_index(&party,bodies[i].pos);
            if(k>=0&&!(hill_arrivals[i]&(1u<<k))){hill_arrivals[i]|=1u<<k;
                fprintf(stderr,"M3D HILL ARRIVE phase=%d hill=%d slot=%d kind=%d elevated=%d pos=%.2f,%.2f,%.2f\n",hill,k,i,f->kind,elevated_hill[k],f->cur_pos.x,f->cur_pos.y,f->cur_pos.z);}}


    }
    for(int i=0;i<GM_MAX_PLAYERS;i++){if(Player_GetPlayerSlotType(i)==Gm_PKind_NA)continue;
        bodies[i].dealt=pt_dealt[i];bodies[i].falls=Player_GetFalls(i);
        for(int j=0;j<GM_MAX_PLAYERS;j++)if(j!=i)bodies[i].kos+=Player_GetKOsByPlayerIndex(i,j);}
    for(int i=0;i<GM_MAX_PLAYERS;i++)if(!out_tick[i]&&Player_GetPlayerSlotType(i)!=Gm_PKind_NA&&!bodies[i].alive)out_tick[i]=party.tick+1;
    if(party.mode==4)for(int i=0;i<GM_MAX_PLAYERS;i++)if(Player_GetPlayerSlotType(i)!=Gm_PKind_NA)party.score[i]=Player_GetCoins(i);
    /* Bonus uses Melee's full original awards calculation once, at timeout.
     * It is deliberately not approximated as damage or KO points. */
    if(party.mode==M3D_PARTY_BONUS&&!party.sudden_death&&!party.finished&&party.duration&&party.tick+1>=party.duration)
        for(int i=0;i<GM_MAX_PLAYERS;i++)if(bodies[i].present){party.score[i]=gm_GetMatchEndPlayerScore(i);fprintf(stderr,"M3D BONUS SCORE slot=%d score=%d\n",i,party.score[i]);}
    int was_finished=party.finished,was_sudden=party.sudden_death;m3d_party_step(&party,bodies);
    if(!was_sudden&&party.sudden_death){
        StartMeleeRules* rules=gm_GetStartMeleeRules();rules->is_stock=1;rules->match_kind=MatchKind_Stock;
        for(int i=0;i<GM_MAX_PLAYERS;i++)if(bodies[i].present){int tied=(party.contenders&(1u<<i))!=0;Player_SetStocks(i,tied?1:0);}
        /* Rebirth clears stale throws, hitstun, projectiles attached to a
         * fighter and death states through the game's own spawn routine. */
        for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];g;g=g->next){Fighter* f=GET_FIGHTER(g);int i=f->player_idx;
            if(party.contenders&(1u<<i)){ftCo_800D4FF4(g);f->dmg.x1830_percent=300;Player_SetHPByIndex(i,f->is_sub_fighter?1:0,300);}
            else ftCo_800D4F24(g,0);}
        fprintf(stderr,"M3D SUDDEN DEATH contenders=%08x percent=300 stocks=1\n",party.contenders);
    }
    /* Diagnostic: end the round early; the healthiest survivor (or hill leader) wins. */
    static int finish_after=-2;if(finish_after==-2)finish_after=option("MELEE3D_NATIVE_FINISH_AFTER",0,0,216000)*60;
    if(finish_after>0&&!party.finished&&party.tick>=finish_after){
        int best=-1;float low=1e9f;
        for(int i=0;i<GM_MAX_PLAYERS;i++)if(bodies[i].alive){HSD_GObj* g=Player_GetEntityAtIndex(i,0);
            float pct=party.mode==3?(g?GET_FIGHTER(g)->dmg.x1830_percent:999):-party.score[i];
            if(pct<low){low=pct;best=i;}}
        const char* test_winner=getenv("MELEE3D_NATIVE_RESULTS_CHECK");
        if(test_winner)for(int i=0;i<GM_MAX_PLAYERS;i++)if(Player_GetPlayerCharacter(i)==atoi(test_winner)){best=i;break;}
        party.finished=1;party.winner=best;
        for(int i=0;i<GM_MAX_PLAYERS;i++)if(bodies[i].alive&&i!=best&&!out_tick[i])out_tick[i]=party.tick;   /* survivors rank above the eliminated */
    }
    /* Hand the finished round to Melee's own GAME! sequence and results scene. */
    if(party.finished&&getenv("MELEE3D_NATIVE_RETURN_TO_MENU"))spotlight_winner=party.winner;
    const char* results=getenv("MELEE3D_NATIVE_RESULTS");
    if(party.finished&&!end_requested&&!(results&&!strcmp(results,"off"))){
        end_requested=1;
        /* Placements: winner, then (survival) last eliminated first or (hill) score. */
        int n=0;for(int i=0;i<GM_MAX_PLAYERS;i++)if(Player_GetPlayerSlotType(i)!=Gm_PKind_NA)result_order[n++]=i;
        for(int a=0;a<n;a++)for(int b=a+1;b<n;b++){int x=result_order[a],y=result_order[b];
            long kx=stock_round()?(out_tick[x]?out_tick[x]:1L<<30):party.score[x];
            long ky=stock_round()?(out_tick[y]?out_tick[y]:1L<<30):party.score[y];
            if(y==party.winner||(x!=party.winner&&ky>kx)){result_order[a]=y;result_order[b]=x;}}
        result_count=n;result_has_winner=party.winner>=0;
        if(party.winner>=0&&!results_supported(party.winner)) {
            /* Added (Akaneia) fighters have no retail results assets: crown
             * the winner in the arena instead, then end on START. */
            result_count=-1;spotlight_winner=party.winner;
            fprintf(stderr,"M3D PARTY SPOTLIGHT winner=%d character=%d\n",party.winner,Player_GetPlayerCharacter(party.winner));
        } else gmVs_GetSceneController()->state.match_result=OUTCOME_ELIMINATION;
        fprintf(stderr,"M3D PARTY RESULTS requested winner=%d\n",party.winner);
    }
    if(party.mode==1&&party.hill_rule==M3D_HILL_BRAWL&&!was_finished&&party.tick%60==0)
        for(int i=0;i<GM_MAX_PLAYERS;i++){if(party.away[i]<900)continue;HSD_GObj* g=Player_GetEntityAtIndex(i,0);Fighter* f=g?GET_FIGHTER(g):NULL;if(!f||!bodies[i].active)continue;
            /* Away from every hill for 15 s: 2% a second, rising to 6% after another 40 s. */
            float dose=fminf(6,2+(party.away[i]-900)/600.0f);f->dmg.x1830_percent=fminf(999,f->dmg.x1830_percent+dose);Player_SetHPByIndex(i,0,f->dmg.x1830_percent);}
    goop_tick();
    if(party.mode==3&&!was_finished&&party.tick%60==0) {
        for(int i=0;i<GM_MAX_PLAYERS;i++) {
            HSD_GObj* g=Player_GetEntityAtIndex(i,0);Fighter* f=g?GET_FIGHTER(g):NULL;
            if(!f||!bodies[i].active)continue;
            float before=f->dmg.x1830_percent;
            if(ko_heal) {
                int kos=0;for(int j=0;j<GM_MAX_PLAYERS;j++)if(i!=j)kos+=Player_GetKOsByPlayerIndex(i,j);
                int gained=kos-last_kos[i];last_kos[i]=kos;
                if(gained>0){f->dmg.x1830_percent=fmaxf(0,f->dmg.x1830_percent-ko_heal*gained);
                    fprintf(stderr,"M3D KO HEAL slot=%d credited=%d heal=%d\n",i,gained,ko_heal*gained);}
            }
            if(f->dmg.x1830_percent!=before)Player_SetHPByIndex(i,0,f->dmg.x1830_percent);
        }
    }
    static int logged_phase=-1;
    if(getenv("MELEE3D_NATIVE_STORM_PROBE")&&!strcmp(getenv("MELEE3D_NATIVE_STORM_PROBE"),"fixture")&&party.tick%30==0) {
        HSD_GObj* g=Player_GetEntity(0);Fighter* f=g?GET_FIGHTER(g):NULL;
        fprintf(stderr,"M3D STORM PROBE tick=%d outside=%d damage=%.2f stocks=%d state=%d finished=%d\n",party.tick,party.outside[0],f?f->dmg.x1830_percent:-1,Player_GetStocks(0),f?f->motion_id:-1,party.finished);
    }
    if(party.mode==3&&party.adaptive_zone&&logged_phase!=party.phase){logged_phase=party.phase;
        fprintf(stderr,"M3D ZONE PHASE tick=%d phase=%d current=%.2f next=%.2f notice=10 rate_limit=30\n",party.tick,party.phase,party.storm_radius,party.phase_target);}
    for(int i=0;i<GM_MAX_PLAYERS;i++)if(party.coins[i]!=last_coins[i]){fprintf(stderr,"M3D PARTY PICKUP tick=%d slot=%d count=%d\n",party.tick,i,party.coins[i]);last_coins[i]=party.coins[i];}
    if(!was_finished&&party.finished){
        int loser=-1,second=-1,low=0,high=0;
        for(int i=0;i<GM_MAX_PLAYERS;i++)if(bodies[i].present&&i!=party.winner){
            int rank=stock_round()?(out_tick[i]?out_tick[i]:1<<30):party.score[i];
            if(loser<0||rank<low){loser=i;low=rank;}if(second<0||rank>high){second=i;high=rank;}}
        m3d_MenuAutoHandicap(party.winner,loser,second);
        int alive=0;for(int i=0;i<GM_MAX_PLAYERS;i++)if(available(i))alive++;
        fprintf(stderr,"M3D PARTY END tick=%d winner=%d mode=%d alive=%d\n",party.tick,party.winner,party.mode,alive);}
    if(party.tick%120==0&&!party.finished){int alive=0;for(int i=0;i<GM_MAX_PLAYERS;i++)if(available(i))alive++;
        fprintf(stderr,"M3D PARTY FRAME tick=%d mode=%d owner=%d occupants=%d score=%d radius=%.2f alive=%d\n",party.tick,party.mode,party.owner,party.occupants,party.mode==4?Player_GetCoins(0):party.owner<0?0:party.score[party.owner],party.storm_radius,alive);
        if(alive!=last_alive){fprintf(stderr,"M3D PARTY SURVIVORS tick=%d count=%d\n",party.tick,alive);last_alive=alive;}}
    hud();scoreboard();br_roster();
}
/* Goop launches fighters through native damage states. Crossing a hidden
 * cylinder no longer kills them or moves the third-person camera. */
int m3d_PartyBlast(Fighter* fp) {(void)fp;return 0;}
void m3d_PartyCamera(Vec3* focus,Vec3* eye) {(void)focus;(void)eye;}
bool m3d_PartyRoundOver(void){return initialized&&party.finished;}
unsigned m3d_PartyChecksum(void) {
    unsigned h=2166136261u;
    const unsigned char* p=(const unsigned char*)&party;
    for(unsigned i=0;i<sizeof party;i++)h=(h^p[i])*16777619u;
    p=(const unsigned char*)goop;
    for(unsigned i=0;i<sizeof goop;i++)h=(h^p[i])*16777619u;
    return h;
}
bool m3d_PartyDropZone(Vec3* center,float* radius){
    if(!initialized||party.mode!=3||party.finished)return false;
    float safe=party.adaptive_zone&&party.phase>0?fminf(party.storm_radius,party.phase_target):party.storm_radius;
    *center=vector(party.storm);*radius=fmaxf(20,safe*.85f);return true;
}

/* ---- Playtest personas (MELEE3D_NATIVE_PERSONAS=camper=2,turtle=2,...) ----
 * Deliberately narrow CPUs for exploit hunting. A rule set is sound when none
 * of them places better than ordinary CPUs. They take the highest CPU slots.
 *   camper  goes to the spot furthest from every objective and waits there
 *   runner  keeps moving to wherever is furthest from live enemies, never attacks
 *   turtle  plays the objective but only shields while an enemy is close
 *   hunter  always heads for the current leader */
enum { PERSONA_NORMAL, PERSONA_CAMPER, PERSONA_RUNNER, PERSONA_TURTLE, PERSONA_HUNTER };
static const char* const persona_names[]={"normal","camper","runner","turtle","hunter"};
static int persona[GM_MAX_PLAYERS],persona_ready;
static Vec3 persona_spot[GM_MAX_PLAYERS];static int persona_spot_tick[GM_MAX_PLAYERS];
static void personas_setup(void) {
    if(persona_ready)return;persona_ready=1;memset(persona,0,sizeof persona);
    const char* spec=getenv("MELEE3D_NATIVE_PERSONAS");if(!spec||!*spec)return;
    int next=GM_MAX_PLAYERS-1;char buffer[256];snprintf(buffer,sizeof buffer,"%s",spec);
    for(char* item=strtok(buffer,",");item;item=strtok(NULL,",")){
        char* eq=strchr(item,'=');int count=eq?atoi(eq+1):1;if(eq)*eq=0;int kind=-1;
        for(int k=1;k<5;k++)if(!strcmp(item,persona_names[k]))kind=k;
        if(kind<0){fprintf(stderr,"M3D PARTY FAIL unknown persona %s\n",item);exit(2);}
        while(count-->0){
            while(next>=0&&(Player_GetPlayerSlotType(next)!=Gm_PKind_Cpu||persona[next]))next--;
            if(next<0)break;persona[next]=kind;fprintf(stderr,"M3D PT PERSONA slot=%d kind=%s\n",next,persona_names[kind]);next--;
        }
    }
}
static int persona_of(Fighter* fp){return fp->player_idx<GM_MAX_PLAYERS&&!fp->is_sub_fighter?persona[fp->player_idx]:PERSONA_NORMAL;}
static Fighter* persona_enemy_near(Fighter* fp,float radius) {
    for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];g;g=g->next){Fighter* o=GET_FIGHTER(g);
        if(o==fp||o->is_sleeping||o->motion_id<14||!available(o->player_idx))continue;
        if(hypotf(o->cur_pos.x-fp->cur_pos.x,o->cur_pos.z-fp->cur_pos.z)<radius&&fabsf(o->cur_pos.y-fp->cur_pos.y)<32)return o;}
    return NULL;
}
/* Returns true and a goal when the persona overrides the objective goal. */
static bool persona_goal(Fighter* fp,Vec3* goal) {
    int kind=persona_of(fp),slot=fp->player_idx;
    if(kind==PERSONA_CAMPER||kind==PERSONA_RUNNER) {
        int every=kind==PERSONA_CAMPER?1800:180;
        if(!persona_spot_tick[slot]||party.tick-persona_spot_tick[slot]>=every) {
            Vec3 avoid[GM_MAX_PLAYERS+M3D_PARTY_HILLS+1];int n=0;
            if(kind==PERSONA_CAMPER){if(party.mode==1)for(int k=0;k<m3d_party_hill_total(&party);k++)avoid[n++]=vector(m3d_party_hill_at(&party,k));
                else if(party.mode==3)avoid[n++]=vector(party.storm);}
            else for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];g;g=g->next){Fighter* o=GET_FIGHTER(g);if(o!=fp&&!o->is_sleeping&&available(o->player_idx))avoid[n++]=o->cur_pos;}
            if(m3d_DelfinoNavFar(avoid,n,party.mode==3?&party.storm:NULL,party.mode==3?party.storm_radius*.8f:0,&persona_spot[slot]))persona_spot_tick[slot]=party.tick?party.tick:1;
        }
        if(persona_spot_tick[slot]){*goal=persona_spot[slot];return true;}
    }
    if(kind==PERSONA_HUNTER) {
        int leader=-1,best=0;for(int i=0;i<GM_MAX_PLAYERS;i++)if(i!=slot&&available(i)&&party.score[i]>best){best=party.score[i];leader=i;}
        Fighter* target=leader>=0?pt_fighter(leader):NULL;
        if(target&&!target->is_sleeping&&target->motion_id>=14){*goal=target->cur_pos;return true;}
    }
    return false;
}
/* Called after the native CPU and route planner wrote this frame's pad. */
static void persona_pad(Fighter* fp) {
    int kind=persona_of(fp);
    if(kind==PERSONA_RUNNER){fp->cpu.buttons&=~(HSD_PAD_A|HSD_PAD_B|HSD_PAD_Z);fp->cpu.cstick.x=fp->cpu.cstick.y=0;}
    if(kind==PERSONA_CAMPER&&persona_spot_tick[fp->player_idx]&&hypotf(fp->cur_pos.x-persona_spot[fp->player_idx].x,fp->cur_pos.z-persona_spot[fp->player_idx].z)<16&&!persona_enemy_near(fp,40)){
        fp->cpu.buttons=0;fp->cpu.lstick.x=fp->cpu.lstick.y=0;fp->cpu.cstick.x=fp->cpu.cstick.y=0;}
    if(kind==PERSONA_TURTLE&&party.mode==1&&m3d_party_inside(&party,point(fp->cur_pos))&&persona_enemy_near(fp,35)){
        fp->cpu.buttons=HSD_PAD_R;fp->cpu.rtrigger=255;fp->cpu.lstick.x=fp->cpu.lstick.y=0;fp->cpu.cstick.x=fp->cpu.cstick.y=0;}
}

float m3d_PartyGoalRadius(void){return party.mode==1||party.mode==3?32:party.mode==4?6:0;}
bool m3d_PartyFlee(Fighter* fp) {
    if(!goop_active())return false;
    Vec3 p=fp->cur_pos;if(m3d_MapIsActive(fp))m3d_MapToWorld(&p);
    float depth=m3d_GoopDepth(&p);
    return depth>.55f||(depth>0&&goop[fp->player_idx].exposure>5);
}
float m3d_PartyRouteCost(Vec3 from,Vec3 to) {
    if(!initialized||party.mode!=M3D_PARTY_SURVIVAL||party.finished)return 0;
    float a=m3d_GoopDepth(&from),b=m3d_GoopDepth(&to);
    if(b>=.95f&&b>a)return 1e20f;
    return b*140+fmaxf(0,b-a)*200;
}
bool m3d_PartyGoal(Fighter* fp,Vec3* goal) {
    if(!initialized||party.finished||fp->is_sub_fighter||fp->player_idx>=GM_MAX_PLAYERS)return false;
    personas_setup();if(!m3d_PartyFlee(fp)&&persona_goal(fp,goal))return true;
    Vec3 p=fp->cur_pos;
    if(party.mode==4){float best=120;Item* pick=NULL;
        for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_ITEM];g;g=g->next){Item* it=g->user_data;if(!it||it->kind!=It_Kind_Unk4)continue;
            float d=hypotf(it->pos.x-p.x,it->pos.z-p.z);if(d<best&&fabsf(it->pos.y-p.y)<40){best=d;pick=it;}}
        if(pick){*goal=pick->pos;return true;}return false;}
    if(party.mode==1){if(m3d_party_inside(&party,point(p)))return false;
        /* Grab an item lying right on the way before heading back to the hill. */
        if(fp->item_gobj==NULL&&fp->cpu.x4C&&fp->cpu.xF9_b7)
            for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_ITEM];g;g=g->next)if(g->user_data==fp->cpu.x4C){
                Item* it=g->user_data;if(hypotf(it->pos.x-p.x,it->pos.z-p.z)<70&&fabsf(it->pos.y-p.y)<30)return false;break;}
        /* Rule-aware choice: under Split a crowded hill pays less, and under
         * Brawl a mid-sized crowd pays most (damage points) while a pile does not. */
        int best=0;float near=1e30f;for(int k=0;k<m3d_party_hill_total(&party);k++){M3dPartyPoint h=m3d_party_hill_at(&party,k);float d=hypotf(m3d_party_distance(point(p),h),p.y-h.y);
            int crowd=party.hill_occupants[k];
            if(party.hill_rule==M3D_HILL_SPLIT)d+=60.0f*crowd;
            if(party.hill_rule==M3D_HILL_BRAWL)d+=crowd>5?45.0f*(crowd-5):0;
            if(d<near){near=d;best=k;}}
        *goal=vector(m3d_party_hill_at(&party,best));return true;}
    if(party.mode==M3D_PARTY_SURVIVAL){
        float d=m3d_party_distance(point(p),party.storm);bool flee=m3d_PartyFlee(fp);
        if(!flee&&(d<party.storm_radius||persona_enemy_near(fp,70)))return false;
        /* Enter the current circle on this side instead of all racing to its
         * exact centre. The navigation mesh chooses a dry, reachable landing. */
        float r=fmaxf(0,party.storm_radius-80),ratio=d>.01f?fminf(1,r/d):0;
        *goal=(Vec3){party.storm.x+(p.x-party.storm.x)*ratio,party.storm.y,party.storm.z+(p.z-party.storm.z)*ratio};
        Vec3 probe=*goal,floor;probe.y=10000;if(m3d_DelfinoFloor(&probe,&floor))*goal=floor;
        return true;
    }
    return false;
}
static void names_destroy(void* p){if(names_text==p)names_text=NULL;HSD_SisLib_803A5A2C(p);}
/* Ownership follows the stage, including font startup and CPU-only games.
 * Retail markers must not keep running invisibly behind this name layer. */
bool m3d_HumanNamesActive(void){return party_map_active();}
static void human_name(int slot,char out[17]) {
    const char* list=getenv("MELEE3D_NATIVE_PLAYER_NAMES");int n=0;
    if(list){for(int i=0;i<slot&&*list;i++){while(*list&&*list!='|')list++;if(*list)list++;}
        while(*list&&*list!='|'&&n<16){unsigned char c=*list++;if(isalnum(c)||c==' '||c=='_'||c=='-')out[n++]=c;}}
    out[n]=0;
    if(!n)snprintf(out,17,"P%d",slot+1);
}
static void human_names(void) {
    if(!HSD_SisLib_804D1124[2])return;
    int humans=0;for(int i=0;i<GM_MAX_PLAYERS;i++)humans+=Player_GetPlayerSlotType(i)==Gm_PKind_Human;
    if(!humans)return;
    if(!names_text){
        int canvas=HSD_SisLib_803A611C(2,NULL,HSD_GOBJ_CLASS_UI,15,0,14,0,25);
        names_text=HSD_SisLib_803A6754(2,canvas);if(!names_text)return;
        names_text->default_kerning=1;names_text->default_alignment=1;
        if(names_text->entity)names_text->entity->user_data_remove_func=names_destroy;
        for(int i=0;i<GM_MAX_PLAYERS;i++){name_entry[i]=name_shadow[i]=-1;if(Player_GetPlayerSlotType(i)!=Gm_PKind_Human)continue;
            char name[17];human_name(i,name);
            name_shadow[i]=HSD_SisLib_803A6B98(names_text,-100,-100,"%s",name);name_entry[i]=HSD_SisLib_803A6B98(names_text,-100,-100,"%s",name);
            GXColor black={0,0,0,255},white={255,255,255,255};
            HSD_SisLib_803A74F0(names_text,name_shadow[i],&black);HSD_SisLib_803A74F0(names_text,name_entry[i],&white);
            HSD_SisLib_803A7548(names_text,name_shadow[i],.32f,.32f);HSD_SisLib_803A7548(names_text,name_entry[i],.32f,.32f);
            if(Player_GetPlayerSlotType(i)==Gm_PKind_Human)fprintf(stderr,"M3D HUMAN NAME slot=%d name=%s\n",i,name);
        }
    }
    HSD_CObj* camera=HSD_CObjGetCurrent();float tv=tanf(HSD_CObjGetFov(camera)*.00872664626f),aspect=HSD_CObjGetAspect(camera);
    for(int i=0;i<GM_MAX_PLAYERS;i++) {
        if(name_entry[i]<0)continue;
        float x=-100,y=-100;HSD_GObj* object=Player_GetEntity(i);
        if(object&&Player_GetPlayerSlotType(i)==Gm_PKind_Human) {
            Fighter* fp=GET_FIGHTER(object);
            if(!fp->is_sleeping&&!fp->invisible&&!m3d_PartyEliminated(i)) {
                Vec3 p=fp->cur_pos,v;p.y+=fmaxf(ftLib_GetNameTagHeight(object),fp->coll_data.ecb.top.y)+4;
                PSMTXMultVec(HSD_CObjGetViewingMtxPtr(camera),&p,&v);
                if(v.z< -3&&v.z> -800) {
                    float nx=v.x/(-v.z*tv*aspect),ny=v.y/(-v.z*tv);
                    if(fabsf(nx)<.95f&&fabsf(ny)<.95f){x=320+nx*320;y=240-ny*240-18;}
                }
            }
        }
        HSD_SisLib_803A746C(names_text,name_entry[i],x,y);HSD_SisLib_803A746C(names_text,name_shadow[i],x+1,y+1);
    }
}
static void vertex(float x,float y,float z,GXColor c){GXPosition3f32(x,y,z);GXColor4u8(c.r,c.g,c.b,c.a);}
static void ring(M3dPartyPoint p,float radius,float height,GXColor c) {
    GXBegin(GX_QUADS,GX_VTXFMT0,96*4);
    for(int i=0;i<96;i++){float a=i*6.2831853f/96,b=(i+1)*6.2831853f/96;
        vertex(p.x+cosf(a)*radius,p.y,p.z+sinf(a)*radius,c);vertex(p.x+cosf(b)*radius,p.y,p.z+sinf(b)*radius,c);
        vertex(p.x+cosf(b)*radius,p.y+height,p.z+sinf(b)*radius,c);vertex(p.x+cosf(a)*radius,p.y+height,p.z+sinf(a)*radius,c);}
    GXEnd();
}
#include "m3d_goop_visual.inc"
/* One small chevron, toward the nearest hill. Selection hysteresis avoids
 * jitter between equally close hills; relocation invalidates the old choice.
 * Projection happens in the world pass, drawing happens in the HUD pass. */
static void objective_project(void) {
    objective_visible=0;objective_tick=m3d_match_frame;
    if(!initialized||party.mode!=M3D_PARTY_HILL||party.finished)return;
    Fighter* subject=m3d_CameraSubject();if(!subject||subject->is_sleeping)return;
    Vec3 p=subject->cur_pos;if(m3d_MapIsActive(subject))m3d_MapToWorld(&p);
    if(m3d_party_inside(&party,point(p)))return;
    int count=m3d_party_hill_total(&party),phase=party.tick/party.hill_period;
    if(phase!=objective_phase){objective_hill=-1;objective_phase=phase;}
    int nearest=0;float distance=1e30f;
    for(int k=0;k<count;k++){
        M3dPartyPoint h=m3d_party_hill_at(&party,k);
        float d=hypotf(m3d_party_distance(point(p),h),p.y-h.y);
        if(d<distance){nearest=k;distance=d;}
    }
    if(objective_hill<0||objective_hill>=count)objective_hill=nearest;
    else {
        M3dPartyPoint h=m3d_party_hill_at(&party,objective_hill);
        float current=hypotf(m3d_party_distance(point(p),h),p.y-h.y);
        if(distance<current*.85f)objective_hill=nearest;
    }
    Vec3 target=vector(m3d_party_hill_at(&party,objective_hill)),v;target.y+=3;
    HSD_CObj* camera=HSD_CObjGetCurrent();if(!camera)return;
    PSMTXMultVec(HSD_CObjGetViewingMtxPtr(camera),&target,&v);
    float projection[7];GXGetProjectionv(projection);
    bool perspective=projection[0]==GX_PERSPECTIVE;
    float x=projection[1]*v.x+projection[2]*(perspective?v.z:1);
    float y=projection[3]*v.y+projection[4]*(perspective?v.z:1);
    objective_visible=m3d_objective_edge(x,y,perspective?-v.z:1,
        pc_widescreen_scale()*(73.0f/60.0f),&objective_arrow);
}
static void objective_render(void) {
    if(!objective_visible||objective_tick!=m3d_match_frame||party.mode!=M3D_PARTY_HILL)return;
    M3dObjectiveArrow* a=&objective_arrow;
    float saved[7];GXGetProjectionv(saved);
    Mtx44 projection;MTXOrtho(projection,240,-240,-a->half_width,a->half_width,-1,1);
    GXSetProjection(projection,GX_ORTHOGRAPHIC);
    Mtx identity;PSMTXIdentity(identity);GXLoadPosMtxImm(identity,0);GXSetCurrentMtx(0);
    GXSetFog(GX_FOG_NONE,0,0,0,0,(GXColor){0,0,0,255});
    /* A dark rim keeps the muted mint chevron legible over bright paving.
     * No text, distance counter, pulsing or per-hill marker clutter. */
    for(int layer=0;layer<2;layer++) {
        float length=layer?12:16,width=layer?5:7,notch=layer?8:10;
        float x=a->x,y=a->y,dx=a->dx,dy=a->dy;
        GXColor c=layer?(GXColor){135,235,205,215}:(GXColor){10,22,24,150};
        float tip=layer?0:2;
        GXBegin(GX_TRIANGLES,GX_VTXFMT0,6);
        vertex(x+dx*tip,y+dy*tip,0,c);
        vertex(x-dx*length-dy*width,y-dy*length+dx*width,0,c);
        vertex(x-dx*notch,y-dy*notch,0,c);
        vertex(x+dx*tip,y+dy*tip,0,c);
        vertex(x-dx*notch,y-dy*notch,0,c);
        vertex(x-dx*length+dy*width,y-dy*length-dx*width,0,c);
        GXEnd();
    }
    GXSetProjectionv(saved);HSD_StateInvalidate(-1);HSD_StateInitTev();
}
void m3d_PartyRender(void) {
    if(!party_map_active())return;
    human_names();objective_project();
    /* Effect/character passes may leave indirect sampling or channel swaps.
     * Establish a complete world pass so cloud alpha cannot become a solid
     * rectangular sheet through inherited TEV state. */
    HSD_StateInvalidate(-1);HSD_StateInitTev();
    GXLoadPosMtxImm(HSD_CObjGetViewingMtxPtr(HSD_CObjGetCurrent()),0);GXSetCurrentMtx(0);
    GXSetNumIndStages(0);GXSetTevDirect(GX_TEVSTAGE0);
    GXSetTevSwapModeTable(GX_TEV_SWAP0,GX_CH_RED,GX_CH_GREEN,GX_CH_BLUE,GX_CH_ALPHA);
    GXSetTevSwapMode(GX_TEVSTAGE0,GX_TEV_SWAP0,GX_TEV_SWAP0);
    GXClearVtxDesc();GXSetVtxDesc(GX_VA_POS,GX_DIRECT);GXSetVtxDesc(GX_VA_CLR0,GX_DIRECT);
    GXSetVtxAttrFmt(GX_VTXFMT0,GX_VA_POS,GX_POS_XYZ,GX_F32,0);GXSetVtxAttrFmt(GX_VTXFMT0,GX_VA_CLR0,GX_CLR_RGBA,GX_RGBA8,0);
    GXSetNumTexGens(0);GXSetNumChans(1);GXSetNumTevStages(1);GXSetTevOrder(GX_TEVSTAGE0,GX_TEXCOORD_NULL,GX_TEXMAP_NULL,GX_COLOR0A0);GXSetTevOp(GX_TEVSTAGE0,GX_PASSCLR);
    GXSetChanCtrl(GX_COLOR0A0,GX_DISABLE,GX_SRC_REG,GX_SRC_VTX,0,GX_DF_NONE,GX_AF_NONE);
    GXSetColorUpdate(GX_TRUE);GXSetAlphaUpdate(GX_FALSE);
    GXSetZMode(GX_TRUE,GX_LEQUAL,GX_FALSE);GXSetCullMode(GX_CULL_NONE);GXSetAlphaCompare(GX_ALWAYS,0,GX_AOP_AND,GX_ALWAYS,0);GXSetZCompLoc(GX_TRUE);
    GXSetBlendMode(GX_BM_BLEND,GX_BL_SRCALPHA,GX_BL_INVSRCALPHA,GX_LO_CLEAR);
    Fighter* subject=m3d_CameraSubject();Vec3 aim;bool locked;
    if(subject&&Player_GetPlayerSlotType(subject->player_idx)==Gm_PKind_Human&&m3d_CombatTarget(subject,&aim,&locked)) {
        M3dPartyPoint p=point(aim);p.y+=1;
        GXColor color=locked?(GXColor){255,190,40,230}:(GXColor){80,230,255,190};
        ring(p,6.5f,.8f,color);p.y+=20;ring(p,2.5f,.5f,color);
    }
    if(subject&&m3d_CombatLaunchFraction(subject)>=.7f){M3dPartyPoint p=point(subject->cur_pos);p.y+=2;ring(p,8,2,(GXColor){255,60,30,230});}
    if(initialized&&party.mode==1)for(int k=0;k<m3d_party_hill_total(&party);k++){M3dPartyPoint h=m3d_party_hill_at(&party,k);h.y+=1;
        bool contested=party.hill_rule==M3D_HILL_SOLO?party.occupants>1:party.hill_occupants[k]>1;
        ring(h,party.hill_radius,3,contested?(GXColor){255,80,40,200}:(GXColor){30,240,190,200});ring(h,2,120,(GXColor){40,255,200,110});}
    if(initialized&&party.mode==M3D_PARTY_SURVIVAL){
        goop_render();

    }
    HSD_StateInvalidate(-1);
}

/* Hold uncontested ground instead of pursuing an enemy across the island.
 * Native attacks and hit reactions are untouched; only planner pads idle. */
void m3d_PartyHold(Fighter* fp){
    if(m3d_PartyFlee(fp))return;
    if(initialized&&!party.finished&&!fp->is_sub_fighter){personas_setup();persona_pad(fp);if(persona_of(fp)!=PERSONA_NORMAL&&persona_of(fp)!=PERSONA_TURTLE)return;}
    if(!initialized||party.finished||fp->is_sub_fighter||party.mode!=1||!m3d_party_inside(&party,point(fp->cur_pos)))return;
    for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];g;g=g->next){Fighter* other=GET_FIGHTER(g);
        if(other->player_idx==fp->player_idx||other->is_sleeping||other->motion_id<14||!available(other->player_idx))continue;
        if(hypotf(fp->cur_pos.x-other->cur_pos.x,fp->cur_pos.z-other->cur_pos.z)<70&&fabsf(fp->cur_pos.y-other->cur_pos.y)<32)return;}
    fp->cpu.buttons=0;fp->cpu.lstick.x=fp->cpu.lstick.y=0;fp->cpu.cstick.x=fp->cpu.cstick.y=0;
}

/* ---- results: added (Akaneia) fighters ---------------------------------
 * The retail results scene indexes ckind tables sized for 26 characters.
 * Akaneia's own GmRst.usd keeps the retail frame layout and appends its
 * fighters' name banners (frames 26-32, the m-ex external id) and a Sonic
 * series emblem; GmRstM<xx>.dat holds each fighter's results animation.
 * Layout constants (camera offsets) borrow a similarly sized retail fighter. */
typedef struct { const char* anim; int layout; float scale; int theme_proxy; const char* theme_file; } M3dResultFighter;
static const M3dResultFighter result_fighters[7]={
    {"GmRstMWf.dat",CKind_Fox,1.0f,CKind_Fox,NULL},
    {"GmRstMDd.dat",CKind_Donkey,.85f,CKind_Donkey,NULL},
    {"GmRstMLz.dat",CKind_Koopa,.84f,CKind_Pikachu,NULL},
    {"GmRstMLc.dat",CKind_Ness,1.0f,CKind_Ness,NULL},
    {"GmRstMSn.dat",CKind_Mario,1.0f,-1,"ff_sonic.hps"},
    {"GmRstMDe.dat",CKind_Koopa,.84f,CKind_Kirby,NULL},
    {"GmRstMTs.dat",CKind_Pikachu,1.0f,-1,"ff_sonic.hps"},
};
static const M3dResultFighter* result_fighter(int ckind){return ckind>=34&&ckind<=40&&m3d_akaneia_enabled()?&result_fighters[ckind-34]:NULL;}
bool m3d_ResultSupported(int ckind){return (ckind>=0&&ckind<26)||result_fighter(ckind);}
const char* m3d_ResultAnimFile(int ckind){const M3dResultFighter* f=result_fighter(ckind);return f?f->anim:NULL;}
int m3d_ResultEmblem(int ckind){return result_fighter(ckind)?(int)m3d_akaneia_emblem(ckind-1):-1;}
float m3d_ResultNameFrame(int ckind,float retail){return result_fighter(ckind)?(float)(ckind-8):retail;}
int m3d_ResultLayoutKind(int ckind){const M3dResultFighter* f=result_fighter(ckind);return f?f->layout:ckind;}
float m3d_ResultScale(int ckind,float retail){const M3dResultFighter* f=result_fighter(ckind);return f?f->scale:retail;}
/* Returns a retail ckind whose victory theme to use, or -1 after playing a
 * named Akaneia track, or ckind unchanged for retail fighters. */
int m3d_ResultThemeKind(int ckind,const char** file){
    const M3dResultFighter* f=result_fighter(ckind);*file=NULL;
    if(!f)return ckind;if(f->theme_file){*file=f->theme_file;return -1;}return f->theme_proxy;
}

/* ---- results: Melee's four-panel results screen ---------------------------
 * Panel 1 is the winner; panels 2-4 are the next finishers (last eliminated
 * in survival, highest score in hill). Everyone else is left off the screen. */
void m3d_PartyResults(MatchEnd* me)
{
    /* Stage teardown has already cleared the live Delfino flag here. A
     * pause quit has no ranked result_order, but still has all 32 standings.
     * Retail only constructs four panels, so compact canceled rounds too. */
    if(!getenv("MELEE3D_NATIVE_DELFINO")&&!getenv("MELEE3D_NATIVE_ONETT_OVERLAY")&&result_count<0)return;
    bool canceled=gm_WasMatchCanceled(me->outcome);
    int order[GM_MAX_PLAYERS],n=0;
    if(result_count>0){n=result_count;memcpy(order,result_order,sizeof order);}
    else for(int i=0;i<GM_MAX_PLAYERS;i++)if(me->player_standings[i].pkind!=Gm_PKind_NA)order[n++]=i;
    if(n<=0)return;
    static struct MatchPlayerData standings[GM_MAX_PLAYERS];
    static struct UnkResultPlayerData extra[6];
    memcpy(standings,me->player_standings,sizeof standings);memcpy(extra,me->x44C,sizeof extra);
    memset(me->player_standings,0,sizeof me->player_standings);memset(me->x44C,0,sizeof me->x44C);
    for(int i=0;i<GM_MAX_PLAYERS;i++)me->player_standings[i].pkind=Gm_PKind_NA;
    int picks[4],places[4],shown=0;
    for(int k=0;k<n&&shown<4;k++)if(m3d_ResultSupported(standings[order[k]].ckind)){picks[shown]=order[k];places[shown]=k;shown++;}
    if(!shown)return;
    for(int p=0;p<shown;p++){
        int src=picks[p];me->player_standings[p]=standings[src];
        if(src<6)me->x44C[p]=extra[src];
        struct MatchPlayerData* d=&me->player_standings[p];
        memset(d->kills,0,sizeof d->kills);
        for(int q=0;q<shown;q++)d->kills[q]=standings[src].kills[picks[q]];
        int place=places[p]<3?places[p]:3;
        d->is_big_loser=place;d->is_small_loser=place;d->team=p;
        /* Keep real scores/statistics. Placements are already represented by
         * the native loser fields, rather than fabricated 4/3/2/1 scores. */
        if(party.mode==1)d->score=party.score[src];
        d->stocks=!canceled&&place==0&&result_has_winner?1:0;
        fprintf(stderr,"M3D PARTY RESULT panel=%d place=%d slot=%d ckind=%d costume=%d\n",p+1,places[p]+1,src,d->ckind,d->x3_u.x0.x3_b0);
    }
    if(!canceled)me->outcome=OUTCOME_ELIMINATION;me->is_teams=0;
    if(canceled)result_count=n;
    me->n_winners=!canceled&&result_has_winner&&places[0]==0?1:0;memset(me->winners,0,sizeof me->winners);
    struct {u8 hi:4;u8 lo:4;}* loser=(void*)&me->loser;loser->hi=shown-1;   /* as fn_80165AC0 */
}

/* ---- presentation: nearby-only off-screen bubbles and local sound -------- */
static bool listener(Vec3* pos,float* yaw)
{
    Fighter* f=m3d_CameraSubject();if(!f)return false;
    *pos=f->cur_pos;if(m3d_MapIsActive(f))m3d_MapToWorld(pos);
    *yaw=m3d_CameraGetYaw();return true;
}
bool m3d_MagnifyHidden(HSD_GObj* gobj)
{
    if(!party_map_active()||!gobj)return false;
    Fighter* f=GET_FIGHTER(gobj);Fighter* me=m3d_CameraSubject();
    if(!me||f==me)return false;
    if(f->is_sleeping||(party.mode==3&&!available(f->player_idx)))return true;
    if(pressure_revealed(f->player_idx))return false;
    Vec3 a=f->cur_pos,b=me->cur_pos;if(m3d_MapIsActive(f))m3d_MapToWorld(&a);if(m3d_MapIsActive(me))m3d_MapToWorld(&b);
    return hypotf(a.x-b.x,a.z-b.z)>150||fabsf(a.y-b.y)>100;
}
/* Full volume within 80 units of the viewed fighter, silent beyond 260; pan by
 * the camera's left/right. Returns false when the sound should not play. */
static unsigned sound_full,sound_quiet,sound_culled;
bool m3d_SpatialSound(Vec3* source,u8* vol,u8* pan)
{
    Vec3 ear;float yaw;
    if(!party_map_active()||!source||!listener(&ear,&yaw))return true;
    if(m3d_match_frame%600==0&&(sound_full|sound_quiet|sound_culled)){
        fprintf(stderr,"M3D AUDIO tick=%d full=%u attenuated=%u culled=%u\n",m3d_match_frame,sound_full,sound_quiet,sound_culled);sound_full=sound_quiet=sound_culled=0;}
    float dx=source->x-ear.x,dy=source->y-ear.y,dz=source->z-ear.z,d=sqrtf(dx*dx+dy*dy+dz*dz);
    float gain=d<=80?1:d>=260?0:(260-d)/180;gain*=gain;
    int v=(int)(*vol*gain+.5f);if(v<=0){sound_culled++;return false;}
    if(gain>=1)sound_full++;else sound_quiet++;*vol=(u8)v;
    float right=dx*cosf(yaw)-dz*sinf(yaw),side=fmaxf(-1,fminf(1,right/90));
    int p=*pan+(int)(side*48);*pan=(u8)(p<0?0:p>127?127:p);
    return true;
}
bool m3d_FighterSound(Fighter* fp,u8* vol,u8* pan)
{
    if(!fp||!party_map_active())return true;
    /* The controlled/spectated fighter is the listener. Never apply a
     * projected-slice distance or an off-centre pan to their own feedback. */
    if(fp==m3d_CameraSubject()){*pan=64;return true;}
    Vec3 p=fp->cur_pos;if(m3d_MapIsActive(fp))m3d_MapToWorld(&p);
    return m3d_SpatialSound(&p,vol,pan);
}
bool m3d_ItemSound(Item* ip,u8* vol,u8* pan)
{
    if(!ip||!party_map_active())return true;
    Vec3 p=ip->pos;if(m3d_MapIsActive(ip))m3d_MapToWorld(&p);
    return m3d_SpatialSound(&p,vol,pan);
}

/* Results panels are ranked, rather than physical controller order. The
 * solo viewer operates their panel even if it is panel two, three or four. */
int m3d_ResultPad(int panel){return result_count>=0&&m3d_MenuActive()?0:panel;}

/* Leaving the results screen ends the play session (relaunch for a new round). */
void m3d_PartyResultsExit(void)
{
    if(result_count<0)return;
    fprintf(stderr,"M3D PARTY RESULTS DONE\n");fflush(stderr);fflush(stdout);
    exit(0);
}
