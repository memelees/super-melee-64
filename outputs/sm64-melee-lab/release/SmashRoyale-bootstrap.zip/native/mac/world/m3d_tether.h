#ifndef M3D_TETHER_H
#define M3D_TETHER_H
#include "m3d.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
/* Tethers retain native chain constraints, drag, collision and timing. Run
 * the complete solver in one lane, rather than rebuilding collision for each
 * link or mixing a world-space hand matrix with planar launch velocity. */
typedef struct {
    Vec3 origin;
    float lx,lz,x0,root_y;
    HSD_GObj* tether;
    bool active;
} M3dTetherView;

static void m3d_tether_point(M3dTetherView* v,Vec3* p,bool world)
{
    float x=p->x,z=p->z;
    if (world) {
        p->x=v->origin.x+(x-v->x0)*v->lx-z*v->lz;
        p->z=v->origin.z+(x-v->x0)*v->lz+z*v->lx;
    } else {
        p->x=v->x0+(x-v->origin.x)*v->lx+(z-v->origin.z)*v->lz;
        p->z=-(x-v->origin.x)*v->lz+(z-v->origin.z)*v->lx;
    }
}

static void m3d_tether_links(M3dTetherView* v,Item* ip,bool world)
{
    ItemLink* link;
    for (link=ip->kind==It_Kind_Samus_GBeam ? ip->xDD4_itemVar.samusgrapple.x0 : ip->xDD4_itemVar.linkhookshot.x0;link;link=link->next) {
        CollData* cd=&link->coll_data;
        m3d_tether_point(v,&link->pos,world);
        m3d_tether_point(v,&cd->cur_pos,world);
        m3d_tether_point(v,&cd->prev_pos,world);
        m3d_tether_point(v,&cd->last_pos,world);
        m3d_tether_point(v,&cd->contact,world);
        if (world) {
            HSD_JObj* joint=link->gobj->hsd_obj;
            Mtx m;
            int j;
            HSD_JObjSetupMatrix(joint);
            PSMTXCopy(joint->mtx,m);
            for (j=0;j<4;j++) {
                joint->mtx[0][j]=v->lx*m[0][j]-v->lz*m[2][j];
                joint->mtx[2][j]=v->lz*m[0][j]+v->lx*m[2][j];
            }
            joint->mtx[0][3]+=v->origin.x-v->x0*v->lx;
            joint->mtx[2][3]+=v->origin.z-v->x0*v->lz;
            /* Native root-bone queries can read SRT translation directly,
             * bypassing the custom matrix used to draw the chain. */
            joint->translate.x=joint->mtx[0][3];
            joint->translate.y=joint->mtx[1][3];
            joint->translate.z=joint->mtx[2][3];
            joint->flags|=0x03800000;
            HSD_JObjSetMtxDirty(joint);
        }
    }
}

static void m3d_tether_begin(Fighter* fp,HSD_GObj* tether,M3dTetherView* v)
{
    HSD_JObj* root=fp->gobj->hsd_obj;
    v->active=false;
    if (!tether || !m3d_GetLane(fp,&v->lx,&v->lz)) return;
    v->origin=fp->cur_pos;
    v->x0=v->origin.x*v->lx+v->origin.z*v->lz;
    if (!m3d_MapBegin(v,&v->origin,v->lx,v->lz)) return;
    v->active=true;v->tether=tether;
    v->root_y=HSD_JObjGetRotationY(root);
    m3d_tether_point(v,&fp->cur_pos,false);
    HSD_JObjSetTranslate(root,&fp->cur_pos);
    HSD_JObjSetRotationY(root,v->root_y-atan2f(v->lx,v->lz)+1.57079633f);
    m3d_tether_links(v,v->tether->user_data,false);
}

static void m3d_tether_end(Fighter* fp,HSD_GObj* tether,M3dTetherView* v)
{
    HSD_JObj* root=fp->gobj->hsd_obj;
    if (!v->active) return;
    if (tether==v->tether) m3d_tether_links(v,v->tether->user_data,true);
    m3d_tether_point(v,&fp->cur_pos,true);
    HSD_JObjSetTranslate(root,&fp->cur_pos);
    HSD_JObjSetRotationY(root,v->root_y);
    m3d_MapEnd(v);
    if(tether==v->tether&&getenv("MELEE3D_NATIVE_TETHER_CHECK")){
        Item* ip=tether->user_data;ItemLink* link=ip->kind==It_Kind_Samus_GBeam?ip->xDD4_itemVar.samusgrapple.x0:ip->xDD4_itemVar.linkhookshot.x0;
        float dx=link->pos.x-fp->cur_pos.x,dz=link->pos.z-fp->cur_pos.z;
        fprintf(stderr,"M3D TETHER FRAME tick=%d kind=%d active=%d along=%.4f across=%.4f x=%.4f y=%.4f z=%.4f\n",m3d_match_frame,fp->kind,link->x2C_b0,dx*v->lx+dz*v->lz,-dx*v->lz+dz*v->lx,link->pos.x,link->pos.y,link->pos.z);
    }
}


#endif
