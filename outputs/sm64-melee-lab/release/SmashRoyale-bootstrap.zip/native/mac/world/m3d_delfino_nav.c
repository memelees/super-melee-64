/* SPDX-License-Identifier: GPL-3.0-or-later
 * DELFINO: collision-derived district routes. Native pads own all movement;
 * there are no actor teleports, speed changes or distant simulation skips. */
#include "m3d.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <melee/ft/types.h>
#include <melee/ft/fighter.h>
#include <melee/ft/ft_081B.h>
#include <melee/ft/inlines.h>
#include <melee/ft/kinds/ftPopo/types.h>
#include <melee/ft/kinds/ftCommon/forward.h>
#include <melee/ft/kinds/ftCommon/ftCo_0A01.h>
#include <melee/pl/player.h>
#include <melee/mp/forward.h>
#include <sysdolphin/baselib/gobj.h>
#include <sysdolphin/baselib/controller.h>
#include <sysdolphin/baselib/random.h>
#include <melee/it/types.h>

typedef struct {Vec3 pos;unsigned component,first,count;} NavNode;
typedef struct {float x,y,z;} M3dPartyPointLike;
typedef struct {unsigned target,kind;} NavEdge;
typedef struct {int node;float cost;} NavHeap;
typedef struct {
    Fighter* fp;Vec3 last,waypoint,progress,escape_direction,failed_goal;
    int escape_node,frames,node,target_node,path[1024],length,cursor,walk_clock,jump_clock,stall,progress_node,settle,cliff_frames,next_plan,special_clock;
    float best_progress,body_radius,body_height;unsigned char* body_fit;
    unsigned replans,failures,travel,stuck,arrivals,sector_changes,last_sector;
    unsigned visited[32];float distance;bool drive,jump,gap,urgent;
    bool was_driven;int fallback_until,fallback_node;
    bool trial_done,trial_selected,trial_crossed;
    struct {int from,to,until;} blocked[16];unsigned block_cursor;
} NavActor;
static NavNode* nodes;static NavEdge* edges;static unsigned node_count,edge_count,main_component;
static float* costs;static int* parents;static unsigned char* closed;static NavHeap* heap;static int heap_count;
static int anchors[GM_MAX_PLAYERS],spawn_anchors[GM_MAX_PLAYERS];
static int respawn_generation[GM_MAX_PLAYERS],respawn_nodes[GM_MAX_PLAYERS];static NavActor actors[GM_MAX_PLAYERS];
static int *reverse_heads,*reverse_next,*reverse_from;
static unsigned *reverse_marks,reverse_epoch;
/* Opt-in slow-call attribution only: no planning/body/navigation decisions
 * change. Thread CPU distinguishes actual work from scheduling/driver waits. */
static int nav_cost_enabled=-1;
static unsigned long long nav_cost_body_misses;
static bool nav_cost_trace(void) {
    if(nav_cost_enabled<0)nav_cost_enabled=getenv("MELEE3D_NATIVE_NAV_COST_TRACE")!=NULL;
    return nav_cost_enabled!=0;
}
static unsigned long long nav_cost_ns(bool cpu) {
#if defined(__APPLE__) || !defined(_WIN32)
    struct timespec value;
    clockid_t clock_id=CLOCK_MONOTONIC;
#ifdef CLOCK_THREAD_CPUTIME_ID
    if(cpu)clock_id=CLOCK_THREAD_CPUTIME_ID;
#else
    if(cpu)return 0;
#endif
    if(clock_gettime(clock_id,&value))return 0;
    return (unsigned long long)value.tv_sec*1000000000ull+value.tv_nsec;
#else
    (void)cpu;return 0;
#endif
}
static void nav_cost_log(const char* phase,NavActor* a,int from,int to,bool result,
                         unsigned long long wall,unsigned long long cpu,
                         unsigned long long misses) {
    if(wall<2000000ull&&cpu<2000000ull)return;
    Vec3 p=from>=0&&(unsigned)from<node_count?nodes[from].pos:(Vec3){NAN,NAN,NAN};
    Vec3 q=to>=0&&(unsigned)to<node_count?nodes[to].pos:(Vec3){NAN,NAN,NAN};
    fprintf(stderr,"M3D NAV COST phase=%s match_tick=%d slot=%u kind=%d actor_tick=%d state=%d wall_ms=%.3f cpu_ms=%.3f body_misses=%llu radius=%.1f height=%.1f from=%d to=%d from_pos=%.3f,%.3f,%.3f to_pos=%.3f,%.3f,%.3f result=%d path=%d/%d\n",
        phase,m3d_match_frame,a->fp->player_idx,a->fp->kind,a->frames,a->fp->motion_id,
        wall/1e6,cpu/1e6,misses,a->body_radius,a->body_height,from,to,
        p.x,p.y,p.z,q.x,q.y,q.z,result,a->cursor,a->length);
}

static int node_heads[8192],*node_next;
static unsigned char* exposed;static unsigned char* boundary_fit[65];
static uint64_t* reachable;static unsigned component_count,reach_words;
#define NAV_PROFILES 9
static bool tier_reaches(int tier,unsigned from,unsigned to){return reachable&&(reachable[((tier*component_count+from)*reach_words)+to/64]&(UINT64_C(1)<<(to%64)));}
static bool can_reach(unsigned from,unsigned to){return tier_reaches(NAV_PROFILES-1,from,to);}
static int jump_profile(Fighter* fp){
    float v=fp->co_attrs.jump_v_initial_velocity,g=fp->co_attrs.gravity,m=fp->co_attrs.air_jump_v_multiplier;
    int jumps=fp->co_attrs.max_jumps;if(jumps<1)jumps=1;if(jumps>6)jumps=6;
    float budget=g>.001f?v*v/(2*g)*(1+(jumps-1)*m*m)*.85f-3:32;
    /* This table is an upper-bound connectivity lookup, not a second jump
     * test. Round UP so a valid 32.8-unit rise is not rounded down to a
     * 32-unit bucket. jump_edge still checks the exact native jump arc,
     * clearance and air drift before A* may use any extended edge. */
    int tier=(int)ceilf((budget+8-32)/8);return tier<0?0:tier>=NAV_PROFILES?NAV_PROFILES-1:tier;
}
static bool actor_reaches(Fighter* fp,unsigned from,unsigned to){return tier_reaches(jump_profile(fp),from,to);}
static bool spread,tour;
static int route_trial,trial_crossing,trial_starts[GM_MAX_PLAYERS],trial_goals[GM_MAX_PLAYERS];
static bool roof_layout,trace_routes;
#define HILL_ROOFS 8
static int hill_roofs[HILL_ROOFS],hill_roof_count,hill_tier;
static bool hills_ready;
static struct {Fighter* fp;Vec3 pos;int tick,node;} supports[GM_MAX_PLAYERS][2];
static float distance(Vec3 a,Vec3 b){float x=a.x-b.x,y=a.y-b.y,z=a.z-b.z;return sqrtf(x*x+y*y+z*z);}
static float horizontal(Vec3 a,Vec3 b){return hypotf(a.x-b.x,a.z-b.z);}
static bool edge_allowed(int tier,unsigned from,NavEdge e){return e.kind<3||
    (nodes[e.target].pos.y-nodes[from].pos.y+(e.kind==4?40:8)<=32+tier*8&&horizontal(nodes[from].pos,nodes[e.target].pos)<=48+tier*20);}

static bool jump_edge(Fighter* fp,unsigned from,NavEdge e){
    if(!edge_allowed(jump_profile(fp),from,e))return false;if(e.kind<3)return true;
    float g=fp->co_attrs.gravity,v=fp->co_attrs.jump_v_initial_velocity,m=fp->co_attrs.air_jump_v_multiplier;
    /* Reserve ten percent of theoretical airtime for native startup/braking.
     * The earlier 20 percent reserve rejected physically reachable crossings. */
    float rise=fmaxf(0,nodes[e.target].pos.y-nodes[from].pos.y),height=v*v/(2*g),time=v/g;
    int jumps=fp->co_attrs.max_jumps;if(jumps<1)jumps=1;if(jumps>6)jumps=6;
    for(int i=1;i<jumps;i++){height+=v*v*m*m/(2*g);time+=v*m/g;}
    if(rise+(e.kind==4?40:8)>height*.85f)return false;
    time+=sqrtf(fmaxf(0,2*(height-rise)/g));
    return horizontal(nodes[from].pos,nodes[e.target].pos)<=fp->co_attrs.air_drift_max*time*.9f;
}
static void fail(const char* message){fprintf(stderr,"M3D NAV FAIL %s\n",message);abort();}
static void* allocate(size_t n){void* p=calloc(1,n);if(!p)fail("allocation");return p;}
static void read_bytes(FILE* f,void* p,size_t n){if(fread(p,1,n,f)!=n)fail("truncated graph");}

/* Reverse adjacency preserves original edge IDs/kinds and is only an exact
 * failure preflight for frozen source Onett. Nonstandard overlapping edge
 * ranges retain the existing planner without this optional acceleration. */
static void nav_reverse_build(void) {
    if(!m3d_ReferenceOverlayActive())return;
    unsigned cursor=0;for(unsigned i=0;i<node_count;i++){
        if(nodes[i].first!=cursor)return;cursor+=nodes[i].count;
    }
    if(cursor!=edge_count)return;
    reverse_heads=allocate(node_count*sizeof(*reverse_heads));
    reverse_next=allocate(edge_count*sizeof(*reverse_next));
    reverse_from=allocate(edge_count*sizeof(*reverse_from));
    reverse_marks=allocate(node_count*sizeof(*reverse_marks));
    for(unsigned i=0;i<node_count;i++)reverse_heads[i]=-1;
    for(unsigned i=0;i<node_count;i++)for(unsigned j=nodes[i].first;j<nodes[i].first+nodes[i].count;j++){
        reverse_from[j]=i;reverse_next[j]=reverse_heads[edges[j].target];reverse_heads[edges[j].target]=j;
    }
}

static int nearest(Vec3 pos,int component);
/* Diagnostic only: exact supported graph endpoints, ordinary CPU pads. */
static void select_file_routes(const char* path) {
    FILE* file=fopen(path,"rb");if(!file)fail("missing route fixture");
    if(fseek(file,0,SEEK_END))fail("route fixture must be a regular bounded file");
    long size=ftell(file);if(size<=0||size>16384)fail("route fixture size limit");
    rewind(file);
    for(int slot=0;slot<GM_MAX_PLAYERS;slot++) {
        Vec3 start,goal;
        if(fscanf(file,"%f %f %f %f %f %f",&start.x,&start.y,&start.z,&goal.x,&goal.y,&goal.z)!=6)
            fail("route fixture requires one start/goal pair per slot");
        if(!isfinite(start.x)||!isfinite(start.y)||!isfinite(start.z)||
           !isfinite(goal.x)||!isfinite(goal.y)||!isfinite(goal.z))fail("route fixture non-finite coordinate");
        int from=nearest(start,-1),to=nearest(goal,-1);
        if(from<0||to<0||distance(nodes[from].pos,start)>.5f||distance(nodes[to].pos,goal)>.5f)
            fail("route fixture endpoint is not an exact graph node");
        if(!exposed[from]||!exposed[to])fail("route fixture endpoint lacks supported stopping room");
        trial_starts[slot]=from;trial_goals[slot]=to;
        Vec3 a=nodes[from].pos,b=nodes[to].pos;
        fprintf(stderr,"M3D NAV TRIAL SETUP slot=%d mode=8 start=%.3f,%.3f,%.3f goal=%.3f,%.3f,%.3f source_nodes=%d,%d\n",slot,a.x,a.y,a.z,b.x,b.y,b.z,from,to);
    }
    char extra;if(fscanf(file," %c",&extra)!=EOF)fail("route fixture has trailing data");
    fclose(file);
}

static void select_hill_anchors(void);
static void select_canal_routes(void){
    const char* value=getenv("MELEE3D_NATIVE_NAV_ENDPOINTS");Vec3 a,b;
    const char* crossing=getenv("MELEE3D_NATIVE_NAV_CROSSING");trial_crossing=crossing?atoi(crossing):-1;
    if(trial_crossing<0||trial_crossing>=4)fail("canal crossing index");
    if(!value||sscanf(value,"%f,%f,%f/%f,%f,%f",&a.x,&a.y,&a.z,&b.x,&b.y,&b.z)!=6||
       !isfinite(a.x)||!isfinite(a.y)||!isfinite(a.z)||!isfinite(b.x)||!isfinite(b.y)||!isfinite(b.z))fail("canal route endpoints");
    for(int i=0;i<GM_MAX_PLAYERS;i++){
        trial_starts[i]=nearest(i%2?b:a,-1);trial_goals[i]=nearest(i%2?a:b,-1);
        Vec3 s=nodes[trial_starts[i]].pos,g=nodes[trial_goals[i]].pos;
        fprintf(stderr,"M3D NAV TRIAL SETUP slot=%d mode=4 start=%.2f,%.2f,%.2f goal=%.2f,%.2f,%.2f\n",i,s.x,s.y,s.z,g.x,g.y,g.z);
    }
}
/* Original Onett fixtures use measured source streets and retained blue-house
 * roofs. This selects initial positions and goals only; native CPU pads own
 * every subsequent step, jump, collision and landing. */
static void select_onett_routes(void) {
    for(int slot=0;slot<GM_MAX_PLAYERS;slot++) {
        Vec3 start,goal;
        if(route_trial==4) {
            start=(Vec3){-128,8.1f,slot%2?-576:-256};
            goal=(Vec3){-128,8.1f,slot%2?-256:-576};
        } else if(route_trial==6) {
            start=(Vec3){-17.1f,0,-77.8f};goal=(Vec3){25.2f,81,-56.8f};
        } else if(route_trial==7) {
            start=slot%2?(Vec3){272,129.6f,-832}:(Vec3){-128,8.1f,-576};
            goal=slot%2?(Vec3){208,180.767f,-880}:(Vec3){272,129.6f,-832};
        } else if(slot%2) {
            start=(Vec3){-214.65f,8.1f,-464};goal=(Vec3){-214.65f,44.55f,-512};
        } else {
            start=(Vec3){97.2f,8.1f,-344};goal=(Vec3){97.2f,44.55f,-400};
        }
        int from=nearest(start,-1),to=nearest(goal,-1);
        if(from<0||to<0||!can_reach(nodes[from].component,nodes[to].component))fail("Onett fixture source anchors disconnected");
        trial_starts[slot]=from;trial_goals[slot]=to;
        Vec3 a=nodes[from].pos,b=nodes[to].pos;
        fprintf(stderr,"M3D ONETT TRIAL SETUP slot=%d mode=%s start=%.3f,%.3f,%.3f goal=%.3f,%.3f,%.3f source_nodes=%d,%d\n",slot,route_trial==4?"north":route_trial==6?"fireescape":route_trial==7?"hills":"roofs",a.x,a.y,a.z,b.x,b.y,b.z,from,to);
    }
}
static void select_island_routes(void){
    for(int i=0;i<GM_MAX_PLAYERS;i++){
        trial_starts[i]=nearest((Vec3){1120+(i%2)*16,34,-832},-1);
        trial_goals[i]=nearest(i%2?(Vec3){1376,68,-1008}:(Vec3){1504,88,-1168},-1);
        Vec3 a=nodes[trial_starts[i]].pos,b=nodes[trial_goals[i]].pos;
        fprintf(stderr,"M3D NAV TRIAL SETUP slot=%d mode=3 start=%.2f,%.2f,%.2f goal=%.2f,%.2f,%.2f\n",i,a.x,a.y,a.z,b.x,b.y,b.z);
    }
}
static void select_roof_routes(Vec3 center) {
    float low=1e30f;for(unsigned i=0;i<node_count;i++)if(exposed[i]&&nodes[i].component==main_component)low=fminf(low,nodes[i].pos.y);
    int chosen[GM_MAX_PLAYERS];
    for(int slot=0;slot<GM_MAX_PLAYERS;slot++) {
        float best=-1;int roof=-1;
        for(unsigned i=0;i<node_count;i++)if(exposed[i]&&nodes[i].pos.y>fmaxf(center.y,low)+28&&
            (route_trial==1?can_reach(main_component,nodes[i].component):tier_reaches(2,nodes[i].component,main_component))) {
            float separation=1e6f;for(int j=0;j<slot;j++)separation=fminf(separation,horizontal(nodes[i].pos,nodes[chosen[j]].pos));
            float score=fminf(separation,1000)+fminf(nodes[i].pos.y-center.y,180)*.1f;
            if(score>best){best=score;roof=i;}
        }
        if(roof<0)fail("no supported roof route");chosen[slot]=roof;
        int ground=-1;best=1e30f;
        for(unsigned i=0;i<node_count;i++)if(exposed[i]&&nodes[i].component==main_component&&nodes[i].pos.y<nodes[roof].pos.y-28) {
            float d=distance(nodes[i].pos,nodes[roof].pos);if(d<best){best=d;ground=i;}
        }
        if(ground<0)fail("roof route has no street endpoint");
        trial_starts[slot]=route_trial==1?ground:roof;trial_goals[slot]=route_trial==1?roof:ground;
        Vec3 a=nodes[trial_starts[slot]].pos,b=nodes[trial_goals[slot]].pos;
        fprintf(stderr,"M3D NAV TRIAL SETUP slot=%d mode=%d start=%.2f,%.2f,%.2f goal=%.2f,%.2f,%.2f\n",slot,route_trial,a.x,a.y,a.z,b.x,b.y,b.z);
    }
}
/* Keep objective anchors stable, but choose a fresh spread for every match.
 * Use the game's seeded RNG so peers agree without depending on spawn-call
 * order; repeated queries and Ice Climbers' companion keep the same seat. */
static void select_spawn_anchors(void) {
    unsigned count=0;
    for(unsigned i=0;i<node_count;i++)if(exposed[i]&&nodes[i].component==main_component)count++;
    if(count<GM_MAX_PLAYERS)fail("not enough safe starting positions");
    unsigned ordinal=(unsigned)(HSD_Randf()*count);int chosen=-1;
    for(unsigned i=0;i<node_count;i++)if(exposed[i]&&nodes[i].component==main_component) {
        if(!ordinal--){chosen=i;break;}
    }
    float* separation=allocate(node_count*sizeof *separation);
    for(unsigned i=0;i<node_count;i++)separation[i]=1e30f;
    for(int slot=0;slot<GM_MAX_PLAYERS;slot++) {
        spawn_anchors[slot]=chosen;
        int next=-1;float best=-1;
        for(unsigned i=0;i<node_count;i++)if(exposed[i]&&nodes[i].component==main_component) {
            float d=distance(nodes[i].pos,nodes[chosen].pos);
            separation[i]=fminf(separation[i],d);
            if(separation[i]>best){best=separation[i];next=i;}
        }
        chosen=next;
    }
    free(separation);
    /* Every seat, including the human, has the same chance at each start. */
    for(int i=GM_MAX_PLAYERS-1;i>0;i--) {
        int j=HSD_Randi(i+1),swap=spawn_anchors[i];
        spawn_anchors[i]=spawn_anchors[j];spawn_anchors[j]=swap;
    }
}

void m3d_DelfinoNavSelect(const char* directory,Vec3* center){
    free(reverse_heads);free(reverse_next);free(reverse_from);free(reverse_marks);reverse_heads=reverse_next=reverse_from=NULL;reverse_marks=NULL;reverse_epoch=0;
    free(nodes);free(edges);free(costs);free(parents);free(closed);free(heap);free(node_next);free(exposed);free(reachable);reachable=NULL;component_count=0;nodes=NULL;edges=NULL;costs=NULL;parents=NULL;closed=NULL;heap=NULL;node_next=NULL;exposed=NULL;node_count=edge_count=0;
    for(int i=0;i<65;i++){free(boundary_fit[i]);boundary_fit[i]=NULL;}
    for(int i=0;i<GM_MAX_PLAYERS;i++)free(actors[i].body_fit);
    memset(actors,0,sizeof actors);memset(supports,0,sizeof supports);hills_ready=false;hill_roof_count=0;
    memset(respawn_generation,0,sizeof respawn_generation);memset(respawn_nodes,0xff,sizeof respawn_nodes);if(!directory)return;
    char path[4096],magic[4];if(snprintf(path,sizeof path,"%s/delfino.dln",directory)>=(int)sizeof path)fail("path");FILE* f=fopen(path,"rb");if(!f)fail("missing graph");
    unsigned version;float step;read_bytes(f,magic,4);read_bytes(f,&version,4);read_bytes(f,&node_count,4);read_bytes(f,&edge_count,4);read_bytes(f,&step,4);
    if(memcmp(magic,"DLN1",4)||version!=3||node_count<16||node_count>100000||edge_count>2000000||!isfinite(step)||step<4||step>32)fail("graph header");
    nodes=allocate(node_count*sizeof(*nodes));edges=allocate(edge_count*sizeof(*edges));read_bytes(f,nodes,node_count*sizeof(*nodes));read_bytes(f,edges,edge_count*sizeof(*edges));if(fgetc(f)!=EOF)fail("trailing graph bytes");fclose(f);
    unsigned* counts=allocate(node_count*sizeof(*counts));unsigned maximum=0;
    for(unsigned i=0;i<node_count;i++){NavNode* n=&nodes[i];if(!isfinite(n->pos.x)||!isfinite(n->pos.y)||!isfinite(n->pos.z)||n->component>=node_count||n->first>edge_count||n->count>edge_count-n->first)fail("node bounds");
        if(n->component+1>component_count)component_count=n->component+1;
        if(++counts[n->component]>maximum){maximum=counts[n->component];main_component=n->component;}}
    for(unsigned i=0;i<edge_count;i++)if(edges[i].target>=node_count||edges[i].kind>4)fail("edge bounds");free(counts);
    nav_reverse_build();
    if(component_count>2048)fail("route component budget");reach_words=(component_count+63)/64;reachable=allocate(NAV_PROFILES*component_count*reach_words*sizeof(*reachable));
    for(int tier=0;tier<NAV_PROFILES;tier++) {
        uint64_t* table=reachable+tier*component_count*reach_words;
        for(unsigned i=0;i<node_count;i++){unsigned from=nodes[i].component;table[from*reach_words+from/64]|=UINT64_C(1)<<(from%64);
            for(unsigned j=nodes[i].first;j<nodes[i].first+nodes[i].count;j++)if(edge_allowed(tier,i,edges[j])){unsigned to=nodes[edges[j].target].component;table[from*reach_words+to/64]|=UINT64_C(1)<<(to%64);}}
        for(unsigned k=0;k<component_count;k++)for(unsigned i=0;i<component_count;i++)if(tier_reaches(tier,i,k))for(unsigned w=0;w<reach_words;w++)table[i*reach_words+w]|=table[k*reach_words+w];
    }
    costs=allocate(node_count*sizeof(*costs));parents=allocate(node_count*sizeof(*parents));closed=allocate(node_count);heap=allocate((edge_count+1)*sizeof(*heap));
    node_next=allocate(node_count*sizeof(*node_next));for(int i=0;i<8192;i++)node_heads[i]=-1;
    exposed=allocate(node_count);for(unsigned i=0;i<node_count;i++){Vec3 p=nodes[i].pos,g;p.y=10000;bool safe=m3d_DelfinoFloor(&p,&g)&&fabsf(g.y-nodes[i].pos.y)<1;
        /* Long trips and respawns end with enough stopping room. Source
         * shoreline triangles may be walkable but immediately lethal. */
        for(int k=0;k<8&&safe;k++){float angle=k*.785398163f;Vec3 q=nodes[i].pos;q.x+=cosf(angle)*16;q.z+=sinf(angle)*16;q.y+=6;
            safe=m3d_DelfinoNavOffsetSupported(&nodes[i].pos,&q,6)&&(m3d_ReferenceOverlayActive()?m3d_DelfinoBlast(&q)==0:m3d_DelfinoBlast(&q)!=2);}
        exposed[i]=safe;}
    for(unsigned i=0;i<node_count;i++){int x=(int)floorf(nodes[i].pos.x/64),z=(int)floorf(nodes[i].pos.z/64);unsigned h=((unsigned)x*73856093u^(unsigned)z*19349663u)&8191u;node_next[i]=node_heads[h];node_heads[h]=i;}
    const char* layout=getenv("MELEE3D_NATIVE_DELFINO_LAYOUT");spread=!layout||strcmp(layout,"plaza");roof_layout=layout&&!strcmp(layout,"roofs");tour=getenv("MELEE3D_NATIVE_DELFINO_TOUR")!=NULL;
    const char* trial=getenv("MELEE3D_NATIVE_DELFINO_ROUTE");route_trial=trial?(!strcmp(trial,"ascent")?1:!strcmp(trial,"islands")?3:!strcmp(trial,"canal")?4:!strcmp(trial,"hills")?5:!strcmp(trial,"boat")?6:2):0;

    const char* onett_trial=getenv("MELEE3D_NATIVE_ONETT_TRIAL");
    if(m3d_ReferenceOverlayActive()&&onett_trial) {
        if(!strcmp(onett_trial,"north"))route_trial=4;
        else if(!strcmp(onett_trial,"roofs"))route_trial=5;
        else if(!strcmp(onett_trial,"fireescape"))route_trial=6;
        else if(!strcmp(onett_trial,"hills"))route_trial=7;
        else fail("Onett trial must be north, roofs, fireescape or hills");
    }
    const char* route_fixture=getenv("MELEE3D_NATIVE_ROUTE_FIXTURE");
    if(route_fixture)route_trial=8;
    if(route_trial)tour=true;trace_routes=getenv("MELEE3D_NATIVE_NAV_TRACE")!=NULL;
    float best=1e30f;
    for(unsigned i=0;i<node_count;i++)if(nodes[i].component==main_component&&exposed[i]){float d=distance(nodes[i].pos,*center);if(d<best){best=d;anchors[0]=i;}}
    if(best==1e30f)fail("main route component has no outdoor spawn");
    for(int k=1;k<GM_MAX_PLAYERS;k++){best=-1;
        for(unsigned i=0;i<node_count;i++)if(nodes[i].component==main_component&&exposed[i]){float nearest=1e30f;for(int j=0;j<k;j++)nearest=fminf(nearest,distance(nodes[i].pos,nodes[anchors[j]].pos));if(nearest>best){best=nearest;anchors[k]=i;}}}
    if(spread&&!route_trial&&!roof_layout)select_spawn_anchors();
    if(route_fixture)select_file_routes(route_fixture);
    else if(m3d_ReferenceOverlayActive()&&route_trial>=4&&route_trial<=7)select_onett_routes();else if(route_trial==5){for(int i=0;i<GM_MAX_PLAYERS;i++){trial_starts[i]=anchors[i];trial_goals[i]=-1;Vec3 a=nodes[anchors[i]].pos;
        fprintf(stderr,"M3D NAV TRIAL SETUP slot=%d mode=5 start=%.2f,%.2f,%.2f goal=0,0,0\n",i,a.x,a.y,a.z);}}
    else if(route_trial==6){for(int i=0;i<GM_MAX_PLAYERS;i++){
        trial_starts[i]=nearest((Vec3){i%2?-736:-704,10,i%2?16:0},-1);
        trial_goals[i]=nearest((Vec3){-816,25,112},-1);
    }}
    else if(route_trial==4)select_canal_routes();else if(route_trial==3)select_island_routes();else if(route_trial||roof_layout)select_roof_routes(*center);
    fprintf(stderr,"M3D NAV LOADED nodes=%u edges=%u main=%u reachable=%u spread=%d tour=%d\n",node_count,edge_count,main_component,maximum,spread,tour);
}
static int nearest(Vec3 pos,int component){int best=-1;float score=1e30f;int cx=(int)floorf(pos.x/64),cz=(int)floorf(pos.z/64);
    for(int r=0;r<=8;r++){
        for(int x=cx-r;x<=cx+r;x++)for(int z=cz-r;z<=cz+r;z++){if(r&&abs(x-cx)!=r&&abs(z-cz)!=r)continue;unsigned h=((unsigned)x*73856093u^(unsigned)z*19349663u)&8191u;
            for(int i=node_heads[h];i>=0;i=node_next[i]){NavNode* n=&nodes[i];if((int)floorf(n->pos.x/64)!=x||(int)floorf(n->pos.z/64)!=z||(component>=0&&n->component!=(unsigned)component))continue;
                float dx=n->pos.x-pos.x,dz=n->pos.z-pos.z,dy=n->pos.y-pos.y,d=dx*dx+dz*dz+dy*dy*2;if(d<score){score=d;best=i;}}}
        if(r&&score<(float)(r*r*4096))return best;
    }
    for(unsigned i=0;i<node_count;i++){if(component>=0&&nodes[i].component!=(unsigned)component)continue;Vec3 p=nodes[i].pos;float dx=p.x-pos.x,dz=p.z-pos.z,dy=p.y-pos.y,d=dx*dx+dz*dz+dy*dy*2;if(d<score){score=d;best=i;}}
    return best;}
/* A fighter above a street is not standing on a roof overhead. Attach the
 * route to the actual supporting layer, then reject wall-separated samples. */
static int support_node(Vec3 pos) {
    Vec3 probe=pos,ground;
    if(!m3d_DelfinoFloor(&probe,&ground))return -1;
    int best=-1;float score=1e30f;int cx=(int)floorf(pos.x/64),cz=(int)floorf(pos.z/64);
    for(int x=cx-1;x<=cx+1;x++)for(int z=cz-1;z<=cz+1;z++) {
        unsigned h=((unsigned)x*73856093u^(unsigned)z*19349663u)&8191u;
        for(int i=node_heads[h];i>=0;i=node_next[i]) {
            Vec3 p=nodes[i].pos;if((int)floorf(p.x/64)!=x||(int)floorf(p.z/64)!=z)continue;
            float d=horizontal(p,ground);if(d>=score||d>=64||!m3d_DelfinoNavConnectedFloor(&p,&ground))continue;
            /* Source floor continuity identifies the layer even halfway up a
             * steep24u grid cell. Connected floor facets are not occluders. */
            Vec3 high=p,other=ground;high.y+=6;other.y+=6;
            if(!m3d_DelfinoNavBodyClear(&p,&high,&other))continue;
            Vec3 foot=p;other=ground;foot.y+=1;other.y+=1;
            if(m3d_DelfinoNavBodyClear(&p,&foot,&other)){best=i;score=d;}
        }
    }
    return best;
}
static int fighter_node(Fighter* fp) {
    if(fp->player_idx>=GM_MAX_PLAYERS)return -1;
    __typeof__(supports[0][0])* c=&supports[fp->player_idx][fp->is_sub_fighter?1:0];
    Vec3 p=fp->cur_pos;
    if(c->fp!=fp||c->tick!=m3d_match_frame||c->pos.x!=p.x||c->pos.y!=p.y||c->pos.z!=p.z){c->fp=fp;c->pos=p;c->tick=m3d_match_frame;c->node=support_node(p);}
    return c->node;
}
/* Spawn placement must validate the positions after native per-fighter offsets.
 * This runs only in Fighter's native spawn/reset path, never during movement. */
static bool onett_spawn_point(Vec3* base,Vec3* point,float body_height) {
    if(m3d_ReferenceOverlayBlast(point))return false;
    Vec3 probe=*point,ground;probe.y=base->y+16;
    if(!m3d_DelfinoFloor(&probe,&ground)||!m3d_DelfinoNavConnectedFloor(base,&ground)||
       !m3d_ReferenceOverlayGroundAllowed(&ground))return false;
    for(int k=0;k<4;k++) {
        Vec3 edge=ground,next;edge.x+=k==0?5:k==1?-5:0;edge.z+=k==2?5:k==3?-5:0;edge.y+=8;
        if(m3d_ReferenceOverlayBlast(&edge)||!m3d_DelfinoFloor(&edge,&next)||
           !m3d_DelfinoNavConnectedFloor(&ground,&next)||!m3d_ReferenceOverlayGroundAllowed(&next))return false;
    }
    Vec3 head=*point;head.y+=body_height;
    return m3d_DelfinoNavBodyClear(&ground,point,&head);
}
static bool onett_spawn_pair(Vec3 base,float rise,float* offsets,int count,float body_height) {
    for(int i=0;i<count;i++) {
        Vec3 point=base;point.x+=offsets[i];point.y+=rise;
        if(!onett_spawn_point(&base,&point,body_height))return false;
    }
    return true;
}
void m3d_DelfinoNavSpawnPose(Fighter* fp,Vec3* pose) {
    if(!m3d_ReferenceOverlayActive()||!node_count||!fp||fp->player_idx>=GM_MAX_PLAYERS)return;
    float own_offset=fp->facing_dir*fp->x40*fp->x34_scale.x;
    float body_height=22*fmaxf(1,fabsf(fp->x34_scale.x));
    float offsets[2]={own_offset,0};int count=1;
    if((fp->kind==Ft_Kind_Popo||fp->kind==Ft_Kind_Nana)&&fp->dat_attrs) {
        const ftIceClimberAttributes* attributes=fp->dat_attrs;
        offsets[0]=fp->facing_dir*attributes->x0*fp->x34_scale.x;
        offsets[1]=fp->facing_dir*attributes->xC4*fp->x34_scale.x;count=2;
    }
    Vec3 base=*pose,ground;base.x-=own_offset;
    if(!m3d_DelfinoFloor(&base,&ground))fail("spawn reset has no actual supporting floor");
    float rise=pose->y-ground.y;base.y=ground.y;
    if(onett_spawn_pair(base,rise,offsets,count,body_height))return;
    int from=nearest(base,-1),chosen=-1;float best=1e30f;
    if(from<0)fail("spawn reset has no source navigation component");
    unsigned component=nodes[from].component;
    for(unsigned i=0;i<node_count;i++)if(nodes[i].component==component&&exposed[i]) {
        float score=distance(base,nodes[i].pos);
        if(score>=best||!onett_spawn_pair(nodes[i].pos,rise,offsets,count,body_height))continue;
        best=score;chosen=i;
    }
    if(chosen<0)fail("no supported interior spawn for actual fighter offsets");
    Vec3 original=*pose;*pose=nodes[chosen].pos;pose->x+=own_offset;pose->y+=rise;
    fprintf(stderr,"M3D ONETT SPAWN ADJUST slot=%u kind=%d sub=%d component=%u offsets=%.3f,%.3f from=%.3f,%.3f,%.3f to=%.3f,%.3f,%.3f spawn_only=1\n",
            fp->player_idx,fp->kind,fp->is_sub_fighter,component,offsets[0],count==2?offsets[1]:offsets[0],
            original.x,original.y,original.z,pose->x,pose->y,pose->z);
}

static bool drop_node(unsigned i);
static bool respawn_clear(int slot,int node,int previous) {
    if(!exposed[node]||nodes[node].component!=main_component)return false;
    Vec3 p=nodes[node].pos;
    if(previous>=0&&horizontal(p,nodes[previous].pos)<64)return false;
    for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];g;g=g->next) {
        Fighter* other=GET_FIGHTER(g);
        if(other->player_idx==slot||other->is_sleeping||other->motion_id<14)continue;
        if(distance(other->cur_pos,p)<45)return false;
    }
    return true;
}
static int random_respawn_node(int slot,int previous) {
    /* Rejection sampling stays cheap during simultaneous 32-seat rebirths.
     * Only safe nodes on the connected city, with room away from opponents. */
    for(int attempt=0;attempt<128;attempt++) {
        int node=(unsigned)(HSD_Randf()*node_count);
        if(respawn_clear(slot,node,previous))return node;
    }
    int start=HSD_Randi(GM_MAX_PLAYERS);
    for(int k=0;k<GM_MAX_PLAYERS;k++) {
        int node=spawn_anchors[(start+k)%GM_MAX_PLAYERS];
        if(respawn_clear(slot,node,previous))return node;
    }
    return spawn_anchors[start];
}
bool m3d_DelfinoNavSpawn(int slot,Vec3* pos){
    if(!node_count||!spread||slot<0||slot>=GM_MAX_PLAYERS)return false;
    int chosen=spawn_anchors[slot];
    if(route_trial||roof_layout){*pos=nodes[trial_starts[slot]].pos;pos->y+=3;return true;}
    /* Humans do not own a NavActor. Native death counts identify each rebirth
     * for every seat and cache its location across repeated spawn queries. */
    int generation=Player_GetFalls(slot);
    if(generation>0) {
        if(respawn_nodes[slot]<0||respawn_generation[slot]!=generation) {
            int previous=respawn_nodes[slot]>=0?respawn_nodes[slot]:chosen;
            respawn_nodes[slot]=random_respawn_node(slot,previous);
            respawn_generation[slot]=generation;
            if(getenv("MELEE3D_NATIVE_SPAWN_CHECK"))fprintf(stderr,"M3D RANDOM RESPAWN slot=%d generation=%d node=%d\n",slot,generation,respawn_nodes[slot]);
        }
        chosen=respawn_nodes[slot];
    }
    *pos=nodes[chosen].pos;pos->y+=10;return true;
}
/* Native GM rebirth resets Player coordinates to the old camera's top before
 * Fighter_Spawn. Replace that temporary pose explicitly; initial placement and
 * transform resets retain their existing offset-validation contract. */
void m3d_DelfinoNavRebirthPrepare(Fighter* fp) {
    if(!m3d_ReferenceOverlayActive()||!node_count||!fp||fp->player_idx>=GM_MAX_PLAYERS)return;
    Vec3 reset;Player_LoadPlayerCoords(fp->player_idx,&reset);
    fprintf(stderr,"M3D ONETT REBIRTH RESET slot=%u kind=%d sub=%d x=%.4f y=%.4f z=%.4f scale=%.3f offset=%.3f\n",fp->player_idx,fp->kind,fp->is_sub_fighter,reset.x,reset.y,reset.z,fp->x34_scale.x,fp->facing_dir*fp->x40*fp->x34_scale.x);
    m3d_ExitLocal(fp);
    Vec3 preferred;if(!m3d_DelfinoNavSpawn(fp->player_idx,&preferred))fail("Onett rebirth has no source spawn");
    float scale=fp->x34_scale.x,offsets[2]={fp->facing_dir*fp->x40*scale,0};int count=1;
    float body_height=22*fmaxf(1,fabsf(scale));
    if((fp->kind==Ft_Kind_Popo||fp->kind==Ft_Kind_Nana)&&fp->dat_attrs){
        const ftIceClimberAttributes* a=fp->dat_attrs;
        offsets[0]=fp->facing_dir*a->x0*scale;offsets[1]=fp->facing_dir*a->xC4*scale;count=2;
    }
    int chosen=-1;float best=1e30f;
    for(unsigned i=0;i<node_count;i++)if(nodes[i].component==main_component&&exposed[i]){
        float score=distance(preferred,nodes[i].pos);if(score>=best)continue;
        if(!onett_spawn_pair(nodes[i].pos,10,offsets,count,body_height))continue;
        bool clear=true;
        for(int k=0;k<count&&clear;k++){
            Vec3 low=nodes[i].pos,high=low;low.x+=offsets[k];high.x+=offsets[k];
            low.y+=10;high.y+=95+body_height;
            clear=m3d_DelfinoNavBodyClear(&nodes[i].pos,&low,&high)&&!m3d_ReferenceOverlayBlast(&high);
        }
        if(clear){chosen=i;best=score;}
    }
    if(chosen<0)fail("Onett rebirth has no clear supported platform descent");
    Vec3 pose=nodes[chosen].pos;pose.y+=10;
    Player_80032768(fp->player_idx,&pose);
    fprintf(stderr,"M3D ONETT REBIRTH PREPARE slot=%u kind=%d sub=%d x=%.4f y=%.4f z=%.4f component=%u offsets=%.3f,%.3f clear_height=%.1f\n",
        fp->player_idx,fp->kind,fp->is_sub_fighter,pose.x,pose.y,pose.z,nodes[chosen].component,offsets[0],count==2?offsets[1]:offsets[0],95+body_height);
}

/* The donor graph has a shared 5x19 clearance envelope. Larger native
 * ECB bounds need a per-actor filter, cached until their envelope grows. */
static void update_body(NavActor* a){
    Fighter* fp=a->fp;
    if(fp->ground_or_air!=GA_Ground||fp->motion_id<ftCo_MS_Wait||fp->motion_id>ftCo_MS_RunBrake)return;
    float left=fp->coll_data.desired_ecb.left.x,right=fp->coll_data.desired_ecb.right.x;
    float r=fmaxf(fabsf(left),fabsf(right));
    float h=fp->coll_data.desired_ecb.top.y;
    r=r>5.25f?ceilf(fminf(64,r)/2)*2:5;h=h>19.25f?ceilf(fminf(128,h)/2)*2:19;
    if(r<=a->body_radius&&h<=a->body_height)return;
    /* A route planned with the smaller perimeter footprint must be
     * rechecked when native ECB growth reveals a larger fighter. */
    if(m3d_ReferenceOverlayActive()&&r>a->body_radius){a->length=0;a->next_plan=0;}
    a->body_radius=fmaxf(a->body_radius,r);a->body_height=fmaxf(a->body_height,h);
    if(a->body_radius>5||a->body_height>19){
        if(!a->body_fit)a->body_fit=allocate(node_count);
        else memset(a->body_fit,0,node_count);
    }
    fprintf(stderr,"M3D NAV BODY slot=%u radius=%.1f height=%.1f\n",fp->player_idx,a->body_radius,a->body_height);
}
/* The semantic outer city boundary is independent of roof/doorway walls.
 * Cache only actual ECB-sized perimeter probes here, not a large isotropic
 * stopping margin that would erase the original narrow exit corridors. The
 * frozen node/REG result is shared by radius across all fighters. */
static bool boundary_node(NavActor* a,unsigned index) {
    if(!m3d_ReferenceOverlayActive())return true;
    unsigned radius=(unsigned)ceilf(fmaxf(5,fminf(64,a->body_radius)));
    if(!boundary_fit[radius])boundary_fit[radius]=allocate(node_count);
    unsigned char* fit=boundary_fit[radius];
    if(fit[index])return fit[index]==1;
    const float unit[8][2]={{1,0},{-1,0},{0,1},{0,-1},
        {.7071067812f,.7071067812f},{-.7071067812f,.7071067812f},
        {.7071067812f,-.7071067812f},{-.7071067812f,-.7071067812f}};
    bool clear=true;
    for(int k=0;k<8&&clear;k++) {
        Vec3 p=nodes[index].pos;p.x+=unit[k][0]*radius;p.z+=unit[k][1]*radius;
        clear=m3d_ReferenceOverlayBlast(&p)==0;
    }
    fit[index]=clear?1:2;return clear;
}
static bool body_node(NavActor* a,unsigned index){
    if(!boundary_node(a,index))return false;
    if(!a->body_fit)return true;
    if(a->body_fit[index])return a->body_fit[index]==1;
    if(nav_cost_enabled==1)++nav_cost_body_misses;
    Vec3 p=nodes[index].pos,foot=p,head=p;foot.y+=1;head.y+=a->body_height;
    bool clear=m3d_DelfinoNavBodyClear(&p,&foot,&head);
    float heights[]={1,a->body_height*.5f,a->body_height};
    for(int i=0;i<3&&clear;i++)for(int axis=0;axis<2&&clear;axis++){
        float radius=i==1?a->body_radius:5;Vec3 from=p,to=p;from.y+=heights[i];to.y+=heights[i];
        if(axis){from.z-=radius;to.z+=radius;}else{from.x-=radius;to.x+=radius;}
        clear=m3d_DelfinoNavBodyClear(&p,&from,&to);
    }
    /* A thin overhanging lip may fall between the horizontal body samples.
     * Test vertical clearance at the existing foot/head radius too. These
     * rays still ignore only actual support and below-floor body volume. */
    for(int k=0;k<4&&clear;k++){
        Vec3 from=p,to=p;float dx=k==0?5:k==1?-5:0,dz=k==2?5:k==3?-5:0;
        from.x+=dx;to.x+=dx;from.z+=dz;to.z+=dz;from.y+=1;to.y+=a->body_height;
        clear=m3d_DelfinoNavBodyClear(&p,&from,&to);
    }
    a->body_fit[index]=clear?1:2;return clear;
}
/* An area objective can be reached anywhere within its capture area. Choose
 * a body-clear endpoint on the approaching side, not a shared central point
 * under an awning or behind a narrow gap. Exact pickups retain zero radius. */

/* Returning false proves the requested endpoint unreachable with the SAME
 * directed jump/body/temporary-block predicates as A*. Returning true means
 * reachable OR unknown; the original A* then owns every path/cost/tie choice.
 * Bound accepted nodes, total body queries (hence cold misses), and edges, so
 * a large reverse region cannot replace one unbounded flood with another. */
static bool nav_reverse_possible(NavActor* actor,int from,int to) {
    if(from==to||!m3d_ReferenceOverlayActive()||!reverse_heads)return true;
    if(!++reverse_epoch){memset(reverse_marks,0,node_count*sizeof(*reverse_marks));reverse_epoch=1;}
    int queue[64];unsigned begin=0,end=1,body_queries=1,edge_queries=0;
    if(!body_node(actor,to))return false;
    queue[0]=to;reverse_marks[to]=reverse_epoch;
    while(begin<end){
        int target=queue[begin++];
        for(int j=reverse_heads[target];j!=-1;j=reverse_next[j]){
            if(edge_queries++==512)return true;
            int source=reverse_from[j];
            if(reverse_marks[source]==reverse_epoch||!jump_edge(actor->fp,source,edges[j]))continue;
            bool blocked=false;for(int k=0;k<16;k++)if(actor->blocked[k].until>actor->frames&&actor->blocked[k].from==source&&actor->blocked[k].to==target){blocked=true;break;}
            if(blocked)continue;
            /* Native A* never body-tests its initial node. */
            if(source==from)return true;
            if(body_queries==64)return true;++body_queries;
            bool clear=body_node(actor,source);reverse_marks[source]=reverse_epoch;
            if(!clear)continue;
            if(end==64)return true;
            queue[end++]=source;
        }
    }
    return false;
}

static int objective_node(NavActor* a,int from,Vec3 goal){
    float radius=m3d_PartyGoalRadius();if(radius<=0)return support_node(goal);
    if(a->frames<a->fallback_until&&distance(goal,a->failed_goal)<48&&
       m3d_PartyRouteCost(a->fp->cur_pos,nodes[a->fallback_node].pos)<1e19f)return a->fallback_node;
    int current=a->target_node;
    if(a->length&&current>=0&&horizontal(nodes[current].pos,goal)<=radius&&fabsf(nodes[current].pos.y-goal.y)<6&&body_node(a,current))return current;
    int cx=(int)floorf(goal.x/64),cz=(int)floorf(goal.z/64),chosen=-1;float best=1e30f;
    for(int x=cx-1;x<=cx+1;x++)for(int z=cz-1;z<=cz+1;z++){
        unsigned h=((unsigned)x*73856093u^(unsigned)z*19349663u)&8191u;
        for(int i=node_heads[h];i>=0;i=node_next[i]){Vec3 p=nodes[i].pos;
            if((int)floorf(p.x/64)!=x||(int)floorf(p.z/64)!=z||horizontal(p,goal)>radius||fabsf(p.y-goal.y)>6||
                !actor_reaches(a->fp,nodes[from].component,nodes[i].component)||!body_node(a,i))continue;
            float score=distance(p,a->fp->cur_pos)+horizontal(p,goal)*.05f;if(score<best){best=score;chosen=i;}
        }
    }
    return chosen>=0?chosen:support_node(goal);
}
Fighter* m3d_DelfinoNavTarget(Fighter* fp,Fighter* current){
    if(!node_count)return current;int from=fighter_node(fp);if(from<0)return current;
    Fighter* chosen=NULL;float best=1e30f;
    for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];g;g=g->next){Fighter* other=GET_FIGHTER(g);if(other==fp||other->is_sleeping||ftCo_IsAlly(fp,other)||other->motion_id<ftCo_MS_Wait)continue;
        float d=distance(fp->cur_pos,other->cur_pos);int to=fighter_node(other);if(to<0||!actor_reaches(fp,nodes[from].component,nodes[to].component)||(actors[fp->player_idx].fp==fp&&!body_node(&actors[fp->player_idx],to)))continue;
        int crowd=0;for(HSD_GObj* c=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];c;c=c->next){Fighter* bot=GET_FIGHTER(c);if(bot!=fp&&bot->cpu.x44==other)crowd++;}
        float score=d*(other==current?.85f:1.f)*(other->player_idx==m3d_PartyBountyLeader()?.6f:1.f)+crowd*18;
        if(d<100&&!m3d_DelfinoVisible(&fp->cur_pos,&other->cur_pos))score+=150;
        if(score<best){best=score;chosen=other;}}
    return chosen;
}
static void push(int node,float cost){if(heap_count>(int)edge_count)fail("search heap budget");int i=heap_count++;while(i){int p=(i-1)/2;if(heap[p].cost<=cost)break;heap[i]=heap[p];i=p;}heap[i]=(NavHeap){node,cost};}
static int pop(void){int result=heap[0].node;NavHeap last=heap[--heap_count];int i=0;
    while(i*2+1<heap_count){int c=i*2+1;if(c+1<heap_count&&heap[c+1].cost<heap[c].cost)c++;if(heap[c].cost>=last.cost)break;heap[i]=heap[c];i=c;}heap[i]=last;return result;}
static bool nav_cost_plan_work(NavActor* actor,int from,int to){
    actor->length=actor->cursor=0;actor->replans++;if(from<0||to<0||!actor_reaches(actor->fp,nodes[from].component,nodes[to].component)){actor->failures++;return false;}
    if(from!=to&&!nav_reverse_possible(actor,from,to)){actor->failures++;return false;}
    for(unsigned i=0;i<node_count;i++){costs[i]=1e30f;parents[i]=-1;closed[i]=0;}heap_count=0;costs[from]=0;push(from,distance(nodes[from].pos,nodes[to].pos));
    while(heap_count){int i=pop();if(closed[i])continue;closed[i]=1;if(i==to)break;NavNode* n=&nodes[i];
        for(unsigned j=n->first;j<n->first+n->count;j++){NavEdge e=edges[j];if(closed[e.target]||!jump_edge(actor->fp,i,e)||!body_node(actor,e.target))continue;bool blocked=false;
            for(int k=0;k<16;k++)if(actor->blocked[k].until>actor->frames&&actor->blocked[k].from==i&&actor->blocked[k].to==(int)e.target){blocked=true;break;}
            float storm_cost=m3d_PartyRouteCost(n->pos,nodes[e.target].pos);
            if(blocked||storm_cost>=1e19f)continue;float c=costs[i]+distance(n->pos,nodes[e.target].pos)+(e.kind?12:0)+storm_cost;
            if(c<costs[e.target]){costs[e.target]=c;parents[e.target]=i;push(e.target,c+distance(nodes[e.target].pos,nodes[to].pos));}}}
    if(!closed[to]){actor->failures++;
        if(trace_routes&&actor->failures==1)fprintf(stderr,"M3D NAV PLAN BLOCK slot=%u from=%d to=%d tofit=%d tier=%d v=%.3f gravity=%.3f multi=%.3f jumps=%d drift=%.3f\n",actor->fp->player_idx,from,to,body_node(actor,to),jump_profile(actor->fp),actor->fp->co_attrs.jump_v_initial_velocity,actor->fp->co_attrs.gravity,actor->fp->co_attrs.air_jump_v_multiplier,actor->fp->co_attrs.max_jumps,actor->fp->co_attrs.air_drift_max);
        return false;}int reverse[1024],count=0;
    for(int i=to;i!=from;i=parents[i]){if(i<0||count==1024){actor->failures++;return false;}reverse[count++]=i;}
    if(!count)reverse[count++]=to;
    for(int i=0;i<count;i++)actor->path[i]=reverse[count-i-1];actor->length=count;actor->target_node=to;actor->node=from;actor->stall=0;actor->progress=actor->fp->cur_pos;return true;
}
static bool plan(NavActor* actor,int from,int to) {
    if(!nav_cost_trace())return nav_cost_plan_work(actor,from,to);
    unsigned long long wall=nav_cost_ns(false),cpu=nav_cost_ns(true),misses=nav_cost_body_misses;
    bool result=nav_cost_plan_work(actor,from,to);
    cpu=nav_cost_ns(true)-cpu;wall=nav_cost_ns(false)-wall;
    nav_cost_log("plan",actor,from,to,result,wall,cpu,nav_cost_body_misses-misses);
    return result;
}

static int farthest(Fighter* fp,int from){int best=from;float far=-1;for(unsigned i=0;i<node_count;i++)if(actor_reaches(fp,nodes[from].component,nodes[i].component)&&exposed[i]&&boundary_node(&actors[fp->player_idx],i)){float d=distance(nodes[i].pos,nodes[from].pos);if(d>far){far=d;best=i;}}return best;}
static unsigned sector(Vec3 pos){int x=(int)floorf(pos.x/256)+16,z=(int)floorf(pos.z/256)+16;return (unsigned)(x&31)*32+(unsigned)(z&31);}
/* A narrow prop/roof can support an actor without a sampled route node.
 * Seek an exposed drop beside that support, rather than steering vertically
 * through the solid floor toward the old waypoint underneath it. */
static int offgraph_exit(NavActor* actor,int destination){
    Fighter* fp=actor->fp;
    int chosen=-1;float best=1e30f;Vec3 from=fp->cur_pos;from.y+=2;
    for(unsigned i=0;i<node_count;i++){
        Vec3 p=nodes[i].pos;float h=horizontal(p,fp->cur_pos),drop=fp->cur_pos.y-p.y;
        if(h<8||h>160||drop<8||drop>192||h+drop*.1f>=best)continue;
        if((destination>=0&&!actor_reaches(fp,nodes[i].component,nodes[destination].component))||!body_node(actor,i))continue;
        bool blocked=false;for(int k=0;k<16;k++)if(actor->blocked[k].from==-1&&actor->blocked[k].until>actor->frames&&
            horizontal(p,nodes[actor->blocked[k].to].pos)<48){blocked=true;break;}if(blocked)continue;
        /* Probe above shallow roof seams: +2 could miss a surface only a
         * few hundredths higher and mistake its underside for an open drop. */
        Vec3 edge={p.x,fp->cur_pos.y+8,p.z},ground;
        if(!m3d_DelfinoFloor(&edge,&ground)||ground.y>fp->cur_pos.y-8)continue;
        bool clear=true;float dx=(p.x-from.x)/h,dz=(p.z-from.z)/h,r=fmaxf(5,actor->body_radius);
        for(int side=-1;side<=1&&clear;side++)for(int height=0;height<3;height++){
            Vec3 a=from,b={p.x,from.y,p.z};float y=height*fmaxf(16,actor->body_height)*.5f;
            a.x-=dz*r*side;a.z+=dx*r*side;b.x-=dz*r*side;b.z+=dx*r*side;a.y+=y;b.y+=y;
            if(!m3d_DelfinoViewClear(&a,&b)){clear=false;break;}}
        if(clear){chosen=i;best=h+drop*.1f;}
    }return chosen;
}
/* A drop endpoint can lie just beyond a roof edge while the actor's ECB
 * still overlaps that roof. Do not brake above the landing's XZ and wait
 * forever for gravity: keep walking in the chosen clear exit direction until
 * native collision actually releases the support, then steer to the landing. */
static Vec3 escape_waypoint(NavActor* actor){
    Fighter* fp=actor->fp;Vec3 p=nodes[actor->escape_node].pos;
    if(fp->ground_or_air==GA_Ground&&fp->cur_pos.y>p.y+7){
        float lead=fmaxf(16,actor->body_radius+8);
        p.x=fp->cur_pos.x+actor->escape_direction.x*lead;p.z=fp->cur_pos.z+actor->escape_direction.z*lead;
    }return p;
}
static bool combat_approach_clear(Fighter* a,Fighter* b){
    if(!m3d_DelfinoVisible(&a->cur_pos,&b->cur_pos))return false;
    /* An unobstructed eye line is insufficient for a larger fighter under
     * a lintel. Use the actor's native collision bounds, not character IDs. */
    float top=fmaxf(16,fminf(64,a->coll_data.desired_ecb.top.y));
    float heights[]={1,fmaxf(8,fminf(top,a->coll_data.desired_ecb.right.y)),top};
    for(int i=0;i<3;i++){Vec3 from=a->cur_pos,to=b->cur_pos;from.y+=heights[i];to.y+=heights[i];
        if(!m3d_DelfinoViewClear(&from,&to))return false;}
    return true;
}
/* A jump edge may include ordinary floor after its actual gap/step. Once
 * native collision has landed there, finish that supported remainder on foot
 * instead of launching again every time the fighter touches the ground. */
static bool grounded_finish(NavActor* a) {
    Fighter* fp=a->fp;if(fp->ground_or_air!=GA_Ground)return false;
    Vec3 start=fp->cur_pos,ground,end=a->waypoint;
    if(!m3d_DelfinoFloor(&start,&ground)||fabsf(ground.y-start.y)>.5f||
       !m3d_DelfinoNavConnectedFloor(&ground,&end))return false;
    float dx=end.x-ground.x,dz=end.z-ground.z,length=hypotf(dx,dz);
    if(length<.001f)return false;
    float rx=-dz/length,rz=dx/length;
    /* The five-unit feet keep real floor coverage on both sides. The torso
     * retains the measured native ECB radius and height. */
    for(int side=-1;side<=1;side+=2) {
        Vec3 p=ground,q=end,from,to;p.x+=rx*5*side;p.z+=rz*5*side;p.y+=6;
        q.x+=rx*5*side;q.z+=rz*5*side;q.y+=6;
        if(!m3d_DelfinoFloor(&p,&from)||!m3d_DelfinoFloor(&q,&to)||
           !m3d_DelfinoNavConnectedFloor(&ground,&from)||
           !m3d_DelfinoNavConnectedFloor(&end,&to)||
           !m3d_DelfinoNavConnectedFloor(&from,&to))return false;
    }
    float height=fmaxf(19,a->body_height),heights[]={.1f,height*.5f,height};
    for(int side=-1;side<=1;side++)for(int endpoint=0;endpoint<2;endpoint++) {
        Vec3 foot=endpoint?end:ground,head=foot;
        foot.x+=rx*5*side;foot.z+=rz*5*side;head.x=foot.x;head.z=foot.z;
        foot.y+=.1f;head.y+=height;
        if(!m3d_DelfinoNavBodyClear(&ground,&foot,&head))return false;
    }
    for(int i=0;i<3;i++)for(int side=-1;side<=1;side++) {
        float radius=i==1?fmaxf(5,a->body_radius):5;
        Vec3 from=ground,to=end;from.y+=heights[i];to.y+=heights[i];
        from.x+=rx*radius*side;from.z+=rz*radius*side;
        to.x+=rx*radius*side;to.z+=rz*radius*side;
        if(!m3d_DelfinoNavBodyClear(&ground,&from,&to))return false;
    }
    return true;
}
/* A collinear shortcut can consume ordinary walking waypoints. A pending
 * jump/gap waypoint is instead consumed by the grounded arrival check above,
 * so the next walking edge cannot erase an unperformed curb/gap crossing. */
static bool nav_skip_waypoint(Fighter* fp,Vec3 here,Vec3 next,unsigned kind) {
    if(kind==1||kind==3)return false;
    float ax=here.x-fp->cur_pos.x,az=here.z-fp->cur_pos.z,bx=next.x-here.x,bz=next.z-here.z;
    float al=hypotf(ax,az),bl=hypotf(bx,bz);
    return al<=18&&al>=.001f&&bl>=.001f&&fabsf(here.y-next.y)<=.5f&&fabsf(fp->cur_pos.y-here.y)<=2&&
           (ax*bx+az*bz)/(al*bl)>=.98f;
}
static unsigned nav_edge_kind(unsigned from,unsigned to) {
    for(unsigned j=nodes[from].first;j<nodes[from].first+nodes[from].count;j++)if(edges[j].target==to)return edges[j].kind;
    return 0;
}
/* A completed route already waits twelve frames before replanning. Keep
 * its Onett pad neutral during that wait; returning to the base CPU here can
 * reapply a dash at a legal endpoint beside the scenic KO boundary. */
static bool boundary_hold(NavActor* a,Vec3* goal) {
    if(!m3d_ReferenceOverlayActive())return false;
    a->waypoint=a->fp->cur_pos;a->drive=true;a->jump=false;a->gap=false;a->jump_clock=0;
    *goal=a->waypoint;return true;
}
static bool nav_cost_route_work(Fighter* fp,Fighter* target,Vec3* goal){
    if(!node_count||fp->player_idx>=GM_MAX_PLAYERS||fp->cpu.kind==CpuKind_Nana)return false;
    NavActor* a=&actors[fp->player_idx];if(a->fp!=fp){free(a->body_fit);memset(a,0,sizeof(*a));a->fp=fp;a->last=a->progress=fp->cur_pos;a->target_node=-1;a->escape_node=-1;a->progress_node=-1;a->last_sector=sector(fp->cur_pos);a->visited[a->last_sector/32]|=1u<<(a->last_sector%32);}
    update_body(a);
    a->frames++;a->drive=false;float moved=horizontal(fp->cur_pos,a->last);if(moved<25)a->distance+=moved;a->last=fp->cur_pos;
    unsigned cell=sector(fp->cur_pos);if(moved>=25){a->last_sector=cell;a->length=0;a->escape_node=-1;}
    if(cell!=a->last_sector){a->sector_changes++;a->visited[cell/32]|=1u<<(cell%32);a->last_sector=cell;}
    if(a->frames%120==0){int visited=0;for(int j=0;j<32;j++)visited+=__builtin_popcount(a->visited[j]);fprintf(stderr,"M3D NAV FRAME slot=%u tick=%d travel=%u stuck=%u distance=%.2f sectors=%d changes=%u replans=%u failures=%u arrivals=%u path=%d/%d goal=%.2f,%.2f,%.2f\n",fp->player_idx,a->frames,a->travel,a->stuck,a->distance,visited,a->sector_changes,a->replans,a->failures,a->arrivals,a->cursor,a->length,a->waypoint.x,a->waypoint.y,a->waypoint.z);}
    if(fp->motion_id<ftCo_MS_Wait)return false;
    a->urgent=m3d_PartyFlee(fp);
    Vec3 recovery=fp->cur_pos;if(!a->length&&!a->urgent&&m3d_CpuRecoveryGoal(fp,&recovery))return false;
    bool objective=m3d_PartyGoal(fp,goal);
    if(!objective&&!tour&&target&&horizontal(fp->cur_pos,target->cur_pos)<65&&fabsf(fp->cur_pos.y-target->cur_pos.y)<32&&combat_approach_clear(fp,target)){a->length=0;a->was_driven=false;return false;}
    if(route_trial&&a->trial_done){a->waypoint=fp->cur_pos;a->drive=true;a->jump=false;return true;}
    int from=fighter_node(fp);
    if(a->escape_node>=0){
        float remaining=distance(fp->cur_pos,nodes[a->escape_node].pos);
        if(remaining<a->best_progress-1){a->best_progress=remaining;a->stall=0;}
        else if(a->was_driven||fp->motion_id==ftCo_MS_StopWall||fp->motion_id==ftCo_MS_StopCeil)a->stall++;
        a->was_driven=false;
        if(a->stall>=90){unsigned b=a->block_cursor++%16;
            a->blocked[b].from=-1;a->blocked[b].to=a->escape_node;a->blocked[b].until=a->frames+900;
            fprintf(stderr,"M3D NAV EXIT RETRY slot=%u node=%d tick=%d\n",fp->player_idx,a->escape_node,a->frames);
            a->escape_node=-1;a->length=0;a->stall=0;}
    }
    if(a->escape_node>=0&&(from<0||fp->ground_or_air!=GA_Ground||(!m3d_ReferenceOverlayActive()&&fabsf(fp->cur_pos.y-nodes[a->escape_node].pos.y)>7))){a->waypoint=escape_waypoint(a);a->length=0;a->drive=true;a->jump=fp->motion_id==ftCo_MS_Ottotto||fp->motion_id==ftCo_MS_OttottoWait;*goal=a->waypoint;return true;}
    if(from<0){
        if(a->escape_node<0&&fp->ground_or_air==GA_Ground){
            int destination=a->target_node>=0?a->target_node:target?fighter_node(target):-1;
            a->escape_node=offgraph_exit(a,destination);if(a->escape_node>=0){a->jump_clock=0;a->stall=0;
                Vec3 p=nodes[a->escape_node].pos;float d=horizontal(p,fp->cur_pos);
                a->escape_direction=(Vec3){(p.x-fp->cur_pos.x)/d,0,(p.z-fp->cur_pos.z)/d};
                a->best_progress=distance(p,fp->cur_pos);
                /* Landing off the route after attempting an edge is evidence
                 * that this actor needs a detour, including clearance/ledge
                 * interactions not represented by the sampled graph. */
                if(a->length&&a->cursor<a->length){unsigned b=a->block_cursor++%16;
                    a->blocked[b].from=a->cursor?a->path[a->cursor-1]:a->node;
                    a->blocked[b].to=a->path[a->cursor];a->blocked[b].until=a->frames+3600;
                    fprintf(stderr,"M3D NAV OFFGRAPH BLOCK slot=%u from=%d to=%d\n",fp->player_idx,a->blocked[b].from,a->blocked[b].to);}
            }
            if(a->escape_node>=0)fprintf(stderr,"M3D NAV OFFGRAPH slot=%u node=%d x=%.2f y=%.2f z=%.2f\n",fp->player_idx,a->escape_node,fp->cur_pos.x,fp->cur_pos.y,fp->cur_pos.z);
        }
        if(a->escape_node>=0){a->waypoint=escape_waypoint(a);a->length=0;a->drive=true;a->jump=fp->motion_id==ftCo_MS_Ottotto||fp->motion_id==ftCo_MS_OttottoWait;*goal=a->waypoint;return true;}
        if(a->length&&a->cursor<a->length){a->waypoint=nodes[a->path[a->cursor]].pos;a->drive=true;a->jump=true;*goal=a->waypoint;return true;}
        return false;
    }
    a->escape_node=-1;
    if(!m3d_ReferenceOverlayActive()&&route_trial==4&&!a->trial_crossed&&fp->ground_or_air==GA_Ground){
        int crossing=m3d_DelfinoCrossing(&fp->cur_pos);
        if(crossing>=0&&(crossing==trial_crossing||trial_crossing==3)){a->trial_crossed=true;
            fprintf(stderr,"M3D NAV TRIAL BRIDGE slot=%u tick=%d x=%.3f y=%.3f z=%.3f\n",fp->player_idx,a->frames,fp->cur_pos.x,fp->cur_pos.y,fp->cur_pos.z);}
    }
    if(route_trial==5&&!a->trial_selected){
        select_hill_anchors();if(!hill_roof_count)fail("no reachable rooftop hill");
        int roof=hill_roofs[fp->player_idx%hill_roof_count];Vec3 p=nodes[roof].pos;
        float angle=(fp->player_idx/hill_roof_count)*1.570796327f;p.x+=cosf(angle)*16;p.z+=sinf(angle)*16;
        int chosen=nearest(p,-1);if(fabsf(nodes[chosen].pos.y-nodes[roof].pos.y)>6)chosen=roof;
        trial_goals[fp->player_idx]=chosen;a->trial_selected=true;p=nodes[chosen].pos;
        fprintf(stderr,"M3D NAV TRIAL TARGET slot=%u tier=%d goal=%.2f,%.2f,%.2f\n",fp->player_idx,jump_profile(fp),p.x,p.y,p.z);
    }
    if(route_trial==1&&!a->trial_selected) {
        int chosen=-1;float best=1e30f;
        for(unsigned i=0;i<node_count;i++)if(exposed[i]&&nodes[i].pos.y>nodes[from].pos.y+28&&actor_reaches(fp,nodes[from].component,nodes[i].component)) {
            float score=distance(nodes[i].pos,fp->cur_pos)+fmaxf(0,nodes[i].pos.y-nodes[from].pos.y)*.5f;
            if(score<best){best=score;chosen=i;}
        }
        if(chosen<0)fail("fighter has no reachable ascent endpoint");trial_goals[fp->player_idx]=chosen;a->trial_selected=true;
        Vec3 p=nodes[chosen].pos;fprintf(stderr,"M3D NAV TRIAL TARGET slot=%u tier=%d goal=%.2f,%.2f,%.2f\n",fp->player_idx,jump_profile(fp),p.x,p.y,p.z);
    }
    int to=objective?objective_node(a,from,*goal):route_trial?trial_goals[fp->player_idx]:tour||!target?(a->length?a->target_node:farthest(fp,from)):
        goal->x==target->cur_pos.x&&goal->y==target->cur_pos.y&&goal->z==target->cur_pos.z?fighter_node(target):support_node(*goal);
    if(to>=0&&!actor_reaches(fp,nodes[from].component,nodes[to].component))to=route_trial?to:target?support_node(target->cur_pos):farthest(fp,from);
    if(to<0)return false;
    if(!a->length&&a->frames<a->next_plan){
        if(a->urgent){a->drive=a->jump=true;*goal=a->waypoint;return true;}
        return boundary_hold(a,goal);
    }
    bool stale=!a->length||a->cursor>=a->length||a->stall>=180||distance(nodes[to].pos,nodes[a->target_node<0?to:a->target_node].pos)>48;
    if(a->urgent&&a->cursor<a->length&&m3d_PartyRouteCost(fp->cur_pos,nodes[a->path[a->cursor]].pos)>=1e19f)stale=true;
    if(stale&&(a->length==0||a->urgent||a->frames%30==(int)fp->player_idx%30)){
        if(a->stall>=180&&a->cursor<a->length){unsigned b=a->block_cursor++%16;a->blocked[b].from=a->cursor?a->path[a->cursor-1]:a->node;a->blocked[b].to=a->path[a->cursor];a->blocked[b].until=a->frames+900;}
        if(!plan(a,from,to)){
            /* Component reachability is an upper bound. The failed search
             * has already visited the actor's exact jump/body-clear set;
             * choose a useful reachable landing instead of retrying an
             * impossible roof forever or pursuing combat into the storm. */
            int alternative=-1;float best=1e30f;
            Vec3 safe_center;float safe_radius;bool storm=objective&&m3d_PartyDropZone(&safe_center,&safe_radius);
            if(objective||route_trial==1)for(unsigned n=0;n<node_count;n++)if(closed[n]&&exposed[n]&&body_node(a,n)){
                if(route_trial==1&&nodes[n].pos.y<nodes[from].pos.y+28)continue;
                if(storm&&horizontal(nodes[n].pos,safe_center)>safe_radius)continue;
                float d=distance(nodes[n].pos,nodes[to].pos);if(d<best){best=d;alternative=n;}
            }
            /* A disconnected pocket may not reach safe ground in one route.
             * Still take any reachable inward progress, rather than attack
             * while the lethal wall closes on it. */
            if(alternative<0&&a->urgent)for(unsigned n=0;n<node_count;n++)if(closed[n]&&exposed[n]&&body_node(a,n)){
                float d=distance(nodes[n].pos,nodes[to].pos);
                if(d<best&&horizontal(nodes[n].pos,fp->cur_pos)>8){best=d;alternative=n;}
            }
            if(alternative<0||!plan(a,from,alternative)){
                a->next_plan=a->frames+30;
                if(a->urgent){a->waypoint=*goal;a->drive=a->jump=true;
                    Vec3 ledge;if(m3d_DelfinoLedge(&fp->cur_pos,&ledge,NULL,NULL)&&horizontal(ledge,fp->cur_pos)<70&&ledge.y>fp->cur_pos.y+4&&
                        (ledge.x-fp->cur_pos.x)*(goal->x-fp->cur_pos.x)+(ledge.z-fp->cur_pos.z)*(goal->z-fp->cur_pos.z)>0)a->waypoint=ledge;
                    *goal=a->waypoint;return true;}
                return false;
            }
            if(objective){a->failed_goal=*goal;a->fallback_node=alternative;a->fallback_until=a->frames+180;}
            if(route_trial==1){trial_goals[fp->player_idx]=alternative;Vec3 p=nodes[alternative].pos;
                fprintf(stderr,"M3D NAV TRIAL TARGET slot=%u tier=%d goal=%.2f,%.2f,%.2f\n",fp->player_idx,jump_profile(fp),p.x,p.y,p.z);}
        }}
    if(!a->length||a->cursor>=a->length)return false;
    while(a->cursor<a->length&&horizontal(fp->cur_pos,nodes[a->path[a->cursor]].pos)<2.5f&&fabsf(fp->cur_pos.y-nodes[a->path[a->cursor]].pos.y)<2&&fp->ground_or_air==GA_Ground){
        if(route_trial&&a->cursor==a->length-1){if(moved>.3f){a->settle=0;break;}if(++a->settle<20)break;}
        a->cursor++;a->settle=0;
    }
    if(a->cursor==a->length){a->arrivals++;a->length=0;
        if(route_trial){a->trial_done=true;fprintf(stderr,"M3D NAV TRIAL PASS slot=%u mode=%d tick=%d x=%.3f y=%.3f z=%.3f\n",fp->player_idx,route_trial,a->frames,fp->cur_pos.x,fp->cur_pos.y,fp->cur_pos.z);}
        a->next_plan=a->frames+12;return boundary_hold(a,goal);}
    while(a->cursor+1<a->length) {
        Vec3 here=nodes[a->path[a->cursor]].pos,next=nodes[a->path[a->cursor+1]].pos;
        unsigned previous=a->cursor?a->path[a->cursor-1]:a->node;
        if(!nav_skip_waypoint(fp,here,next,nav_edge_kind(previous,a->path[a->cursor])))break;
        a->cursor++;
    }
    int next=a->path[a->cursor];a->waypoint=nodes[next].pos;a->gap=a->jump=false;
    /* Supported kind0 ascents follow native floor slopes. Height alone must
     * not turn a continuous walking corridor into repeated jump requests. */
    unsigned edge_kind=0;
    int previous=a->cursor?a->path[a->cursor-1]:a->node;
    for(unsigned j=nodes[previous].first;j<nodes[previous].first+nodes[previous].count;j++)if(edges[j].target==(unsigned)next){
        edge_kind=edges[j].kind;a->jump=edge_kind==1||edge_kind>=3;a->gap=edge_kind>=3;break;
    }
    if(a->jump&&grounded_finish(a))a->jump=false;
    float remaining=distance(fp->cur_pos,a->waypoint);
    if(a->progress_node!=next||remaining<a->best_progress-1){a->stall=0;a->progress_node=next;a->best_progress=remaining;}
    else if(a->was_driven)a->stall++;
    a->was_driven=false;
    if(a->stall>=120||(a->stall>=12&&(fp->motion_id==ftCo_MS_Ottotto||fp->motion_id==ftCo_MS_OttottoWait)))a->jump=true;
    if(trace_routes&&a->frames%12==0){Vec3 start=nodes[previous].pos;
        fprintf(stderr,"M3D NAV TRACE slot=%u tick=%d path=%d/%d from=%.2f,%.2f,%.2f to=%.2f,%.2f,%.2f pos=%.2f,%.2f,%.2f motion=%d vy=%.2f jumps=%u/%d jump=%d stall=%d edge=%u\n",fp->player_idx,a->frames,a->cursor,a->length,start.x,start.y,start.z,a->waypoint.x,a->waypoint.y,a->waypoint.z,fp->cur_pos.x,fp->cur_pos.y,fp->cur_pos.z,fp->motion_id,fp->self_vel.y,fp->x1968_jumpsUsed,fp->co_attrs.max_jumps,a->jump,a->stall,edge_kind);}
    if(trace_routes&&a->frames%12==0){CollData* c=&fp->coll_data;
        fprintf(stderr,"M3D NAV COLL slot=%u tick=%d current=%.3f,%.3f,%.3f,%.3f desired=%.3f,%.3f,%.3f,%.3f flags=%x wall=%d,%d floor=%d\n",fp->player_idx,a->frames,c->ecb.left.x,c->ecb.right.x,c->ecb.bottom.y,c->ecb.top.y,c->desired_ecb.left.x,c->desired_ecb.right.x,c->desired_ecb.bottom.y,c->desired_ecb.top.y,c->env_flags,c->left_facing_wall.index,c->right_facing_wall.index,c->floor.index);}
    a->drive=true;*goal=a->waypoint;return true;
}
bool m3d_DelfinoNavRoute(Fighter* fp,Fighter* target,Vec3* goal) {
    if(!nav_cost_trace())return nav_cost_route_work(fp,target,goal);
    unsigned long long wall=nav_cost_ns(false),cpu=nav_cost_ns(true),misses=nav_cost_body_misses;
    bool result=nav_cost_route_work(fp,target,goal);
    cpu=nav_cost_ns(true)-cpu;wall=nav_cost_ns(false)-wall;
    if(node_count&&fp->player_idx<GM_MAX_PLAYERS&&actors[fp->player_idx].fp==fp){
        NavActor* a=&actors[fp->player_idx];
        /* Route fields can be stale after a failed plan; the separate plan
         * record above always carries its actual requested from/to nodes. */
        nav_cost_log("route",a,a->node,a->target_node,result,wall,cpu,nav_cost_body_misses-misses);
    }
    return result;
}

/* Native precision input alone brakes only within five units. A jump or
 * dash can carry substantially farther than that. Predict a conservative
 * stopping nose along the current native lane; two semantic boundary queries
 * bound this guard's per-frame cost. Normal pads/physics own the actual stop. */
static bool boundary_brake(NavActor* a) {
    if(!m3d_ReferenceOverlayActive())return false;
    Fighter* fp=a->fp;float lx,lz;if(!m3d_GetLane(fp,&lx,&lz))return false;
    bool air=fp->ground_or_air==GA_Air;
    float velocity=air?fp->self_vel.x:fp->gr_vel,native_speed=fabsf(velocity),speed=native_speed;
    /* Full deflection can start a native dash before the next velocity
     * sample. Include its real launch speed when deciding if walking is safer. */
    if(!air&&abs(fp->cpu.lstick.x)>=120)speed=fmaxf(speed,fp->co_attrs.dash_initial_velocity);
    float decel=air?fp->co_attrs.air_drift_stick_mul*(velocity>0?127.f/128:1)+fp->co_attrs.aerial_drift_base:
        fp->co_attrs.ground_friction;
    if(speed<.01f||decel<.001f)return false;
    float steps=ceilf(speed/decel);
    float runoff=speed+steps*speed-decel*steps*(steps-1)*.5f+fmaxf(5,a->body_radius);
    float sign=velocity<0?-1:1;
    if(native_speed<.01f)sign=fp->cpu.lstick.x<0?-1:1;
    Vec3 nose=fp->cur_pos,second=nose;
    nose.x+=lx*sign*runoff;nose.z+=lz*sign*runoff;
    bool unsafe=m3d_ReferenceOverlayBlast(&nose)!=0;
    bool anticipated=false;
    /* CpuAim preserves the signed native momentum when a waypoint changes.
     * A sharp turn can therefore point that momentum AWAY from the next
     * target. Brake before reaching the corner, not after the lane rotates. */
    if(!unsafe&&a->cursor+1<a->length&&horizontal(fp->cur_pos,a->waypoint)<=runoff) {
        Vec3 next=nodes[a->path[a->cursor+1]].pos;
        float dx=next.x-a->waypoint.x,dz=next.z-a->waypoint.z,len=hypotf(dx,dz);
        if(len>.001f) {
            float turn=dx*lx+dz*lz<0?-1:1;second=a->waypoint;
            second.x+=dx/len*turn*sign*runoff;second.z+=dz/len*turn*sign*runoff;
            anticipated=true;
        }
    }
    if(!unsafe) {
        if(!anticipated){second=fp->cur_pos;second.x+=(nose.x-second.x)*.5f;second.z+=(nose.z-second.z)*.5f;}
        unsafe=m3d_ReferenceOverlayBlast(&second)!=0;
    }
    if(!unsafe)return false;
    if(air)fp->cpu.lstick.x=velocity>0?-127:127;
    else {
        /* Once slow, approach through the existing precision walking range.
         * This prevents a stop/re-dash cycle without stopping short of the
         * unchanged2.5u arrival test. Native movement owns the actual speed. */
        float walking=fp->co_attrs.walk_max_vel*(48.f/127);
        if(native_speed>walking)fp->cpu.lstick.x=0;
        else if(fp->cpu.lstick.x>48)fp->cpu.lstick.x=48;
        else if(fp->cpu.lstick.x<-48)fp->cpu.lstick.x=-48;
    }
    if(trace_routes&&a->frames%12==0)fprintf(stderr,"M3D NAV BOUNDARY BRAKE slot=%u tick=%d air=%d speed=%.3f runoff=%.3f turn=%d pad=%d\n",fp->player_idx,a->frames,air,native_speed,runoff,anticipated,fp->cpu.lstick.x);
    return true;
}
/* Explicit diagnostic only: observe all movement channels at the two real
 * failure areas. No source queries or movement/state writes are added. */
static void boundary_debug(NavActor* a,int phase) {
    static int enabled=-1;if(enabled<0)enabled=getenv("MELEE3D_NATIVE_ONETT_BRAKE_TRACE")!=NULL;
    if(!enabled||!m3d_ReferenceOverlayActive())return;
    Fighter* f=a->fp;Vec3 p=f->cur_pos;
    bool field=f->player_idx==0&&p.z>320&&p.z<390;
    bool curb=f->player_idx==2&&p.x>-120&&p.x<-70&&p.z>-4&&p.z<48;
    if(!field&&!curb)return;
    float lx=0,lz=0;m3d_GetLane(f,&lx,&lz);
    CollData* c=&f->coll_data;
    fprintf(stderr,"M3D NAV BOUNDARY DETAIL slot=%u tick=%d phase=%d motion=%d anim=%.3f ga=%d pos=%.6f,%.6f,%.6f prev=%.6f,%.6f,%.6f delta=%.6f,%.6f,%.6f lane=%.6f,%.6f goal=%.6f,%.6f,%.6f pad=%d input=%.6f gr=%.6f self=%.6f,%.6f,%.6f accel=%.6f,%.6f,%.6f ground_accel=%.6f,%.6f kb=%.6f,%.6f,%.6f shield=%.6f nudge=%.6f,%.6f buffered=%.6f,%.6f,%.6f buffer_flags=%d,%d blend=%d,%d blend_vel=%.6f,%.6f,%.6f friction=%.6f,%.6f,%.6f floor=%d floor_flags=%x floor_normal=%.6f,%.6f,%.6f ecb=%.6f,%.6f,%.6f,%.6f env=%x\n",
        f->player_idx,a->frames,phase,f->motion_id,f->cur_anim_frame,f->ground_or_air,
        p.x,p.y,p.z,f->prev_pos.x,f->prev_pos.y,f->prev_pos.z,f->pos_delta.x,f->pos_delta.y,f->pos_delta.z,lx,lz,
        a->waypoint.x,a->waypoint.y,a->waypoint.z,f->cpu.lstick.x,f->input.lstick[0].x,f->gr_vel,
        f->self_vel.x,f->self_vel.y,f->self_vel.z,f->x74_self_accel.x,f->x74_self_accel.y,f->x74_self_accel.z,
        f->xE4_ground_accel_1,f->xE8_ground_accel_2,f->x8c_kb_vel.x,f->x8c_kb_vel.y,f->x8c_kb_vel.z,
        f->xF4_ground_attacker_shield_kb_vel,f->xF8_playerNudgeVel.x,f->xF8_playerNudgeVel.y,
        f->xD4_unk_vel.x,f->xD4_unk_vel.y,f->xD4_unk_vel.z,f->x2222_b6,f->x2222_b7,
        f->dmg.x1948,f->dmg.x194C,f->xA4_unk_vel.x,f->xA4_unk_vel.y,f->xA4_unk_vel.z,
        f->co_attrs.ground_friction,p_ftCommonData->run_dash_turn_friction_multiplier,ft_GetGroundFrictionMultiplier(f),
        c->floor.index,c->floor.flags,c->floor.normal.x,c->floor.normal.y,c->floor.normal.z,
        c->ecb.left.x,c->ecb.right.x,c->ecb.bottom.y,c->ecb.top.y,c->env_flags);
}
void m3d_DelfinoNavDrive(Fighter* fp){
    if(!node_count||fp->player_idx>=GM_MAX_PLAYERS)return;NavActor* a=&actors[fp->player_idx];if(a->fp!=fp)return;
    /* Travel-only diagnostic: prevent a one-frame combat handoff at route
     * endpoints from turning a navigation test into an unscored fight. */
    if(tour){fp->cpu.buttons&=~(HSD_PAD_A|HSD_PAD_B|HSD_PAD_Z);fp->cpu.cstick.x=fp->cpu.cstick.y=0;}
    if(route_trial&&a->trial_done){fp->cpu.lstick.x=fp->cpu.lstick.y=0;fp->cpu.buttons=0;return;}
    if(fp->motion_id==ftCo_MS_CliffWait){
        a->cliff_frames++;fp->cpu.buttons=0;fp->cpu.cstick.x=fp->cpu.cstick.y=0;fp->cpu.lstick.y=0;
        fp->cpu.lstick.x=a->cliff_frames<6?0:(a->waypoint.y<fp->cur_pos.y-12?-127:127)*fp->facing_dir;
        return;
    }
    a->cliff_frames=0;
    if(!a->drive)return;
    if(a->jump_clock>0)a->jump_clock--;
    if(a->special_clock>0)a->special_clock--;
    if(a->jump&&a->jump_clock==0&&(fp->ground_or_air==GA_Ground||
        ((a->gap||a->waypoint.y>fp->cur_pos.y+1||(a->stall>=120&&(fp->coll_data.env_flags&Collide_WallMask)))&&fp->self_vel.y<.5f&&fp->x1968_jumpsUsed<fp->co_attrs.max_jumps)))a->jump_clock=24;
    bool jump=a->jump_clock>18;
    if(m3d_CpuTravelPad(fp,&a->waypoint,jump,true)){
        /* Spend native air jumps before requesting recovery. Trigger up-B
         * only from steerable locomotion; native specials, hitstun, throws
         * and ledge catches retain their own callbacks and movement. */
        if(fp->ground_or_air==GA_Air&&a->jump&&!jump&&fp->self_vel.y<.5f&&
           fp->x1968_jumpsUsed>=fp->co_attrs.max_jumps&&a->waypoint.y>fp->cur_pos.y+6&&
           !a->special_clock&&!fp->item_gobj) {
            fp->cpu.buttons=HSD_PAD_B;fp->cpu.lstick.y=127;a->special_clock=90;
            if(trace_routes)fprintf(stderr,"M3D NAV RECOVER slot=%u tick=%d y=%.2f target_y=%.2f jumps=%u\n",fp->player_idx,a->frames,fp->cur_pos.y,a->waypoint.y,fp->x1968_jumpsUsed);
        }
        if(jump&&a->jump_clock==24&&trace_routes)fprintf(stderr,"M3D NAV JUMP slot=%u tick=%d used=%u maximum=%d\n",fp->player_idx,a->frames,fp->x1968_jumpsUsed,fp->co_attrs.max_jumps);
        boundary_debug(a,0);boundary_brake(a);boundary_debug(a,1);
        /* A held direction keeps native WalkFast walking forever. A single
         * neutral pad frame followed by full deflection requests a real dash,
         * with native acceleration and corner/edge braking left intact. */
        bool walking=fp->motion_id>=ftCo_MS_WalkSlow&&fp->motion_id<=ftCo_MS_WalkFast;
        if(walking&&!jump&&abs(fp->cpu.lstick.x)>=120&&horizontal(fp->cur_pos,a->waypoint)>8) {
            if(++a->walk_clock>=12){fp->cpu.lstick.x=0;a->walk_clock=0;if(trace_routes)fprintf(stderr,"M3D NAV RUN FLICK slot=%u tick=%d\n",fp->player_idx,a->frames);}
        }else a->walk_clock=0;
        a->was_driven=true;a->travel++;if(a->stall>=120)a->stuck++;
    }
}
bool m3d_DelfinoNavSteering(Fighter* fp){return node_count&&fp->player_idx<GM_MAX_PLAYERS&&actors[fp->player_idx].fp==fp&&actors[fp->player_idx].drive&&!actors[fp->player_idx].trial_done;}

/* Stable, collision-derived and mutually reachable objective positions.
 * Far-spaced spawn anchors give the entire connected district useful goals;
 * a second set is inset toward nearby exposed routes, never through walls. */
/* Item drops: a uniformly chosen outdoor route node (the graph samples walkable
 * ground on a fixed grid, so this is uniform over the playable area) that the
 * weakest jumper can reach from the main district. Near a point, the search
 * uses the spatial hash instead. */
static bool drop_node(unsigned i){return exposed[i]&&tier_reaches(0,main_component,nodes[i].component);}
static bool drop_clear(Vec3 p){
    for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_ITEM];g;g=g->next){Item* ip=g->user_data;
        if(ip&&horizontal(ip->pos,p)<28&&fabsf(ip->pos.y-p.y)<40)return false;}
    return true;
}
bool m3d_DelfinoNavDrop(Vec3* pos,const Vec3* near,float radius){
    if(!node_count)return false;
    Vec3 zone;float zone_radius;bool zoned=m3d_PartyDropZone(&zone,&zone_radius);
    if(near){
        int cx=(int)floorf(near->x/64),cz=(int)floorf(near->z/64),reach=(int)ceilf(radius/64),found=0,chosen=-1;
        for(int x=cx-reach;x<=cx+reach;x++)for(int z=cz-reach;z<=cz+reach;z++){unsigned h=((unsigned)x*73856093u^(unsigned)z*19349663u)&8191u;
            for(int i=node_heads[h];i>=0;i=node_next[i]){Vec3 p=nodes[i].pos;
                if((int)floorf(p.x/64)!=x||(int)floorf(p.z/64)!=z||!drop_node(i)||horizontal(p,*near)>radius||fabsf(p.y-near->y)>24)continue;
                if(zoned&&horizontal(p,zone)>zone_radius)continue;
                if(!drop_clear(p))continue;
                if(HSD_Randi(++found)==0)chosen=i;}}
        if(chosen<0)return false;
        *pos=nodes[chosen].pos;pos->y+=30+20*HSD_Randf();return true;
    }
    for(int attempt=0;attempt<96;attempt++){unsigned i=HSD_Randi(node_count);if(!drop_node(i))continue;Vec3 p=nodes[i].pos;
        if(zoned&&horizontal(p,zone)>zone_radius)continue;
        if(!drop_clear(p))continue;
        *pos=p;pos->y+=45+30*HSD_Randf();return true;}
    return false;
}
/* Playtest personas: the reachable outdoor node furthest from every point in
 * `avoid` (optionally inside a circle). A fixed stride over the graph keeps
 * it deterministic and off the game's random stream. */
bool m3d_DelfinoNavFar(const Vec3* avoid,int count,const void* zone_center,float zone_radius,Vec3* out){
    if(!node_count)return false;const M3dPartyPointLike* zc=zone_center;int chosen=-1;float best=-1;unsigned stride=node_count/700+1;
    for(unsigned i=0;i<node_count;i+=stride){if(!drop_node(i))continue;Vec3 p=nodes[i].pos;
        if(zc&&hypotf(p.x-zc->x,p.z-zc->z)>zone_radius)continue;
        float near=1e30f;for(int k=0;k<count;k++){float d=horizontal(p,avoid[k]);if(d<near)near=d;}
        if(near>best){best=near;chosen=i;}}
    if(chosen<0)return false;*out=nodes[chosen].pos;return true;
}
bool m3d_DelfinoNavObjective(int index,Vec3* pos){
    if(!node_count)return false;
    int chosen=anchors[index%16];
    /* Slots 16+ (hills): halfway between this spawn anchor and its nearest
     * neighbour, the point furthest from both, so no one spawns on a hill. */
    if(index>=16){float best=1e30f;Vec3 wanted=nodes[chosen].pos;int other=-1;float gap=1e30f;
        for(int k=0;k<GM_MAX_PLAYERS;k++){if(anchors[k]==chosen)continue;float d=distance(nodes[anchors[k]].pos,wanted);if(d<gap){gap=d;other=anchors[k];}}
        if(other>=0){wanted.x=(wanted.x+nodes[other].pos.x)/2;wanted.y=(wanted.y+nodes[other].pos.y)/2;wanted.z=(wanted.z+nodes[other].pos.z)/2;}
        for(unsigned i=0;i<node_count;i++)if(exposed[i]&&nodes[i].component==main_component){float d=distance(nodes[i].pos,wanted);if(d<best){best=d;chosen=i;}}}
    *pos=nodes[chosen].pos;return true;
}

/* Hills get their own elevated pool; spawn/storm anchors remain on streets.
 * Read the roster's original mobility only after fighters have been created.
 * Cap the shared tier conservatively and require a way back down, plus enough
 * supported roof around the centre for a fight rather than a narrow chimney. */
static bool hill_roof_node(unsigned i,int tier){
    if(!exposed[i]||nodes[i].pos.y<nodes[anchors[0]].pos.y+28||
        !tier_reaches(tier,main_component,nodes[i].component)||!tier_reaches(tier,nodes[i].component,main_component))return false;
    for(int k=0;k<8;k++){float angle=k*.785398163f;Vec3 p=nodes[i].pos,g;
        p.x+=cosf(angle)*28;p.z+=sinf(angle)*28;p.y+=6;
        if(!m3d_DelfinoFloor(&p,&g)||fabsf(g.y-nodes[i].pos.y)>5||m3d_DelfinoBlast(&g)==2)return false;}
    return true;
}
static void select_hill_anchors(void){
    if(hills_ready||!node_count)return;hills_ready=true;hill_tier=2;
    for(HSD_GObj* g=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];g;g=g->next){Fighter* f=GET_FIGHTER(g);
        if(!f->is_sub_fighter){int tier=jump_profile(f);if(tier<hill_tier)hill_tier=tier;}}
    unsigned char* eligible=allocate(node_count);unsigned candidates=0;
    for(unsigned i=0;i<node_count;i++){eligible[i]=hill_roof_node(i,hill_tier);candidates+=eligible[i];}
    for(int k=0;k<HILL_ROOFS;k++){
        int chosen=-1;float best=-1;
        for(unsigned i=0;i<node_count;i++)if(eligible[i]){
            float separation=1e30f;for(int j=0;j<k;j++)separation=fminf(separation,horizontal(nodes[i].pos,nodes[hill_roofs[j]].pos));
            if(k&&separation<96)continue;
            float score=k?separation:nodes[i].pos.y;
            if(score>best){best=score;chosen=i;}}
        if(chosen<0)break;hill_roofs[hill_roof_count++]=chosen;
        Vec3 p=nodes[chosen].pos;fprintf(stderr,"M3D HILL ROOF index=%d node=%d tier=%d pos=%.2f,%.2f,%.2f\n",k,chosen,hill_tier,p.x,p.y,p.z);
    }
    free(eligible);fprintf(stderr,"M3D HILL POOL roofs=%d candidates=%u tier=%d\n",hill_roof_count,candidates,hill_tier);
}
/* Multi-hill rounds mix street and roof goals. A single hill alternates on
 * relocation and opens upstairs, so even the short/final round has verticality. */
bool m3d_DelfinoNavHill(int phase,int index,Vec3* pos){
    if(!node_count)return false;select_hill_anchors();
    if(hill_roof_count&&(phase+index)%2==0){*pos=nodes[hill_roofs[(phase*3+index/2)%hill_roof_count]].pos;return true;}
    m3d_DelfinoNavObjective(16+((phase*7+index*4)%16),pos);return false;
}
