#include "pc/m3d_room.h"
/* SPDX-License-Identifier: GPL-3.0-or-later
 * DELFINO: opt-in local-disc geometry preview. Static J3D conversion is not a
 * material/audio parity claim. Native fighter simulation owns combat. */
#include "m3d.h"
#include "m3d_goop_rules.h"
#include "m3d_surface.h"
#include "m3d_holes.h"
#include <pc/m3d_lab.h>
#include <pc/m3d_menu.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <melee/gr/ground.h>
#include <melee/gr/grlib.h>
#include <melee/lb/lbarchive.h>
#include <melee/lb/lbaudio_ax.h>
#include <melee/ft/ftlib.h>
#include <melee/ft/ft_0877.h>
#include <sysdolphin/baselib/particle.h>
#include <melee/gr/types.h>
#include <melee/lb/lbarchive.h>
#include <melee/cm/camera.h>
#include <pc/m3d_photo.h>
#include <melee/mp/mplib.h>
#include <melee/mp/types.h>
#include <melee/mp/mpcoll.h>
#include <melee/mp/mpisland.h>
#include <melee/ft/types.h>
#include <melee/pl/player.h>
#include <sysdolphin/baselib/jobj.h>
#include <sysdolphin/baselib/cobj.h>
#include <sysdolphin/baselib/gobj.h>
#include <sysdolphin/baselib/gobjgxlink.h>
#include <sysdolphin/baselib/gobjobject.h>
#include <sysdolphin/baselib/state.h>
#include <sysdolphin/baselib/tev.h>
#include <sysdolphin/baselib/pobj.h>
#include <sysdolphin/baselib/random.h>
#include <sysdolphin/baselib/shadow.h>
#include <sysdolphin/baselib/tobj.h>
#include <dolphin/gx.h>

#define DL_LINES 16380
static float kill_depth=85.0f; /* Chosen once with the mounted Sunshine bank. */
#define DL_SLICE_CACHE 512
typedef struct {Vec3 p[3],n;unsigned surface,flags;} DlTriangle;
typedef struct {Vec3 p;GXColor color;float u,v;} DlVertex;
typedef struct {unsigned material,first,count;} DlDraw;
typedef struct {Vec3 a,b,inward;} DlLedge;
typedef struct {unsigned width,height,format,s,t,flags,size;unsigned cull,depth_test,depth_func,depth_write,blend_mode,blend_src,blend_dst,blend_logic,alpha_comp0,alpha_ref0,alpha_op,alpha_comp1,alpha_ref1,z_comp_loc;unsigned char* pixels;GXTexObj object;} DlTexture;
static DlTriangle* tris;
static unsigned triangle_count,draw_count,vertex_count,texture_count;
static DlDraw* draws;static DlVertex* vertices;static DlTexture* textures;
static unsigned* visible_faces;
static unsigned* faded_faces,*faded_offsets,*faded_counts;
static unsigned faded_total;
static unsigned char* faded_mask;
typedef struct {Vec3 lo,hi;unsigned first,count;bool faded;} DlFadeGroup;
static DlFadeGroup* fade_groups;static unsigned fade_group_count;
static unsigned *face_groups,*group_faces,*face_material;
static int faded_tick=-1,last_overlay_tick=-1;
typedef struct {unsigned* faces;unsigned count,capacity,bytes;void* commands;} DlRenderStream;
static DlRenderStream* render_streams;
static unsigned render_stream_bins;
static bool render_stream_off,render_stream_check;
static unsigned long long render_requests,render_hits,render_verified;
static void* render_reference;static unsigned render_reference_capacity;
static Vec3* gpu_positions;static GXColor* gpu_colors;static float (*gpu_uvs)[2];
static DlLedge* ledges;static unsigned ledge_count;
static bool active,slicing;
/* Scene-heap archive: reload and relocate once for each stage lifetime. */
static HSD_Archive* water_archive;
static int water_splash_tick[GM_MAX_PLAYERS][2];
typedef struct {Vec3 point,normal;float rise,run;} DlStep;
static DlStep steps[256];static unsigned step_count;
static void smooth_steps(void);
static int last_render_tick=-1;
static unsigned* shadow_faces;static unsigned shadow_count;
static int last_shadow_validation_tick=-1;
static MapCollData collision_data;
static MapJoint map_joint;
static MapLine *map_lines,*original_lines;
static DiscVec2* map_points;
static Vec2 *saved,*previous;
static unsigned* saved_flags;
static int* triangle_for_line;
static Vec3 map_min,map_max;
static Vec3 spawn_center;
static float goop_street;
float m3d_DelfinoStreetHeight(void){return goop_street;}
static M3dHole sealed_holes[64];static int sealed_count;
static unsigned sealed_first,sealed_visual[64];
/* Conservative world bounds prune queries without changing triangle geometry. */
typedef struct {Vec3 lo,hi;int first,count,left,right;} DlNode;
static DlNode* nodes;static unsigned* order;static int node_count,sort_axis;
static Vec3 *tri_lo,*tri_hi,*render_centers;static float* render_radii;
static float (*render_support)[2];
#define DL_FLOOR_PARTS 6
static int (*lines_for_triangle)[DL_FLOOR_PARTS];
static float water_height_max;
static int live_lines[2048],live_count;
/* Exact geometry/topology reuse. No lane quantisation, triangle pruning or
 * physics throttling: every key includes the complete slice transform. */
typedef struct {int id;MapLine line;Vec2 a,b;} DlSliceSegment;
typedef struct {
    float key[5];int valid,count,capacity;
    DlSliceSegment* segments;unsigned short* next_line;
} DlSliceCache;
static DlSliceCache slice_cache[DL_SLICE_CACHE],*current_slice;
static struct {float key[6];bool valid,blocked;} ray_cache[16384];
static unsigned long long ray_requests,ray_hits,ray_checks;
static unsigned long long slice_requests,slice_hits,slice_checks;
static int slice_log_tick=-1;
static bool slice_check,slice_cache_off;
static mpIsland slice_islands[2048];
static struct mpIsland_80458E88_t saved_islands;
static float component(Vec3 p,int axis){return axis==0?p.x:axis==1?p.y:p.z;}
static int order_compare(const void* a,const void* b) {
    unsigned i=*(const unsigned*)a,j=*(const unsigned*)b;
    float x=component(tri_lo[i],sort_axis)+component(tri_hi[i],sort_axis),y=component(tri_lo[j],sort_axis)+component(tri_hi[j],sort_axis);
    return x<y?-1:x>y?1:i<j?-1:i>j;
}
static int build_node(int first,int count) {
    int id=node_count++;DlNode* n=&nodes[id];n->lo=(Vec3){1e20f,1e20f,1e20f};n->hi=(Vec3){-1e20f,-1e20f,-1e20f};
    for(int j=first;j<first+count;j++){unsigned i=order[j];
        n->lo.x=fminf(n->lo.x,tri_lo[i].x);n->lo.y=fminf(n->lo.y,tri_lo[i].y);n->lo.z=fminf(n->lo.z,tri_lo[i].z);
        n->hi.x=fmaxf(n->hi.x,tri_hi[i].x);n->hi.y=fmaxf(n->hi.y,tri_hi[i].y);n->hi.z=fmaxf(n->hi.z,tri_hi[i].z);}
    n->first=first;n->count=count;n->left=n->right=-1;
    if(count>8){Vec3 d={n->hi.x-n->lo.x,n->hi.y-n->lo.y,n->hi.z-n->lo.z};sort_axis=d.x>d.y?(d.x>d.z?0:2):(d.y>d.z?1:2);
        qsort(order+first,count,sizeof(*order),order_compare);int half=count/2;
        n->left=build_node(first,half);n->right=build_node(first+half,count-half);n->count=0;}
    return id;
}

static void fail(const char* reason) {fprintf(stderr,"M3D DELFINO FAIL %s\n",reason);abort();}
static void* alloc(size_t size) {void* p=calloc(1,size);if(!p)fail("allocation");return p;}
static void read_bytes(FILE* f,void* p,size_t size) {if(fread(p,1,size,f)!=size)fail("truncated bank");}
static unsigned word(FILE* f) {unsigned n;read_bytes(f,&n,4);return n;}
static FILE* open_bank(const char* directory,const char* name,const char* magic,int version) {
    char path[4096],tag[4];if(snprintf(path,sizeof path,"%s/%s",directory,name)>=(int)sizeof path)fail("cache path");
    FILE* f=fopen(path,"rb");if(!f)fail("missing local cache bank");read_bytes(f,tag,4);
    if(memcmp(tag,magic,4) || word(f)!=(unsigned)version)fail("bank version");return f;
}
static void finish(FILE* f) {if(fgetc(f)!=EOF)fail("trailing bank data");fclose(f);}
static void seal_small_holes(void) {
    M3dHoleEdge* edges=alloc(triangle_count*3*sizeof(*edges));int count=0;
    for(unsigned i=0;i<triangle_count;i++){DlTriangle* t=&tris[i];if(t->flags&3||t->n.y<M3D_WALKABLE)continue;
        for(int k=0;k<3;k++){Vec3 a=t->p[k],b=t->p[(k+1)%3];edges[count++]=m3d_hole_edge((M3dHolePoint){a.x,a.y,a.z},(M3dHolePoint){b.x,b.y,b.z});}}
    sealed_count=m3d_holes_find(edges,count,sealed_holes,64,spawn_center.y-kill_depth);free(edges);
    sealed_first=triangle_count;unsigned extra=0;
    for(int h=0;h<sealed_count;h++)extra+=sealed_holes[h].count;
    DlTriangle* enlarged=alloc((triangle_count+extra)*sizeof(*tris));memcpy(enlarged,tris,triangle_count*sizeof(*tris));free(tris);tris=enlarged;
    for(int h=0;h<sealed_count;h++){M3dHole* hole=&sealed_holes[h];
        for(int k=0;k<hole->count;k++){M3dHolePoint a=hole->center,b=hole->p[(k+1)%hole->count],c=hole->p[k];
            tris[triangle_count++]=(DlTriangle){.p={{a.x,a.y,a.z},{b.x,b.y,b.z},{c.x,c.y,c.z}},.n={0,1,0}};}
        fprintf(stderr,"M3D MAP SEAL hole=%d center=%.3f,%.3f,%.3f edges=%d\n",h,hole->center.x,hole->center.y,hole->center.z,hole->count);
    }
    unsigned kept=0;
    for(unsigned l=0;l<ledge_count;l++){int sealed=0;DlLedge e=ledges[l];
        for(int h=0;h<sealed_count&&!sealed;h++)for(int k=0;k<sealed_holes[h].count;k++) {
            M3dHolePoint a=sealed_holes[h].p[k],b=sealed_holes[h].p[(k+1)%sealed_holes[h].count];
            M3dHolePoint x={e.a.x,e.a.y,e.a.z},y={e.b.x,e.b.y,e.b.z};
            if((!m3d_hole_point_compare(a,x)&&!m3d_hole_point_compare(b,y))||(!m3d_hole_point_compare(a,y)&&!m3d_hole_point_compare(b,x)))sealed=1;
        }
        if(!sealed)ledges[kept++]=e;
    }ledge_count=kept;
    fprintf(stderr,"M3D MAP SEALS holes=%d triangles=%u coast_preserved=1\n",sealed_count,extra);
}
static void seal_materials(unsigned faces) {
    for(int h=0;h<sealed_count;h++){M3dHolePoint p=sealed_holes[h].center;float best=1e30f;unsigned chosen=~0u;
        for(unsigned face=0;face<faces;face++) {
            if(textures[face_material[face]].flags&7)continue;
            DlVertex* v=vertices+3*face;Vec3 a=v[0].p,b=v[1].p,c=v[2].p;
            float ny=(b.z-a.z)*(c.x-a.x)-(b.x-a.x)*(c.z-a.z);
            if(ny<.001f)continue;
            float d=0;for(int k=0;k<3;k++)d+=hypotf(v[k].p.x-p.x,v[k].p.z-p.z)+8*fabsf(v[k].p.y-p.y);
            if(d<best){best=d;chosen=face;}
        }
        if(chosen==~0u)fail("sealed opening has no floor material");sealed_visual[h]=chosen;
        fprintf(stderr,"M3D MAP SEAL MATERIAL hole=%d face=%u cost=%.2f\n",h,chosen,best);
    }
}
static void clear(void) {
    water_archive=NULL;memset(water_splash_tick,0xff,sizeof water_splash_tick);
    m3d_PartyReset();
    for(unsigned i=0;i<2*draw_count*render_stream_bins;i++){free(render_streams[i].faces);free(render_streams[i].commands);}
    free(faded_faces);free(faded_offsets);free(faded_counts);free(faded_mask);faded_mask=NULL;
    free(fade_groups);free(face_groups);free(group_faces);free(face_material);
    fade_groups=NULL;face_groups=group_faces=face_material=NULL;fade_group_count=0;
    faded_faces=faded_offsets=faded_counts=NULL;faded_total=0;faded_tick=last_overlay_tick=-1;
    free(render_streams);free(render_reference);render_streams=NULL;render_reference=NULL;
    render_stream_bins=render_reference_capacity=0;render_requests=render_hits=render_verified=0;
    for(unsigned i=0;i<DL_SLICE_CACHE;i++){free(slice_cache[i].segments);free(slice_cache[i].next_line);}
    memset(slice_cache,0,sizeof slice_cache);current_slice=NULL;
    memset(ray_cache,0,sizeof ray_cache);ray_requests=ray_hits=ray_checks=0;
    slice_requests=slice_hits=slice_checks=0;slice_log_tick=-1;
    m3d_DelfinoNavSelect(NULL,NULL);
    if(textures)for(unsigned i=0;i<texture_count;i++)free(textures[i].pixels);
    free(textures);free(tris);free(draws);free(vertices);free(visible_faces);free(map_lines);free(original_lines);free(ledges);ledges=NULL;ledge_count=0;
    free(gpu_positions);free(gpu_colors);free(gpu_uvs);gpu_positions=NULL;gpu_colors=NULL;gpu_uvs=NULL;
    free(map_points);free(saved);free(previous);free(saved_flags);free(triangle_for_line);
    free(shadow_faces);shadow_faces=NULL;shadow_count=0;
    free(nodes);free(order);free(tri_lo);free(tri_hi);free(lines_for_triangle);free(render_centers);free(render_radii);free(render_support);render_support=NULL;
    nodes=NULL;order=NULL;tri_lo=tri_hi=render_centers=NULL;render_radii=NULL;lines_for_triangle=NULL;node_count=live_count=0;
    textures=NULL;tris=NULL;draws=NULL;vertices=NULL;visible_faces=NULL;map_lines=original_lines=NULL;map_points=NULL;
    saved=previous=NULL;saved_flags=NULL;triangle_for_line=NULL;texture_count=triangle_count=draw_count=vertex_count=0;
    active=slicing=false;step_count=0;sealed_count=0;kill_depth=85.0f;
    last_render_tick=last_shadow_validation_tick=-1;
}
bool m3d_DelfinoActive(void) {return active;}
bool m3d_DelfinoExactLines(void) {return slicing;}
void m3d_DelfinoSelect(bool enabled) {
    clear();slice_check=getenv("MELEE3D_NATIVE_SLICE_CHECK")!=NULL;
    const char* cache_mode=getenv("MELEE3D_NATIVE_SLICE_CACHE");slice_cache_off=cache_mode&&!strcmp(cache_mode,"off");
    const char* stream_mode=getenv("MELEE3D_NATIVE_RENDER_STREAM");render_stream_off=stream_mode&&!strcmp(stream_mode,"immediate");
    render_stream_check=getenv("MELEE3D_NATIVE_RENDER_CHECK")!=NULL;
    const char* directory=m3d_MenuSunshineBank();if(!enabled || !directory || !*directory)return;
    kill_depth=m3d_MenuSunshineKillDepth();
    if(getenv("MELEE3D_NATIVE_STAGE_CHECK"))fprintf(stderr,"M3D SUNSHINE PROFILE recovery_depth=%.0f\n",kill_depth);
    FILE* settings=open_bank(directory,"delfino.dls","DLS1",2);float donor_scale;
    read_bytes(settings,&donor_scale,4);read_bytes(settings,&spawn_center,sizeof spawn_center);
    ledge_count=word(settings);if(ledge_count>10000)fail("ledge budget");ledges=alloc(ledge_count*sizeof(*ledges));read_bytes(settings,ledges,ledge_count*sizeof(*ledges));finish(settings);
    if(!isfinite(donor_scale)||donor_scale<=0||donor_scale>1)fail("donor scale");
    FILE* f=open_bank(directory,"delfino.dlc","DLC1",1);triangle_count=word(f);
    if(!triangle_count || triangle_count>30000)fail("collision budget");tris=alloc(triangle_count*sizeof(*tris));
    read_bytes(f,tris,triangle_count*sizeof(*tris));finish(f);
    map_min=(Vec3){1e20f,1e20f,1e20f};map_max=(Vec3){-1e20f,-1e20f,-1e20f};
    for(unsigned i=0;i<triangle_count;i++) {
        DlTriangle* t=&tris[i];float norm=t->n.x*t->n.x+t->n.y*t->n.y+t->n.z*t->n.z;
        if(!isfinite(norm) || fabsf(norm-1)>.001f || t->flags>15)fail("collision metadata");
        for(int j=0;j<3;j++) {
            Vec3 p=t->p[j];if(!isfinite(p.x)||!isfinite(p.y)||!isfinite(p.z)||fabsf(p.x)>100000||fabsf(p.y)>100000||fabsf(p.z)>100000)fail("collision vertex");
            map_min.x=fminf(map_min.x,p.x);map_min.y=fminf(map_min.y,p.y);map_min.z=fminf(map_min.z,p.z);
            map_max.x=fmaxf(map_max.x,p.x);map_max.y=fmaxf(map_max.y,p.y);map_max.z=fmaxf(map_max.z,p.z);
        }
    }
    seal_small_holes();
    nodes=alloc(triangle_count*2*sizeof(*nodes));order=alloc(triangle_count*sizeof(*order));
    shadow_faces=alloc(triangle_count*sizeof(*shadow_faces));
    tri_lo=alloc(triangle_count*sizeof(*tri_lo));tri_hi=alloc(triangle_count*sizeof(*tri_hi));
    for(unsigned i=0;i<triangle_count;i++){order[i]=i;tri_lo[i]=tri_hi[i]=tris[i].p[0];
        for(int j=1;j<3;j++){Vec3 p=tris[i].p[j];tri_lo[i].x=fminf(tri_lo[i].x,p.x);tri_lo[i].y=fminf(tri_lo[i].y,p.y);tri_lo[i].z=fminf(tri_lo[i].z,p.z);
            tri_hi[i].x=fmaxf(tri_hi[i].x,p.x);tri_hi[i].y=fmaxf(tri_hi[i].y,p.y);tri_hi[i].z=fmaxf(tri_hi[i].z,p.z);}}
    build_node(0,triangle_count);
    active=true;smooth_steps();active=false;memset(ray_cache,0,sizeof ray_cache);
    f=open_bank(directory,"delfino.dlv","DLV1",2);texture_count=word(f);draw_count=word(f);unsigned faces=word(f);
    if(!texture_count||texture_count>512||!draw_count||draw_count>4096||!faces||faces>500000)fail("visual budget");
    textures=alloc(texture_count*sizeof(*textures));draws=alloc(draw_count*sizeof(*draws));vertex_count=faces*3;vertices=alloc(vertex_count*sizeof(*vertices));
    visible_faces=alloc(faces*sizeof(*visible_faces));
    render_stream_bins=(faces+19999)/20000;
    render_streams=alloc(2*draw_count*render_stream_bins*sizeof(*render_streams));
    faded_faces=alloc(faces*sizeof(*faded_faces));faded_mask=alloc(faces);
    faded_offsets=alloc(draw_count*sizeof(*faded_offsets));faded_counts=alloc(draw_count*sizeof(*faded_counts));
    for(unsigned i=0;i<texture_count;i++) {
        DlTexture* t=&textures[i];read_bytes(f,t,7*4);read_bytes(f,&t->cull,14*4);
        if(t->cull>3||t->depth_test>1||t->depth_func>7||t->depth_write>1||t->blend_mode>3||t->blend_src>7||t->blend_dst>7||t->blend_logic>15||t->alpha_comp0>7||t->alpha_ref0>255||t->alpha_op>3||t->alpha_comp1>7||t->alpha_ref1>255||t->z_comp_loc>1)fail("material raster state");
        if(!t->width||t->width>1024||!t->height||t->height>1024||t->s>2||t->t>2||t->flags>15||t->size>4*1024*1024)fail("texture metadata");
        unsigned tw=t->format==0||t->format==1||t->format==2||t->format==14?8:4;
        unsigned th=t->format==0||t->format==14?8:4;
        unsigned bits=t->format==0||t->format==14?4:t->format<=2?8:t->format<=5?16:t->format==6?32:0;
        unsigned expected=((t->width+tw-1)/tw)*((t->height+th-1)/th)*tw*th*bits/8;
        if(!bits || t->size!=expected)fail("texture extent");
        t->pixels=alloc(t->size);read_bytes(f,t->pixels,t->size);
        GXInitTexObj(&t->object,t->pixels,t->width,t->height,t->format,t->s,t->t,GX_FALSE);
        GXInitTexObjLOD(&t->object,GX_LINEAR,GX_LINEAR,0,0,0,GX_FALSE,GX_FALSE,GX_ANISO_1);
    }
    read_bytes(f,draws,draw_count*sizeof(*draws));read_bytes(f,vertices,vertex_count*sizeof(*vertices));finish(f);
    f=open_bank(directory,"delfino.dlg","DLG1",1);
    if(word(f)!=faces)fail("cutaway face count");fade_group_count=word(f);
    if(!fade_group_count||fade_group_count>faces)fail("cutaway group count");
    face_groups=alloc(faces*sizeof(*face_groups));read_bytes(f,face_groups,faces*sizeof(*face_groups));finish(f);
    fade_groups=alloc(fade_group_count*sizeof(*fade_groups));group_faces=alloc(faces*sizeof(*group_faces));face_material=alloc(faces*sizeof(*face_material));
    for(unsigned i=0;i<faces;i++)face_material[i]=~0u;
    for(unsigned i=0;i<draw_count;i++)for(unsigned j=draws[i].first;j<draws[i].first+draws[i].count;j++){
        if(face_material[j]!=~0u)fail("overlapping visual draws");face_material[j]=draws[i].material;
    }
    seal_materials(faces);
    for(unsigned g=0;g<fade_group_count;g++){fade_groups[g].lo=(Vec3){1e20f,1e20f,1e20f};fade_groups[g].hi=(Vec3){-1e20f,-1e20f,-1e20f};}
    for(unsigned i=0;i<faces;i++) {
        if(face_material[i]==~0u||face_groups[i]>=fade_group_count)fail("cutaway group coverage");
        DlFadeGroup* g=&fade_groups[face_groups[i]];g->count++;
        for(int k=0;k<3;k++){Vec3 p=vertices[i*3+k].p;
            g->lo.x=fminf(g->lo.x,p.x);g->lo.y=fminf(g->lo.y,p.y);g->lo.z=fminf(g->lo.z,p.z);
            g->hi.x=fmaxf(g->hi.x,p.x);g->hi.y=fmaxf(g->hi.y,p.y);g->hi.z=fmaxf(g->hi.z,p.z);}
    }
    unsigned offset=0;unsigned* cursors=alloc(fade_group_count*sizeof(*cursors));
    for(unsigned g=0;g<fade_group_count;g++){if(!fade_groups[g].count)fail("empty cutaway group");cursors[g]=fade_groups[g].first=offset;offset+=fade_groups[g].count;}
    for(unsigned i=0;i<faces;i++)group_faces[cursors[face_groups[i]]++]=i;free(cursors);
    fprintf(stderr,"M3D CUTAWAY GROUPS loaded=%u faces=%u\n",fade_group_count,faces);
    gpu_positions=alloc(vertex_count*sizeof(*gpu_positions));gpu_colors=alloc(vertex_count*sizeof(*gpu_colors));gpu_uvs=alloc(vertex_count*sizeof(*gpu_uvs));
    for(unsigned i=0;i<draw_count;i++)if(draws[i].material>=texture_count||draws[i].first>faces||draws[i].count>faces-draws[i].first)fail("draw extent");
    for(unsigned i=0;i<vertex_count;i++) {DlVertex* v=&vertices[i];if(!isfinite(v->p.x)||!isfinite(v->p.y)||!isfinite(v->p.z)||!isfinite(v->u)||!isfinite(v->v))fail("visual vertex");gpu_positions[i]=v->p;gpu_colors[i]=v->color;gpu_uvs[i][0]=v->u;gpu_uvs[i][1]=v->v;}
    render_support=alloc(faces*sizeof(*render_support));
    for(unsigned i=0;i<faces;i++){Vec3 a=vertices[i*3].p,b=vertices[i*3+1].p,c=vertices[i*3+2].p;
        Vec3 u={b.x-a.x,b.y-a.y,b.z-a.z},v={c.x-a.x,c.y-a.y,c.z-a.z};
        Vec3 n={u.y*v.z-u.z*v.y,u.z*v.x-u.x*v.z,u.x*v.y-u.y*v.x};float length=sqrtf(n.x*n.x+n.y*n.y+n.z*n.z);
        render_support[i][0]=length>1e-8f?n.y/length:0;render_support[i][1]=fminf(a.y,fminf(b.y,c.y));}
    render_centers=alloc(faces*sizeof(*render_centers));render_radii=alloc(faces*sizeof(*render_radii));
    for(unsigned i=0;i<faces;i++){Vec3 c={0};for(int j=0;j<3;j++){Vec3 p=vertices[i*3+j].p;c.x+=p.x/3;c.y+=p.y/3;c.z+=p.z/3;}render_centers[i]=c;
        for(int j=0;j<3;j++){Vec3 p=vertices[i*3+j].p;float dx=p.x-c.x,dy=p.y-c.y,dz=p.z-c.z;render_radii[i]=fmaxf(render_radii[i],sqrtf(dx*dx+dy*dy+dz*dz));}}
    {unsigned dropped=0;for(unsigned i=0;i<triangle_count;i++){DlTriangle* t=&tris[i];
        float top=fmaxf(t->p[0].y,fmaxf(t->p[1].y,t->p[2].y));
        if(top<spawn_center.y-kill_depth&&!(t->flags&2)){t->flags|=2;dropped++;}}
     fprintf(stderr,"M3D DELFINO UNDERGROUND dropped=%u depth=%.1f\n",dropped,spawn_center.y-kill_depth);}
    {unsigned heights[512]={0},total=0;float lo=map_min.y,span=fmaxf(1,map_max.y-lo);
     for(unsigned i=0;i<triangle_count;i++)if(!(tris[i].flags&3)&&tris[i].n.y>.65f){
        float y=(tris[i].p[0].y+tris[i].p[1].y+tris[i].p[2].y)/3;
        int k=(int)((y-lo)/span*511);if(k<0)k=0;if(k>511)k=511;heights[k]++;total++;}
     unsigned count=0;goop_street=spawn_center.y;
     for(int k=0;k<512;k++){count+=heights[k];if(count>=total/4){goop_street=lo+span*k/511;break;}}
     fprintf(stderr,"M3D GOOP STREET height=%.2f streets_first=1\n",goop_street);}
    active=true;m3d_DelfinoNavSelect(directory,&spawn_center);fprintf(stderr,"M3D DELFINO LOADED triangles=%u render=%u textures=%u static_preview=1\n",triangle_count,faces,texture_count);
}

#define DL_WALKABLE M3D_WALKABLE
static int kind(DlTriangle* t) {return m3d_surface_kind(t->n.y);}
static float height_node(int id,Vec3* p,int mode,float ceiling,float best);
static bool wet_floor(Vec3* p,float* surface) {
    float water=height_node(0,p,1,1e20f,-1e20f);
    if(water<-1e19f||p->y>=water-.01f)return false;
    /* A real ceiling protects submerged tunnels; an upward-facing seabed
     * must not masquerade as a roof once a falling fighter passes it. */
    float cover=height_node(0,p,4,water+.1f,-1e20f);
    if(cover>p->y+2)return false;
    if(surface)*surface=water;return true;
}
/* Split a floor segment at donor water/ceiling footprint boundaries. This
 * retains dry shore ends and covered tunnels even when both ends of a large
 * donor triangle lie outside the water but its middle crosses the ocean. */
static int floor_parts(unsigned i) {
    return kind(&tris[i])==0&&tri_lo[i].y<water_height_max?DL_FLOOR_PARTS:1;
}
static int float_compare(const void* a,const void* b) {
    float x=*(const float*)a,y=*(const float*)b;return (x>y)-(x<y);
}
static bool triangle_span(DlTriangle* t,Vec3 a,Vec3 b,float* lo,float* hi) {
    if(fabsf(t->n.y)<.00001f)return false;
    Vec3 u=t->p[0],v=t->p[1],w=t->p[2];
    float area=(v.x-u.x)*(w.z-u.z)-(v.z-u.z)*(w.x-u.x),sign=area>=0?1:-1;
    *lo=0;*hi=1;
    for(int k=0;k<3;k++) {
        u=t->p[k];v=t->p[(k+1)%3];float ex=v.x-u.x,ez=v.z-u.z;
        float f=sign*(ex*(a.z-u.z)-ez*(a.x-u.x)),d=sign*(ex*(b.z-a.z)-ez*(b.x-a.x));
        if(fabsf(d)<1e-8f){if(f<-.00001f)return false;continue;}
        float cross=-f/d;if(d>0)*lo=fmaxf(*lo,cross);else *hi=fminf(*hi,cross);
        if(*lo>*hi)return false;
    }return true;
}
static float plane_y(DlTriangle* t,Vec3 p) {
    return t->p[0].y-(t->n.x*(p.x-t->p[0].x)+t->n.z*(p.z-t->p[0].z))/t->n.y;
}
static void water_cuts(int id,Vec3 a,Vec3 b,float cuts[256],int* count) {
    DlNode* n=&nodes[id];
    if(fmaxf(a.x,b.x)<n->lo.x||fminf(a.x,b.x)>n->hi.x||fmaxf(a.z,b.z)<n->lo.z||fminf(a.z,b.z)>n->hi.z||n->lo.y>water_height_max+.1f)return;
    if(!n->count){water_cuts(n->left,a,b,cuts,count);water_cuts(n->right,a,b,cuts,count);return;}
    for(int k=n->first;k<n->first+n->count;k++) {
        unsigned i=order[k];DlTriangle* t=&tris[i];bool water=(t->flags&1)&&!(t->flags&8);
        if(!water&&((t->flags&3)||kind(t)!=1||tri_lo[i].y>water_height_max+.1f))continue;
        float lo,hi;if(!triangle_span(t,a,b,&lo,&hi))continue;
        if(*count>249)fail("water boundary budget");cuts[(*count)++]=lo;cuts[(*count)++]=hi;
        float f=a.y-plane_y(t,a)+(water?0:2),g=b.y-plane_y(t,b)+(water?0:2);
        if(fabsf(g-f)>1e-8f){float cross=-f/(g-f);if(cross>lo&&cross<hi)cuts[(*count)++]=cross;}
    }
}
static int split_water_floor(Vec3 a,Vec3 b,Vec3 segments[DL_FLOOR_PARTS][2]) {
    float cuts[256]={0,1};int count=2,parts=0;bool previous_dry=false;
    water_cuts(0,a,b,cuts,&count);qsort(cuts,count,sizeof(*cuts),float_compare);
    for(int k=1;k<count;k++) {
        float lo=cuts[k-1],hi=cuts[k];if(hi-lo<1e-7f)continue;
        float mid=(lo+hi)*.5f;Vec3 p={a.x+(b.x-a.x)*mid,a.y+(b.y-a.y)*mid,a.z+(b.z-a.z)*mid};
        if(wet_floor(&p,NULL)){previous_dry=false;continue;}
        Vec3 begin={a.x+(b.x-a.x)*lo,a.y+(b.y-a.y)*lo,a.z+(b.z-a.z)*lo};
        Vec3 end={a.x+(b.x-a.x)*hi,a.y+(b.y-a.y)*hi,a.z+(b.z-a.z)*hi};
        if(previous_dry)segments[parts-1][1]=end;
        else {if(parts==DL_FLOOR_PARTS)fail("water floor segment budget");segments[parts][0]=begin;segments[parts++][1]=end;}
        previous_dry=true;
    }return parts;
}
MapCollData* m3d_DelfinoCollision(MapCollData* original) {
    if(!active)return original;
    water_height_max=-1e20f;
    for(unsigned i=0;i<triangle_count;i++)if((tris[i].flags&1)&&!(tris[i].flags&8))water_height_max=fmaxf(water_height_max,tri_hi[i].y);
    int counts[4]={0},total=0;
    for(unsigned i=0;i<triangle_count;i++)if(!(tris[i].flags&3)) {int k=kind(&tris[i]);counts[k]+=k==0?floor_parts(i):1;if(k==2)counts[3]++;}
    for(int k=0;k<4;k++)total+=counts[k];
    if(total>DL_LINES || total*2>32760)fail("native stable line capacity");
    map_lines=alloc(total*sizeof(*map_lines));original_lines=alloc(total*sizeof(*map_lines));map_points=alloc(total*2*sizeof(*map_points));
    saved=alloc(total*2*sizeof(*saved));previous=alloc(total*2*sizeof(*previous));saved_flags=alloc(total*sizeof(*saved_flags));triangle_for_line=alloc(total*sizeof(int));
    lines_for_triangle=alloc(triangle_count*sizeof(*lines_for_triangle));for(unsigned i=0;i<triangle_count;i++)for(int k=0;k<DL_FLOOR_PARTS;k++)lines_for_triangle[i][k]=-1;
    memset(&collision_data,0,sizeof collision_data);memset(&map_joint,0,sizeof map_joint);
    int start=0;
    for(int k=0;k<4;k++) {
        collision_data.ranges[k].start=map_joint.ranges[k].start=start;
        collision_data.ranges[k].count=map_joint.ranges[k].count=counts[k];
        for(unsigned i=0;i<triangle_count;i++) {
            DlTriangle* t=&tris[i];if(t->flags&3 || (kind(t)!=k && !(k==3&&kind(t)==2)))continue;
            for(int part=0;part<(k==0?floor_parts(i):1);part++) {
                MapLine* line=&map_lines[start];int v=start*2;
                line->v0_idx=v;line->v1_idx=v+1;line->prev_id0=line->prev_id1=line->next_id0=line->next_id1=-1;
                line->hi_flags=1<<k;line->lo_flags=k==0 && !(t->flags&4)?LINE_FLAG_LEDGE:0;
                float x=(t->p[0].x+t->p[1].x+t->p[2].x)/3,y=(t->p[0].y+t->p[1].y+t->p[2].y)/3;
                map_points[v].x=x-1;map_points[v].y=y;map_points[v+1].x=x+1;map_points[v+1].y=y;
                lines_for_triangle[i][k==0?part:k==3?1:0]=start;triangle_for_line[start++]=i;
            }
        }
    }
    memcpy(original_lines,map_lines,total*sizeof(*map_lines));
    map_joint.left_bound=map_joint.bottom_bound=-200000;map_joint.right_bound=map_joint.top_bound=200000;map_joint.vtx_count=total*2;
    DP_SET(collision_data.verts,map_points);collision_data.vert_count=total*2;
    DP_SET(collision_data.lines,map_lines);collision_data.line_count=total;
    DP_SET(collision_data.joints,&map_joint);collision_data.joint_count=1;
    fprintf(stderr,"M3D DELFINO COLLISION lines=%d floors=%d ceilings=%d walls=%d\n",total,counts[0],counts[1],counts[2]);return &collision_data;
}

static void slice_triangle(unsigned index,Vec3* pos,float lx,float lz,float x0,CollVtx* v,CollLine* c) {
    DlTriangle* t=&tris[index];if(t->flags&3)return;
    Vec3 points[6];int n=0;
    for(int j=0;j<3;j++) {
        Vec3 a=t->p[j],b=t->p[(j+1)%3];float da=-(a.x-pos->x)*lz+(a.z-pos->z)*lx,db=-(b.x-pos->x)*lz+(b.z-pos->z)*lx;
        if(fabsf(da)<.0001f)da=0;if(fabsf(db)<.0001f)db=0;
        if(da==0)points[n++]=a;
        if((da<0&&db>0)||(da>0&&db<0)){float f=da/(da-db);points[n++]=(Vec3){a.x+f*(b.x-a.x),a.y+f*(b.y-a.y),a.z+f*(b.z-a.z)};}
    }
    if(n<2)return;int ia=0,ib=1;float span=0;
    for(int j=0;j<n;j++)for(int k=j+1;k<n;k++){float dx=points[j].x-points[k].x,dy=points[j].y-points[k].y,dz=points[j].z-points[k].z,dist=dx*dx+dy*dy+dz*dz;if(dist>span){span=dist;ia=j;ib=k;}}
    Vec3 segments[DL_FLOOR_PARTS][2];int parts=1;
    segments[0][0]=points[ia];segments[0][1]=points[ib];
    if(floor_parts(index)>1)parts=split_water_floor(points[ia],points[ib],segments);
    for(int side=0;side<DL_FLOOR_PARTS;side++) {
        if(kind(t)==0&&side>=parts)continue;
        Vec3 pa=kind(t)==0?segments[side][0]:points[ia],pb=kind(t)==0?segments[side][1]:points[ib];
        Vec2 a={x0+(pa.x-pos->x)*lx+(pa.z-pos->z)*lz,pa.y},b={x0+(pb.x-pos->x)*lx+(pb.z-pos->z)*lz,pb.y};
        float dx=a.x-b.x,dy=a.y-b.y;if(dx*dx+dy*dy<.000001f)continue;
        if(fmaxf(a.x,b.x)<x0-1200||fminf(a.x,b.x)>x0+1200)continue;
        int i=lines_for_triangle[index][side];if(i<0)continue;MapLine* line=&map_lines[i];Vec2 u=a,w=b;
        float dot=t->n.x*lx+t->n.z*lz;
        if((line->hi_flags==4&&dot<=0)||(line->hi_flags==8&&dot>=0))continue;
        /* Native right-facing walls run top to bottom, left-facing walls
         * bottom to top. Reversing them defeats height lookup after contact. */
        bool swap=(line->hi_flags==1&&u.x>w.x)||(line->hi_flags==2&&u.x<w.x)||(line->hi_flags==4&&u.y<w.y)||(line->hi_flags==8&&u.y>w.y);
        if(swap){Vec2 q=u;u=w;w=q;}
        for(int k=0;k<2;k++){int id=k?line->v1_idx:line->v0_idx;saved[id]=v[id].pos;previous[id]=v[id].prev_pos;v[id].pos=v[id].prev_pos=k?w:u;}
        c[i].flags=(c[i].flags|LINE_FLAG_ENABLED)&~LINE_FLAG_EMPTY;
        if(live_count==2048)fail("local slice segment budget");live_lines[live_count++]=i;
    }
}
static void slice_node(int id,Vec3* pos,float lx,float lz,float x0,CollVtx* v,CollLine* c) {
    DlNode* n=&nodes[id];float cx=(n->lo.x+n->hi.x)*.5f,cz=(n->lo.z+n->hi.z)*.5f,ex=(n->hi.x-n->lo.x)*.5f,ez=(n->hi.z-n->lo.z)*.5f;
    if(fabsf(-(cx-pos->x)*lz+(cz-pos->z)*lx)>fabsf(lz)*ex+fabsf(lx)*ez+.001f)return;
    if(fabsf((cx-pos->x)*lx+(cz-pos->z)*lz)>1200+fabsf(lx)*ex+fabsf(lz)*ez+.001f)return;
    if(n->count){for(int i=n->first;i<n->first+n->count;i++)slice_triangle(order[i],pos,lx,lz,x0,v,c);}
    else{slice_node(n->left,pos,lx,lz,x0,v,c);slice_node(n->right,pos,lx,lz,x0,v,c);}
}
static unsigned endpoint_bucket(int x,int y,unsigned kind){return ((unsigned)x*73856093u^(unsigned)y*19349663u^kind*83492791u)&8191u;}
static int line_compare(const void* a,const void* b){int x=*(const int*)a,y=*(const int*)b;return (x>y)-(x<y);}
static bool follows(MapLine* u,MapLine* w,CollVtx* v) {
    /* Overlapping donor faces can have endpoints closer than the weld
     * tolerance. Native line walkers require an acyclic oriented chain. */
    Vec2 a=v[u->v0_idx].pos,b=v[u->v1_idx].pos,c=v[w->v0_idx].pos,d=v[w->v1_idx].pos;
    float first=u->hi_flags<=2?a.x+b.x:a.y+b.y,second=u->hi_flags<=2?c.x+d.x:c.y+d.y;
    return u->hi_flags==1||u->hi_flags==8?second>first:second<first;
}
static void build_slice(Vec3* pos,float lx,float lz,float x0,CollVtx* v,CollLine* c) {
    slice_node(0,pos,lx,lz,x0,v,c);qsort(live_lines,live_count,sizeof(*live_lines),line_compare);
    /* Hash neighbouring endpoint cells, retaining the old exact tolerance and
     * highest-ID tie order. This replaces the quadratic all-pairs join. */
    int buckets[8192],next[2048];for(int i=0;i<8192;i++)buckets[i]=-1;
    for(int k=0;k<live_count;k++){MapLine* line=&map_lines[live_lines[k]];Vec2 p=v[line->v0_idx].pos;unsigned h=endpoint_bucket((int)floorf(p.x/.005f),(int)floorf(p.y/.005f),line->hi_flags);next[k]=buckets[h];buckets[h]=k;}
    for(int k=0;k<live_count;k++){int i=live_lines[k];MapLine* u=&map_lines[i];Vec2 p=v[u->v1_idx].pos;int x=(int)floorf(p.x/.005f),y=(int)floorf(p.y/.005f),chosen=-1;
        for(int dx=-1;dx<=1;dx++)for(int dy=-1;dy<=1;dy++)for(int h=buckets[endpoint_bucket(x+dx,y+dy,u->hi_flags)];h>=0;h=next[h]){
            int j=live_lines[h];MapLine* w=&map_lines[j];Vec2 q=v[w->v0_idx].pos;
            if(i!=j&&u->hi_flags==w->hi_flags&&follows(u,w,v)&&fabsf(p.x-q.x)<.005f&&fabsf(p.y-q.y)<.005f){if(j>chosen)chosen=j;if(i>w->prev_id0)w->prev_id0=w->prev_id1=i;}}
        u->next_id0=u->next_id1=chosen;
    }
}
static void restore_slice_geometry(CollVtx* v) {
    for(int k=0;k<live_count;k++){int i=live_lines[k];MapLine* line=&map_lines[i];
        int a=line->v0_idx,b=line->v1_idx;v[a].pos=saved[a];v[a].prev_pos=previous[a];
        v[b].pos=saved[b];v[b].prev_pos=previous[b];*line=original_lines[i];}
}
static unsigned long long slice_signature(CollVtx* v,CollLine* c) {
    unsigned long long h=1469598103934665603ULL;
    for(int k=0;k<live_count;k++) {
        int i=live_lines[k];MapLine* line=&map_lines[i];
        const void* parts[]={&i,line,&v[line->v0_idx].pos,&v[line->v1_idx].pos,&c[i].flags};
        size_t sizes[]={sizeof i,sizeof *line,sizeof(Vec2),sizeof(Vec2),sizeof c[i].flags};
        for(int j=0;j<5;j++)for(size_t b=0;b<sizes[j];b++)h=(h^((const unsigned char*)parts[j])[b])*1099511628211ULL;
    }return h;
}
static void store_slice(DlSliceCache* entry,const float key[5],CollVtx* v) {
    if(entry->capacity<live_count){free(entry->segments);entry->segments=alloc(live_count*sizeof(*entry->segments));entry->capacity=live_count;}
    entry->count=live_count;memcpy(entry->key,key,sizeof entry->key);entry->valid=1;
    for(int k=0;k<live_count;k++){int i=live_lines[k];MapLine* line=&map_lines[i];
        entry->segments[k]=(DlSliceSegment){i,*line,v[line->v0_idx].pos,v[line->v1_idx].pos};}
    if(!entry->next_line)entry->next_line=alloc(collision_data.line_count*sizeof(*entry->next_line));
    int k=live_count-1;unsigned short next=65535;
    for(int i=collision_data.line_count-1;i>=0;i--){if(k>=0&&live_lines[k]==i){next=i;k--;}entry->next_line[i]=next;}
}
static void apply_slice(DlSliceCache* entry,CollVtx* v,CollLine* c) {
    live_count=entry->count;
    for(int k=0;k<live_count;k++) {
        DlSliceSegment* segment=&entry->segments[k];int i=segment->id;live_lines[k]=i;
        MapLine* line=&map_lines[i];*line=segment->line;int a=line->v0_idx,b=line->v1_idx;
        saved[a]=v[a].pos;previous[a]=v[a].prev_pos;saved[b]=v[b].pos;previous[b]=v[b].prev_pos;
        v[a].pos=v[a].prev_pos=segment->a;v[b].pos=v[b].prev_pos=segment->b;
        c[i].flags=(c[i].flags|LINE_FLAG_ENABLED)&~LINE_FLAG_EMPTY;
    }
}
void m3d_DelfinoSlice(Vec3* pos,float lx,float lz,float x0) {
    if(!active||slicing)fail("nested collision scope");slicing=true;
    CollVtx* v=mpGetGroundCollVtx();CollLine* c=mpGetGroundCollLine();live_count=0;
    for(int i=0;i<collision_data.line_count;i++){saved_flags[i]=c[i].flags;c[i].flags=(c[i].flags|LINE_FLAG_EMPTY)&~LINE_FLAG_ENABLED;}
    float key[5]={pos->x,pos->z,lx,lz,x0};unsigned hash=2166136261u;
    for(int i=0;i<5;i++){unsigned bits;memcpy(&bits,&key[i],sizeof bits);hash=(hash^bits)*16777619u;}
    DlSliceCache* entry=&slice_cache[(hash^(hash>>16))&(DL_SLICE_CACHE-1)];
    current_slice=slice_cache_off?NULL:entry;++slice_requests;
    if(!slice_cache_off&&entry->valid&&!memcmp(entry->key,key,sizeof key)) {
        ++slice_hits;
        if(slice_check) {
            /* Compare the applied cache against a fresh build of every
             * endpoint, stable line ID, chain link and enabled flag. */
            build_slice(pos,lx,lz,x0,v,c);unsigned long long expected=slice_signature(v,c);
            restore_slice_geometry(v);
            for(int k=0;k<live_count;k++){int i=live_lines[k];c[i].flags=(c[i].flags|LINE_FLAG_EMPTY)&~LINE_FLAG_ENABLED;}
            apply_slice(entry,v,c);
            if(slice_signature(v,c)!=expected)fail("cached slice differs from exact rebuild");++slice_checks;
        } else apply_slice(entry,v,c);
    } else {
        build_slice(pos,lx,lz,x0,v,c);
        if(!slice_cache_off)store_slice(entry,key,v);
    }
    if(m3d_match_frame%120==0&&slice_log_tick!=m3d_match_frame){slice_log_tick=m3d_match_frame;
        fprintf(stderr,"M3D SLICE CACHE tick=%d requests=%llu hits=%llu verified=%llu enabled=%d\n",m3d_match_frame,slice_requests,slice_hits,slice_checks,!slice_cache_off);
        fprintf(stderr,"M3D RAY CACHE tick=%d requests=%llu hits=%llu verified=%llu enabled=%d\n",m3d_match_frame,ray_requests,ray_hits,ray_checks,!slice_cache_off);}
    /* The original import created one native island per triangle. Borrow only
     * the enabled islands for this query, rather than scanning thousands of
     * disabled islands in every native CPU floor decision. */
    saved_islands=mpIsland_80458E88;memset(&mpIsland_80458E88,0,sizeof mpIsland_80458E88);
    mpIsland *floor_tail=NULL,*ceiling_tail=NULL;int count=0;
    for(int k=0;k<live_count;k++){int i=live_lines[k];MapLine* line=&map_lines[i];if(line->hi_flags>2)continue;
        mpIsland* island=&slice_islands[count++];memset(island,0,sizeof(*island));bool floor=line->hi_flags==1;
        island->vtx0=floor?line->v0_idx:line->v1_idx;island->vtx1=floor?line->v1_idx:line->v0_idx;
        Vec2 a=v[island->vtx0].pos,b=v[island->vtx1].pos;island->pos0=(Vec3){a.x,a.y,0};island->pos1=(Vec3){b.x,b.y,0};island->line0=island->line1=i;island->joint_id=0;
        if(floor){if(floor_tail)floor_tail->next=island;else mpIsland_80458E88.floors=island;floor_tail=island;}
        else{if(ceiling_tail)ceiling_tail->next=island;else mpIsland_80458E88.ceilings=island;ceiling_tail=island;}}
    mpIsland_80458E88.non_dynamic_floors_tail=floor_tail;mpIsland_80458E88.non_dynamic_ceilings_tail=ceiling_tail;
    CollJoint* joint=mpGetGroundCollJoint();joint[0].bounding_min=(Vec2){-200000,-200000};joint[0].bounding_max=(Vec2){200000,200000};joint[0].flags&=~CollJoint_TooFar;
}
void m3d_DelfinoEnd(void) {
    if(!slicing)return;CollVtx* v=mpGetGroundCollVtx();CollLine* c=mpGetGroundCollLine();
    restore_slice_geometry(v);
    for(int i=0;i<collision_data.line_count;i++)c[i].flags=saved_flags[i];
    mpIsland_80458E88=saved_islands;slicing=false;current_slice=NULL;
}
bool m3d_DelfinoAdvanceLine(CollLine** line,int* index,int count) {
    if(!slicing)return m3d_ReferenceOverlayAdvanceLine(line,index,count);
    CollLine* base=mpGetGroundCollLine();int id=(int)(*line-base),lo=0,hi=live_count;
    if(current_slice) {
        if(id<0||id>=collision_data.line_count)return false;
        int next=current_slice->next_line[id];
        if(slice_check){while(lo<hi){int mid=(lo+hi)/2;if(live_lines[mid]<id)lo=mid+1;else hi=mid;}
            if(next!=(lo==live_count?65535:live_lines[lo]))fail("cached next-line differs from binary search");}
        int offset=next-id;if(next==65535||offset>=count-*index)return false;
        *line+=offset;*index+=offset;return true;
    }
    while(lo<hi){int mid=(lo+hi)/2;if(live_lines[mid]<id)lo=mid+1;else hi=mid;}
    if(lo==live_count)return false;int offset=live_lines[lo]-id;
    if(offset>=count-*index)return false;*line+=offset;*index+=offset;return true;
}
static bool triangle_height(DlTriangle* t,Vec3* p,float* y) {
    if(fabsf(t->n.y)<.00001f)return false;
    float sign=0;
    for(int j=0;j<3;j++) {Vec3 a=t->p[j],b=t->p[(j+1)%3];float q=(b.x-a.x)*(p->z-a.z)-(b.z-a.z)*(p->x-a.x);if(fabsf(q)<.001f)continue;if(sign*q<0)return false;sign=q;}
    *y=t->p[0].y-(t->n.x*(p->x-t->p[0].x)+t->n.z*(p->z-t->p[0].z))/t->n.y;return true;
}
static float height_node(int id,Vec3* p,int mode,float ceiling,float best) {
    DlNode* n=&nodes[id];if(p->x<n->lo.x-.001f||p->x>n->hi.x+.001f||p->z<n->lo.z-.001f||p->z>n->hi.z+.001f||n->lo.y>ceiling+.001f||n->hi.y<best-.001f)return best;
    if(n->count){for(int j=n->first;j<n->first+n->count;j++){DlTriangle* t=&tris[order[j]];float y;
        if(mode==1?(!(t->flags&1)||(t->flags&8)):(t->flags&3)||(((mode==0||mode==2)&&kind(t)!=0)||(mode==4&&kind(t)!=1)))continue;
        if(triangle_height(t,p,&y)&&y<=ceiling&&y>best) {
            Vec3 at={p->x,y,p->z};if(mode==0&&wet_floor(&at,NULL))continue;best=y;
        }}}
    else{best=height_node(n->left,p,mode,ceiling,best);best=height_node(n->right,p,mode,ceiling,best);}return best;
}
static bool segment_blocked(int id,Vec3 a,Vec3 d) {
    DlNode* n=&nodes[id];float enter=0,exit=1;
    for(int k=0;k<3;k++){float p=component(a,k),v=component(d,k),lo=component(n->lo,k)-.001f,hi=component(n->hi,k)+.001f;
        if(fabsf(v)<1e-8f){if(p<lo||p>hi)return false;}else{float x=(lo-p)/v,y=(hi-p)/v;if(x>y){float t=x;x=y;y=t;}enter=fmaxf(enter,x);exit=fminf(exit,y);if(enter>exit)return false;}}
    if(!n->count)return segment_blocked(n->left,a,d)||segment_blocked(n->right,a,d);
    for(int j=n->first;j<n->first+n->count;j++){DlTriangle* t=&tris[order[j]];if(t->flags&3)continue;
        Vec3 u={t->p[1].x-t->p[0].x,t->p[1].y-t->p[0].y,t->p[1].z-t->p[0].z},v={t->p[2].x-t->p[0].x,t->p[2].y-t->p[0].y,t->p[2].z-t->p[0].z};
        Vec3 p={d.y*v.z-d.z*v.y,d.z*v.x-d.x*v.z,d.x*v.y-d.y*v.x};float det=u.x*p.x+u.y*p.y+u.z*p.z;if(fabsf(det)<1e-7f)continue;
        Vec3 s={a.x-t->p[0].x,a.y-t->p[0].y,a.z-t->p[0].z};float x=(s.x*p.x+s.y*p.y+s.z*p.z)/det;if(x<0||x>1)continue;
        Vec3 q={s.y*u.z-s.z*u.y,s.z*u.x-s.x*u.z,s.x*u.y-s.y*u.x};float y=(d.x*q.x+d.y*q.y+d.z*q.z)/det;if(y<0||x+y>1)continue;
        float h=(v.x*q.x+v.y*q.y+v.z*q.z)/det;if(h>.001f&&h<.999f)return true;
    }return false;
}
static bool body_segment_blocked(int id,Vec3 a,Vec3 d,const M3dSupportPlanes* support) {
    DlNode* n=&nodes[id];float enter=0,exit=1;
    for(int k=0;k<3;k++){float p=component(a,k),v=component(d,k),lo=component(n->lo,k)-.001f,hi=component(n->hi,k)+.001f;
        if(fabsf(v)<1e-8f){if(p<lo||p>hi)return false;}else{float x=(lo-p)/v,y=(hi-p)/v;if(x>y){float t=x;x=y;y=t;}enter=fmaxf(enter,x);exit=fminf(exit,y);if(enter>exit)return false;}}
    if(!n->count)return body_segment_blocked(n->left,a,d,support)||body_segment_blocked(n->right,a,d,support);
    for(int j=n->first;j<n->first+n->count;j++){DlTriangle* t=&tris[order[j]];if(t->flags&3)continue;if(m3d_support_plane_matches(support,t->n.x,t->n.y,t->n.z,t->p[0].x,t->p[0].y,t->p[0].z))continue;
        Vec3 u={t->p[1].x-t->p[0].x,t->p[1].y-t->p[0].y,t->p[1].z-t->p[0].z},v={t->p[2].x-t->p[0].x,t->p[2].y-t->p[0].y,t->p[2].z-t->p[0].z};
        Vec3 p={d.y*v.z-d.z*v.y,d.z*v.x-d.x*v.z,d.x*v.y-d.y*v.x};float det=u.x*p.x+u.y*p.y+u.z*p.z;if(fabsf(det)<1e-7f)continue;
        Vec3 s={a.x-t->p[0].x,a.y-t->p[0].y,a.z-t->p[0].z};float x=(s.x*p.x+s.y*p.y+s.z*p.z)/det;if(x<0||x>1)continue;
        Vec3 q={s.y*u.z-s.z*u.y,s.z*u.x-s.x*u.z,s.x*u.y-s.y*u.x};float y=(d.x*q.x+d.y*q.y+d.z*q.z)/det;if(y<0||x+y>1)continue;
        float h=(v.x*q.x+v.y*q.y+v.z*q.z)/det;if(h>.001f&&h<.999f&&!m3d_support_below_all(support,a.x+d.x*h,a.y+d.y*h,a.z+d.z*h))return true;
    }return false;
}
static void delfino_support_planes(int id,Vec3* p,M3dSupportPlanes* supports) {
    DlNode* n=&nodes[id];if(p->x<n->lo.x-.001f||p->x>n->hi.x+.001f||p->z<n->lo.z-.001f||p->z>n->hi.z+.001f||n->lo.y>p->y+.5f||n->hi.y<p->y-.5f)return;
    if(!n->count){delfino_support_planes(n->left,p,supports);delfino_support_planes(n->right,p,supports);return;}
    for(int j=n->first;j<n->first+n->count;j++){DlTriangle* t=&tris[order[j]];float y;
        if(!(t->flags&3)&&t->n.y>=M3D_WALKABLE&&triangle_height(t,p,&y)&&fabsf(y-p->y)<.5f)m3d_support_plane_add(supports,t->n.x,t->n.y,t->n.z,t->p[0].x,t->p[0].y,t->p[0].z);}
}
static void delfino_floor_intervals(int id,Vec3* a,Vec3* b,M3dFloorProfile* profile) {
    if(profile->overflow)return;DlNode* n=&nodes[id];
    if(fmaxf(a->x,b->x)<n->lo.x-.001f||fminf(a->x,b->x)>n->hi.x+.001f||fmaxf(a->z,b->z)<n->lo.z-.001f||fminf(a->z,b->z)>n->hi.z+.001f)return;
    if(!n->count){delfino_floor_intervals(n->left,a,b,profile);delfino_floor_intervals(n->right,a,b,profile);return;}
    for(int i=n->first;i<n->first+n->count;i++){DlTriangle* t=&tris[order[i]];if(t->flags&3)continue;
        float points[3][3];for(int k=0;k<3;k++){points[k][0]=t->p[k].x;points[k][1]=t->p[k].y;points[k][2]=t->p[k].z;}
        m3d_floor_interval(profile,a->x,a->z,b->x,b->z,points,t->n.x,t->n.y,t->n.z);
    }
}
static bool delfino_floor_profile(Vec3* a,Vec3* b,M3dSupportPlanes* supports,float* endpoint_y) {
    if(fabsf(a->x-b->x)+fabsf(a->z-b->z)<.00001f){if(endpoint_y)*endpoint_y=a->y;return supports->count>0;}
    M3dFloorProfile profile={0};delfino_floor_intervals(0,a,b,&profile);
    return m3d_floor_connected(&profile,a->x,a->y,a->z,b->x,b->z,supports,endpoint_y);
}
bool m3d_DelfinoNavConnectedFloor(Vec3* a,Vec3* b) {
    if(!active)return m3d_ReferenceOverlayConnectedFloor(a,b);M3dSupportPlanes planes={0};delfino_support_planes(0,a,&planes);float endpoint_y=a->y;
    return planes.count&&delfino_floor_profile(a,b,&planes,&endpoint_y)&&fabsf(endpoint_y-b->y)<=.5f;
}
bool m3d_DelfinoNavBodyClear(Vec3* support,Vec3* a,Vec3* b) {
    if(!active)return m3d_ReferenceOverlayBodyClear(support,a,b);M3dSupportPlanes planes={0};delfino_support_planes(0,support,&planes);
    delfino_floor_profile(support,a,&planes,NULL);if(fabsf(a->x-b->x)+fabsf(a->z-b->z)>.00001f)delfino_floor_profile(support,b,&planes,NULL);
    return !body_segment_blocked(0,*a,(Vec3){b->x-a->x,b->y-a->y,b->z-a->z},&planes);
}
bool m3d_DelfinoNavOffsetSupported(Vec3* support,Vec3* offset,float tolerance) {
    if(!active)return m3d_ReferenceOverlayOffsetSupported(support,offset,tolerance);M3dSupportPlanes planes={0};delfino_support_planes(0,support,&planes);
    (void)tolerance;/* Actual continuous floor coverage replaces extrapolated height tolerance. */
    return planes.count&&delfino_floor_profile(support,offset,&planes,NULL);
}
static bool exact_segment_blocked(Vec3 a,Vec3 d) {
    ++ray_requests;
    if(slice_cache_off)return segment_blocked(0,a,d);
    float key[6]={a.x,a.y,a.z,d.x,d.y,d.z};unsigned hash=2166136261u;
    for(int i=0;i<6;i++){unsigned bits;memcpy(&bits,&key[i],sizeof bits);hash=(hash^bits)*16777619u;}
    unsigned slot=(hash^(hash>>16))&16383u;
    if(ray_cache[slot].valid&&!memcmp(ray_cache[slot].key,key,sizeof key)) {
        ++ray_hits;
        if(slice_check){if(ray_cache[slot].blocked!=segment_blocked(0,a,d))fail("cached ray differs from exact query");++ray_checks;}
        return ray_cache[slot].blocked;
    }
    bool blocked=segment_blocked(0,a,d);memcpy(ray_cache[slot].key,key,sizeof key);
    ray_cache[slot].valid=true;ray_cache[slot].blocked=blocked;return blocked;
}
bool m3d_DelfinoViewClear(Vec3* a,Vec3* b) {
    if(!active)return m3d_ReferenceOverlayViewClear(a,b);Vec3 d={b->x-a->x,b->y-a->y,b->z-a->z};return !exact_segment_blocked(*a,d);
}
bool m3d_DelfinoVisible(Vec3* a,Vec3* b) {
    if(!active){Vec3 from=*a,to=*b;from.y+=6;to.y+=6;return m3d_ReferenceOverlayViewClear(&from,&to);}Vec3 from=*a;from.y+=6;Vec3 d={b->x-a->x,b->y-a->y,b->z-a->z};return !exact_segment_blocked(from,d);
}
bool m3d_DelfinoFloor(Vec3* pos,Vec3* ground) {
    if(!active)return m3d_ReferenceOverlayActive()&&m3d_ReferenceFloor(pos,ground);float best=height_node(0,pos,0,pos->y+.1f,-1e20f);
    if(best<-1e19f)return false;*ground=*pos;ground->y=best;return true;
}
static int crossing_node(int id,Vec3* p){
    DlNode* n=&nodes[id];
    if(p->x<n->lo.x-.001f||p->x>n->hi.x+.001f||p->z<n->lo.z-.001f||p->z>n->hi.z+.001f||p->y<n->lo.y-1||p->y>n->hi.y+1)return -1;
    if(n->count){for(int j=n->first;j<n->first+n->count;j++){DlTriangle* t=&tris[order[j]];float y;
        if(t->surface>=0x7000&&t->surface<0x7003&&kind(t)==0&&triangle_height(t,p,&y)&&fabsf(y-p->y)<1)return t->surface-0x7000;}
        return -1;}
    int found=crossing_node(n->left,p);return found>=0?found:crossing_node(n->right,p);
}
int m3d_DelfinoCrossing(Vec3* pos){return active?crossing_node(0,pos):-1;}
/* Bevel only short vertical risers with solid treads on both sides. The
 * visual mesh stays untouched. Shared floor vertices move with the foot of
 * the riser so native slope collision sees a continuous chain, in every slice.
 * Full walls, unsupported edges, water and overhead obstructions are retained. */
static void smooth_steps(void) {
    typedef struct {Vec3 from,to,normal,second;float run,second_run;bool corner;} Shift;
    Shift shifts[768];unsigned shift_count=0;bool selected[30000]={0};
    for(unsigned i=0;i<triangle_count;i++) {
        DlTriangle* t=&tris[i];float lo=tri_lo[i].y,hi=tri_hi[i].y,rise=hi-lo;
        if(selected[i]||t->flags&3||fabsf(t->n.y)>.001f||rise<.5f||rise>3)continue;
        /* Only whole rectangular risers: a low triangular corner cut from a
         * tall building face must remain a wall. Process both halves together. */
        int partner=-1;
        for(unsigned k=i+1;k<triangle_count&&partner<0;k++) {
            DlTriangle* q=&tris[k];if(selected[k]||q->flags&3||fabsf(tri_lo[k].y-lo)>.001f||fabsf(tri_hi[k].y-hi)>.001f||fabsf(q->n.x-t->n.x)>.001f||fabsf(q->n.z-t->n.z)>.001f||fabsf(q->n.y)>.001f)continue;
            int shared=0,aligned=0;
            for(int j=0;j<3;j++)for(int h=0;h<3;h++) {
                Vec3 a=t->p[j],b=q->p[h];
                if(fabsf(a.x-b.x)<.001f&&fabsf(a.z-b.z)<.001f){if(fabsf(a.y-b.y)<.001f)shared++;else if(fabsf(fabsf(a.y-b.y)-rise)<.001f)aligned++;}
            }
            if(shared==2&&aligned==2)partner=k;
        }
        if(partner<0)continue;
        Vec3 feet[2];int count=0;
        for(int half=0;half<2&&count<=2;half++)for(int j=0;j<3&&count<=2;j++) {
            Vec3 q=tris[half?partner:i].p[j];if(fabsf(q.y-lo)>.001f)continue;
            bool found=false;for(int k=0;k<count;k++)if(hypotf(q.x-feet[k].x,q.z-feet[k].z)<.001f)found=true;
            if(!found){if(count==2){count=3;break;}feet[count++]=q;}
        }
        if(count!=2)continue;
        Vec3 p={(feet[0].x+feet[1].x)/2,lo,(feet[0].z+feet[1].z)/2};
        float run=0;Vec3 lower,upper={p.x-t->n.x*.2f,hi+.2f,p.z-t->n.z*.2f};
        float high=height_node(0,&upper,0,upper.y,-1e20f);
        if(fabsf(high-hi)>.1f)continue;
        /* Adapt to narrow flights, keeping a small flat part of each tread. */
        for(float ratio=2;ratio>=1;ratio-=.5f) {
            float length=rise*ratio;lower=(Vec3){p.x+t->n.x*(length+.2f),lo+.2f,p.z+t->n.z*(length+.2f)};
            float low=height_node(0,&lower,0,lower.y,-1e20f);
            if(fabsf(low-lo)<.1f){run=length;break;}
        }
        if(!run)continue;
        lower.y=hi+12;upper.y=hi+12;
        if(segment_blocked(0,lower,(Vec3){upper.x-lower.x,0,upper.z-lower.z}))continue;
        lower.y=lo+1;upper.y=hi+1;
        if(m3d_DelfinoBlast(&lower)||m3d_DelfinoBlast(&upper))continue;
        Shift changes[2];int indices[2];bool conflict=false;
        for(int j=0;j<2;j++) {
            Vec3 q=feet[j];int index=-1;
            for(unsigned k=0;k<shift_count;k++)if(fabsf(shifts[k].from.x-q.x)<.001f&&fabsf(shifts[k].from.y-q.y)<.001f&&fabsf(shifts[k].from.z-q.z)<.001f){index=k;break;}
            indices[j]=index;
            Shift change={.from=q,.to={q.x+t->n.x*run,q.y,q.z+t->n.z*run},.normal=t->n,.run=run};
            if(index>=0) {
                change=shifts[index];float dx=change.to.x-q.x,dz=change.to.z-q.z;
                if(fabsf(dx*t->n.x+dz*t->n.z-run)>.01f) {
                    /* Curved stairs share corners between different normals.
                     * Meet both ramp widths at their bisector, once per vertex. */
                    float det=change.normal.x*t->n.z-change.normal.z*t->n.x;
                    if(fabsf(det)<.001f){conflict=true;break;}
                    dx=(change.run*t->n.z-run*change.normal.z)/det;
                    dz=(change.normal.x*run-t->n.x*change.run)/det;
                    if(hypotf(dx,dz)>2*fmaxf(run,change.run)||(change.corner&&fabsf(dx*change.second.x+dz*change.second.z-change.second_run)>.01f)){conflict=true;break;}
                    change.to=(Vec3){q.x+dx,q.y,q.z+dz};change.corner=true;change.second=t->n;change.second_run=run;
                }
            }
            changes[j]=change;
        }
        if(conflict)continue;
        for(int j=0;j<2;j++){if(indices[j]>=0)shifts[indices[j]]=changes[j];else{if(shift_count==768)fail("stair vertex budget");shifts[shift_count++]=changes[j];}}
        selected[i]=selected[partner]=true;
        if(step_count==256)fail("stair candidate budget");
        steps[step_count++]=(DlStep){p,t->n,rise,run};
    }
    const char* probe=getenv("MELEE3D_NATIVE_DELFINO_PROBE");
    if(probe&&!strcmp(probe,"stairs-raw")){fprintf(stderr,"M3D DELFINO STAIRS RAW risers=%u\n",step_count);return;}
    unsigned changed=0;
    for(unsigned i=0;i<triangle_count;i++) {
        DlTriangle* t=&tris[i];if(!selected[i]&&(t->flags&3||t->n.y<=.05f))continue;
        bool moved=false;
        for(int j=0;j<3;j++){Vec3 q=t->p[j];for(unsigned k=0;k<shift_count;k++)if(fabsf(shifts[k].from.x-q.x)<.001f&&fabsf(shifts[k].from.y-q.y)<.001f&&fabsf(shifts[k].from.z-q.z)<.001f){t->p[j]=shifts[k].to;moved=true;break;}}
        if(!moved)continue;
        Vec3 a={t->p[1].x-t->p[0].x,t->p[1].y-t->p[0].y,t->p[1].z-t->p[0].z},b={t->p[2].x-t->p[0].x,t->p[2].y-t->p[0].y,t->p[2].z-t->p[0].z};
        Vec3 n={a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};float length=sqrtf(n.x*n.x+n.y*n.y+n.z*n.z);
        if(length<.001f)fail("degenerate stair bevel");
        if(n.x*t->n.x+n.y*t->n.y+n.z*t->n.z<0)length=-length;
        t->n=(Vec3){n.x/length,n.y/length,n.z/length};if(selected[i])t->flags|=4;changed++;
        tri_lo[i]=tri_hi[i]=t->p[0];for(int j=1;j<3;j++){Vec3 q=t->p[j];tri_lo[i].x=fminf(tri_lo[i].x,q.x);tri_lo[i].y=fminf(tri_lo[i].y,q.y);tri_lo[i].z=fminf(tri_lo[i].z,q.z);tri_hi[i].x=fmaxf(tri_hi[i].x,q.x);tri_hi[i].y=fmaxf(tri_hi[i].y,q.y);tri_hi[i].z=fmaxf(tri_hi[i].z,q.z);}
    }
    node_count=0;build_node(0,triangle_count);
    fprintf(stderr,"M3D DELFINO STAIRS risers=%u changed_faces=%u max_rise=3 slopes=0.5..1\n",step_count,changed);
}
bool m3d_DelfinoStepProbe(int ordinal,Vec3* point,Vec3* normal,float* rise,float* run) {
    if(!active)return false;
    /* Spread samples through the candidate bank; duplicate triangles are fine
     * for collision, but not useful as consecutive traversal evidence. */
    if(ordinal<0||ordinal>=12)return false;
    unsigned valid[256],count=0;
    for(unsigned i=0;i<step_count;i++) {
        DlStep* s=&steps[i];Vec3 low={s->point.x+s->normal.x*(s->run+3),s->point.y+10,s->point.z+s->normal.z*(s->run+3)},high={s->point.x-s->normal.x*3,s->point.y+10,s->point.z-s->normal.z*3},a,b;
        if(!m3d_DelfinoFloor(&low,&a)||!m3d_DelfinoFloor(&high,&b)||fabsf(a.y-s->point.y)>3||fabsf(b.y-s->point.y-s->rise)>3)continue;
        low.y=high.y=fmaxf(a.y,b.y)+12;if(!m3d_DelfinoViewClear(&low,&high))continue;
        valid[count++]=i;
    }
    if(count<12)return false;
    DlStep* step=&steps[valid[(unsigned)ordinal*count/12]];*point=step->point;*normal=step->normal;*rise=step->rise;*run=step->run;return true;
}
static bool ledge_has_drop(Vec3 q,Vec3 inward) {
    Vec3 outside={q.x-inward.x*5,q.y+24,q.z-inward.z*5},floor;
    return !m3d_DelfinoFloor(&outside,&floor)||floor.y<q.y-8;
}
bool m3d_DelfinoLedge(Vec3* pos,Vec3* goal,float* nx,float* nz) {
    if(!active)return false;float best=1e30f;
    for(unsigned i=0;i<ledge_count;i++) {DlLedge* l=&ledges[i];Vec3 d={l->b.x-l->a.x,l->b.y-l->a.y,l->b.z-l->a.z};
        float den=d.x*d.x+d.y*d.y+d.z*d.z;if(den<.0001f)continue;
        float t=fmaxf(0,fminf(1,((pos->x-l->a.x)*d.x+(pos->y-l->a.y)*d.y+(pos->z-l->a.z)*d.z)/den));
        Vec3 q={l->a.x+t*d.x,l->a.y+t*d.y,l->a.z+t*d.z};float dist=(q.x-pos->x)*(q.x-pos->x)+(q.y-pos->y)*(q.y-pos->y)+(q.z-pos->z)*(q.z-pos->z);
        if(dist<best){
            if(!ledge_has_drop(q,l->inward))continue;
            /* A donor boundary can be a pool/seabed edge. Recovery targets
             * need a dry landing under this map's existing water-KO rule. */
            Vec3 landing={q.x+l->inward.x*2,q.y+4,q.z+l->inward.z*2},floor;
            if(!m3d_DelfinoFloor(&landing,&floor)||fabsf(floor.y-q.y)>4)continue;
            landing.y=floor.y+1;if(m3d_DelfinoBlast(&landing))continue;
            best=dist;*goal=q;if(nx)*nx=l->inward.x;if(nz)*nz=l->inward.z;}
    }return best<1e29f;
}
/* A local ceiling leaves the same launch clearance above the square and the
 * rooftops. The native top-KO predicate still requires upward knockback (or
 * its original explicit death flags); jumping/recovery alone does not KO. */
float m3d_DelfinoBlastTop(Vec3* pos) {
    if(!active)return stage_info.blast_zone.top;
    float floor=height_node(0,pos,0,pos->y+.1f,-1e20f);
    if(floor<-1e19f)floor=spawn_center.y;
    return floor+M3D_DELFINO_KO_CLEARANCE;
}
int m3d_DelfinoBlast(Vec3* pos) {
    if(!active)return m3d_ReferenceOverlayBlast(pos);
    if(pos->y<spawn_center.y-kill_depth)return 2;
    if(pos->x<map_min.x-400||pos->z<map_min.z-400)return -1;
    if(pos->x>map_max.x+400||pos->z>map_max.z+400)return 1;
    /* Water follows the standard bottom-death path in ftCo_800D3158. */
    float best=height_node(0,pos,1,1e20f,-1e20f);
    if(best<-1e19f||pos->y>=best+1)return 0;
    if(height_node(0,pos,4,best+.1f,-1e20f)>pos->y+2)return 0;
    return 2;
}
/* Navigation and loot still treat deep water as unsafe. Fighters instead get
 * Great Bay's ordinary falling/recovery window, then the native bottom KO. */
int m3d_DelfinoFighterBlast(Fighter* fp,Vec3* pos,Vec3* previous) {
    float surface=-1e20f;
    bool exposed;
    if(active) {
        surface=height_node(0,pos,1,1e20f,-1e20f);
        float dry=surface>-1e19f?height_node(0,pos,4,surface+.1f,-1e20f):-1e20f;
        exposed=surface>-1e19f&&dry<=pos->y+2;
    } else {
        exposed=m3d_ReferenceOverlayWater(pos,&surface);
    }
    if(exposed&&previous->y>=surface&&pos->y<surface&&pos->y<previous->y&&
       fp->motion_id>=14&&!ft_80087838(fp->gobj)&&fp->player_idx<GM_MAX_PLAYERS) {
        int* last=&water_splash_tick[fp->player_idx][fp->is_sub_fighter?1:0];
        if(*last!=m3d_match_frame) {
            *last=m3d_match_frame;Vec3 splash={pos->x,surface,pos->z};
            /* Original Great Bay generator and size, using its own particle
             * bank. No change to fighter state, jumps, gravity or velocity. */
            HSD_Generator* g=water_archive?grLib_801C96F8(0x7537,0x1E,&splash):NULL;
            float scale=ftLib_80086B80(fp->gobj)/10.0f;
            if(g&&g->appsrt){g->appsrt->scale.x*=scale;g->appsrt->scale.y*=scale;g->appsrt->scale.z*=scale;Ground_801C53EC(0x57E40);}
            if(getenv("MELEE3D_NATIVE_DELFINO_PROBE"))fprintf(stderr,"M3D WATER SPLASH tick=%d slot=%d effect=%d pos=%.3f,%.3f,%.3f jumps=%d\n",m3d_match_frame,fp->player_idx,g&&g->appsrt?1:0,splash.x,splash.y,splash.z,fp->x1968_jumpsUsed);
        }
    }
    if(!active&&exposed)return pos->y<surface-120?2:0;
    int side=m3d_DelfinoBlast(pos);
    if(side==2&&exposed) {
        float deep=height_node(0,pos,1,1e20f,-1e20f);
        /* About Great Bay's depth below its surface. Preserve dry tunnels and
         * inland shallow beds, plus the existing side and storm blast zones. */
        if(deep>-1e19f)return pos->y<deep-120?2:0;
    }
    return side;
}
bool m3d_DelfinoDrop(Vec3* pos) {
    if(!active)return false;
    Vec3 near;float radius;
    if(m3d_ItemDropNear(&near,&radius)&&m3d_DelfinoNavDrop(pos,&near,radius))return true;
    if(m3d_DelfinoNavDrop(pos,NULL,0))return true;
    for(int j=0;j<256;j++) {unsigned i=HSD_Randi(triangle_count);DlTriangle* t=&tris[i];if(t->flags&3||t->n.y<.65f)continue;
        float u=HSD_Randf(),v=HSD_Randf();if(u+v>1){u=1-u;v=1-v;}
        *pos=(Vec3){t->p[0].x+u*(t->p[1].x-t->p[0].x)+v*(t->p[2].x-t->p[0].x),t->p[0].y+u*(t->p[1].y-t->p[0].y)+v*(t->p[2].y-t->p[0].y)+40,t->p[0].z+u*(t->p[1].z-t->p[0].z)+v*(t->p[2].z-t->p[0].z)};
        if(m3d_DelfinoBlast(pos)!=2)return true;
    }return false;
}
void m3d_DelfinoSpawn(int slot,int count,Vec3* pos) {
    /* Seeded safe starts cover the connected city, including the human. */
    if(m3d_DelfinoNavSpawn(slot,pos)){fprintf(stderr,"M3D DELFINO SPAWN slot=%d x=%g y=%g z=%g spread=1\n",slot,pos->x,pos->y,pos->z);return;}
    float angle=6.283185307f*slot/count;*pos=(Vec3){spawn_center.x+sinf(angle)*45,10000,spawn_center.z+cosf(angle)*45};
    Vec3 ground;if(!m3d_DelfinoFloor(pos,&ground))fail("plaza spawn has no floor");pos->y=ground.y+10;
    fprintf(stderr,"M3D DELFINO SPAWN slot=%d x=%g y=%g z=%g\n",slot,pos->x,pos->y,pos->z);
}
void m3d_DelfinoSpawnAim(Vec3* target){if(m3d_ReferenceOverlayActive())m3d_ReferenceOverlayAim(target);else *target=spawn_center;}
void m3d_DelfinoRebirth(Fighter* fp) {
    bool onett=m3d_ReferenceOverlayActive();
    if(!active&&!onett)return;
    /* Rebirth entry may run inside the dead fighter's borrowed collision
     * frame. Close it before installing a genuinely new world position. */
    m3d_ExitLocal(fp);
    Vec3 target;
    if(onett)target=fp->cur_pos;else m3d_SpawnPoint(fp->player_idx,&target);
    target.y+=35;
    m3d_CameraRebirth(fp);
    Vec3 focus;m3d_DelfinoSpawnAim(&focus);
    m3d_SetLane(fp,(focus.x-target.x)*fp->facing_dir,(focus.z-target.z)*fp->facing_dir);
    Player_SetSpawnPlatformPos(fp->player_idx,&target);
    Player_80032FA4(fp->player_idx,-1);fp->smash_attrs.x2135=-1;
    fp->mv.co.common.x4=target;
    fp->cur_pos=target;fp->cur_pos.y+=50;fp->prev_pos=fp->cur_pos;
    fp->self_vel=(Vec3){0};fp->xD4_unk_vel=(Vec3){0};
    mpColl_80043680(&fp->coll_data,&fp->cur_pos);
    HSD_JObjSetTranslate(fp->gobj->hsd_obj,&fp->cur_pos);
    if(Player_GetPlayerSlotType(fp->player_idx)==Gm_PKind_Human&&m3d_RoomIsViewer(fp->player_idx))m3d_CameraSetMode(m3d_CameraGetMode());
    fprintf(stderr,"M3D DELFINO REBIRTH slot=%u x=%.4f y=%.4f z=%.4f target_y=%.4f\n",fp->player_idx,fp->cur_pos.x,fp->cur_pos.y,fp->cur_pos.z,target.y);
}
bool m3d_DelfinoCameraFade(void) {
    return active && !m3d_PhotoActive() && m3d_CameraIsActive() && m3d_CameraGetMode()!=1;
}
void m3d_DelfinoCamera(Vec3* from,Vec3* eye) {
    /* Keep the preferred framing; the late stage pass reveals the fighter
     * through blockers rather than pushing the eye against their back. */
    if(!active||m3d_DelfinoCameraFade())return;
    Vec3 d={eye->x-from->x,eye->y-from->y,eye->z-from->z};float length=sqrtf(d.x*d.x+d.y*d.y+d.z*d.z),best=1;
    if(length<1)return;
    for(int ray=0;ray<5;ray++) {
        Vec3 a=*from;a.x+=ray==1?2:ray==2?-2:0;a.y+=ray==3?2:ray==4?-2:0;
        if(!segment_blocked(0,a,d))continue;
        float low=0,high=1;
        for(int step=0;step<14;step++){float mid=(low+high)*.5f;Vec3 part={d.x*mid,d.y*mid,d.z*mid};
            if(segment_blocked(0,a,part))high=mid;else low=mid;}
        best=fminf(best,low);
    }
    if(best<1){best=fmaxf(4/length,best-2/length);eye->x=from->x+d.x*best;eye->y=from->y+d.y*best;eye->z=from->z+d.z*best;}
}
static void render_indices(const unsigned* faces,unsigned count,unsigned base_face) {
    GXBegin(GX_TRIANGLES,GX_VTXFMT0,count*3);
    for(unsigned j=0;j<count;j++)for(int k=0;k<3;k++){u16 index=(faces[j]-base_face)*3+k;GXPosition1x16(index);GXColor1x16(index);GXTexCoord1x16(index);}
    GXEnd();
}
static void render_cached(unsigned draw,const unsigned* faces,unsigned count,unsigned base_face) {
    ++render_requests;
    DlRenderStream* stream=&render_streams[draw*render_stream_bins+base_face/20000];
    if(stream->commands && stream->count==count && !memcmp(stream->faces,faces,count*sizeof(*faces)))++render_hits;
    else {
        if(count>stream->capacity){
            free(stream->faces);free(stream->commands);stream->capacity=count;
            stream->faces=alloc(count*sizeof(*faces));stream->commands=alloc((3+count*18+31)&~31u);
        }
        stream->count=count;memcpy(stream->faces,faces,count*sizeof(*faces));
        /* The native recorder flushes pending matrices/material state before
         * capture. Only this primitive's original indexed vertex commands are
         * retained; camera, textures and array bindings stay live each frame. */
        GXBeginDisplayList(stream->commands,(3+stream->capacity*18+31)&~31u);
        render_indices(faces,count,base_face);stream->bytes=GXEndDisplayList();
    }
    if(render_stream_check) {
        unsigned size=(3+count*18+31)&~31u;
        if(size>render_reference_capacity){free(render_reference);render_reference=alloc(size);render_reference_capacity=size;}
        GXBeginDisplayList(render_reference,render_reference_capacity);
        render_indices(faces,count,base_face);unsigned bytes=GXEndDisplayList();
        if(bytes!=stream->bytes || memcmp(render_reference,stream->commands,bytes))fail("cached render stream differs from native indexed draw");
        ++render_verified;
    }
    GXCallDisplayList(stream->commands,stream->bytes);
}
/* Exact open eye-to-body segment. Objects behind the character and the
 * surface supporting their feet cannot intersect this segment. */
static bool cutaway_triangle(Vec3 eye,Vec3 point,Vec3 a,Vec3 b,Vec3 c,unsigned cull) {
    Vec3 d={point.x-eye.x,point.y-eye.y,point.z-eye.z};
    Vec3 u={b.x-a.x,b.y-a.y,b.z-a.z},v={c.x-a.x,c.y-a.y,c.z-a.z};
    Vec3 p={d.y*v.z-d.z*v.y,d.z*v.x-d.x*v.z,d.x*v.y-d.y*v.x};
    float det=u.x*p.x+u.y*p.y+u.z*p.z;if(fabsf(det)<1e-7f)return false;
    /* Imported J3D uses GX clockwise fronts. Do not let an invisible back
     * face trigger a cutaway (or reappear in the translucent pass). */
    if(cull==GX_CULL_ALL || (cull==GX_CULL_BACK&&det>0) || (cull==GX_CULL_FRONT&&det<0))return false;
    Vec3 s={eye.x-a.x,eye.y-a.y,eye.z-a.z};
    float x=(s.x*p.x+s.y*p.y+s.z*p.z)/det;if(x<0||x>1)return false;
    Vec3 q={s.y*u.z-s.z*u.y,s.z*u.x-s.x*u.z,s.x*u.y-s.y*u.x};
    float y=(d.x*q.x+d.y*q.y+d.z*q.z)/det;if(y<0||x+y>1)return false;
    float t=(v.x*q.x+v.y*q.y+v.z*q.z)/det;
    float length=sqrtf(d.x*d.x+d.y*d.y+d.z*d.z);
    return length>1 && t>.001f && t<1-.25f/length;
}
static bool cutaway_bounds(DlFadeGroup* g,Vec3 eye,Vec3 point) {
    float enter=0,exit=1;
    for(int k=0;k<3;k++) {
        float p=component(eye,k),d=component(point,k)-p,lo=component(g->lo,k)-.001f,hi=component(g->hi,k)+.001f;
        if(fabsf(d)<1e-8f){if(p<lo||p>hi)return false;}
        else{float a=(lo-p)/d,b=(hi-p)/d;if(a>b){float t=a;a=b;b=t;}enter=fmaxf(enter,a);exit=fminf(exit,b);if(enter>exit)return false;}
    }return true;
}
static float cutaway_feet;static unsigned cutaway_ground_saved;
static struct {Vec3 point;int slot;} cutaway_audit_points[GM_MAX_PLAYERS];static int cutaway_audit_count;
static unsigned cutaway_audit_views,cutaway_audit_hidden;
static bool supporting_face(unsigned face) {
    return m3d_surface_support(render_support[face][0],render_support[face][1],cutaway_feet);
}
static Vec3 cutaway_foot(Fighter* actor) {
    Vec3 p=actor->cur_pos,above=p,floor;above.y+=4;
    /* A landing can render with the root slightly below its supporting
     * surface. Aim the visibility rays above the physical floor in that
     * frame instead of allowing pavement to become a transient occluder. */
    if(m3d_DelfinoFloor(&above,&floor)&&floor.y>p.y&&floor.y<=p.y+4)p.y=floor.y;
    return p;
}
static void update_cutaways(Vec3 eye,Fighter* player,Vec3 forward,Vec3 right,Vec3 up) {
    for(unsigned g=0;g<fade_group_count;g++)fade_groups[g].faded=false;
    if(!player||!m3d_DelfinoCameraFade())return;
    struct {Vec3 foot;float height;} targets[GM_MAX_PLAYERS];int count=0;cutaway_audit_count=0;
    Vec3 lo=eye,hi=eye;
    for(HSD_GObj* object=HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER];object;object=object->next){
        Fighter* f=object->user_data;if(!f||f->is_sub_fighter||f->is_sleeping||f->motion_id<14)continue;
        Vec3 foot=cutaway_foot(f);float height=f->coll_data.ecb.top.y;
        if(!isfinite(height)||height<=1)height=9*f->x34_scale.y;
        if(f!=player){
            if(hypotf(foot.x-player->cur_pos.x,foot.z-player->cur_pos.z)>140||fabsf(foot.y-player->cur_pos.y)>72)continue;
            Vec3 q={foot.x-eye.x,foot.y+height*.5f-eye.y,foot.z-eye.z};
            float depth=q.x*forward.x+q.y*forward.y+q.z*forward.z;
            float side=q.x*right.x+q.y*right.y+q.z*right.z,vertical=q.x*up.x+q.y*up.y+q.z*up.z;
            if(depth<1||fabsf(side)>depth*.95f+12||fabsf(vertical)>depth*.65f+12)continue;
        }
        if(f==player)cutaway_feet=foot.y;
        if(count==GM_MAX_PLAYERS)break;
        targets[count].foot=foot;targets[count++].height=height;
        cutaway_audit_points[cutaway_audit_count].point=foot;cutaway_audit_points[cutaway_audit_count].point.y+=height*2/3;
        cutaway_audit_points[cutaway_audit_count++].slot=f->player_idx;
        lo.x=fminf(lo.x,foot.x);lo.y=fminf(lo.y,foot.y);lo.z=fminf(lo.z,foot.z);
        hi.x=fmaxf(hi.x,foot.x);hi.y=fmaxf(hi.y,foot.y+height);hi.z=fmaxf(hi.z,foot.z);
    }
    unsigned faded=0,tests=0,npc_faded=0;
    for(unsigned id=0;id<fade_group_count;id++) {
        DlFadeGroup* g=&fade_groups[id];
        /* One shared broad phase bounds all the eye-to-body rays. Most of
         * the city is rejected here even with many nearby opponents. */
        if(g->hi.x<lo.x||g->lo.x>hi.x||g->hi.y<lo.y||g->lo.y>hi.y||g->hi.z<lo.z||g->lo.z>hi.z)continue;
        for(int actor=0;actor<count&&!g->faded;actor++)for(int ray=0;ray<3&&!g->faded;ray++) {
            Vec3 point=targets[actor].foot;point.y+=targets[actor].height*(ray==0?1.0f/3:ray==1?2.0f/3:.9f);
            if(!cutaway_bounds(g,eye,point))continue;
            for(unsigned j=g->first;j<g->first+g->count;j++) {
                unsigned face=group_faces[j];if(textures[face_material[face]].flags&3)continue;
                if(m3d_surface_support(render_support[face][0],render_support[face][1],targets[actor].foot.y))continue;
                tests++;
                if(cutaway_triangle(eye,point,vertices[face*3].p,vertices[face*3+1].p,vertices[face*3+2].p,textures[face_material[face]].cull)){
                    g->faded=true;faded++;if(targets[actor].foot.x!=player->cur_pos.x||targets[actor].foot.z!=player->cur_pos.z)npc_faded++;break;
                }
            }
        }
    }
    if(m3d_match_frame%120==0)fprintf(stderr,"M3D CUTAWAY GROUPS tick=%d target=%u nearby=%d faded=%u npc_faded=%u tested=%u\n",m3d_match_frame,player->player_idx,count,faded,npc_faded,tests);
}
bool m3d_DelfinoCameraReveals(Vec3* eye,Vec3* point) {
    if(!active)return true;
    if(faded_total && last_overlay_tick!=m3d_match_frame)return false;
    Vec3 d={point->x-eye->x,point->y-eye->y,point->z-eye->z};
    for(unsigned draw=0;draw<draw_count;draw++) {
        DlDraw* b=&draws[draw];DlTexture* texture=&textures[b->material];
        if(texture->flags&3)continue;
        for(unsigned face=b->first;face<b->first+b->count;face++) {
            if(faded_mask[face])continue;
            Vec3 a=vertices[face*3].p,b=vertices[face*3+1].p,c=vertices[face*3+2].p;
            Vec3 u={b.x-a.x,b.y-a.y,b.z-a.z},v={c.x-a.x,c.y-a.y,c.z-a.z};
            Vec3 p={d.y*v.z-d.z*v.y,d.z*v.x-d.x*v.z,d.x*v.y-d.y*v.x};
            float det=u.x*p.x+u.y*p.y+u.z*p.z;if(fabsf(det)<1e-7f)continue;
            if(texture->cull==GX_CULL_ALL || (texture->cull==GX_CULL_BACK&&det>0) || (texture->cull==GX_CULL_FRONT&&det<0))continue;
            Vec3 s={eye->x-a.x,eye->y-a.y,eye->z-a.z};
            float x=(s.x*p.x+s.y*p.y+s.z*p.z)/det;if(x<0||x>1)continue;
            Vec3 q={s.y*u.z-s.z*u.y,s.z*u.x-s.x*u.z,s.x*u.y-s.y*u.x};
            float y=(d.x*q.x+d.y*q.y+d.z*q.z)/det;if(y<0||x+y>1)continue;
            float t=(v.x*q.x+v.y*q.y+v.z*q.z)/det;if(t>.001f&&t<.999f)return false;
        }
    }return true;
}
static void draw_faces(unsigned draw,const unsigned* faces,unsigned number) {
    unsigned first=0;
    while(first<number) {
        unsigned window=(faces[first]/20000)*20000,base_face=faces[first],base=base_face*3,count=0;
        while(first+count<number && faces[first+count]<window+20000)count++;
        /* Upload only the indexed span. A translucent cutaway often contains
         * a handful of faces; uploading an entire 60k-vertex window twice
         * exhausts Aurora's fixed per-frame storage pool. */
        unsigned arrays=(faces[first+count-1]-base_face+1)*3;
        GXSETARRAY(GX_VA_POS,&gpu_positions[base],arrays*sizeof(*gpu_positions),sizeof(*gpu_positions),true);
        GXSETARRAY(GX_VA_CLR0,&gpu_colors[base],arrays*sizeof(*gpu_colors),sizeof(*gpu_colors),true);
        GXSETARRAY(GX_VA_TEX0,&gpu_uvs[base],arrays*sizeof(*gpu_uvs),sizeof(*gpu_uvs),true);
        if(render_stream_off)render_indices(faces+first,count,base_face);
        else render_cached(draw,faces+first,count,base_face);
        first+=count;
    }
}
static void render_seals(bool faded) {
    if(!sealed_count)return;
    GXClearVtxDesc();GXSetVtxDesc(GX_VA_POS,GX_DIRECT);GXSetVtxDesc(GX_VA_CLR0,GX_DIRECT);GXSetVtxDesc(GX_VA_TEX0,GX_DIRECT);
    GXSetTexCoordGen(GX_TEXCOORD0,GX_TG_MTX2x4,GX_TG_TEX0,GX_IDENTITY);
    GXSetNumTexGens(1);GXSetNumTevStages(1);GXSetTevOrder(GX_TEVSTAGE0,GX_TEXCOORD0,GX_TEXMAP0,GX_COLOR0A0);GXSetTevOp(GX_TEVSTAGE0,GX_MODULATE);GXSetTevSwapMode(GX_TEVSTAGE0,GX_TEV_SWAP0,GX_TEV_SWAP0);
    GXSetCullMode(GX_CULL_NONE);GXSetZMode(GX_TRUE,GX_LEQUAL,!faded);
    GXSetAlphaCompare(GX_GREATER,0,GX_AOP_AND,GX_ALWAYS,0);GXSetZCompLoc(GX_FALSE);
    GXSetBlendMode(GX_BM_BLEND,GX_BL_SRCALPHA,GX_BL_INVSRCALPHA,GX_LO_CLEAR);
    Fighter* subject=m3d_CameraSubject();
    for(int h=0;h<sealed_count;h++) {
        M3dHole* hole=&sealed_holes[h];unsigned face=sealed_visual[h];
        bool fade=fade_groups[face_groups[face]].faded&&subject&&hole->center.y>subject->cur_pos.y+.6f;
        if(fade!=faded)continue;
        DlVertex* v=vertices+3*face;GXLoadTexObj(&textures[face_material[face]].object,GX_TEXMAP0);
        float bx=v[1].p.x-v[0].p.x,bz=v[1].p.z-v[0].p.z,cx=v[2].p.x-v[0].p.x,cz=v[2].p.z-v[0].p.z,den=bx*cz-bz*cx;
        GXBegin(GX_TRIANGLES,GX_VTXFMT0,hole->count*3);
        for(int k=0;k<hole->count;k++)for(int j=0;j<3;j++) {
            M3dHolePoint p=j==0?hole->center:hole->p[(k+(j==1?1:0))%hole->count];
            float dx=p.x-v[0].p.x,dz=p.z-v[0].p.z,w1=(dx*cz-dz*cx)/den,w2=(bx*dz-bz*dx)/den;
            float u=v[0].u+w1*(v[1].u-v[0].u)+w2*(v[2].u-v[0].u),t=v[0].v+w1*(v[1].v-v[0].v)+w2*(v[2].v-v[0].v);
            GXPosition3f32(p.x,p.y,p.z);GXColor4u8(v[0].color.r,v[0].color.g,v[0].color.b,faded?64:255);GXTexCoord2f32(u,t);
        }GXEnd();
    }
}
static void render(HSD_GObj* object,intptr_t pass) {
    bool faded=object==NULL;HSD_GObj* camera=Camera_80030A50();
    if(!active||pass!=0||(!faded&&Camera_8003108C()!=0)||!camera||HSD_CObjGetCurrent()!=camera->hsd_obj)return;
    if(faded){if(faded_tick!=m3d_match_frame||!faded_total)return;}
    else {if(last_render_tick==m3d_camera_frame)return;last_render_tick=m3d_camera_frame;
        faded_tick=m3d_match_frame;faded_total=0;memset(faded_counts,0,draw_count*sizeof(*faded_counts));
        memset(faded_mask,0,vertex_count/3);}
    HSD_StateInvalidate(-1);HSD_StateInitTev();GXColor clear={0,0,0,255};
    GXSetNumIndStages(0);GXSetTevDirect(GX_TEVSTAGE0);GXSetTevDirect(GX_TEVSTAGE1);GXSetTevDirect(GX_TEVSTAGE2);
    /* Native HSD materials may leave a nonidentity channel swap active. */
    GXSetTevSwapModeTable(GX_TEV_SWAP0,GX_CH_RED,GX_CH_GREEN,GX_CH_BLUE,GX_CH_ALPHA);
    GXSetFog(GX_FOG_NONE,0,0,0,0,clear);GXSetColorUpdate(GX_TRUE);GXSetAlphaUpdate(GX_FALSE);
    HSD_PObjClearMtxMark(NULL,0);
    GXLoadPosMtxImm(HSD_CObjGetViewingMtxPtr(HSD_CObjGetCurrent()),0);GXSetCurrentMtx(0);
    GXClearVtxDesc();GXSetVtxDesc(GX_VA_POS,GX_INDEX16);GXSetVtxDesc(GX_VA_CLR0,GX_INDEX16);GXSetVtxDesc(GX_VA_TEX0,GX_INDEX16);
    GXSetVtxAttrFmt(GX_VTXFMT0,GX_VA_POS,GX_POS_XYZ,GX_F32,0);GXSetVtxAttrFmt(GX_VTXFMT0,GX_VA_CLR0,GX_CLR_RGBA,GX_RGBA8,0);GXSetVtxAttrFmt(GX_VTXFMT0,GX_VA_TEX0,GX_TEX_ST,GX_F32,0);
    GXSetNumTexGens(1);GXSetNumChans(1);GXSetNumTevStages(1);GXSetCullMode(GX_CULL_NONE);
    GXSetChanCtrl(GX_COLOR0A0,GX_DISABLE,GX_SRC_REG,GX_SRC_VTX,0,GX_DF_NONE,GX_AF_NONE);
    GXSetTexCoordGen(GX_TEXCOORD0,GX_TG_MTX2x4,GX_TG_TEX0,GX_IDENTITY);
    GXSetTevOrder(GX_TEVSTAGE0,GX_TEXCOORD0,GX_TEXMAP0,GX_COLOR0A0);GXSetTevOp(GX_TEVSTAGE0,GX_MODULATE);GXSetTevSwapMode(GX_TEVSTAGE0,GX_TEV_SWAP0,GX_TEV_SWAP0);
    GXSetAlphaCompare(GX_GREATER,0,GX_AOP_AND,GX_ALWAYS,0);GXSetZCompLoc(GX_FALSE);
    if(faded) {
        GXSetNumTevStages(2);GXSetTevKColor(GX_KCOLOR0,(GXColor){255,255,255,64});
        GXSetTevOrder(GX_TEVSTAGE1,GX_TEXCOORD_NULL,GX_TEXMAP_NULL,GX_COLOR_NULL);
        GXSetTevSwapMode(GX_TEVSTAGE1,GX_TEV_SWAP0,GX_TEV_SWAP0);
        GXSetTevColorIn(GX_TEVSTAGE1,GX_CC_ZERO,GX_CC_ZERO,GX_CC_ZERO,GX_CC_CPREV);
        GXSetTevColorOp(GX_TEVSTAGE1,GX_TEV_ADD,GX_TB_ZERO,GX_CS_SCALE_1,GX_TRUE,GX_TEVPREV);
        GXSetTevKAlphaSel(GX_TEVSTAGE1,GX_TEV_KASEL_K0_A);
        GXSetTevAlphaIn(GX_TEVSTAGE1,GX_CA_ZERO,GX_CA_APREV,GX_CA_KONST,GX_CA_ZERO);
        GXSetTevAlphaOp(GX_TEVSTAGE1,GX_TEV_ADD,GX_TB_ZERO,GX_CS_SCALE_1,GX_TRUE,GX_TEVPREV);
    }
    Vec3 eye,interest;HSD_CObjGetEyePosition(HSD_CObjGetCurrent(),&eye);HSD_CObjGetInterest(HSD_CObjGetCurrent(),&interest);
    if(getenv("MELEE3D_NATIVE_DELFINO_PROBE")&&m3d_match_frame%120==0){
        HSD_GObj* object=Player_GetEntity(0);Fighter* fp=object->user_data;Vec3 root,view;
        HSD_JObjGetTranslation(object->hsd_obj,&root);PSMTXMultVec(HSD_CObjGetViewingMtxPtr(HSD_CObjGetCurrent()),&fp->cur_pos,&view);
        fprintf(stderr,"M3D WALL RENDER tick=%d eye=%.2f,%.2f,%.2f actor=%.2f,%.2f,%.2f root=%.2f,%.2f,%.2f view=%.2f,%.2f,%.2f\n",m3d_match_frame,eye.x,eye.y,eye.z,fp->cur_pos.x,fp->cur_pos.y,fp->cur_pos.z,root.x,root.y,root.z,view.x,view.y,view.z);}
    Vec3 forward={interest.x-eye.x,interest.y-eye.y,interest.z-eye.z};float length=sqrtf(forward.x*forward.x+forward.y*forward.y+forward.z*forward.z);
    forward.x/=length;forward.y/=length;forward.z/=length;
    float horizontal=hypotf(forward.x,forward.z);Vec3 right={-forward.z/horizontal,0,forward.x/horizontal};
    Vec3 up={right.y*forward.z-right.z*forward.y,right.z*forward.x-right.x*forward.z,right.x*forward.y-right.y*forward.x};
    Fighter* player=m3d_CameraSubject();
    if(!faded){update_cutaways(eye,player,forward,right,up);cutaway_ground_saved=0;}
    unsigned visible_total=0;
    for(unsigned i=0;i<draw_count;i++) {
        DlDraw* d=&draws[i];DlTexture* t=&textures[d->material];bool sky=t->flags&2;
        if(!faded){GXSetNumTexGens(1);GXSetNumTevStages(1);GXSetNumIndStages(0);GXSetTevDirect(GX_TEVSTAGE0);}
        if(t->flags&4) {
            float u=fmodf(m3d_match_frame*.0013f,1),v=fmodf(m3d_match_frame*(t->flags&8?-.006f:.0008f),1);
            Mtx tex={{1,0,0,u},{0,1,0,v},{0,0,1,0}};
            GXLoadTexMtxImm(tex,GX_TEXMTX0,GX_MTX2x4);
            GXSetTexCoordGen(GX_TEXCOORD0,GX_TG_MTX2x4,GX_TG_TEX0,GX_TEXMTX0);
        } else GXSetTexCoordGen(GX_TEXCOORD0,GX_TG_MTX2x4,GX_TG_TEX0,GX_IDENTITY);
        GXLoadTexObj(&t->object,GX_TEXMAP0);GXSetZMode(t->depth_test&&!sky,t->depth_func,t->depth_write&&!sky);
        GXSetCullMode(t->cull);GXSetBlendMode(t->blend_mode,t->blend_src,t->blend_dst,t->blend_logic);
        GXSetAlphaCompare(t->alpha_comp0,t->alpha_ref0,t->alpha_op,t->alpha_comp1,t->alpha_ref1);GXSetZCompLoc(t->z_comp_loc);
        if(faded) {
            if(!faded_counts[i])continue;
            GXSetZMode(GX_TRUE,GX_LEQUAL,GX_FALSE);GXSetCullMode(t->cull);
            GXSetBlendMode(GX_BM_BLEND,GX_BL_SRCALPHA,GX_BL_INVSRCALPHA,GX_LO_CLEAR);
            GXSetAlphaCompare(GX_GREATER,0,GX_AOP_AND,GX_ALWAYS,0);GXSetZCompLoc(GX_FALSE);
            draw_faces(i+draw_count,faded_faces+faded_offsets[i],faded_counts[i]);
            continue;
        }
        if((t->flags&4)&&!(t->flags&8))m3d_GoopWaterMaterial();
        faded_offsets[i]=faded_total;
        unsigned number=0;
        for(unsigned face=d->first;face<d->first+d->count;face++) {
            Vec3 c=render_centers[face],q;float radius=render_radii[face];
            q=(Vec3){c.x-eye.x,c.y-eye.y,c.z-eye.z};float depth=q.x*forward.x+q.y*forward.y+q.z*forward.z;
            float side=fabsf(q.x*right.x+q.y*right.y+q.z*right.z),height=fabsf(q.x*up.x+q.y*up.y+q.z*up.z);
            if(!sky&&(depth+radius<1||side>depth*1.1f+radius*1.5f||height>depth*.65f+radius*1.3f))continue;
            bool supporting=!sky&&supporting_face(face);
            if(!faded&&supporting&&fade_groups[face_groups[face]].faded)cutaway_ground_saved++;
            if(!sky && fade_groups[face_groups[face]].faded && !supporting) {
                faded_faces[faded_total++]=face;faded_counts[i]++;faded_mask[face]=1;
            } else visible_faces[number++]=face;
        }
        visible_total+=number;
        draw_faces(i,visible_faces,number);
    }
    if(!faded&&cutaway_ground_saved&&m3d_match_frame%60==0)fprintf(stderr,"M3D CUTAWAY SUPPORT tick=%d opaque=%u faded=0\n",m3d_match_frame,cutaway_ground_saved);
    if(m3d_match_frame<10)fprintf(stderr,"M3D DELFINO RENDER tick=%d triangles=%u indexed=1\n",m3d_match_frame,visible_total);
    if(render_stream_check && m3d_match_frame%120==0)fprintf(stderr,"M3D RENDER STREAM tick=%d requests=%llu hits=%llu verified=%llu\n",m3d_match_frame,render_requests,render_hits,render_verified);
    GXSETARRAY(GX_VA_POS,NULL,0,0,false);GXSETARRAY(GX_VA_CLR0,NULL,0,0,false);GXSETARRAY(GX_VA_TEX0,NULL,0,0,false);
    render_seals(faded);
    if(!faded&&m3d_PhotoActive()&&m3d_match_frame>=240)m3d_PhotoCapture();
    if(!faded&&!m3d_PhotoActive())m3d_PartyRender();else last_overlay_tick=m3d_match_frame;
    if(m3d_match_frame%120==0 && (!faded||faded_total))
        fprintf(stderr,"M3D CAMERA FADE tick=%d pass=%s faces=%u alpha=64 depth_write=0\n",m3d_match_frame,faded?"overlay":"opaque",faded_total);
    GXClearVtxDesc();
    HSD_PObjClearMtxMark(NULL,0);
    HSD_StateInvalidate(-1);
}
/* Reuse the rendered surface geometry, including roofs and walls, rather
 * than placing a flat disc through the city. Near the moving front, subdivide
 * large faces so the edge follows their surface instead of triangle corners. */
typedef struct {Vec3 p;GXColor color;float u,v;} GoopVertex;
static GoopVertex goop_batch[16380];static unsigned goop_batch_count;
static void goop_flush(void) {
    if(!goop_batch_count)return;
    GXBegin(GX_TRIANGLES,GX_VTXFMT0,goop_batch_count);
    for(unsigned i=0;i<goop_batch_count;i++){GoopVertex* v=&goop_batch[i];GXPosition3f32(v->p.x,v->p.y,v->p.z);GXColor4u8(v->color.r,v->color.g,v->color.b,v->color.a);GXTexCoord2f32(v->u,v->v);}GXEnd();goop_batch_count=0;
}
static void goop_vertex(Vec3 p,int axis) {
    if(goop_batch_count==16380)goop_flush();
    GoopVertex* v=&goop_batch[goop_batch_count++];v->p=p;v->p.y+=.12f;
    float x=axis==2?p.z:p.x,z=axis?p.y:p.z;
    v->color=(GXColor){160,122,84,255};
    v->u=x*.0065f;v->v=z*.0051f;
}
static void goop_triangle(Vec3 a,Vec3 b,Vec3 c,int level,int axis) {
    Vec3 middle={(a.x+b.x+c.x)/3,(a.y+b.y+c.y)/3,(a.z+b.z+c.z)/3};
    float ca=m3d_GoopField(&a),cb=m3d_GoopField(&b),cc=m3d_GoopField(&c),cm=m3d_GoopField(&middle);
    float low=fminf(cm,fminf(ca,fminf(cb,cc))),high=fmaxf(cm,fmaxf(ca,fmaxf(cb,cc)));
    if(high<=0)return;
    if(level>0&&low<=0) {
        Vec3 ab={(a.x+b.x)/2,(a.y+b.y)/2,(a.z+b.z)/2},bc={(b.x+c.x)/2,(b.y+c.y)/2,(b.z+c.z)/2},ac={(a.x+c.x)/2,(a.y+c.y)/2,(a.z+c.z)/2};
        goop_triangle(a,ab,ac,level-1,axis);goop_triangle(ab,b,bc,level-1,axis);goop_triangle(ac,bc,c,level-1,axis);goop_triangle(ab,bc,ac,level-1,axis);return;
    }
    /* Clip at the signed growth field. Covered ground stays opaque all the
     * way to a firm, irregular edge; it never fades into the paving. */
    Vec3 v[3]={a,b,c},out[5];float f[3]={ca,cb,cc};int count=0;
    for(int i=0;i<3;i++) {
        int j=(i+1)%3;if(f[i]>0)out[count++]=v[i];
        if((f[i]>0)!=(f[j]>0)){float t=f[i]/(f[i]-f[j]);out[count++]=(Vec3){v[i].x+(v[j].x-v[i].x)*t,v[i].y+(v[j].y-v[i].y)*t,v[i].z+(v[j].z-v[i].z)*t};}
    }
    for(int i=1;i+1<count;i++){goop_vertex(out[0],axis);goop_vertex(out[i],axis);goop_vertex(out[i+1],axis);}
}
/* The water render mesh extends far beyond its gameplay collision mesh.
 * Clip every painted triangle at sea level, including mixed shore triangles;
 * a centre-only collision query leaves giant distant seabed faces exposed. */
static void goop_land_triangle(Vec3 a,Vec3 b,Vec3 c,int level,int axis) {
    Vec3 v[3]={a,b,c},out[5];int count=0;float sea=water_height_max+.3f;
    for(int i=0;i<3;i++) {
        int j=(i+1)%3;float x=v[i].y-sea,y=v[j].y-sea;
        if(x>0)out[count++]=v[i];
        if((x>0)!=(y>0)){float t=x/(x-y);out[count++]=(Vec3){v[i].x+(v[j].x-v[i].x)*t,sea,v[i].z+(v[j].z-v[i].z)*t};}
    }
    for(int i=1;i+1<count;i++)goop_triangle(out[0],out[i],out[i+1],level,axis);
}
void m3d_DelfinoGoop(void) {
    if(!active){m3d_ReferenceOverlayGoop(goop_triangle);goop_flush();return;}HSD_CObj* camera=HSD_CObjGetCurrent();if(!camera)return;
    Vec3 eye;HSD_CObjGetEyePosition(camera,&eye);MtxPtr view=HSD_CObjGetViewingMtxPtr(camera);
    for(unsigned i=0;i<draw_count;i++) {
        DlDraw* d=&draws[i];if(textures[d->material].flags&3)continue; // water, leaves, sky
        for(unsigned face=d->first;face<d->first+d->count;face++) {
            if(faded_mask[face])continue;
            Vec3 center=render_centers[face],v;float r=render_radii[face];
            if(!m3d_GoopMayCover(&center,r))continue;
            if(hypotf(center.x-eye.x,center.z-eye.z)>1100+r)continue;
            PSMTXMultVec(view,&center,&v);if(v.z>r||fabsf(v.x)>-v.z*1.3f+r||fabsf(v.y)>-v.z*.8f+r)continue;
            Vec3 a=vertices[face*3].p,b=vertices[face*3+1].p,c=vertices[face*3+2].p;
            // Normal offset prevents coplanar flicker on vertical walls too.
            Vec3 u={b.x-a.x,b.y-a.y,b.z-a.z},w={c.x-a.x,c.y-a.y,c.z-a.z};
            Vec3 n={u.y*w.z-u.z*w.y,u.z*w.x-u.x*w.z,u.x*w.y-u.y*w.x};float length=sqrtf(n.x*n.x+n.y*n.y+n.z*n.z);
            if(length<.001f)continue;
            int axis=fabsf(n.y)>length*.5f?0:fabsf(n.z)>fabsf(n.x)?1:2;
            float offset=(n.x*(eye.x-a.x)+n.y*(eye.y-a.y)+n.z*(eye.z-a.z))<0?-.08f:.08f;
            n.x*=offset/length;n.y*=offset/length;n.z*=offset/length;
            a.x+=n.x;a.y+=n.y;a.z+=n.z;b.x+=n.x;b.y+=n.y;b.z+=n.z;c.x+=n.x;c.y+=n.y;c.z+=n.z;
            goop_land_triangle(a,b,c,r>240?6:r>120?5:r>60?4:r>30?3:2,axis);
        }
    }
    goop_flush();
}
void m3d_DelfinoRenderOccluders(void) {
    if(m3d_ReferenceOverlayActive()&&!m3d_PhotoActive()&&HSD_CObjGetCurrent()) {
        HSD_StateInvalidate(-1);HSD_StateInitTev();HSD_PObjClearMtxMark(NULL,0);
        GXLoadPosMtxImm(HSD_CObjGetViewingMtxPtr(HSD_CObjGetCurrent()),0);GXSetCurrentMtx(0);
        GXSetChanCtrl(GX_COLOR0A0,GX_DISABLE,GX_SRC_REG,GX_SRC_VTX,0,GX_DF_NONE,GX_AF_NONE);
        m3d_PartyRender();GXClearVtxDesc();HSD_PObjClearMtxMark(NULL,0);HSD_StateInvalidate(-1);
    }
    render(NULL,0);if(active)m3d_lab_camera_render();
    if(m3d_GameplayCaptureActive()&&m3d_lab_atlas_ready())m3d_PhotoCapture();
    if(active&&getenv("MELEE3D_NATIVE_CUTAWAY_AUDIT")&&m3d_match_frame%30==0){
        Vec3 eye;HSD_CObjGetEyePosition(HSD_CObjGetCurrent(),&eye);
        for(int i=0;i<cutaway_audit_count;i++){
            cutaway_audit_views++;
            if(!m3d_DelfinoCameraReveals(&eye,&cutaway_audit_points[i].point)){
                cutaway_audit_hidden++;
                fprintf(stderr,"M3D CUTAWAY HIDDEN tick=%d slot=%d\n",m3d_match_frame,cutaway_audit_points[i].slot);
            }
        }
        if(m3d_match_frame%120==0)fprintf(stderr,"M3D CUTAWAY AUDIT tick=%d views=%u hidden=%u\n",m3d_match_frame,cutaway_audit_views,cutaway_audit_hidden);
    }
}
/* Private map-lab compositions keep native HSD structures, including paletted
 * materials and their full joint hierarchy. Only explicit static bind poses
 * are supported: original stage callbacks could move collision independently.
 * Archive memory belongs to the scene heap; GObj owns each loaded JObj tree. */
static void prefab_render(HSD_GObj* object,intptr_t pass) {
    HSD_GObj* camera=Camera_80030A50();
    if(!active||Camera_8003108C()!=0||!camera||HSD_CObjGetCurrent()!=camera->hsd_obj)return;
    HSD_StateInvalidate(-1);HSD_GObj_JObjCallback(object,pass);HSD_StateInvalidate(-1);
}
static void prefab_init(void) {
    if(!getenv("MELEE3D_NATIVE_MAP_BANK"))return;
    const char* directory=m3d_MenuSunshineBank();char path[4096];
    if(!directory||snprintf(path,sizeof path,"%s/prefabs.txt",directory)>=(int)sizeof path)fail("prefab path");
    FILE* f=fopen(path,"r");if(!f)return;
    char line[512],names[16][128];HSD_Archive* archives[16];int count=0,archive_count=0;
    while(fgets(line,sizeof line,f)) {
        char name[128],extra;int group;float scale,x,y,z;
        if(line[0]=='#'||line[0]=='\n')continue;
        if(count>=16||!strchr(line,'\n')||sscanf(line,"%127s %d %f %f %f %f %c",name,&group,&scale,&x,&y,&z,&extra)!=6)fail("prefab manifest");
        if(!*name||strspn(name,"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.")!=strlen(name)
           ||strstr(name,"..")||!isfinite(scale)||scale<=0||scale>4
           ||!isfinite(x)||!isfinite(y)||!isfinite(z)||fabsf(x)>100000||fabsf(y)>100000||fabsf(z)>100000)fail("prefab transform");
        int index=0;while(index<archive_count&&strcmp(names[index],name))index++;
        if(index==archive_count) {
            strcpy(names[index],name);archives[index]=lbArchive_LoadArchive(name);
            if(!archives[index])fail("prefab archive");archive_count++;
        }
        UnkStageDat* data=HSD_ArchiveGetPublicAs(UnkStageDat,archives[index],"map_head");
        if(!data||group<0||group>=data->unkC||group>255)fail("prefab group");
        HSD_Joint* desc=DP(HSD_Joint,MAP_GOBJ_DESC(data,group)->unk0);
        if(!desc)fail("prefab joint");
        HSD_JObj* root=HSD_JObjLoadJoint(desc);HSD_JObj* wrapper=HSD_JObjAlloc();
        if(!root||!wrapper)fail("prefab allocation");
        Vec3 s={scale,scale,scale},p={x,y,z};
        HSD_JObjSetScale(wrapper,&s);HSD_JObjSetTranslate(wrapper,&p);
        HSD_JObjAddNext(root,wrapper);
        HSD_GObj* object=GObj_Create(3,5,0);if(!object)fail("prefab object");
        HSD_GObjObject_80390A70(object,HSD_GObj_JObjKind,wrapper);
        GObj_SetupGXLink(object,prefab_render,3,1);
        fprintf(stderr,"M3D PREFAB STATIC archive=%s group=%d scale=%.6f pos=%.3f,%.3f,%.3f\n",name,group,scale,x,y,z);count++;
    }
    if(ferror(f)||!count)fail("prefab manifest empty");fclose(f);
}
void m3d_WaterInit(void) {
    if(water_archive)return;
    water_archive=lbArchive_LoadArchive("GrGb.dat");
    int* particles=HSD_ArchiveGetPublicAs(int,water_archive,"map_ptcl");
    int* texture_bank=HSD_ArchiveGetPublicAs(int,water_archive,"map_texg");
    if(!particles||!texture_bank)fail("missing Great Bay water effects");
    psInitDataBankLocate(particles,texture_bank,NULL);
    psInitDataBankLoad(0x1E,particles,texture_bank,NULL,NULL);
    /* Add Great Bay's SFX while retaining the selected fighters' banks. */
    lbAudioAx_8002702C(8,lbAudioAx_80026EBC(St_Kind_GreatBay));
    lbAudioAx_80027168();lbAudioAx_80027648();
    fprintf(stderr,"M3D WATER BANK stage=GreatBay bank=30 effect=30007\n");
}
void m3d_DelfinoInit(void) {
    m3d_WaterInit();
    for(int i=0;i<4;i++)Ground_GetStageGObj(i);
    HSD_GObj* object=GObj_Create(3,5,0);GObj_SetupGXLink(object,render,3,0);
    prefab_init();

    Ground_801C39C0();Ground_801C3BB4();
    stage_info.blast_zone.left=map_min.x-400;stage_info.blast_zone.right=map_max.x+400;
    stage_info.blast_zone.bottom=map_min.y-300;stage_info.blast_zone.top=map_max.y+400;
    stage_info.cam_info.cam_bounds.left=map_min.x;stage_info.cam_info.cam_bounds.right=map_max.x;
    stage_info.cam_info.cam_bounds.bottom=map_min.y;stage_info.cam_info.cam_bounds.top=map_max.y;
    Camera_800311DC(1);Camera_800311CC(64000);
}
/* The affine projection of a node AABB conservatively bounds every receiver
 * UV. Keep original triangle order and exact clipping after candidate pruning. */
static void shadow_candidates(int id,HSD_Shadow* shadow) {
    DlNode* n=&nodes[id];Vec3 c={(n->lo.x+n->hi.x)*.5f,(n->lo.y+n->hi.y)*.5f,(n->lo.z+n->hi.z)*.5f};
    Vec3 h={(n->hi.x-n->lo.x)*.5f,(n->hi.y-n->lo.y)*.5f,(n->hi.z-n->lo.z)*.5f};
    for(int k=0;k<2;k++) {float* m=shadow->texture->mtx[k];
        float center=m[0]*c.x+m[1]*c.y+m[2]*c.z+m[3],radius=fabsf(m[0])*h.x+fabsf(m[1])*h.y+fabsf(m[2])*h.z;
        float pad=.001f*(1+fabsf(center)+radius);
        if(center+radius < -pad || center-radius > 1+pad)return;}
    if(n->count){for(int j=n->first;j<n->first+n->count;j++)shadow_faces[shadow_count++]=order[j];}
    else{shadow_candidates(n->left,shadow);shadow_candidates(n->right,shadow);}
}
static int shadow_order(const void* a,const void* b) {unsigned x=*(const unsigned*)a,y=*(const unsigned*)b;return x<y?-1:x>y;}
static void validate_shadow(HSD_Shadow* shadow,int checkpoint) {
    Vec3 eye,focus;HSD_CObjGetEyePosition(shadow->camera,&eye);HSD_CObjGetInterest(shadow->camera,&focus);
    float slope=hypotf(eye.x-focus.x,eye.z-focus.z)/fabsf(eye.y-focus.y);
    fprintf(stderr,"M3D SHADOW DIRECTION tick=%d slope=%.6f angle=%.4f\n",checkpoint,slope,atanf(slope)*180/3.14159265f);
    if(!isfinite(slope)||slope>.061f||slope<.055f)fail("shadow direction is not nearly vertical");
    int tested=0,failed=0;
    for(unsigned i=0;i<triangle_count;i++) {DlTriangle* t=&tris[i];if(t->flags&3||t->n.y<.05f)continue;tested++;
        float lo[2]={1e30f,1e30f},hi[2]={-1e30f,-1e30f};
        for(int j=0;j<3;j++){Vec3 p=t->p[j];for(int k=0;k<2;k++){float* m=shadow->texture->mtx[k];float uv=m[0]*p.x+m[1]*p.y+m[2]*p.z+m[3];lo[k]=fminf(lo[k],uv);hi[k]=fmaxf(hi[k],uv);}}
        if(hi[0]<0||lo[0]>1||hi[1]<0||lo[1]>1)continue;
        unsigned first=0,last=shadow_count;while(first<last){unsigned mid=(first+last)/2;if(shadow_faces[mid]<i)first=mid+1;else last=mid;}
        if(first==shadow_count||shadow_faces[first]!=i)failed++;
    }
    fprintf(stderr,"M3D DELFINO SHADOW CHECK tick=%d tested=%d candidates=%u failed=%d actual_tick=%d\n",checkpoint,tested,shadow_count,failed,m3d_match_frame);
    if(failed)fail("shadow pruning disagrees with full mesh");
}
void m3d_DelfinoShadow(HSD_Shadow* shadow) {
    if(!active)return;
    shadow_count=0;shadow_candidates(0,shadow);qsort(shadow_faces,shadow_count,sizeof(*shadow_faces),shadow_order);
    /* Physics can advance past a checkpoint between rendered frames. Run the
     * same full-mesh oracle at the next shadow pass and record its actual tick. */
    int checkpoint=last_shadow_validation_tick<120 && m3d_match_frame>=120 ? 120 :
        last_shadow_validation_tick<480 && m3d_match_frame>=480 ? 480 : 0;
    if(getenv("MELEE3D_NATIVE_DELFINO_VALIDATE") && checkpoint){validate_shadow(shadow,checkpoint);last_shadow_validation_tick=checkpoint;}
    for(unsigned face=0;face<shadow_count;face++) {unsigned i=shadow_faces[face];DlTriangle* t=&tris[i];if(t->flags&3||t->n.y<.05f)continue;
        float uv[3][2],umin=1e30f,umax=-1e30f,vmin=1e30f,vmax=-1e30f;
        for(int j=0;j<3;j++) {Vec3 p=t->p[j];for(int k=0;k<2;k++)uv[j][k]=shadow->texture->mtx[k][0]*p.x+shadow->texture->mtx[k][1]*p.y+shadow->texture->mtx[k][2]*p.z+shadow->texture->mtx[k][3];
            umin=fminf(umin,uv[j][0]);umax=fmaxf(umax,uv[j][0]);vmin=fminf(vmin,uv[j][1]);vmax=fmaxf(vmax,uv[j][1]);}
        if(umax<0||umin>1||vmax<0||vmin>1)continue;
        struct ShadowVertex {Vec3 p;float uv[2];} a[12],b[12];int count=3;
        for(int j=0;j<3;j++){a[j].p=t->p[j];a[j].uv[0]=uv[j][0];a[j].uv[1]=uv[j][1];}
        for(int plane=0;plane<4&&count;plane++) {int output=0,axis=plane/2;float edge=plane%2,sign=edge?-1:1;
            for(int j=0;j<count;j++) {struct ShadowVertex u=a[j],v=a[(j+1)%count];float du=(u.uv[axis]-edge)*sign,dv=(v.uv[axis]-edge)*sign;
                if(du>=0)b[output++]=u;
                if((du<0)!=(dv<0)) {float f=du/(du-dv);struct ShadowVertex w;
                    w.p=(Vec3){u.p.x+f*(v.p.x-u.p.x),u.p.y+f*(v.p.y-u.p.y),u.p.z+f*(v.p.z-u.p.z)};
                    for(int k=0;k<2;k++)w.uv[k]=u.uv[k]+f*(v.uv[k]-u.uv[k]);b[output++]=w;}
            }count=output;memcpy(a,b,count*sizeof(*a));
        }
        if(count<3)continue;GXBegin(GX_TRIANGLEFAN,GX_VTXFMT0,count);
        for(int j=0;j<count;j++){GXPosition3f32(a[j].p.x,a[j].p.y+.05f,a[j].p.z);GXColor4u8(255,255,255,255);GXTexCoord2f32(a[j].uv[0],a[j].uv[1]);}GXEnd();
    }
}
void m3d_DelfinoValidate(int tick) {
    if(!active)return;int tested=0,failed=0;
    int water_tested=0,seals_tested=0;
    for(int h=0;h<sealed_count;h++)for(int k=-1;k<sealed_holes[h].count;k++) {
        M3dHole* hole=&sealed_holes[h];M3dHolePoint at=hole->center;
        if(k>=0){at.x+=(hole->p[k].x-at.x)*.8f;at.z+=(hole->p[k].z-at.z)*.8f;}
        Vec3 p={at.x,at.y+.5f,at.z},floor;
        if(!m3d_DelfinoFloor(&p,&floor)||fabsf(floor.y-at.y)>.2f)fail("sealed floor query");
        for(int a=0;a<4;a++) {
            Vec3 from=p,to=p,hit;to.y=at.y-2;int line;u32 flags;
            bool began=m3d_MapBegin(&p,&p,cosf(a*.785398163f),sinf(a*.785398163f));
            if(!began)fail("sealed floor slice");
            m3d_MapToLocal(&from);m3d_MapToLocal(&to);
            bool found=mpCheckAll(&hit,&line,&flags,NULL,-1,-1,from.x,from.y,to.x,to.y);
            if(found)m3d_MapToWorld(&hit);m3d_MapEnd(&p);
            if(!found||fabsf(hit.y-at.y)>.2f)fail("sealed floor native collision");seals_tested++;
        }
    }
    fprintf(stderr,"M3D MAP SEALS CHECK tick=%d holes=%d queries=%d\n",tick,sealed_count,seals_tested);
    for(unsigned i=0;i<triangle_count;i++) {
        DlTriangle* t=&tris[i];if(t->flags&3||t->n.y<.65f)continue;
        Vec3 p={0};for(int j=0;j<3;j++){p.x+=t->p[j].x/3;p.y+=t->p[j].y/3;p.z+=t->p[j].z/3;}
        if(wet_floor(&p,NULL)) {
            for(int a=0;a<3;a++) {
                Vec3 from=p,to=p,hit,normal;from.y+=.8f;to.y-=1.2f;int line;u32 flags;
                bool began=m3d_MapBegin(&p,&p,cosf(a*.785398163f),sinf(a*.785398163f));
                if(!began)fail("water floor slice");m3d_MapToLocal(&from);m3d_MapToLocal(&to);
                bool found=mpCheckFloor(from.x,from.y,to.x,to.y,0,&hit,&line,&flags,&normal,-1,-1,-1,NULL,NULL);
                if(found)m3d_MapToWorld(&hit);m3d_MapEnd(&p);
                if(found&&wet_floor(&hit,NULL)){fprintf(stderr,"M3D WATER SOLID source=%u line=%d at=%.4f,%.4f,%.4f hit=%.4f,%.4f,%.4f\n",i,line,p.x,p.y,p.z,hit.x,hit.y,hit.z);fail("solid floor in exposed deep water");}water_tested++;
            }
            continue;
        }
        if(i%47)continue;
        float expected=p.y;p.y+=.2f;
        Vec3 ceiling=p,actual;ceiling.y=expected+.89f;
        bool fast=m3d_DelfinoFloor(&ceiling,&actual);float brute=-1e20f;
        for(unsigned k=0;k<triangle_count;k++){DlTriangle* q=&tris[k];float y;if(q->flags&3||q->n.y<=.05f)continue;
            if(triangle_height(q,&ceiling,&y)&&y<=ceiling.y+.1f){Vec3 at={ceiling.x,y,ceiling.z};if(!wet_floor(&at,NULL))brute=fmaxf(brute,y);}}
        if(fast!=(brute>-1e19f)||(fast&&fabsf(actual.y-brute)>.001f))fail("spatial floor differs from full mesh");
        if(fast)expected=actual.y;
        for(int a=0;a<3;a++) {
            Vec3 top=p,bottom=p,hit={0};int line=-1;u32 flags;top.y=p.y+.8f;bottom.y=p.y-1.2f;
            bool began=m3d_MapBegin(&p,&p,cosf(a*.785398163f),sinf(a*.785398163f)),ok=false;
            if(began){m3d_MapToLocal(&top);m3d_MapToLocal(&bottom);ok=mpCheckAll(&hit,&line,&flags,NULL,-1,-1,top.x,top.y,bottom.x,bottom.y);if(ok)m3d_MapToWorld(&hit);m3d_MapEnd(&p);}
            tested++;if(!ok||fabsf(hit.y-expected)>.15f){failed++;
                if(line>=0){DlTriangle* q=&tris[triangle_for_line[line]];float height;bool inside=triangle_height(q,&ceiling,&height);fprintf(stderr,"M3D RAY DETAIL source=%d p=%.6f,%.6f,%.6f inside=%d height=%.6f normal=%.6f,%.6f,%.6f a=%.6f,%.6f,%.6f b=%.6f,%.6f,%.6f c=%.6f,%.6f,%.6f\n",triangle_for_line[line],ceiling.x,ceiling.y,ceiling.z,inside,height,q->n.x,q->n.y,q->n.z,q->p[0].x,q->p[0].y,q->p[0].z,q->p[1].x,q->p[1].y,q->p[1].z,q->p[2].x,q->p[2].y,q->p[2].z);}
                fprintf(stderr,"M3D DELFINO RAY FAIL tri=%u angle=%d expected=%.4f actual=%.4f line=%d\n",i,a,expected,hit.y,line);}
        }
    }
    fprintf(stderr,"M3D WATER COLLISION tick=%d queries=%d solid=0\n",tick,water_tested);
    fprintf(stderr,"M3D DELFINO CHECK tick=%d tested=%d failed=%d\n",tick,tested,failed);if(failed)fail("geometry rays");
}

/* Select physical building faces for pad-driven contact regression. No render
 * triangles are used as collision, and gameplay never calls this fixture. */
bool m3d_DelfinoWaterProbe(int ordinal,Vec3* water,Vec3* floor) {
    Vec3 choices[64],beds[64];int count=0;
    bool shallow=ordinal<8;
    for(unsigned i=0;i<triangle_count&&count<64;i++) {
        DlTriangle* t=&tris[i];if(!(t->flags&1)||t->n.y<.65f||!!(t->flags&8)!=shallow)continue;
        Vec3 p={0};for(int k=0;k<3;k++){p.x+=t->p[k].x/3;p.y+=t->p[k].y/3;p.z+=t->p[k].z/3;}
        Vec3 below=p,bed={0};below.y-=3;
        if(shallow) {
            if(!m3d_DelfinoFloor(&p,&bed)||p.y-bed.y>4.1f||p.y-bed.y<0||m3d_DelfinoBlast(&below))continue;
            Vec3 upper=p,landing;upper.y+=20;if(!m3d_DelfinoFloor(&upper,&landing)||fabsf(landing.y-bed.y)>.1f)continue;
        }else if(m3d_DelfinoBlast(&below)!=2)continue;
        choices[count]=p;beds[count++]=bed;
    }
    if(!shallow){if(!count)return false;*water=choices[0];*floor=beds[0];return true;}
    /* Start at the lowest inland pool, then cover distant water bodies rather
     * than testing eight adjacent triangles of the same hillside basin. */
    int selected[8];
    for(int step=0;step<=ordinal;step++) {
        int best=-1;float score=-1e20f;
        for(int i=0;i<count;i++) {
            float value=-choices[i].y;
            if(step){value=1e20f;for(int j=0;j<step;j++) {
                Vec3 a=choices[i],b=choices[selected[j]];float dx=a.x-b.x,dy=a.y-b.y,dz=a.z-b.z;
                value=fminf(value,dx*dx+dy*dy+dz*dz);
            }}
            bool used=false;for(int j=0;j<step;j++)if(selected[j]==i)used=true;
            if(!used&&value>score){best=i;score=value;}
        }
        if(best<0)return false;selected[step]=best;
    }
    *water=choices[selected[ordinal]];*floor=beds[selected[ordinal]];return true;
}
bool m3d_DelfinoCeilingProbe(int ordinal,Vec3* ground) {
    for(unsigned i=0;i<triangle_count;i++) {
        DlTriangle* t=&tris[i];if(t->flags&3||t->n.y<.8f)continue;
        Vec3 p={0};for(int k=0;k<3;k++){p.x+=t->p[k].x/3;p.y+=t->p[k].y/3;p.z+=t->p[k].z/3;}
        if(ordinal==0 ? fabsf(p.y-spawn_center.y)>8 : p.y<spawn_center.y+60)continue;
        Vec3 high=p;high.y+=182;Vec3 floor;
        if(!m3d_DelfinoFloor(&high,&floor)||fabsf(floor.y-p.y)>.1f)continue;
        p.y+=1;if(m3d_DelfinoBlast(&p))continue;
        *ground=floor;return true;
    }return false;
}
bool m3d_DelfinoWallProbe(int ordinal,Vec3* start,Vec3* normal,Vec3* face,float* top) {
    int found=0;Vec3 chosen[32];
    for(unsigned i=0;i<triangle_count;i++) {
        DlTriangle* t=&tris[i];if(t->flags&3||fabsf(t->n.y)>.02f)continue;
        float lo=fminf(t->p[0].y,fminf(t->p[1].y,t->p[2].y)),hi=fmaxf(t->p[0].y,fmaxf(t->p[1].y,t->p[2].y));
        if(hi-lo<45)continue;
        Vec3 p={0};for(int j=0;j<3;j++){p.x+=t->p[j].x/3;p.y+=t->p[j].y/3;p.z+=t->p[j].z/3;}
        Vec3 out={p.x+t->n.x*14,p.y+2,p.z+t->n.z*14},ground;
        if(!m3d_DelfinoFloor(&out,&ground)||p.y-ground.y<6||p.y-ground.y>42||hi-ground.y<45||m3d_DelfinoBlast(&ground)==2)continue;
        bool separate=true;for(int j=0;j<found;j++)if(hypotf(p.x-chosen[j].x,p.z-chosen[j].z)<32)separate=false;
        if(!separate)continue;
        chosen[found++]=p;if(found==ordinal+1){*start=ground;start->y+=1;*normal=t->n;*face=p;*top=hi;return true;}
        if(found==32)break;
    }
    return false;
}

/* Diagnostic sample of genuine donor boundary edges. Geometry and native
 * catch eligibility are not changed to make the fixture pass. */
bool m3d_DelfinoLedgeProbe(int ordinal,Vec3* edge,Vec3* inward) {
    if(!active||ordinal<0||ordinal>16)return false;
    if(ordinal==16) {
        /* Dedicated low, dry dock with water below for release/jump cases.
         * Do not depend on an arbitrary ordinal in the spread selector. */
        for(unsigned i=0;i<ledge_count;i++) {
            DlLedge* l=&ledges[i];Vec3 q={(l->a.x+l->b.x)/2,(l->a.y+l->b.y)/2,(l->a.z+l->b.z)/2};
            if(q.y>40||hypotf(l->b.x-l->a.x,l->b.z-l->a.z)<12||fabsf(l->a.y-l->b.y)>2||!ledge_has_drop(q,l->inward))continue;
            Vec3 inside={q.x+l->inward.x*12,q.y+2,q.z+l->inward.z*12},out={q.x-l->inward.x*5,q.y-25,q.z-l->inward.z*5},floor;
            Vec3 hang=out;hang.y=q.y-7;
            if(!m3d_DelfinoFloor(&inside,&floor)||fabsf(floor.y-q.y)>2||m3d_DelfinoBlast(&inside)||m3d_DelfinoBlast(&hang)||m3d_DelfinoBlast(&out)!=2)continue;
            *edge=q;*inward=l->inward;return true;
        }
        return false;
    }
    int selected[16];
    for(int k=0;k<=ordinal;k++) {
        int chosen=-1;float best=-1;
        for(unsigned i=0;i<ledge_count;i++) {
            DlLedge* l=&ledges[i];float length=hypotf(l->b.x-l->a.x,l->b.z-l->a.z);
            if(length<12||fabsf(l->b.y-l->a.y)>2)continue;
            Vec3 q={(l->a.x+l->b.x)*.5f,(l->a.y+l->b.y)*.5f,(l->a.z+l->b.z)*.5f};
            Vec3 inside={q.x+l->inward.x*12,q.y+2,q.z+l->inward.z*12},outside={q.x-l->inward.x*5,q.y-7,q.z-l->inward.z*5},ground;
            if(!m3d_DelfinoFloor(&inside,&ground)||fabsf(ground.y-q.y)>2||m3d_DelfinoBlast(&outside)||m3d_DelfinoBlast(&inside))continue;
            if(!ledge_has_drop(q,l->inward))continue;
            Vec3 above=outside;above.y=q.y+24;
            if(m3d_DelfinoFloor(&above,&ground)&&ground.y>q.y-16)continue;
            Vec3 head=inside;head.y+=20;if(!m3d_DelfinoViewClear(&inside,&head))continue;
            float separation=2000;
            for(int j=0;j<k;j++){DlLedge* old=&ledges[selected[j]];float dx=q.x-(old->a.x+old->b.x)*.5f,dz=q.z-(old->a.z+old->b.z)*.5f;separation=fminf(separation,hypotf(dx,dz));}
            if(separation<30)continue;
            float score=separation+fminf(length,80)*.1f;
            if(score>best){best=score;chosen=i;}
        }
        if(chosen<0)return false;selected[k]=chosen;
    }
    DlLedge* l=&ledges[selected[ordinal]];*edge=(Vec3){(l->a.x+l->b.x)*.5f,(l->a.y+l->b.y)*.5f,(l->a.z+l->b.z)*.5f};*inward=l->inward;return true;
}

void m3d_DelfinoLedgeTargetsCheck(void) {
    unsigned checked=0;
    for(unsigned i=0;i<ledge_count&&checked<8;i++) {
        DlLedge* l=&ledges[i];Vec3 q={(l->a.x+l->b.x)*.5f,(l->a.y+l->b.y)*.5f,(l->a.z+l->b.z)*.5f};
        Vec3 land={q.x+l->inward.x*2,q.y+4,q.z+l->inward.z*2},floor,goal;float nx,nz;
        float raw=height_node(0,&land,2,land.y+.1f,-1e20f);if(raw<-1e19f)continue;land.y=raw+1;
        if(!m3d_DelfinoBlast(&land))continue;
        if(!m3d_DelfinoLedge(&q,&goal,&nx,&nz))fail("no dry recovery target");
        land=(Vec3){goal.x+nx*2,goal.y+4,goal.z+nz*2};
        if(!m3d_DelfinoFloor(&land,&floor)||fabsf(floor.y-goal.y)>4)fail("recovery target lacks a landing");
        land.y=floor.y+1;if(m3d_DelfinoBlast(&land))fail("recovery target enters water KO volume");checked++;
    }
    if(checked!=8)fail("insufficient wet-target negative cases");
    fprintf(stderr,"M3D LEDGE TARGETS PASS wet=%u checked=%u\n",checked,checked);
}

float m3d_DelfinoExtent(Vec3* p){if(m3d_ReferenceOverlayActive())return m3d_ReferenceOverlayExtent(p);return hypotf(fmaxf(fabsf(map_min.x-p->x),fabsf(map_max.x-p->x)),fmaxf(fabsf(map_min.z-p->z),fabsf(map_max.z-p->z)));}

/* Area-weighted dry collision surfaces, including roofs and offshore pillars.
 * Radial bins approximate intersections (not an exact polygon union). The
 * opening bound uses every vertex, so no dry surface is clipped initially. */
void m3d_DelfinoZoneRadii(Vec3* center,float radii[33]) {
    if(m3d_ReferenceOverlayActive()){m3d_ReferenceOverlayZoneRadii(center,radii);return;}
    float extent=140,bins[512]={0},area=0;
    for(unsigned i=0;i<triangle_count;i++){DlTriangle* t=&tris[i];if(t->flags&3||t->n.y<.65f)continue;
        for(int j=0;j<3;j++)extent=fmaxf(extent,hypotf(t->p[j].x-center->x,t->p[j].z-center->z)+40);}
    for(unsigned i=0;i<triangle_count;i++){DlTriangle* t=&tris[i];if(t->flags&3||t->n.y<.65f)continue;
        Vec3 a=t->p[0],b=t->p[1],c=t->p[2];
        float weight=fabsf((b.x-a.x)*(c.z-a.z)-(b.z-a.z)*(c.x-a.x))*.5f;
        int bin=(int)(hypotf((a.x+b.x+c.x)/3-center->x,(a.z+b.z+c.z)/3-center->z)/extent*511);
        bins[bin<0?0:bin>511?511:bin]+=weight;area+=weight;
    }
    for(int n=1;n<=32;n++) {
        float target=(n-1)*7300.0f*8,covered=0;radii[n]=extent;
        for(int i=0;i<512;i++){covered+=bins[i];if(covered>=target){radii[n]=fmaxf(140,(i+1)*extent/512);break;}}
    }
    radii[0]=extent;
    fprintf(stderr,"M3D ZONE GEOMETRY area=%.2f opening=%.2f pair=%.2f eight=%.2f sixteen=%.2f dry_mesh=1\n",area,extent,radii[2],radii[8],radii[16]);
}
