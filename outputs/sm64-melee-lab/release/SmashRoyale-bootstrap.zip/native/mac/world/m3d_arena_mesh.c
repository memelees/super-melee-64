/* Native source port of the shared melee3d overlay; first stage gate: FD. */
/// Source surface cross-sections. All fighters/items use native map queries.
#include "m3d.h"

#include <math.h>
#include <string.h>
#include <dolphin/dvd.h>
#include <dolphin/os.h>
#include <melee/gr/ground.h>
#include <melee/gr/types.h>
#include <melee/lb/lbfile.h>
#include <melee/mp/mplib.h>
#include <melee/mp/mpisland.h>
#include <melee/mp/types.h>
#include <sysdolphin/baselib/random.h>
#include <sysdolphin/baselib/gobj.h>
#include <sysdolphin/baselib/gobjuserdata.h>
#include <sysdolphin/baselib/initialize.h>
#include <sysdolphin/baselib/memory.h>

#define MESH_LINES 1024
#define MESH_EDGES 4096
#define MESH_PATCHES 512

typedef struct { u32 magic, version, patches, edges, size, reserved[3]; } MeshHeader;
typedef struct { Vec3 n; float d; u32 first, count, capacity, kind; } MeshPatch;
typedef struct { Vec3 a, b; } MeshEdge;
static MeshHeader* mesh;
static MeshPatch* patches;
static MeshEdge* edges;
typedef struct {float x0,z0,x1,z1;} PatchBounds;
typedef struct {
    MapLine lines[MESH_LINES], saved_lines[MESH_LINES];
    Vec2 points[MESH_LINES*2],saved_pos[MESH_LINES*2],saved_prev[MESH_LINES*2];
    u32 saved_flags[MESH_LINES];
    u16 patch_start[MESH_PATCHES][2];
    Vec2 intersections[MESH_EDGES];
    bool live[MESH_LINES];
    int link_heads[4096],link_next[MESH_LINES*2];
    PatchBounds patch_bounds[MESH_PATCHES];
} MeshStorage;
static MeshStorage* storage;
static MapCollData data;
static MapJoint joint;
static MapLine *lines,*saved_lines;
static Vec2 *points,*saved_pos,*saved_prev,*intersections;
static u32* saved_flags;
static u16 (*patch_start)[2];
static bool* live;
static int *link_heads,*link_next;
static PatchBounds* patch_bounds;

static unsigned endpoint_hash(int x,int y)
{
    return ((unsigned)x*73856093u ^ (unsigned)y*19349663u)&4095;
}

static int endpoint_match(CollVtx* v,Vec2* p,int own,int wanted_end)
{
    int x=(int)(p->x*1000),y=(int)(p->y*1000);
    int dx,dy,id,best=-1;
    for (dx=-1;dx<=1;dx++) for (dy=-1;dy<=1;dy++) {
        for (id=link_heads[endpoint_hash(x+dx,y+dy)];id>=0;id=link_next[id]) {
            int line=id/2,end=id&1;
            Vec2 q=v[end ? lines[line].v1_idx : lines[line].v0_idx].pos;
            if (line!=own && end==wanted_end && line>best &&
                fabsf(p->x-q.x)<0.001f && fabsf(p->y-q.y)<0.001f) best=line;
        }
    }
    return best;
}

static void link_surfaces(CollVtx* v)
{
    int i,end;
    for (i=0;i<4096;i++) link_heads[i]=-1;
    for (i=0;i<data.line_count;i++) if (live[i]) for (end=0;end<2;end++) {
        int id=i*2+end;
        Vec2 p=v[end ? lines[i].v1_idx : lines[i].v0_idx].pos;
        unsigned h=endpoint_hash((int)(p.x*1000),(int)(p.y*1000));
        link_next[id]=link_heads[h]; link_heads[h]=id;
    }
    for (i=0;i<data.line_count;i++) if (live[i]) {
        Vec2 a=v[lines[i].v0_idx].pos,b=v[lines[i].v1_idx].pos;
        lines[i].prev_id0=lines[i].prev_id1=endpoint_match(v,&a,i,1);
        lines[i].next_id0=lines[i].next_id1=endpoint_match(v,&b,i,0);
    }
}

bool m3d_ArenaMeshActive(void) { return mesh != NULL; }

bool m3d_ArenaMeshLoad(char* filename)
{
    MeshHeader* h;
    HSD_GObj* owner;
    u8* mesh_bank;
    int size, i, j,entry,capacity, counts[4] = { 0, 0, 0, 0 };
    mesh = NULL;
    storage=NULL;
    if (!filename || (entry=DVDConvertPathToEntrynum(filename)) < 0) return false;
    size=lbFile_8001634C(entry);
    if(size<32 || size>131072)return false;
    capacity=((size+31)&~31)+64;
    /* Native menus share the memory left after executable BSS. Keep the large
     * imported collision workspace match-owned, just like presentation banks. */
    storage=OSAllocFromHeap(HSD_GetHeap(),((sizeof(*storage)+31)&~31)+capacity);
    if(!storage) {OSReport("M3D ERR surface storage unavailable\n");return false;}
    lines=storage->lines;saved_lines=storage->saved_lines;
    points=storage->points;saved_pos=storage->saved_pos;saved_prev=storage->saved_prev;
    saved_flags=storage->saved_flags;patch_start=storage->patch_start;
    intersections=storage->intersections;live=storage->live;
    link_heads=storage->link_heads;link_next=storage->link_next;
    patch_bounds=storage->patch_bounds;
    owner=GObj_Create(3,5,0);
    if(!owner) {HSD_Free(storage);storage=NULL;return false;}
    GObj_InitUserData(owner,4,HSD_Free,storage);
    mesh_bank=(u8*)storage+((sizeof(*storage)+31)&~31);
    h=(MeshHeader*)mesh_bank;
    size = m3d_LoadFile(filename, (char*) mesh_bank, capacity);
    if (size < 32 || h->magic != 0x4D334331 || h->version != 1 ||
        h->patches < 1 || h->patches > MESH_PATCHES || h->edges > MESH_EDGES ||
        h->size != size || size != 32 + h->patches * 32 + h->edges * 24 ||
        h->reserved[0] || h->reserved[1] || h->reserved[2]) goto invalid;
    patches = (MeshPatch*) (h + 1);
    edges = (MeshEdge*) (patches + h->patches);
    for (i = 0; i < h->patches; i++) {
        MeshPatch* p = &patches[i];
        float norm = p->n.x * p->n.x + p->n.y * p->n.y + p->n.z * p->n.z;
        if (!(fabsf(norm - 1) < 0.001f) || !(fabsf(p->d) < 10000) ||
            p->kind > 2 || p->first > h->edges ||
            p->count > h->edges - p->first || p->count < 3 ||
            p->capacity < 1 || p->capacity > p->count / 2) goto invalid;
        if (p->kind == 2) {
            counts[2] += p->capacity;
            counts[3] += p->capacity;
        } else counts[p->kind] += p->capacity;
    }
    if (counts[0] + counts[1] + counts[2] + counts[3] > MESH_LINES) goto invalid;
    for (i = 0; i < h->edges; i++) {
        float* values = (float*) &edges[i];
        for (j = 0; j < 6; j++) if (!(fabsf(values[j]) <= 10000)) goto invalid;
    }
    for (i=0;i<h->patches;i++) {
        MeshPatch* p=&patches[i];
        patch_bounds[i].x0=patch_bounds[i].z0=1.0e20f;
        patch_bounds[i].x1=patch_bounds[i].z1=-1.0e20f;
        for (j=0;j<p->count;j++) {
            MeshEdge* e=&edges[p->first+j];
            int k;
            for (k=0;k<2;k++) {
                Vec3* q=k ? &e->b : &e->a;
                if(q->x<patch_bounds[i].x0)patch_bounds[i].x0=q->x;
                if(q->x>patch_bounds[i].x1)patch_bounds[i].x1=q->x;
                if(q->z<patch_bounds[i].z0)patch_bounds[i].z0=q->z;
                if(q->z>patch_bounds[i].z1)patch_bounds[i].z1=q->z;
            }
        }
    }
    mesh = h;
    OSReport("M3D COLLISION planes=%d edges=%d\n", h->patches, h->edges);
    return true;
invalid:
    OSReport("M3D ERR invalid surface bank\n");
    return false;
}

MapCollData* m3d_ArenaMeshCollision(void)
{
    int counts[4] = { 0, 0, 0, 0 }, cursor[4], i, j, k, total = 0;
    float scale = Ground_801C0498();
    memset(&data, 0, sizeof(data));
    memset(&joint, 0, sizeof(joint));
    memset(lines, 0, sizeof(storage->lines));
    for (i = 0; i < mesh->patches; i++) {
        MeshPatch* p = &patches[i];
        if (p->kind == 2) { counts[2] += p->capacity; counts[3] += p->capacity; }
        else counts[p->kind] += p->capacity;
    }
    for (k = 0; k < 4; k++) {
        cursor[k] = total;
        joint.ranges[k].start = data.ranges[k].start = total;
        joint.ranges[k].count = data.ranges[k].count = counts[k];
        total += counts[k];
    }
    for (i = 0; i < mesh->patches; i++) {
        MeshPatch* p = &patches[i];
        for (k = p->kind; k <= (p->kind == 2 ? 3 : p->kind); k++) {
            patch_start[i][k == 3] = cursor[k];
            for (j = 0; j < p->capacity; j++) {
                int id = cursor[k]++, v = id * 2;
                MapLine* line = &lines[id];
                /* Independent, nondegenerate seeds keep one native island per
                 * slot. Real coordinates are supplied for every query window. */
                points[v].x = (k < 2 ? -82 : 0) / scale;
                points[v+1].x = (k < 2 ? 82 : 0) / scale;
                points[v].y = (k < 2 ? (k == 0 ? 0 : -70) : -70) / scale;
                points[v+1].y = (k < 2 ? (k == 0 ? 0 : -70) : 0) / scale;
                line->v0_idx = v + (k == 1 || k == 2);
                line->v1_idx = v + !(k == 1 || k == 2);
                line->prev_id0 = line->prev_id1 = -1;
                line->next_id0 = line->next_id1 = -1;
                line->hi_flags = 1 << k;
                line->lo_flags = k == 0 ? LINE_FLAG_LEDGE : 0;
            }
        }
    }
    joint.left_bound = joint.bottom_bound = -200000;
    joint.right_bound = joint.top_bound = 200000;
    joint.vtx_count = total * 2;
    DP_SET(data.verts, points); data.vert_count = total * 2;
    DP_SET(data.lines, lines); data.line_count = total;
    DP_SET(data.joints, &joint); data.joint_count = 1;
    return &data;
}

static void refresh_islands(mpIsland* island)
{
    CollVtx* v = mpGetGroundCollVtx();
    while (island) {
        island->pos0.x = v[island->vtx0].pos.x;
        island->pos0.y = v[island->vtx0].pos.y;
        island->pos1.x = v[island->vtx1].pos.x;
        island->pos1.y = v[island->vtx1].pos.y;
        island->flags = live[island->line0] ? 0 : 2;
        island = island->next;
    }
}

void m3d_ArenaMeshMap(Vec3* pos, float lx, float lz, float x0)
{
    CollVtx* v = mpGetGroundCollVtx();
    CollLine* c = mpGetGroundCollLine();
    int i, j, k;
    for (i = 0; i < data.vert_count; i++) {
        saved_pos[i] = v[i].pos; saved_prev[i] = v[i].prev_pos;
    }
    memcpy(saved_lines, lines, data.line_count * sizeof(*lines));
    for (i = 0; i < data.line_count; i++) {
        saved_flags[i] = c[i].flags;
        c[i].flags = lines[i].hi_flags | LINE_FLAG_EMPTY;
        live[i] = false;
        lines[i].prev_id0 = lines[i].prev_id1 = -1;
        lines[i].next_id0 = lines[i].next_id1 = -1;
        v[i*2].pos.x = v[i*2+1].pos.x = 100000 + i;
    }
    for (i = 0; i < mesh->patches; i++) {
        MeshPatch* p = &patches[i];
        int n = 0, kind = p->kind, start, nearest = 0;
        float best = 1.0e20f;
        float cx=(patch_bounds[i].x0+patch_bounds[i].x1)*0.5f;
        float cz=(patch_bounds[i].z0+patch_bounds[i].z1)*0.5f;
        float reach=(patch_bounds[i].x1-patch_bounds[i].x0)*0.5f*fabsf(lz)+
                    (patch_bounds[i].z1-patch_bounds[i].z0)*0.5f*fabsf(lx);
        if(fabsf(-(cx-pos->x)*lz+(cz-pos->z)*lx)>reach+0.001f)continue;
        if (kind == 2) kind = p->n.x * lx + p->n.z * lz > 0 ? 2 : 3;
        start = patch_start[i][kind == 3];
        for (j = 0; j < p->count; j++) {
            MeshEdge* e = &edges[p->first + j];
            float a = -(e->a.x - pos->x) * lz + (e->a.z - pos->z) * lx;
            float b = -(e->b.x - pos->x) * lz + (e->b.z - pos->z) * lx;
            if ((a <= 0 && b > 0) || (b <= 0 && a > 0)) {
                float t = a / (a - b);
                Vec2 q;
                q.x = (e->a.x + t * (e->b.x - e->a.x) - pos->x) * lx +
                      (e->a.z + t * (e->b.z - e->a.z) - pos->z) * lz;
                q.y = e->a.y + t * (e->b.y - e->a.y);
                /* Insertion sort by lane distance (floor) or height (wall). */
                for (k = n; k > 0; k--) {
                    Vec2 r = intersections[k-1];
                    if ((p->kind < 2 ? r.x <= q.x : r.y <= q.y)) break;
                    intersections[k] = r;
                }
                intersections[k] = q; n++;
            }
        }
        if ((n & 1) || n/2>p->capacity) continue;
        for (j = 0; j < n; j += 2) {
            Vec2 a = intersections[j], b = intersections[j+1];
            float dx = a.x > 0 ? a.x : b.x < 0 ? -b.x : 0;
            float dy = a.y > pos->y ? a.y - pos->y : b.y < pos->y ? pos->y - b.y : 0;
            float dist = dx*dx + dy*dy;
            if ((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y) < 0.000001f) continue;
            if (dist < best) { best = dist; nearest = j/2; }
        }
        /* Slot zero follows the interval nearest the query owner. Grounded
         * floor IDs therefore survive a camera turn on concave surfaces. */
        for (j = 0; j < n/2; j++) {
            int pair = j == 0 ? nearest : j == nearest ? 0 : j;
            int id = start+j, vi = id*2;
            Vec2 a = intersections[pair*2], b = intersections[pair*2+1];
            if ((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y) < 0.000001f) continue;
            a.x += x0; b.x += x0;
            v[vi].pos = a; v[vi+1].pos = b;
            c[id].flags = lines[id].hi_flags | lines[id].lo_flags | LINE_FLAG_ENABLED;
            live[id] = true;
        }
    }
    for (i = 0; i < data.vert_count; i++) v[i].prev_pos = v[i].pos;
    /* Link source surfaces only at coincident endpoints, never across a gap. */
    link_surfaces(v);
    refresh_islands(mpIsland_80458E88.floors);
    refresh_islands(mpIsland_80458E88.ceilings);
}

void m3d_ArenaMeshEnd(void)
{
    CollVtx* v = mpGetGroundCollVtx();
    CollLine* c = mpGetGroundCollLine();
    int i;
    for (i = 0; i < data.vert_count; i++) {
        v[i].pos = saved_pos[i]; v[i].prev_pos = saved_prev[i];
    }
    memcpy(lines, saved_lines, data.line_count * sizeof(*lines));
    for (i = 0; i < data.line_count; i++) { c[i].flags = saved_flags[i]; live[i] = true; }
    refresh_islands(mpIsland_80458E88.floors);
    refresh_islands(mpIsland_80458E88.ceilings);
}

static bool contains(MeshPatch* p, float x, float z)
{
    bool inside = false;
    int j;
    int i=p-patches;
    if(x<patch_bounds[i].x0 || x>patch_bounds[i].x1 ||
       z<patch_bounds[i].z0 || z>patch_bounds[i].z1)return false;
    for (j = 0; j < p->count; j++) {
        MeshEdge* e = &edges[p->first+j];
        if ((e->a.z > z) != (e->b.z > z) &&
            x < (e->b.x-e->a.x)*(z-e->a.z)/(e->b.z-e->a.z)+e->a.x)
            inside = !inside;
    }
    return inside;
}

void m3d_ArenaMeshSpawnRing(Vec3* center,float* radius)
{
    float best=0;
    Vec3 seed=*center;
    int i,j,step,r;
    if(!mesh)return;
    /* The largest horizontal support surface supplies a world-space centre;
     * donor origins need not be anywhere near the middle of their stage. */
    for(i=0;i<mesh->patches;i++) {
        MeshPatch* p=&patches[i];
        float area=0,x=0,z=0;
        if(p->kind!=0 || p->n.y<0.9f)continue;
        for(j=0;j<p->count;j++) {
            MeshEdge* e=&edges[p->first+j];
            float a=e->a.x*e->b.z-e->b.x*e->a.z;
            area+=a;x+=(e->a.x+e->b.x)*a;z+=(e->a.z+e->b.z)*a;
        }
        if(fabsf(area)>best) {
            best=fabsf(area);seed.x=x/(3*area);seed.z=z/(3*area);
            seed.y=(p->d-p->n.x*seed.x-p->n.z*seed.z)/p->n.y;
        }
    }
    for(r=40;r>=8;r-=8)for(step=0;step<49;step++) {
        Vec3 candidate=seed;
        bool valid=true;
        if(step) {
            float angle=((step-1)%8)*0.785398163f;
            float distance=(1+(step-1)/8)*20;
            candidate.x+=sinf(angle)*distance;candidate.z+=cosf(angle)*distance;
        }
        for(j=0;j<9;j++) {
            Vec3 q=candidate,floor;
            if(j) {q.x+=r*sinf((j-1)*0.785398163f);q.z+=r*cosf((j-1)*0.785398163f);}
            q.y=9999;
            if(!m3d_GroundBelow(&q,&floor) || fabsf(floor.y-seed.y)>3) {valid=false;break;}
        }
        if(valid) {*center=candidate;*radius=r;return;}
    }
    /* Keep the existing safe surface fallback for exceptionally small maps. */
    *center=seed;center->y=0;m3d_ArenaMeshSpawn(center);*radius=8;
}

bool m3d_ArenaMeshOutside(Vec3* pos)
{
    int i;
    for (i = 0; i < mesh->patches; i++)
        if (patches[i].kind == 0 && contains(&patches[i], pos->x, pos->z))
            return false;
    return true;
}

void m3d_ArenaMeshInward(Vec3* pos, float* nx, float* nz)
{
    int i, j;
    float best = 1.0e20f;
    *nx = 1; *nz = 0;
    for (i = 0; i < mesh->patches; i++) {
        MeshPatch* p = &patches[i];
        if (p->kind != 0) continue;
        for (j = 0; j < p->count; j++) {
            MeshEdge* e = &edges[p->first+j];
            float dx = e->b.x-e->a.x, dz = e->b.z-e->a.z;
            float length = dx*dx+dz*dz, t, x, y, z, dist;
            if (length < 0.000001f) continue;
            t = ((pos->x-e->a.x)*dx+(pos->z-e->a.z)*dz)/length;
            if (t < 0) t = 0;
            if (t > 1) t = 1;
            x = e->a.x+t*dx; z = e->a.z+t*dz;
            y = e->a.y+t*(e->b.y-e->a.y);
            dist = (x-pos->x)*(x-pos->x)+(z-pos->z)*(z-pos->z)+
                   (y-pos->y)*(y-pos->y);
            if (dist < best) {
                float sign, inv = 1.0f/sqrtf(length);
                float tx = -dz*inv, tz = dx*inv;
                float mx = (e->a.x+e->b.x)*0.5f;
                float mz = (e->a.z+e->b.z)*0.5f;
                sign = contains(p, mx+tx*0.01f, mz+tz*0.01f) ? 1 : -1;
                best = dist; *nx = tx*sign; *nz = tz*sign;
            }
        }
    }
}


void m3d_ArenaMeshSpawn(Vec3* pos)
{
    Vec3 original = *pos, best = *pos;
    float score = 1.0e20f;
    int i, j, step;
    if (!mesh) return;
    /* Preserve native spawn/respawn height. Fit its horizontal anchor to a
     * source floor with room for a fighter, preferring the reference deck. */
    for (step = 0; step <= 20; step++) {
        float t = 1.0f - step * 0.05f;
        float x = original.x*t, z = original.z*t;
        float highest = -1.0e20f;
        /* A source floor below a roof is inside the solid. Only the first
         * surface visible from above can receive a new spawn anchor. */
        for (i = 0; i < mesh->patches; i++) {
            MeshPatch* p = &patches[i];
            float height;
            if (p->kind != 0 || !contains(p, x, z)) continue;
            height = (p->d-p->n.x*x-p->n.z*z)/p->n.y;
            if (height > highest) highest = height;
        }
        for (i = 0; i < mesh->patches; i++) {
            MeshPatch* p = &patches[i];
            float height, candidate, clearance = 1.0e20f;
            if (p->kind != 0 || !contains(p, x, z)) continue;
            height = (p->d-p->n.x*x-p->n.z*z)/p->n.y;
            if (height < highest-0.001f) continue;
            for (j = 0; j < p->count; j++) {
                MeshEdge* e = &edges[p->first+j];
                float dx = e->b.x-e->a.x, dz = e->b.z-e->a.z;
                float length = dx*dx+dz*dz, u, ex, ez, distance;
                if (length < 0.000001f) continue;
                u = ((x-e->a.x)*dx+(z-e->a.z)*dz)/length;
                if (u < 0) u = 0;
                if (u > 1) u = 1;
                ex = e->a.x+u*dx-x; ez = e->a.z+u*dz-z;
                distance = ex*ex+ez*ez;
                if (distance < clearance) clearance = distance;
            }
            if (clearance < 36) continue;
            candidate = fabsf(height)*10+(x-original.x)*(x-original.x)+
                        (z-original.z)*(z-original.z);
            if (candidate < score) {
                score = candidate; best.x = x; best.z = z;
                best.y = original.y+height;
            }
        }
    }
    *pos = best;
}

/* Imported maps own their extents. FD supplies locator infrastructure, never
 * the playable map's size or KO box. The same padding applies to every map. */
static Vec3 map_min, map_max;
void m3d_ArenaMeshBounds(void)
{
    float radius = 0;
    int i, j;
    if (!mesh) return;
    map_min.x = map_min.y = map_min.z = 1.0e20f;
    map_max.x = map_max.y = map_max.z = -1.0e20f;
    for (i = 0; i < mesh->patches; i++) {
        MeshPatch* p = &patches[i];
        for (j = 0; j < p->count; j++) {
            Vec3* v = &edges[p->first+j].a;
            float r = sqrtf(v->x*v->x+v->z*v->z);
            if (r > radius) radius = r;
            if (v->x < map_min.x) map_min.x = v->x;
            if (v->y < map_min.y) map_min.y = v->y;
            if (v->z < map_min.z) map_min.z = v->z;
            if (v->x > map_max.x) map_max.x = v->x;
            if (v->y > map_max.y) map_max.y = v->y;
            if (v->z > map_max.z) map_max.z = v->z;
        }
    }
    stage_info.cam_info.cam_x_offset = stage_info.cam_info.cam_y_offset = 0;
    stage_info.cam_info.cam_bounds.left = -radius-30;
    stage_info.cam_info.cam_bounds.right = radius+30;
    stage_info.cam_info.cam_bounds.bottom = map_min.y-30;
    stage_info.cam_info.cam_bounds.top = map_max.y+80;
    stage_info.blast_zone.left = -radius-120;
    stage_info.blast_zone.right = radius+120;
    stage_info.blast_zone.bottom = map_min.y-100;
    stage_info.blast_zone.top = map_max.y+200;
    OSReport("M3D BOUNDS solid=(%g,%g,%g)/(%g,%g,%g) blastY=%g/%g\n",
             map_min.x,map_min.y,map_min.z,map_max.x,map_max.y,map_max.z,
             stage_info.blast_zone.bottom,stage_info.blast_zone.top);
}

int m3d_ArenaMeshBlastSide(Vec3* pos)
{
    if (!mesh) return 0;
    if (pos->x > map_max.x+120 || pos->z > map_max.z+120) return 1;
    if (pos->x < map_min.x-120 || pos->z < map_min.z-120) return -1;
    return 0;
}

/* Query real receiver geometry instead of assuming that every map is Y=0. */
bool m3d_GroundBelow(Vec3* pos, Vec3* ground)
{
    float highest = -1.0e20f;
    int i;
    if (!m3d_StageIs3D()) return false;
    if(m3d_DelfinoActive())return m3d_DelfinoFloor(pos,ground);
    if(m3d_ReferenceActive())return m3d_ReferenceFloor(pos,ground);
    if (mesh) {
        for (i = 0; i < mesh->patches; i++) {
            MeshPatch* p = &patches[i];
            float y;
            if (p->kind != 0 || !contains(p, pos->x, pos->z)) continue;
            y = (p->d-p->n.x*pos->x-p->n.z*pos->z)/p->n.y;
            if (y <= pos->y+0.1f && y > highest) highest = y;
        }
        if (highest < -1.0e19f) return false;
        *ground = *pos; ground->y = highest;
        return true;
    } else {
        Vec3 a = *pos, b = *pos, hit, normal;
        int line;
        u32 flags;
        bool result;
        if (!m3d_MapBegin(&hit, pos, 1, 0)) return false;
        a.y += 0.1f; b.y = -20000;
        m3d_MapToLocal(&a); m3d_MapToLocal(&b);
        result = mpCheckAllRemap(&hit, &line, &flags, &normal, -1, -1,
                                 a.x,a.y,b.x,b.y);
        if (result) { m3d_MapToWorld(&hit); *ground = hit; }
        m3d_MapEnd(&hit);
        return result;
    }
}

bool m3d_RandomDrop(Vec3* pos)
{
    int i;
    float x0 = -80, x1 = 80, z0 = -80, z1 = 80;
    Vec3 sample, floor;
    if (!m3d_StageIs3D()) return false;
    if(m3d_DelfinoActive())return m3d_DelfinoDrop(pos);
    if(m3d_ReferenceActive())return m3d_ReferenceDrop(pos);
    if (mesh) { x0=map_min.x; x1=map_max.x; z0=map_min.z; z1=map_max.z; }
    for (i = 0; i < 128; i++) {
        sample.x=x0+(x1-x0)*HSD_Randf();
        sample.z=z0+(z1-z0)*HSD_Randf();
        sample.y=9999;
        if (!m3d_GroundBelow(&sample,&floor)) continue;
        *pos=floor; pos->y += 40+30*HSD_Randf();
        return true;
    }
    return false;
}

bool m3d_SegmentClear(Vec3* from, Vec3* to)
{
    Vec3 a=*from,b=*to,hit,normal;
    float dx=b.x-a.x,dz=b.z-a.z,length=sqrtf(dx*dx+dz*dz);
    int line;
    u32 flags;
    bool blocked;
    if (length<0.01f) return true;
    if (!m3d_MapBegin(&hit,from,dx/length,dz/length)) return false;
    m3d_MapToLocal(&a); m3d_MapToLocal(&b);
    blocked=mpCheckAllRemap(&hit,&line,&flags,&normal,-1,-1,a.x,a.y,b.x,b.y);
    m3d_MapEnd(&hit);
    return !blocked;
}
