/* Screen-edge objective layout, independent of the native render backend. */
#ifndef M3D_OBJECTIVE_H
#define M3D_OBJECTIVE_H
#include <math.h>
typedef struct {float x,y,dx,dy,half_width;} M3dObjectiveArrow;
/* Clip coordinates come from the ACTUAL submitted world-camera projection,
 * including widescreen. Positive w is in front; never mirror rear targets.
 * Output uses square pixels in a canvas with a logical height of 480. */
static int m3d_objective_edge(float x,float y,float w,float aspect,M3dObjectiveArrow* out)
{
    if(!isfinite(x)||!isfinite(y)||!isfinite(w)||!isfinite(aspect)||aspect<=0)return 0;
    if(w>0&&fabsf(x)<=w&&fabsf(y)<=w)return 0;
    float hw=240*aspect,hh=240;
    float dx=x*hw,dy=y*hh,length=hypotf(dx,dy);
    if(length<.00001f){dx=0;dy=-1;length=1;} /* Directly behind: turn around. */
    dx/=length;dy/=length;
    float sx=fabsf(dx)>.00001f?(hw-26)/fabsf(dx):1e20f;
    float sy=fabsf(dy)>.00001f?(hh-26)/fabsf(dy):1e20f;
    float distance=fminf(sx,sy);
    float px=dx*distance,py=dy*distance;
    /* Keep the top-centre arrow below the existing hill scoreboard. */
    if(py>112&&fabsf(px)<210){distance=112/dy;px=dx*distance;py=112;}
    *out=(M3dObjectiveArrow){px,py,dx,dy,hw};return 1;
}
#endif
