/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef M3D_SURFACE_H
#define M3D_SURFACE_H
#include <math.h>
/* One walkable limit for collision slices, floor rays and presentation.
 * Normals are unit length. Steep surfaces face either way and remain walls. */
#define M3D_WALKABLE .64f
static inline int m3d_surface_kind(float normal_y)
{
    return normal_y >= M3D_WALKABLE ? 0 :
           normal_y <= -M3D_WALKABLE ? 1 : 2;
}
/* Protect supporting ground only. Horizontal tops above the subject are
 * genuine occluders and must still fade along with their object. The caller
 * stabilizes feet against the nearby physical floor during landings. */
static inline int m3d_surface_support(float normal_y, float min_y, float feet_y)
{
    return (normal_y >= M3D_WALKABLE || normal_y <= -M3D_WALKABLE) &&
           min_y <= feet_y + .6f;
}

/* A navigation body may straddle its own sloping floor. Identify actual
 * supporting planes first; only those planes may be ignored by body rays.
 * A parallel ceiling, another slope and every wall remain obstructions. */
typedef struct {float nx,ny,nz,d;} M3dSupportPlane;
typedef struct {M3dSupportPlane planes[16];int count;} M3dSupportPlanes;
static inline int m3d_support_plane_matches(const M3dSupportPlanes* s,float nx,float ny,float nz,float x,float y,float z) {
    if(ny<M3D_WALKABLE)return 0;float d=nx*x+ny*y+nz*z;
    for(int i=0;i<s->count;i++){const M3dSupportPlane* p=&s->planes[i];
        if(fabsf(nx-p->nx)<.0001f&&fabsf(ny-p->ny)<.0001f&&fabsf(nz-p->nz)<.0001f&&fabsf(d-p->d)<.02f)return 1;}
    return 0;
}
static inline void m3d_support_plane_add(M3dSupportPlanes* s,float nx,float ny,float nz,float x,float y,float z) {
    if(ny<M3D_WALKABLE||m3d_support_plane_matches(s,nx,ny,nz,x,y,z)||s->count==16)return;
    s->planes[s->count++]=(M3dSupportPlane){nx,ny,nz,nx*x+ny*y+nz*z};
}
static inline float m3d_support_plane_height(const M3dSupportPlane* p,float x,float z){return(p->d-p->nx*x-p->nz*z)/p->ny;}

/* A horizontal foot-width ray can enter its own sloping floor slab. Only
 * intersections strictly beneath EVERY actual supporting plane lie outside
 * the standing body's above-floor volume. This never hides a raised ceiling
 * or wall above the support, including where multiple slopes meet. */
static inline int m3d_support_below_all(const M3dSupportPlanes* s,float x,float y,float z) {
    if(!s->count)return 0;
    for(int i=0;i<s->count;i++)if(y>=m3d_support_plane_height(&s->planes[i],x,z)-.01f)return 0;
    return 1;
}

/* Exact projected intervals identify only source facets continuously connected
 * to the feet. A convex crease can change normal inside the body radius;
 * disconnected roofs, vertical steps and genuine gaps never become support. */
#define M3D_PROFILE_INTERVALS 128
typedef struct {float lo,hi;M3dSupportPlane plane;} M3dFloorInterval;
typedef struct {M3dFloorInterval intervals[M3D_PROFILE_INTERVALS];int count,overflow;} M3dFloorProfile;
static inline void m3d_floor_interval(M3dFloorProfile* profile,float ax,float az,float bx,float bz,const float points[3][3],float nx,float ny,float nz) {
    if(ny<M3D_WALKABLE)return;float lo=0,hi=1,dx=bx-ax,dz=bz-az;
    for(int i=0;i<3;i++){
        int j=(i+1)%3;float ex=points[j][0]-points[i][0],ez=points[j][2]-points[i][2];
        float v=ex*(az-points[i][2])-ez*(ax-points[i][0]),dv=ex*dz-ez*dx;
        if(fabsf(dv)<1e-10f){if(v>1e-6f)return;}
        else if(dv>0)hi=fminf(hi,-v/dv);else lo=fmaxf(lo,-v/dv);
    }
    lo=fmaxf(0,lo);hi=fminf(1,hi);if(hi-lo<=1e-6f)return;
    if(profile->count==M3D_PROFILE_INTERVALS){profile->overflow=1;return;}
    profile->intervals[profile->count++]=(M3dFloorInterval){lo,hi,{nx,ny,nz,nx*points[0][0]+ny*points[0][1]+nz*points[0][2]}};
}
static inline int m3d_floor_connected(const M3dFloorProfile* profile,float ax,float ay,float az,float bx,float bz,M3dSupportPlanes* supports,float* endpoint_y) {
    if(profile->overflow)return 0;float events[M3D_PROFILE_INTERVALS*2+2]={0,1};int count=2;
    for(int i=0;i<profile->count;i++){events[count++]=profile->intervals[i].lo;events[count++]=profile->intervals[i].hi;}
    for(int i=1;i<count;i++){float v=events[i];int j=i;while(j&&events[j-1]>v){events[j]=events[j-1];j--;}events[j]=v;}
    float last_y=ay;int selected=0;
    for(int k=0;k+1<count;k++){
        float lo=events[k],hi=events[k+1];if(hi-lo<=1e-6f)continue;
        float x=ax+(bx-ax)*lo,z=az+(bz-az)*lo,best=.50001f;int chosen=-1;
        for(int i=0;i<profile->count;i++){
            const M3dFloorInterval* interval=&profile->intervals[i];if(interval->lo>lo+1e-6f||interval->hi<hi-1e-6f)continue;
            float delta=fabsf(m3d_support_plane_height(&interval->plane,x,z)-last_y);
            if(delta<=.5f&&delta<best){best=delta;chosen=i;}
        }
        if(chosen<0)return 0;const M3dSupportPlane* plane=&profile->intervals[chosen].plane;
        /* Ignore only actual selected support facets in body occlusion rays. */
        m3d_support_plane_add(supports,plane->nx,plane->ny,plane->nz,x,m3d_support_plane_height(plane,x,z),z);
        last_y=m3d_support_plane_height(plane,ax+(bx-ax)*hi,az+(bz-az)*hi);selected++;
    }
    if(endpoint_y)*endpoint_y=last_y;return selected>0;
}

#endif
