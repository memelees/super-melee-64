/* SPDX-License-Identifier: GPL-3.0-or-later
 * Native environment/config boundary for the shared source overlay. */
#include "m3d.h"
#include <melee/ft/types.h>
#include <melee/pl/player.h>
#include <sysdolphin/baselib/gobj.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

M3dConfig m3d_cfg;

bool m3d_SeparateAttackInputs(void) {
    const char* mode=getenv("MELEE3D_NATIVE_INPUTS");return mode&&!strcmp(mode,"spatial");
}

void m3d_NativeConfigure(void)
{
    m3d_CombatConfigure();
    const char* enabled=getenv("MELEE3D_NATIVE_3D");
    memset(&m3d_cfg,0,sizeof m3d_cfg);
    m3d_cfg.loaded=true;m3d_cfg.mode3d=enabled && !strcmp(enabled,"1");
    m3d_cfg.boot_match=m3d_cfg.mode3d;m3d_cfg.stage=32;
    const char* camera=getenv("MELEE3D_NATIVE_CAMERA");
    m3d_cfg.camera=camera && !strcmp(camera,"smash") ? 1:camera&&!strcmp(camera,"combat")?2:0;
    m3d_CameraSetMode(m3d_cfg.camera);
    if(m3d_cfg.mode3d)fprintf(stderr,"M3D WORLD ENABLED capacity=%d camera=%s\n",GM_MAX_PLAYERS,m3d_cfg.camera==2?"combat":m3d_cfg.camera==1?"smash":"orbit");
}

/* Apply through the same attribute-rebuild boundary as native item/size
 * modifiers. Every rebuild starts from DAT attributes, so respawns and item
 * changes cannot compound the multiplier. Private special-move tuning stays
 * with the original move. This applies equally to human and CPU fighters. */
static float rule_number(const char* key,float lo,float hi) {
    const char* value=getenv(key);if(!value)return 1;
    char* end;float v=strtof(value,&end);
    if(!*value||*end||!isfinite(v)||v<lo||v>hi){fprintf(stderr,"M3D LAB FAIL invalid rule %s\n",key);exit(2);}
    return v;
}
void m3d_ApplyRuleModifiers(Fighter* fp) {
    const char* enabled=getenv("MELEE3D_NATIVE_3D");if(!enabled||strcmp(enabled,"1"))return;
    float speed=rule_number("MELEE3D_NATIVE_MOVE_SPEED",.5f,2),gravity=rule_number("MELEE3D_NATIVE_GRAVITY",.25f,1.5f);
    if(speed==1&&gravity==1){m3d_GoopAttributes(fp,true);return;}
    float old_speed=fp->co_attrs.dash_max_velocity,old_gravity=fp->co_attrs.gravity;
#define SCALE(field) fp->co_attrs.field*=speed
    SCALE(walk_accel_mul);SCALE(walk_accel_base);SCALE(walk_max_vel);
    SCALE(slow_walk_max);SCALE(mid_walk_point);SCALE(fast_walk_min);SCALE(ground_friction);
    SCALE(dash_initial_velocity);SCALE(dash_accel_mul);SCALE(dash_accel_base);SCALE(dash_max_velocity);
    SCALE(ground_max_horizontal_velocity);SCALE(jump_h_initial_velocity);SCALE(jump_h_max_velocity);
    SCALE(air_jump_h_multiplier); /* Native name; this is a horizontal launch velocity. */
    SCALE(air_drift_stick_mul);SCALE(aerial_drift_base);SCALE(air_drift_max);SCALE(aerial_friction);
    SCALE(air_max_horizontal_velocity);SCALE(ledge_jump_horizontal_velocity);SCALE(wall_jump_horizontal_velocity);
#undef SCALE
    fp->co_attrs.gravity*=gravity;
    fp->co_attrs.terminal_velocity*=sqrtf(gravity);fp->co_attrs.fast_fall_velocity*=sqrtf(gravity);
    m3d_GoopAttributes(fp,true);
    fprintf(stderr,"M3D RULE APPLY slot=%u kind=%d speed=%.4f gravity=%.4f dash=%.6f,%.6f fall=%.6f,%.6f\n",fp->player_idx,fp->kind,speed,gravity,old_speed,fp->co_attrs.dash_max_velocity,old_gravity,fp->co_attrs.gravity);
}

int m3d_LoadFile(const char* name,char* buffer,int capacity)
{
    /* Optional historical donor-map banks are outside the initial FD gate. */
    const char* directory=getenv("MELEE3D_NATIVE_MAPS");
    if(!directory || capacity<=0 || strstr(name,".."))return 0;
    char path[4096];snprintf(path,sizeof path,"%s/%s",directory,name);
    FILE* file=fopen(path,"rb");if(!file)return 0;
    size_t length=fread(buffer,1,capacity,file);
    if(!feof(file) && fgetc(file)!=EOF)length=0;
    fclose(file);return (int)length;
}

void m3d_LogFrame(void)
{
    if(m3d_DelfinoActive() && getenv("MELEE3D_NATIVE_DELFINO_VALIDATE") && (m3d_match_frame==120||m3d_match_frame==480))m3d_DelfinoValidate(m3d_match_frame);
    if(!m3d_StageIs3D() || m3d_match_frame%120)return;
    for(int i=0;i<GM_MAX_PLAYERS;++i) {
        HSD_GObj* object=Player_GetEntity(i);if(!object)continue;
        Fighter* fp=object->user_data;float lx,lz;
        if(!m3d_GetLane(fp,&lx,&lz))continue;
        fprintf(stderr,"M3D WORLD FRAME tick=%d slot=%d kind=%d x=%.4f y=%.4f z=%.4f lx=%.5f lz=%.5f yaw=%.5f cpu_frames=%d motion=%d vy=%.3f jumps=%u/%d flags=%x gravity=%.4f terminal=%.4f fast=%.4f falling=%d anim=%.2f phys=%p\n",
            m3d_match_frame,i,fp->kind,fp->cur_pos.x,fp->cur_pos.y,fp->cur_pos.z,lx,lz,m3d_CameraGetYaw(),m3d_CpuFrames(fp),fp->motion_id,fp->self_vel.y,fp->x1968_jumpsUsed,fp->co_attrs.max_jumps,fp->cpu.buttons,fp->co_attrs.gravity,fp->co_attrs.terminal_velocity,fp->co_attrs.fast_fall_velocity,fp->fall_fast,fp->cur_anim_frame,(void*)fp->phys_cb);
        if(!isfinite(fp->cur_pos.x) || !isfinite(fp->cur_pos.y) || !isfinite(fp->cur_pos.z)) {
            fprintf(stderr,"M3D LAB FAIL nonfinite native world position\n");abort();
        }
    }
}
