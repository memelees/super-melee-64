/* Source-defined convex playable unions. Geometry remains physically present;
 * this semantic boundary controls legal feet/grounded support, never ceilings. */
#ifndef M3D_PLAYABLE_REGIONS_H
#define M3D_PLAYABLE_REGIONS_H
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct {float x,z;} M3dRegionPoint;
typedef struct {M3dRegionPoint* points;unsigned count;float cap,lo[2],hi[2],sign;} M3dRegion;
typedef struct {float lo[2],hi[2],cap;unsigned first,count;int left,right;} M3dRegionNode;
typedef struct {M3dRegion*regions;M3dRegionNode*nodes;unsigned*order;unsigned count,node_count;float lo[2],hi[2];}M3dRegions;
static M3dRegions* m3d_region_sort_context;static int m3d_region_sort_axis;
static void m3d_regions_free(M3dRegions*r){for(unsigned i=0;i<r->count;i++)free(r->regions[i].points);free(r->regions);free(r->nodes);free(r->order);memset(r,0,sizeof(*r));}
static int m3d_region_compare(const void*a,const void*b){M3dRegion*x=&m3d_region_sort_context->regions[*(unsigned*)a],*y=&m3d_region_sort_context->regions[*(unsigned*)b];float u=x->lo[m3d_region_sort_axis]+x->hi[m3d_region_sort_axis],v=y->lo[m3d_region_sort_axis]+y->hi[m3d_region_sort_axis];return(u>v)-(u<v);}
static int m3d_regions_build(M3dRegions*r,unsigned first,unsigned count){int id=r->node_count++;M3dRegionNode*n=&r->nodes[id];n->lo[0]=n->lo[1]=1e20f;n->hi[0]=n->hi[1]=-1e20f;n->cap=-1e20f;n->first=first;n->count=count;
 for(unsigned i=first;i<first+count;i++){M3dRegion*p=&r->regions[r->order[i]];for(int k=0;k<2;k++){n->lo[k]=fminf(n->lo[k],p->lo[k]);n->hi[k]=fmaxf(n->hi[k],p->hi[k]);}n->cap=fmaxf(n->cap,p->cap);}
 if(count>8){m3d_region_sort_axis=n->hi[0]-n->lo[0]>n->hi[1]-n->lo[1]?0:1;m3d_region_sort_context=r;qsort(r->order+first,count,sizeof(unsigned),m3d_region_compare);unsigned half=count/2;n->left=m3d_regions_build(r,first,half);n->right=m3d_regions_build(r,first+half,count-half);n->count=0;}return id;}
/* Missing files preserve older source banks; malformed supplied files fail. */
static int m3d_regions_load(M3dRegions*r,const char*path){m3d_regions_free(r);FILE*f=fopen(path,"rb");if(!f)return 0;char magic[4];unsigned version,count;int ok=0;
 if(fread(magic,1,4,f)!=4||fread(&version,4,1,f)!=1||fread(&count,4,1,f)!=1||memcmp(magic,"OPR1",4)||version!=1||!count||count>8192)goto done;
 r->regions=calloc(count,sizeof(*r->regions));r->nodes=calloc(count*2,sizeof(*r->nodes));r->order=calloc(count,sizeof(*r->order));if(!r->regions||!r->nodes||!r->order)goto done;r->count=count;
 for(unsigned i=0;i<count;i++){M3dRegion*p=&r->regions[i];if(fread(&p->count,4,1,f)!=1||fread(&p->cap,4,1,f)!=1||p->count<3||p->count>64||!isfinite(p->cap)||fabsf(p->cap)>20000)goto done;
  p->points=calloc(p->count,sizeof(*p->points));if(!p->points||fread(p->points,sizeof(*p->points),p->count,f)!=p->count)goto done;p->lo[0]=p->lo[1]=1e20f;p->hi[0]=p->hi[1]=-1e20f;
  for(unsigned j=0;j<p->count;j++){M3dRegionPoint a=p->points[j],b=p->points[(j+1)%p->count],c=p->points[(j+2)%p->count];if(!isfinite(a.x)||!isfinite(a.z)||fabsf(a.x)>20000||fabsf(a.z)>20000)goto done;
   p->lo[0]=fminf(p->lo[0],a.x);p->hi[0]=fmaxf(p->hi[0],a.x);p->lo[1]=fminf(p->lo[1],a.z);p->hi[1]=fmaxf(p->hi[1],a.z);float cross=(b.x-a.x)*(c.z-b.z)-(b.z-a.z)*(c.x-b.x);if(fabsf(cross)>1e-6f){if(p->sign*cross<0)goto done;p->sign=cross;}}
  if(p->sign==0)goto done;
  for(unsigned j=0;j<p->count;j++){M3dRegionPoint a=p->points[j],b=p->points[(j+1)%p->count];float dx=b.x-a.x,dz=b.z-a.z,sign=p->sign>0?1:-1;
   for(unsigned k=0;k<p->count;k++){M3dRegionPoint q=p->points[k];if((dx*(q.z-a.z)-dz*(q.x-a.x))*sign<-.001f*hypotf(dx,dz))goto done;}}
  r->order[i]=i;
 }
 if(fgetc(f)!=EOF)goto done;m3d_regions_build(r,0,count);for(int k=0;k<2;k++){r->lo[k]=r->nodes[0].lo[k];r->hi[k]=r->nodes[0].hi[k];}ok=1;
 done:fclose(f);if(!ok){m3d_regions_free(r);return-1;}return 1;}
static bool m3d_regions_node(M3dRegions*r,int id,float x,float y,float z,bool grounded){M3dRegionNode*n=&r->nodes[id];if(x<n->lo[0]-.001f||x>n->hi[0]+.001f||z<n->lo[1]-.001f||z>n->hi[1]+.001f||(grounded&&y>n->cap+.01f))return false;
 if(!n->count)return m3d_regions_node(r,n->left,x,y,z,grounded)||m3d_regions_node(r,n->right,x,y,z,grounded);
 for(unsigned i=n->first;i<n->first+n->count;i++){M3dRegion*p=&r->regions[r->order[i]];if(grounded&&y>p->cap+.01f)continue;bool inside=true;float sign=p->sign>0?1:-1;
  for(unsigned j=0;j<p->count;j++){M3dRegionPoint a=p->points[j],b=p->points[(j+1)%p->count];float dx=b.x-a.x,dz=b.z-a.z,cross=(dx*(z-a.z)-dz*(x-a.x))*sign;if(cross<-.001f*hypotf(dx,dz)){inside=false;break;}}
  if(inside)return true;
 }return false;}
static bool m3d_regions_contains(M3dRegions*r,float x,float y,float z,bool grounded){return !r->count||m3d_regions_node(r,0,x,y,z,grounded);}
#endif
