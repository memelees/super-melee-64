#ifndef M3D_ONETT_TRAFFIC_MATH_H
#define M3D_ONETT_TRAFFIC_MATH_H
/* Source car callback distances sample real street lanes in world units. */
typedef struct {Vec3*points;float*distance;unsigned count;float length;}M3dTrafficPath;
static bool m3d_traffic_sample(const M3dTrafficPath*path,float distance,Vec3*position,Vec3*direction){
 if(path->count<2)return false;unsigned lo=0,hi=path->count-1;
 if(distance<=0)hi=1;else if(distance>=path->length)lo=path->count-2;else while(hi-lo>1){unsigned m=(lo+hi)/2;if(path->distance[m]<=distance)lo=m;else hi=m;}
 Vec3 a=path->points[lo],b=path->points[hi];float span=path->distance[hi]-path->distance[lo];if(span<=.001f)return false;float t=(distance-path->distance[lo])/span;
 *position=(Vec3){a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,a.z+(b.z-a.z)*t};float horizontal=hypotf(b.x-a.x,b.z-a.z);if(horizontal<=.001f)return false;*direction=(Vec3){(b.x-a.x)/horizontal,(b.y-a.y)/horizontal,(b.z-a.z)/horizontal};return true;
}
static float m3d_traffic_virtual_edge(float original,float length,float scale){return original<0?726-(length+160)/scale:-642+(length+160)/scale;}
static float m3d_traffic_progress(float center_x,bool reverse,float scale){return(reverse?center_x+642*scale:726*scale-center_x)-80;}
static void m3d_traffic_pose(Vec3 source_origin,Vec3 source_center,Vec3 road,Vec3 direction,float sign,Vec3*position,Vec3*rotation){
 float norm=sqrtf(1+direction.y*direction.y);
 Vec3 u={sign*direction.x/norm,sign*direction.y/norm,sign*direction.z/norm};
 Vec3 v={-direction.y*direction.x/norm,1/norm,-direction.y*direction.z/norm};
 Vec3 w={-sign*direction.z,0,sign*direction.x};
 Vec3 d={source_center.x-source_origin.x,source_center.y-source_origin.y,source_center.z-source_origin.z};
 *position=(Vec3){road.x-u.x*d.x-v.x*d.y-w.x*d.z,road.y+source_center.y-u.y*d.x-v.y*d.y-w.y*d.z,road.z-u.z*d.x-v.z*d.y-w.z*d.z};
 rotation->y=asinf(fmaxf(-1,fminf(1,-u.z)));
 if(fabsf(u.z)>.999999f){rotation->x=rotation->z=0;}
 else{rotation->x=atan2f(v.z,w.z);rotation->z=atan2f(u.y,u.x);}
}
#endif
