/* Native source port of the shared melee3d overlay; first stage gate: FD. */
/// 3D overlay for the shared item system. Item callbacks retain vanilla
/// lane-local velocity; only integration and model yaw enter world space.
#include "m3d.h"
#include "m3d_combat_rules.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dolphin/os.h>
#include <melee/ft/ftlib.h>
#include <melee/ft/inlines.h>
#include <melee/gr/types.h>
#include <melee/lb/lb_00B0.h>
#include <melee/it/types.h>
#include <melee/pl/player.h>
#include <melee/mp/mplib.h>
#include <sysdolphin/baselib/gobj.h>
#include <sysdolphin/baselib/jobj.h>
#include <sysdolphin/baselib/random.h>

#define M3D_ITEM_CAPACITY 256
#define M3D_ITEM_PI 3.14159265f

typedef struct M3dItem {
    Item* ip;
    float lx, lz;
    float pose_delta, posed_y;
    bool posed,controlled;
    int target_slot;
    int queries;
    int owner_slot, assist_slot, moving_frames;
    bool held_logged;
    float assist_distance;
    Vec3 query_origin;
    Vec3 spawn_origin;
} M3dItem;

static M3dItem m3d_items[M3D_ITEM_CAPACITY];
static M3dItem* m3d_query;
static HSD_GObj* m3d_query_item_target;
static M3dItem* m3d_ItemGet(Item* ip);

static bool item_onett_car(Item* ip)
{
    if (!m3d_ReferenceOverlayActive() || !ip || ip->kind!=It_PKind_Random ||
        ip->xDD4_itemVar.yaku.x2!=1) return false;
    Ground* gp=ip->xDD4_itemVar.yaku.x10;
    if (!gp || gp->map_id!=3) return false;
    HSD_JObj* bone=ip->xDD4_itemVar.yaku.x4_u.x4;
    for (int i=0;i<4;i++) if (gp->u.onettcar.car_jobjs[i]==bone) return true;
    return false;
}


/* Original callers sometimes set a bone query's Z to zero before spawning.
 * Keep the unmodified result long enough for the shared spawn adapter to
 * recover that one coordinate. Match buffer identity, root, frame and XY;
 * never guess depth from X (which is singular when firing along Z). */
#define M3D_WORLD_POINTS 64
static struct {
    Vec3* buffer;
    HSD_JObj* root;
    Vec3 pos;
    int frame;
} m3d_world_points[M3D_WORLD_POINTS];
static int m3d_world_point_next;

void m3d_ItemsReset(void)
{
    int i;
    for (i = 0; i < M3D_ITEM_CAPACITY; i++) m3d_items[i].ip = NULL;
    for (i = 0; i < M3D_WORLD_POINTS; i++) {
        m3d_world_points[i].buffer = NULL;
        m3d_world_points[i].frame = -1;
    }
    m3d_world_point_next = 0;
    m3d_query = NULL;
    m3d_query_item_target = NULL;
}

void m3d_RecordWorldPoint(HSD_JObj* bone, Vec3* pos)
{
    int i;
    if (!m3d_StageIs3D() || bone == NULL) {
        return;
    }
    while (HSD_JObjGetParent(bone) != NULL) {
        bone = HSD_JObjGetParent(bone);
    }
    m3d_WorldBonePoint(bone, pos);
    for (i = 0; i < M3D_ITEM_CAPACITY; i++) {
        M3dItem* m = &m3d_items[i];
        if (m->ip && m->ip->entity->hsd_obj == bone && !m->posed &&
            !m->ip->xDC8_word.flags.x13) {
            /* Stage cars already report actual source-bone world points.
             * Applying a random dropped-item lane would rotate their hits
             * away from the visible road/model. */
            if (item_onett_car(m->ip)) break;
            float dx=pos->x-m->ip->pos.x, dz=pos->z-m->ip->pos.z;
            pos->x=m->ip->pos.x+dx*m->lx-dz*m->lz;
            pos->z=m->ip->pos.z+dx*m->lz+dz*m->lx;
            break;
        }
    }
    i = m3d_world_point_next;
    m3d_world_points[i].buffer = pos;
    m3d_world_points[i].root = bone;
    m3d_world_points[i].pos = *pos;
    m3d_world_points[i].frame = m3d_match_frame;
    m3d_world_point_next = (i + 1) % M3D_WORLD_POINTS;
}

void m3d_ItemSpawnPos(HSD_GObj* parent, Vec3* source, Vec3* dest)
{
    int n, i;
    bool found = false;
    float depth = 0.0f;
    *dest = *source;
    if (!m3d_EntityIs3D(parent)) {
        if (!m3d_StageIs3D()) dest->z = 0.0f;
        return;
    }
    if (source->z != 0.0f) {
        return;
    }
    for (n = 1; n <= M3D_WORLD_POINTS; n++) {
        i = (m3d_world_point_next + M3D_WORLD_POINTS - n) % M3D_WORLD_POINTS;
        if (m3d_world_points[i].buffer == source &&
            m3d_world_points[i].root == parent->hsd_obj &&
            m3d_world_points[i].frame == m3d_match_frame &&
            m3d_world_points[i].pos.x == source->x)
        {
            dest->z = m3d_world_points[i].pos.z;
            return;
        }
    }
    /* Some callers copy the query into a SpawnItem before zeroing Z. Only
     * recover a copied value if its owner/frame/XY identify one depth. */
    for (n = 1; n <= M3D_WORLD_POINTS; n++) {
        i = (m3d_world_point_next + M3D_WORLD_POINTS - n) % M3D_WORLD_POINTS;
        if (m3d_world_points[i].root == parent->hsd_obj &&
            m3d_world_points[i].frame == m3d_match_frame &&
            m3d_world_points[i].pos.x == source->x &&
            m3d_world_points[i].pos.y == source->y)
        {
            if (found && depth != m3d_world_points[i].pos.z) {
                found = false; break; /* ambiguous: use the owner anchor */
            }
            depth = m3d_world_points[i].pos.z;
            found = true;
        }
    }
    if (found) {
        dest->z = depth;
    } else {
        Vec3 anchor;
        float lx, lz, dx;
        if (ftLib_IsFighter(parent)) {
            ftLib_GetPos(parent,&anchor);
            m3d_GetLane(GET_FIGHTER(parent),&lx,&lz);
        } else {
            Item* ip=parent->user_data;
            M3dItem* m=m3d_ItemGet(ip);
            if (!m) return;
            anchor=ip->pos; lx=m->lx; lz=m->lz;
        }
        dx=source->x-anchor.x;
        dest->x=anchor.x+dx*lx;
        dest->z=anchor.z+dx*lz;
    }
}

void m3d_ItemPrepareSpawn(SpawnItem* spawn)
{
    HSD_GObj* source=spawn->x0_parent_gobj;
    /* Native Pokemon/container children retain an owner in x0, but the
     * physical emitter (ball/container/weapon) lives in x4. */
    if (m3d_EntityIs3D(spawn->x4_parent_gobj2)) source=spawn->x4_parent_gobj2;
    if (m3d_EntityIs3D(source)) {
        m3d_ItemSpawnPos(source,&spawn->prev_pos,&spawn->prev_pos);
    }
}

bool m3d_ItemReleasePoint(Item* ip, Vec3* point)
{
    M3dItem* m=m3d_ItemGet(ip);
    if (!m) return false;
    if (ftLib_IsFighter(ip->owner)) {
        m3d_GetLane(GET_FIGHTER(ip->owner),&m->lx,&m->lz);
        m->owner_slot=GET_FIGHTER(ip->owner)->player_idx;
    }
    m3d_ItemSpawnPos(ip->owner,point,point);
    m->moving_frames=0; m->assist_distance=0; m->assist_slot=-1;
    return true;
}

float m3d_ItemDeltaX(Item* ip, Vec3* from, Vec3* to)
{
    M3dItem* m=m3d_ItemGet(ip);
    return m ? (to->x-from->x)*m->lx+(to->z-from->z)*m->lz : to->x-from->x;
}

float m3d_ItemWorldYaw(Item* ip, float native_yaw)
{
    M3dItem* m=m3d_ItemGet(ip);
    return m && !m->posed ? native_yaw+atan2f(m->lx,m->lz)-M3D_ITEM_PI/2 : native_yaw;
}

static M3dItem* m3d_ItemGet(Item* ip)
{
    int i;
    if (!m3d_StageIs3D() || ip == NULL) {
        return NULL;
    }
    for (i = 0; i < M3D_ITEM_CAPACITY; i++) {
        M3dItem* m = &m3d_items[i];
        if (m->ip == ip) {
            /* Attached articles (e.g. a blaster) follow the current owner.
             * Released projectiles keep the lane captured at spawn. */
            if (item_onett_car(ip)) {
                /* The attached car callback owns world-space placement;
                 * preserve it through QueryEnd and native model posing. */
                m->lx=1; m->lz=0;
            } else if (ip->xDC8_word.flags.x13 && ftLib_IsFighter(ip->owner)) {
                m3d_GetLane(GET_FIGHTER(ip->owner), &m->lx, &m->lz);
            }
            return m;
        }
    }
    return NULL;
}

bool m3d_EntityIs3D(HSD_GObj* gobj)
{
    if (ftLib_IsFighter(gobj)) {
        return m3d_FighterIs3D(GET_FIGHTER(gobj));
    }
    return gobj != NULL && gobj->classifier == HSD_GOBJ_CLASS_ITEM &&
           m3d_ItemGet(gobj->user_data) != NULL;
}

void m3d_ItemInit(Item* ip, HSD_GObj* parent)
{
    float lx, lz;
    M3dItem* p;
    int i;
    if (!m3d_StageIs3D()) {
        return;
    }
    lx = 1.0f; lz = 0.0f;
    if (ftLib_IsFighter(parent)) {
        if (!m3d_GetLane(GET_FIGHTER(parent), &lx, &lz)) {
            return;
        }
    } else if (parent && parent->classifier == HSD_GOBJ_CLASS_ITEM &&
               (p = m3d_ItemGet(parent->user_data)) != NULL)
    {
        lx = p->lx;
        lz = p->lz;
    } else if (parent == NULL) {
        /* Map drops face a random heading, so walking or sliding items
         * (Bob-omb, Mr. Saturn, shells) spread out instead of all moving along X. */
        float a = HSD_Randf() * 2 * M3D_ITEM_PI;
        lx = cosf(a);
        lz = sinf(a);
    }
    if(ip->kind==It_Kind_Matadogas_Gas1 || ip->kind==It_Kind_Matadogas_Gas2) {
        float angle=HSD_Randf()*2*M3D_ITEM_PI;
        lx=cosf(angle);lz=sinf(angle);
    }
    for (i = 0; i < M3D_ITEM_CAPACITY; i++) {
        M3dItem* m = &m3d_items[i];
        if (m->ip == NULL) {
            m->ip = ip;
            m->lx = lx;
            m->lz = lz;
            m->posed = false;
            m->controlled=false;
            m->target_slot = -1;
            m->queries = 0;
            m->owner_slot = ftLib_IsFighter(parent) ? GET_FIGHTER(parent)->player_idx : -1;
            if (parent && parent->classifier==HSD_GOBJ_CLASS_ITEM) {
                M3dItem* source=m3d_ItemGet(parent->user_data);
                if (source) m->owner_slot=source->owner_slot;
            }
            m->assist_slot=-1; m->moving_frames=0; m->assist_distance=0;
            m->held_logged=false;
            m->spawn_origin=ip->pos;
            if(getenv("MELEE3D_NATIVE_AREA_LIFECYCLE") && parent && parent->classifier==HSD_GOBJ_CLASS_ITEM)
                fprintf(stderr,"M3D AREA CHILD kind=%d parent=%d pos=%.3f,%.3f,%.3f\n",ip->kind,((Item*)parent->user_data)->kind,ip->pos.x,ip->pos.y,ip->pos.z);
            if (m3d_cfg.log_every > 0) {
                OSReport("M3D SPAWN kind=%d x=%d y=%d z=%d lx=%d lz=%d\n",
                         ip->kind, (int) (ip->pos.x * 100),
                         (int) (ip->pos.y * 100), (int) (ip->pos.z * 100),
                         (int) (lx * 100), (int) (lz * 100));
            }
            return;
        }
    }
}

/* Returning aerial summons must leave the local fight, rather than travel
 * to the top of a mega-map's tallest landmark. Keep the native rise speed,
 * hidden wait, expansion and fall; only replace its off-screen boundary. */
float m3d_ItemReturnTop(Item* ip,float original)
{
    M3dItem* m=m3d_ItemGet(ip);
    bool returns=ip->kind==It_PKind_Kabigon||ip->kind==It_PKind_Lugia||ip->kind==It_PKind_Houou;
    return m && returns ? fminf(original,m->spawn_origin.y+200.0f) : original;
}

static void item_usage_end(M3dItem* m);
void m3d_ItemForget(Item* ip)
{
    int i;
    for (i = 0; i < M3D_ITEM_CAPACITY; i++) {
        if (m3d_items[i].ip == ip) {
            item_usage_end(&m3d_items[i]);
            if (m3d_query == &m3d_items[i]) {
                m3d_query = NULL;
                m3d_query_item_target = NULL;
            }
            m3d_items[i].ip = NULL;
            return;
        }
    }
}

int m3d_ItemAssistSlot(Item* ip)
{
    M3dItem* m=m3d_ItemGet(ip);
    return m ? m->assist_slot : -1;
}
static void projectile_assist(M3dItem* m, Vec3* velocity)
{
    Item* ip=m->ip;
    HSD_GObj* owner;
    HSD_GObj* target;
    Fighter* fp;
    Vec3 goal;
    float sign,dx,dz,current,desired,delta;
    if (m->controlled || m->queries || (ip->hold_kind!=ITEM_HOLD_8 && ip->hold_kind!=ITEM_HOLD_1) ||
        ip->ground_or_air!=GA_Air || fabsf(velocity->x)<0.25f) return;
    if (ftLib_IsFighter(ip->owner) && m->owner_slot!=GET_FIGHTER(ip->owner)->player_idx) {
        m->owner_slot=GET_FIGHTER(ip->owner)->player_idx;
        m->assist_slot=-1; m->moving_frames=0; m->assist_distance=0;
    }
    if (m->owner_slot<0 || !(owner=Player_GetEntityAtIndex(m->owner_slot,0))) return;
    fp=GET_FIGHTER(owner);
    sign=velocity->x<0 ? -1.0f : 1.0f;
    if (m->moving_frames++==0) {
        target=m3d_AimTarget(fp,&ip->pos,m->lx*sign,m->lz*sign);
        m->assist_slot=target ? GET_FIGHTER(target)->player_idx : -1;
    }
    float turn=.0349066f;
    if(m3d_ProjectileDistanceAssist()) {
        turn=m3d_combat_projectile_turn(hypotf(velocity->x,velocity->z),m->assist_distance);
        m->assist_distance+=hypotf(velocity->x,velocity->z);
    } else if(m->moving_frames>24)return;
    if (turn<=0 || m->assist_slot<0 ||
        !(target=Player_GetEntityAtIndex(m->assist_slot,0))) return;
    if (GET_FIGHTER(target)->is_sleeping || GET_FIGHTER(target)->motion_id<=ftCo_MS_RebirthWait) {
        m->assist_slot=-1; return;
    }
    goal=GET_FIGHTER(target)->cur_pos; goal.y+=8;
    if (!m3d_SegmentClear(&ip->pos,&goal)) { m->assist_slot=-1; return; }
    dx=goal.x-ip->pos.x; dz=goal.z-ip->pos.z;
    if (dx*velocity->x*m->lx+dz*velocity->x*m->lz<=0) return;
    current=atan2f(m->lx,m->lz); desired=atan2f(dx*sign,dz*sign);
    delta=desired-current;
    while (delta>M3D_ITEM_PI) delta-=2*M3D_ITEM_PI;
    while (delta<-M3D_ITEM_PI) delta+=2*M3D_ITEM_PI;
    if (delta>turn) delta=turn;
    if (delta<-turn) delta=-turn;
    m->lx=sinf(current+delta); m->lz=cosf(current+delta);
}

/* Controllable articles consume the owner's cached world input. Native
 * callbacks retain their pitch turn rate, speed, lifetime and release rules. */
bool m3d_ItemControl(Item* ip,HSD_GObj* owner,float turn,float* x,float* y)
{
    M3dItem* m=m3d_ItemGet(ip);Vec2 world,cstick;bool throttle;
    if(!m || !ftLib_IsFighter(owner))return false;
    m->controlled=true;
    Fighter* fp=GET_FIGHTER(owner);
    if(Player_GetPlayerSlotType(fp->player_idx)!=Gm_PKind_Human ||
       !m3d_GetMoveInput(fp,&world,&cstick,&throttle))return false;
    float mag=hypotf(world.x,world.y),sign=ip->x40_vel.x<0 ? -1:1;
    if(mag>.001f) {
        float angle=atan2f(m->lz,m->lx),desired=atan2f(sign*world.y,sign*world.x),delta=desired-angle;
        while(delta>M3D_ITEM_PI)delta-=2*M3D_ITEM_PI;
        while(delta<-M3D_ITEM_PI)delta+=2*M3D_ITEM_PI;
        delta=fmaxf(-turn,fminf(turn,delta));m->lx=cosf(angle+delta);m->lz=sinf(angle+delta);
    }
    *x=sign*mag;*y=m3d_SeparateAttackInputs()?m3d_GetVerticalInput(fp):m3d_CameraGetMode()==0 && !throttle ? 0:cstick.y;
    if(m3d_SeparateAttackInputs())m3d_combat_di(x,y);
    return true;
}
/* PK Thunder's head turns in a full sphere. Keep native speed and angular
 * response, then express the result through the shared lane integrator. */
float m3d_ThunderSpeed(void){return m3d_StageIs3D()?.6f:1;}
float m3d_ThunderLifetime(void){return 1;}
bool m3d_ThunderLaunch(Item* ip,HSD_GObj* owner,float speed)
{
    M3dItem* m=m3d_ItemGet(ip);if(!m||!ftLib_IsFighter(owner))return false;
    Fighter* fp=GET_FIGHTER(owner);float x,z;if(!m3d_GetLane(fp,&x,&z))return false;
    m->lx=x*fp->facing_dir;m->lz=z*fp->facing_dir;m->controlled=true;
    Vec3 center=fp->cur_pos;if(m3d_MapIsActive(fp))m3d_MapToWorld(&center);
    /* Use the native self-hit centre, rather than the raised casting hand.
     * Start outside its initial separation latch, along the real 3D facing. */
    float scale=fp->x34_scale.y;
    ip->pos=(Vec3){center.x+m->lx*15*scale,center.y+5*scale,center.z+m->lz*15*scale};
    ip->x378_itemColl.cur_pos=ip->x378_itemColl.prev_pos=ip->x378_itemColl.last_pos=ip->pos;
    m->spawn_origin=ip->pos;
    ip->x40_vel=(Vec3){speed,0,0};ip->facing_dir=1;return true;
}
bool m3d_ItemSteerVelocity(Item* ip,HSD_GObj* owner,float turn,float speed)
{
    M3dItem* m=m3d_ItemGet(ip);Vec2 world,cstick;bool throttle;
    if(!m||!ftLib_IsFighter(owner))return false;
    Fighter* fp=GET_FIGHTER(owner);
    if(Player_GetPlayerSlotType(fp->player_idx)!=Gm_PKind_Human||!m3d_SeparateAttackInputs()||
       !m3d_GetMoveInput(fp,&world,&cstick,&throttle))return false;
    m->controlled=true;
    Vec3 desired={world.x,m3d_GetVerticalInput(fp),world.y};
    float length=sqrtf(desired.x*desired.x+desired.y*desired.y+desired.z*desired.z);
    if(length<.2f)return true;
    desired.x/=length;desired.y/=length;desired.z/=length;
    Vec3 current={ip->x40_vel.x*m->lx,ip->x40_vel.y,ip->x40_vel.x*m->lz};
    length=sqrtf(current.x*current.x+current.y*current.y+current.z*current.z);
    if(length<.001f)current=(Vec3){0,1,0};
    else {current.x/=length;current.y/=length;current.z/=length;}
    float dot=fmaxf(-1,fminf(1,current.x*desired.x+current.y*desired.y+current.z*desired.z));
    float angle=acosf(dot),step=fminf(angle,turn*fminf(1,angle/(M3D_ITEM_PI/4)));
    if(angle>.00001f) {
        Vec3 tangent={desired.x-dot*current.x,desired.y-dot*current.y,desired.z-dot*current.z};
        float norm=sqrtf(tangent.x*tangent.x+tangent.y*tangent.y+tangent.z*tangent.z);
        if(norm<.0001f) { /* Exactly opposite input still needs a turn axis. */
            /* Reversing a horizontal stick must not invent vertical input. */
            tangent=(Vec3){-current.z,0,current.x};
            norm=hypotf(tangent.x,tangent.z);
            if(norm<.0001f){tangent=(Vec3){m->lx,0,m->lz};norm=1;}
        }
        float c=cosf(step),s=sinf(step)/norm;
        current=(Vec3){current.x*c+tangent.x*s,current.y*c+tangent.y*s,current.z*c+tangent.z*s};
    }
    float horizontal=hypotf(current.x,current.z);
    if(horizontal>.0001f){m->lx=current.x/horizontal;m->lz=current.z/horizontal;}
    ip->x40_vel=(Vec3){horizontal*speed,current.y*speed,0};
    return true;
}
bool m3d_ItemSteer3D(Item* ip,HSD_GObj* owner,float turn,float speed)
{
    if(!m3d_ItemSteerVelocity(ip,owner,turn,speed))return false;
    ip->xDD4_itemVar.pkthunder.angles[0]=atan2f(ip->x40_vel.y,ip->x40_vel.x);
    return true;
}

bool m3d_ItemTrailFrame(Item* ip,Vec3* next,float* pitch)
{
    M3dItem* m=m3d_ItemGet(ip);if(!m)return false;
    float dx=ip->pos.x-next->x,dz=ip->pos.z-next->z,horizontal=hypotf(dx,dz);
    if(horizontal>.0001f){m->lx=dx/horizontal;m->lz=dz/horizontal;}
    ip->facing_dir=1;m->controlled=true;
    *pitch=atan2f(ip->pos.y-next->y,horizontal);
    return true;
}

bool m3d_ItemControlAccel(Item* ip,HSD_GObj* owner,float acceleration,float maximum)
{
    M3dItem* m=m3d_ItemGet(ip);Vec2 world,cstick;bool throttle;
    if(!m || !ftLib_IsFighter(owner))return false;
    m->controlled=true;Fighter* fp=GET_FIGHTER(owner);
    if(Player_GetPlayerSlotType(fp->player_idx)!=Gm_PKind_Human ||
       !m3d_GetMoveInput(fp,&world,&cstick,&throttle))return false;
    if(hypotf(world.x,world.y)>.2f) {
        float vx=ip->x40_vel.x*m->lx+acceleration*world.x,vz=ip->x40_vel.x*m->lz+acceleration*world.y;
        float speed=hypotf(vx,vz);
        if(speed>.001f){m->lx=vx/speed;m->lz=vz/speed;ip->x40_vel.x=fminf(speed,maximum);}
    }
    return true;
}

bool m3d_ItemAddVel(Item* ip, Vec3* v)
{
    M3dItem* m = m3d_ItemGet(ip);
    if (m == NULL) {
        return false;
    }
    projectile_assist(m,v);
    ip->pos.x += v->x * m->lx - v->z * m->lz;
    ip->pos.y += v->y;
    ip->pos.z += v->x * m->lz + v->z * m->lx;
    return true;
}

void m3d_ItemUnpose(Item* ip)
{
    M3dItem* m = m3d_ItemGet(ip);
    HSD_JObj* jobj;
    if (m == NULL || !m->posed) {
        return;
    }
    jobj = ip->entity->hsd_obj;
    /* A state change may already have replaced the rotation. */
    if (HSD_JObjGetRotationY(jobj) == m->posed_y) {
        HSD_JObjSetRotationY(jobj, m->posed_y - m->pose_delta);
    }
    m->posed = false;
}

/* Onett's native scripts put their hit spheres thirty units toward the
 * original 2D fighting plane. The 3D hazard must follow the actual visible
 * model child (including its source steering/spin and ground-scale parent).
 * Keep native script damage, radius, height, element and victim histories. */
static void item_onett_car_hitboxes(Item* ip)
{
    if (!item_onett_car(ip)) return;
    Ground* gp=ip->xDD4_itemVar.yaku.x10;
    HSD_JObj* bone=ip->xDD4_itemVar.yaku.x4_u.x4;
    const float center_x[4]={1.75f,-1.25f,2.0f,-.25f};
    const float center_z[4]={.125f,.125f,.125f,-.125f};
    for (int model=0;model<4;model++) if(gp->u.onettcar.car_jobjs[model]==bone) {
        HSD_JObj* child=HSD_JObjGetChild(bone);
        if (!child) return;
        for (int i=0;i<4;i++) {
            HitCapsule* hit=&ip->x5D4_hitboxes[i].hit;
            if(hit->state==HitCapsule_Disabled)continue;
            hit->jobj=child;
            hit->b_offset.x=center_x[model];
            hit->b_offset.z=center_z[model];
        }
        return;
    }
}

void m3d_ItemPose(Item* ip)
{
    M3dItem* m = m3d_ItemGet(ip);
    HSD_JObj* jobj;
    if (m == NULL || ip->xDC8_word.flags.x13) {
        return;
    }
    item_onett_car_hitboxes(ip);
    m3d_ItemUnpose(ip);
    jobj = ip->entity->hsd_obj;
    m->pose_delta = atan2f(m->lx, m->lz) - M3D_ITEM_PI / 2;
    m->posed_y = HSD_JObjGetRotationY(jobj) + m->pose_delta;
    HSD_JObjSetRotationY(jobj, m->posed_y);
    m->posed = true;
}

/* These attacks surround their emitter. Their native cross-section often
 * consists of several ordinary spheres placed left/right along the 2D lane.
 * Revolve that section about world Y for each recipient; do not scale a shape,
 * flatten depth, change vertical reach, or make directional attacks radial.
 * Position-only borrowing keeps the real capsules and victim histories intact.
 */
static bool item_area_kind(Item* ip)
{
    switch(ip->kind) {
    case It_PKind_Kireihana: /* Sleep Powder */
    case It_PKind_Raikou:    /* Spark */
    case It_PKind_Entei:     /* Fire Spin */
    case It_PKind_Thunder:   /* Thundershock */
    case It_PKind_Pippi:     /* Metronome */
    case It_PKind_Freezer:   /* Blizzard */
    case It_PKind_Fushigibana: /* Earthquake */
    case It_PKind_Togepy:    /* Metronome's local effects */
    case It_PKind_Kabigon:   /* Body Slam */
        return true;
    case It_Kind_BombHei:
        return ip->msid==11;
    case It_Kind_MSBomb:
        return ip->msid==6;
    case It_Kind_WStar: /* The impact is radial, the moving ride is not. */
        return ip->msid==5;
    case It_Kind_Link_Bomb:
    case It_Kind_CLink_Bomb:
        return ip->msid==5;
    case It_Kind_Samus_Bomb:
        return ip->msid==3;
    case It_PKind_Marumine:  /* Selfdestruct only; not its rolling body */
        return ip->msid==6;
    default:
        return false;
    }
}

bool m3d_ItemAreaBegin(Item* ip, Vec3* target, Vec3 saved[8])
{
    if(!item_area_kind(ip))return false;
    if(getenv("MELEE3D_NATIVE_AREA_BASELINE"))return false;
    M3dItem* m=m3d_ItemGet(ip);
    if(!m)return false;
    float dx=target->x-ip->pos.x,dz=target->z-ip->pos.z;
    float length=hypotf(dx,dz);
    if(length<.001f)return false;
    /* The nearer half of the original section retains its native side. */
    float sign=dx*m->lx+dz*m->lz<0 ? -1.0f:1.0f;
    float tx=sign*dx/length,tz=sign*dz/length;
    float c=tx*m->lx+tz*m->lz,s=tz*m->lx-tx*m->lz;
    for(int i=0;i<4;i++) {
        HitCapsule* h=&ip->x5D4_hitboxes[i].hit;
        saved[i*2]=h->x4C;saved[i*2+1]=h->x58;
        if(h->state==HitCapsule_Disabled)continue;
        Vec3* points[2]={&h->x4C,&h->x58};
        for(int n=0;n<2;n++) {
            Vec3* p=points[n];dx=p->x-ip->pos.x;dz=p->z-ip->pos.z;
            p->x=ip->pos.x+c*dx-s*dz;
            p->z=ip->pos.z+s*dx+c*dz;
        }
    }
    return true;
}

void m3d_ItemAreaEnd(Item* ip, bool began, Vec3 saved[8])
{
    if(!began)return;
    for(int i=0;i<4;i++) {
        ip->x5D4_hitboxes[i].hit.x4C=saved[i*2];
        ip->x5D4_hitboxes[i].hit.x58=saved[i*2+1];
    }
}

float m3d_ItemHitDirection(Fighter* victim, Item* ip, float vanilla_dir)
{
    M3dItem* m = m3d_ItemGet(ip);
    float dir = ip->x40_vel.x;
    float side;
    if (m == NULL || !m3d_FighterIs3D(victim)) {
        return vanilla_dir;
    }
    if(item_onett_car(ip)) {
        if(getenv("MELEE3D_NATIVE_ONETT_CAR_PROBE"))fprintf(stderr,"M3D CAR PROBE SELECT tick=%d slot=%u kind=%d item=%p native_damage_selected=1\n",m3d_match_frame,victim->player_idx,ip->kind,(void*)ip->entity);
        /* The source car model may now follow a north/south city street.
         * Recover its actual world X axis after yaw/pitch; item lanes remain
         * identity because the attached bones already own world placement. */
        Vec3 origin,local={1,0,0},point;
        HSD_JObj* bone=ip->xDD4_itemVar.yaku.x4_u.x4;
        lb_8000B1CC(bone,NULL,&origin);lb_8000B1CC(bone,&local,&point);
        float lx=point.x-origin.x,lz=point.z-origin.z,length=hypotf(lx,lz);
        if(length>.001f){lx/=length;lz/=length;float side=(victim->cur_pos.x-ip->pos.x)*lx+(victim->cur_pos.z-ip->pos.z)*lz;
            m3d_SetLane(victim,side<0?-lx:lx,side<0?-lz:lz);return -1.0f;}
    }
    if(item_area_kind(ip)) {
        float dx=victim->cur_pos.x-ip->pos.x,dz=victim->cur_pos.z-ip->pos.z;
        float length=hypotf(dx,dz);
        if(length>.001f){m3d_SetLane(victim,dx/length,dz/length);return -1.0f;}
    }
    if (dir > -0.0001f && dir < 0.0001f) {
        side = (victim->cur_pos.x - ip->pos.x) * m->lx +
               (victim->cur_pos.z - ip->pos.z) * m->lz;
        dir = side;
    }
    if (dir < 0.0f) {
        m3d_SetLane(victim, -m->lx, -m->lz);
    } else {
        m3d_SetLane(victim, m->lx, m->lz);
    }
    return -1.0f;
}

/* Collision queries borrow a stage slice, but return world coordinates
 * before any character/item callbacks run. Velocities and normals remain
 * in the native lane-local frame so vanilla bounce calculations survive. */
bool m3d_ItemCollBegin(CollData* coll)
{
    HSD_GObj* gobj = coll->x0_gobj;
    M3dItem* m;
    if (ftLib_IsFighter(gobj)) {
        Fighter* fp = GET_FIGHTER(gobj);
        float lx, lz;
        if (!m3d_GetLane(fp, &lx, &lz) ||
            !m3d_MapBegin(coll, &coll->cur_pos, lx, lz)) return false;
        m3d_MapCollToLocal(coll);
        return true;
    }
    if (gobj == NULL || gobj->classifier != HSD_GOBJ_CLASS_ITEM) return false;
    m = m3d_ItemGet(gobj->user_data);
    if (m == NULL || !m3d_MapBegin(coll, &coll->cur_pos, m->lx, m->lz)) {
        return false;
    }
    m3d_MapCollToLocal(coll);
    return true;
}

void m3d_ItemCollEnd(CollData* coll, bool began)
{
    if (began && m3d_MapIsActive(coll)) {
        m3d_MapCollToWorld(coll);
        m3d_MapEnd(coll);
    }
}

bool m3d_ItemRayCast(HSD_GObj* gobj, Vec3* from, Vec3* to, Vec3* normal,
                       int* line, u32* flags, int joint_only)
{
    M3dItem* m = NULL;
    Vec3 a = *from, b = *to, hit;
    bool began = false;
    bool result;
    if (gobj != NULL && gobj->classifier == HSD_GOBJ_CLASS_ITEM) {
        m = m3d_ItemGet(gobj->user_data);
    }
    if (m != NULL) {
        began = m3d_MapBegin(&hit, to, m->lx, m->lz);
    }
    if (began) {
        m3d_MapToLocal(&a);
        m3d_MapToLocal(&b);
    }
    result = mpCheckAllRemap(&hit, line, flags, normal, -1, joint_only,
                              a.x, a.y, b.x, b.y);
    if (began) {
        if (result) {
            m3d_MapToWorld(&hit);
        }
        m3d_MapEnd(&hit);
    }
    if (result) {
        *to = hit;
    }
    return result;
}

/* A read-only query view for native item physics. Entity positions, models,
 * velocity, gravity and character data never enter this frame. Only the
 * shared target helpers adapt their metrics and returned target points. */
bool m3d_ItemQueryBegin(Item* ip)
{
    M3dItem* m = m3d_ItemGet(ip);
    if (m == NULL || m3d_query != NULL || ip->xDC8_word.flags.x13) {
        return false;
    }
    m3d_query = m;
    m->query_origin=ip->pos;
    if (m->target_slot>=0) {
        HSD_GObj* target=Player_GetEntityAtIndex(m->target_slot,0);
        if (target && !GET_FIGHTER(target)->is_sleeping) {
            Vec3 goal=GET_FIGHTER(target)->cur_pos;
            float dx=goal.x-ip->pos.x,dz=goal.z-ip->pos.z;
            float length=sqrtf(dx*dx+dz*dz);
            float sign=ip->x40_vel.x<0 ? -1.0f : ip->x40_vel.x>0 ? 1.0f : ip->facing_dir;
            if (length>1) { m->lx=sign*dx/length; m->lz=sign*dz/length; }
        }
    }
    m3d_query_item_target = NULL;
    return true;
}

void m3d_ItemQueryEnd(Item* ip, bool began)
{
    if (began && m3d_query != NULL && m3d_query->ip == ip) {
        M3dItem* m=m3d_query;
        Vec3* before=&m->query_origin;
        float dx=ip->pos.x-before->x;
        float dz=ip->pos.z==0 ? 0 : ip->pos.z-before->z;
        /* Direct planar movement in an autonomous native callback follows its
         * item lane too. Map collision already returned world coordinates. */
        if (ip->pos.x!=ip->x378_itemColl.cur_pos.x ||
            ip->pos.z!=ip->x378_itemColl.cur_pos.z) {
            ip->pos.x=before->x+dx*m->lx-dz*m->lz;
            ip->pos.z=before->z+dx*m->lz+dz*m->lx;
        }
        m3d_query = NULL;
        m3d_query_item_target = NULL;
    }
}

float m3d_ItemQuerySide(Vec3* from, Vec3* to, float vanilla_dx)
{
    if (m3d_query == NULL) {
        return vanilla_dx;
    }
    return (to->x - from->x) * m3d_query->lx +
           (to->z - from->z) * m3d_query->lz;
}

float m3d_ItemQueryDistance(Vec3* from, Vec3* to, float vanilla_dist_sq)
{
    float dx, dy, dz;
    if (m3d_query == NULL) {
        return vanilla_dist_sq;
    }
    dx = to->x - from->x;
    dy = to->y - from->y;
    dz = to->z - from->z;
    return dx * dx + dy * dy + dz * dz;
}

void m3d_ItemQueryPoint(Vec3* point)
{
    float dx, dz;
    Vec3* origin;
    if (m3d_query == NULL) {
        return;
    }
    origin = &m3d_query->ip->pos;
    dx = point->x - origin->x;
    dz = point->z - origin->z;
    point->x = origin->x + dx * m3d_query->lx + dz * m3d_query->lz;
    point->z = origin->z - dx * m3d_query->lz + dz * m3d_query->lx;
}

/* Summons which read a fighter directly still run a planar native planner.
 * Give that planner a slice through its chosen target, just as for the CPU.
 * Fighter-owned equipment uses GetPos for attachment, so retains world space. */
void m3d_ItemFighterPoint(HSD_GObj* target, Vec3* point)
{
    M3dItem* m=m3d_query;
    Item* ip;
    float dx,dz,length,sign;
    if (!m) return;
    ip=m->ip;
    if (ip->hold_kind!=ITEM_HOLD_9 && ip->hold_kind!=ITEM_HOLD_10) return;
    dx=point->x-ip->pos.x; dz=point->z-ip->pos.z;
    length=sqrtf(dx*dx+dz*dz);
    sign=ip->facing_dir<0 ? -1.0f : 1.0f;
    if (length>1) { m->lx=sign*dx/length; m->lz=sign*dz/length; }
    m3d_ItemQueryRecord(target);
    point->x=ip->pos.x+dx*m->lx+dz*m->lz;
    point->z=ip->pos.z;
}

void m3d_ItemQueryRecord(HSD_GObj* target)
{
    if (m3d_query == NULL) {
        return;
    }
    m3d_query->queries++;
    m3d_query->target_slot = -1;
    m3d_query_item_target = NULL;
    if (ftLib_IsFighter(target)) {
        m3d_query->target_slot = GET_FIGHTER(target)->player_idx;
    } else if (target != NULL && target->classifier == HSD_GOBJ_CLASS_ITEM) {
        m3d_query->target_slot = -2;
        m3d_query_item_target = target;
    }
}

void m3d_ItemQueryFallbackPoint(HSD_GObj* target, Vec3* point)
{
    if (m3d_query != NULL && target == m3d_query_item_target) {
        m3d_ItemQueryPoint(point);
    }
}

bool m3d_ItemQueryStats(Item* ip, int* target_slot, int* queries)
{
    M3dItem* m = m3d_ItemGet(ip);
    if (m == NULL) {
        return false;
    }
    *target_slot = m->target_slot;
    *queries = m->queries;
    return true;
}

/* Map-wide random drops. Melee's own spawner still decides what appears and
 * when (frequency table, stage item weights, Poke Ball limit, spawn effect);
 * on a 3D stage the pace scales with the fighters still in play, a live cap
 * bounds simulation cost, and the drop point is sampled across reachable
 * outdoor ground (inside the safe zone in Survival).
 *
 * MELEE3D_NATIVE_ITEMS=off|verylow|low|medium|high|veryhigh (default medium).
 * MELEE3D_NATIVE_ITEM_SWEEP=1 is a diagnostic: every common item kind in turn,
 * every two seconds, next to a fighter, ignoring the live cap. */
#define M3D_DROP_CAP 28
static const char* const drop_names[] = {"off","verylow","low","medium","high","veryhigh"};
static int drop_sweep = -1, drop_sweep_next, drop_tick, drop_spawned, drop_skipped;
static unsigned short drop_count[It_Kind_Common_End], held_count[It_Kind_Common_End], touched_count[It_Kind_Common_End];
static unsigned long long drop_kinds_seen, drop_kinds_held;

int m3d_ItemDropFrequency(void)
{
    const char* s = getenv("MELEE3D_NATIVE_ITEMS");
    int i;
    if (s == NULL) return 2;
    for (i = 0; i < 6; i++) if (!strcmp(s, drop_names[i])) return i - 1;
    fprintf(stderr, "M3D ITEM FAIL invalid MELEE3D_NATIVE_ITEMS=%s\n", s);
    exit(2);
}

static bool sweeping(void)
{
    if (drop_sweep < 0) drop_sweep = getenv("MELEE3D_NATIVE_ITEM_SWEEP") != NULL;
    return drop_sweep;
}

static int drop_players(void)
{
    int n = 0;
    HSD_GObj* g;
    for (g = HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER]; g; g = g->next) {
        Fighter* fp = GET_FIGHTER(g);
        if (fp->is_sub_fighter || fp->is_sleeping) continue;
        if (m3d_PartyActive() && m3d_PartyEliminated(fp->player_idx)) continue;
        n++;
    }
    return n;
}

static int drop_live(int* held)
{
    int n = 0;
    HSD_GObj* g;
    *held = 0;
    for (g = HSD_GObjPLinkHead[HSD_GOBJ_PLINK_ITEM]; g; g = g->next) {
        Item* ip = g->user_data;
        if (ip == NULL || ip->kind == It_Kind_Unk4 || ip->kind >= It_Kind_Common_End) continue;
        n++;
        if (ip->owner != NULL && ip->xDC8_word.flags.x13) (*held)++;
    }
    return n;
}

static int drop_cap(int players)
{
    int cap = players + 4;
    return cap < 4 ? 4 : cap > M3D_DROP_CAP ? M3D_DROP_CAP : cap;
}

void m3d_ItemDropLimits(s32* common_cap)
{
    s32 native = *common_cap;
    drop_tick = drop_spawned = drop_skipped = 0;
    drop_sweep_next = 0;
    drop_kinds_seen = drop_kinds_held = 0;
    memset(drop_count, 0, sizeof drop_count); memset(held_count, 0, sizeof held_count); memset(touched_count, 0, sizeof touched_count);
    if (*common_cap < M3D_DROP_CAP + 12) *common_cap = M3D_DROP_CAP + 12;
    fprintf(stderr, "M3D ITEM LIMITS common=%d native=%d drop_cap=%d sweep=%d\n",
            *common_cap, native, M3D_DROP_CAP, sweeping());
}

/* Per-player pace: Melee's interval is tuned for four fighters sharing one
 * screen, so divide it by (fighters in play / 4), between 1x and 8x. */
int m3d_ItemDropInterval(int frames)
{
    float factor;
    int result;
    if (sweeping()) return 120;
    factor = drop_players() / 4.0f;
    if (factor < 1) factor = 1;
    if (factor > 8) factor = 8;
    result = (int) (frames / factor);
    return result < 30 ? 30 : result;
}

int m3d_ItemDropKind(int kind)
{
    int held, live, players, cap;
    if (m3d_PartyRoundOver()) return -1; /* no new loot once a winner is decided */
    if (sweeping()) {
        kind = drop_sweep_next % It_Kind_Common_End;
        drop_sweep_next++;
        return kind;
    }
    if (kind < 0) return kind;
    live = drop_live(&held);
    players = drop_players();
    cap = drop_cap(players);
    if (live >= cap) {
        drop_skipped++;
        return -1;
    }
    return kind;
}

/* Sweep drops land beside a fighter so the item is actually used. */
bool m3d_ItemDropNear(Vec3* center, float* radius)
{
    HSD_GObj* g;
    int n = 0, pick;
    if (!sweeping() && HSD_Randi(3)==0) return false;
    for (g = HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER]; g; g = g->next) {
        Fighter* fp = GET_FIGHTER(g);
        if (!fp->is_sub_fighter && !fp->is_sleeping && fp->ground_or_air == GA_Ground) n++;
    }
    if (n == 0) return false;
    pick = HSD_Randi(n);
    for (g = HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER]; g; g = g->next) {
        Fighter* fp = GET_FIGHTER(g);
        if (fp->is_sub_fighter || fp->is_sleeping || fp->ground_or_air != GA_Ground) continue;
        if (pick-- == 0) {
            *center = fp->cur_pos;
            *radius = sweeping()?36:140;
            return true;
        }
    }
    return false;
}

void m3d_ItemDropped(HSD_GObj* item, int kind)
{
    Item* ip = item->user_data;
    int held, live = drop_live(&held), players = drop_players();
    drop_spawned++;
    if (kind >= 0 && kind < 64) drop_kinds_seen |= 1ULL << kind;
    if (kind >= 0 && kind < It_Kind_Common_End) drop_count[kind]++;
    fprintf(stderr, "M3D ITEM DROP tick=%d kind=%d x=%.1f y=%.1f z=%.1f live=%d cap=%d players=%d\n",
            drop_tick, kind, ip->pos.x, ip->pos.y, ip->pos.z, live, drop_cap(players), players);
}

/* Usage evidence: first fighter to hold each item, and items that vanish
 * beside a fighter without being held (healing, Starman, mushrooms...). */
static void item_usage_end(M3dItem* m)
{
    Item* ip = m->ip;
    HSD_GObj* g;
    float best = 1e30f;
    int slot = -1;
    if (ip->kind >= It_Kind_Common_End || m->held_logged || !m3d_StageIs3D()) return;
    for (g = HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER]; g; g = g->next) {
        Fighter* fp = GET_FIGHTER(g);
        float d = hypotf(fp->cur_pos.x - ip->pos.x, fp->cur_pos.z - ip->pos.z);
        if (!fp->is_sleeping && d < best && fabsf(fp->cur_pos.y - ip->pos.y) < 25) { best = d; slot = fp->player_idx; }
    }
    if (best < 18) {
        touched_count[ip->kind]++;
        fprintf(stderr, "M3D ITEM TOUCHED tick=%d kind=%d slot=%d distance=%.1f\n", drop_tick, ip->kind, slot, best);
    }
}

static void item_usage_scan(void)
{
    int i;
    for (i = 0; i < M3D_ITEM_CAPACITY; i++) {
        M3dItem* m = &m3d_items[i];
        HSD_GObj* owner;
        if (m->ip == NULL || m->held_logged || m->ip->kind >= It_Kind_Common_End) continue;
        owner = m->ip->owner;
        if (owner == NULL || !ftLib_IsFighter(owner) || m->ip->xDC8_word.flags.x13 == 0) continue;
        m->held_logged = true;
        held_count[m->ip->kind]++;
        drop_kinds_held |= 1ULL << m->ip->kind;
        fprintf(stderr, "M3D ITEM HELD tick=%d kind=%d slot=%d character=%d\n", drop_tick, m->ip->kind,
                GET_FIGHTER(owner)->player_idx, GET_FIGHTER(owner)->kind);
    }
}

void m3d_ItemDropTick(void)
{
    int held, live;
    item_usage_scan();
    if (drop_tick % 1800 == 1799) {
        char line[2048];
        int k, n = 0;
        for (k = 0; k < It_Kind_Common_End && n < (int) sizeof line - 32; k++)
            if (drop_count[k] || held_count[k] || touched_count[k])
                n += snprintf(line + n, sizeof line - n, " %d:%u/%u/%u", k, drop_count[k], held_count[k], touched_count[k]);
        line[n] = 0;
        fprintf(stderr, "M3D ITEM USAGE tick=%d kind:dropped/held/touched%s\n", drop_tick + 1, line);
    }
    if (++drop_tick % 600) return;
    live = drop_live(&held);
    fprintf(stderr, "M3D ITEM CENSUS tick=%d live=%d held=%d spawned=%d skipped=%d players=%d kinds=%llx held_kinds=%llx\n",
            drop_tick, live, held, drop_spawned, drop_skipped, drop_players(),
            drop_kinds_seen, drop_kinds_held);
}
