/* SPDX-License-Identifier: GPL-3.0-or-later
 * Conservative caps for small closed holes in imported walkable scenery.
 * No coastline/outer perimeter, open seam, non-manifold or concave filling. */
#ifndef M3D_HOLES_H
#define M3D_HOLES_H
#include <math.h>
#include <stdlib.h>
#include <string.h>
typedef struct {float x,y,z;} M3dHolePoint;
typedef struct {M3dHolePoint a,b;int key[6],used;} M3dHoleEdge;
typedef struct {M3dHolePoint p[32],center;int count;} M3dHole;
static int m3d_hole_point_compare(M3dHolePoint a,M3dHolePoint b) {
    int qa[3]={(int)lrintf(a.x*1000),(int)lrintf(a.y*1000),(int)lrintf(a.z*1000)};
    int qb[3]={(int)lrintf(b.x*1000),(int)lrintf(b.y*1000),(int)lrintf(b.z*1000)};
    for(int k=0;k<3;k++)if(qa[k]!=qb[k])return qa[k]<qb[k]?-1:1;return 0;
}
static M3dHoleEdge m3d_hole_edge(M3dHolePoint a,M3dHolePoint b) {
    M3dHoleEdge e={.a=a,.b=b};M3dHolePoint lo=a,hi=b;
    if(m3d_hole_point_compare(a,b)>0){lo=b;hi=a;}
    float v[6]={lo.x,lo.y,lo.z,hi.x,hi.y,hi.z};
    for(int k=0;k<6;k++)e.key[k]=(int)lrintf(v[k]*1000);return e;
}
static int m3d_hole_edge_compare(const void* pa,const void* pb) {
    const M3dHoleEdge *a=pa,*b=pb;
    for(int k=0;k<6;k++)if(a->key[k]!=b->key[k])return a->key[k]<b->key[k]?-1:1;return 0;
}
static int m3d_holes_find(M3dHoleEdge* edges,int count,M3dHole* holes,int capacity,float min_y) {
    qsort(edges,count,sizeof *edges,m3d_hole_edge_compare);int boundary=0;
    for(int i=0;i<count;){int next=i+1;while(next<count&&!m3d_hole_edge_compare(&edges[i],&edges[next]))next++;
        if(next==i+1)edges[boundary++]=edges[i];i=next;}
    int found=0;
    for(int start=0;start<boundary&&found<capacity;start++) {
        if(edges[start].used)continue;M3dHole h={0};int current=start,closed=0;
        while(!edges[current].used&&h.count<32) {
            M3dHoleEdge* e=&edges[current];e->used=1;h.p[h.count++]=e->a;
            int outgoing=0,incoming=0,next=-1;
            for(int j=0;j<boundary;j++) {
                if(!m3d_hole_point_compare(edges[j].a,e->b)){outgoing++;next=j;}
                if(!m3d_hole_point_compare(edges[j].b,e->b))incoming++;
            }
            if(incoming!=1||outgoing!=1)break;
            if(next==start){closed=1;break;}current=next;
        }
        if(!closed||h.count<3)continue;
        float area=0,minx=h.p[0].x,maxx=minx,minz=h.p[0].z,maxz=minz,miny=h.p[0].y,maxy=miny;int convex=1;
        for(int j=0;j<h.count;j++) {
            M3dHolePoint a=h.p[j],b=h.p[(j+1)%h.count],c=h.p[(j+2)%h.count];
            area+=a.x*b.z-b.x*a.z;
            if((b.x-a.x)*(c.z-b.z)-(b.z-a.z)*(c.x-b.x)<-.01f)convex=0;
            minx=fminf(minx,a.x);maxx=fmaxf(maxx,a.x);minz=fminf(minz,a.z);maxz=fmaxf(maxz,a.z);miny=fminf(miny,a.y);maxy=fmaxf(maxy,a.y);
            h.center.x+=a.x/h.count;h.center.y+=a.y/h.count;h.center.z+=a.z/h.count;
        }
        /* Upward floor winding gives a negative outer boundary in XZ. A
         * positive boundary encloses a hole. Limit to a few fighter widths. */
        if(!convex||area<2||area>1600||maxx-minx>32||maxz-minz>32||maxy-miny>.2f||miny<min_y)continue;
        holes[found++]=h;
    }
    return found;
}
#endif
