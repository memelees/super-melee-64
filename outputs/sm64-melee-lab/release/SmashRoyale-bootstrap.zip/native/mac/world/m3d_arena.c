/* Native source port of the shared melee3d overlay; first stage gate: FD. */
/// Private stage banks: shared convex floor slicing and untextured rendering.
/// The bank contains source geometry; the executable contains only this loader.
#include "m3d.h"

#include <dolphin/dvd.h>
#include <dolphin/gx.h>
#include <dolphin/os.h>
#include <math.h>
#include <melee/cm/camera.h>
#include <melee/gr/ground.h>
#include <melee/mp/types.h>
#include <sysdolphin/baselib/cobj.h>
#include <sysdolphin/baselib/gobj.h>
#include <sysdolphin/baselib/gobjgxlink.h>
#include <sysdolphin/baselib/state.h>
#include <sysdolphin/baselib/tev.h>
#include <string.h>
#include <stdio.h>

typedef struct {
    u32 magic, version, edges, triangles;
    float top, bottom;
    u32 size, reserved;
} M3dArenaHeader;
typedef struct { float nx, nz, k; } M3dArenaPlane;
typedef struct { Vec3 pos; GXColor color; } M3dArenaVertex;

static u8 bank[65536] ATTRIBUTE_ALIGN(32);
static M3dArenaHeader* arena;
static M3dArenaPlane* planes;
static M3dArenaVertex* vertices;
typedef struct { int key; char *prefix, *title, *subtitle, *music; bool ready; } ArenaProfile;
static ArenaProfile profiles[6] = {
    { 4, "m3d_bowser", "BOWSER", "IN THE SKY", "/m3d_bowser.hps", true },
    { 11, "m3d_ganon", "GANONDORF", "CHAMBER", "/m3d_ganon.hps", false },
    { 5, "m3d_carrier", "AIRCRAFT", "CARRIER", "/m3d_sa2_boss03.hps", true },
    { 12, "m3d_forest", "SONIC VS", "SHADOW", "/m3d_sa2_boss04.hps", true },
    { 13, "m3d_bigfoot", "BIG FOOT", "CITY SQUARE", "/m3d_sa2_boss01.hps", false },
    { 14, "m3d_ark", "SPACE", "COLONY ARK", "/m3d_sa2_boss03.hps", false },
};
static bool available[6];
static int active_id;

void m3d_ArenaFilename(char* suffix, char* buffer)
{
    sprintf(buffer, "%s%s", profiles[active_id-1].prefix, suffix);
}
char* m3d_ArenaMusic(void)
{
    return active_id ? profiles[active_id-1].music : NULL;
}
int m3d_ArenaKey(int stkind)
{
    int i;
    for (i = 0; i < 6; i++) if (profiles[i].key == stkind && available[i]) return i+1;
    return 0;
}
char* m3d_ArenaLabel(int stkind, int line)
{
    int id = m3d_ArenaKey(stkind);
    if (!id) return "";
    return line ? profiles[id-1].subtitle : profiles[id-1].title;
}
static MapCollData collision;
static MapJoint joint;
static MapLine lines[4];
static DiscVec2 points[4];

void m3d_ArenaBoot(void)
{
    int i;
    char path[64];
    for (i = 0; i < 6; i++) {
        active_id = i+1;
        m3d_ArenaFilename("_col.bin", path);
        available[i] = DVDConvertPathToEntrynum(path) >= 0;
        m3d_ArenaFilename("_vis.bin", path);
        available[i] = available[i] && DVDConvertPathToEntrynum(path) >= 0 &&
                       DVDConvertPathToEntrynum(profiles[i].music) >= 0 && profiles[i].ready;
    }
    active_id = 0;
}

bool m3d_ArenaAvailable(void) { return available[0]; }
bool m3d_ArenaActive(void) { return arena != NULL || m3d_ArenaMeshActive(); }

static bool bounded(float x, float limit)
{
    return x == x && x >= -limit && x <= limit;
}

void m3d_ArenaLoad(int id)
{
    M3dArenaHeader* h = (M3dArenaHeader*) bank;
    int i, size;
    char path[64];
    arena = NULL;
    active_id = id >= 1 && id <= 6 ? id : 0;
    m3d_ArenaMeshLoad(NULL);
    m3d_ArenaVisualLoad(false);
    if (!active_id) return;
    m3d_ArenaFilename("_col.bin", path);
    if (!m3d_ArenaMeshLoad(path)) { active_id = 0; return; }
    m3d_ArenaVisualLoad(true);
    if (active_id != 1) return;
    size = m3d_LoadFile("m3d_bowser.bin", (char*) bank, sizeof(bank));
    if (size < sizeof(*h) || h->magic != 0x4D334131 || h->version != 1 ||
        h->edges < 3 || h->edges > 32 || h->triangles < 1 ||
        h->triangles > 1024 || h->reserved != 0 || h->size != size ||
        size != sizeof(*h) + h->edges * sizeof(*planes) +
                    h->triangles * 3 * sizeof(*vertices) ||
        h->top != 0 || !bounded(h->bottom, 1000) || h->bottom >= -1)
    {
        OSReport("M3D ERR invalid arena bank\n");
        return;
    }
    planes = (M3dArenaPlane*) (h + 1);
    vertices = (M3dArenaVertex*) (planes + h->edges);
    for (i = 0; i < h->edges; i++) {
        float norm = planes[i].nx * planes[i].nx +
                     planes[i].nz * planes[i].nz;
        if (!bounded(norm - 1, 0.001f) || !bounded(planes[i].k, 1000) ||
            planes[i].k <= 1)
        {
            OSReport("M3D ERR invalid arena boundary\n");
            return;
        }
    }
    for (i = 0; i < h->triangles * 3; i++) {
        Vec3* v = &vertices[i].pos;
        if (!bounded(v->x, 10000) || !bounded(v->y, 10000) ||
            !bounded(v->z, 10000))
        {
            OSReport("M3D ERR invalid arena vertex\n");
            return;
        }
    }
    arena = h;

    OSReport("M3D ARENA Bowser edges=%d triangles=%d\n", h->edges,
             h->triangles);
}

/// Intersect a horizontal lane with every outward boundary half-plane.
bool m3d_ArenaSlice(Vec3* pos, float lx, float lz, float* lo, float* hi)
{
    int i;
    *lo = -100000;
    *hi = 100000;
    for (i = 0; i < arena->edges; i++) {
        M3dArenaPlane* p = &planes[i];
        float a = p->nx * lx + p->nz * lz;
        float b = p->k - p->nx * pos->x - p->nz * pos->z;
        if (fabsf(a) < 0.00001f) {
            if (b < 0) return false;
        } else if (a > 0) {
            if (b / a < *hi) *hi = b / a;
        } else if (b / a > *lo) {
            *lo = b / a;
        }
        if (*lo > *hi) return false;
    }
    return true;
}

bool m3d_ArenaOutside(Vec3* pos)
{
    int i;
    if (m3d_ArenaMeshActive()) return m3d_ArenaMeshOutside(pos);
    for (i = 0; i < arena->edges; i++) {
        M3dArenaPlane* p = &planes[i];
        if (p->nx * pos->x + p->nz * pos->z > p->k) return true;
    }
    return false;
}

void m3d_ArenaInward(Vec3* pos, float* nx, float* nz)
{
    float best = 1.0e9f;
    int i;
    if (m3d_ArenaMeshActive()) { m3d_ArenaMeshInward(pos, nx, nz); return; }
    for (i = 0; i < arena->edges; i++) {
        M3dArenaPlane* p = &planes[i];
        float d = fabsf(p->k - p->nx * pos->x - p->nz * pos->z);
        if (d < best) {
            best = d;
            *nx = -p->nx;
            *nz = -p->nz;
        }
    }
}

MapCollData* m3d_ArenaCollision(MapCollData* native)
{
    static u16 v0[4] = { 0, 2, 1, 3 };
    static u16 v1[4] = { 1, 3, 2, 0 };
    static s16 prev[4] = { 3, 2, 0, 1 };
    static s16 next[4] = { 2, 3, 1, 0 };
    float scale;
    int i;
    if (m3d_ArenaMeshActive()) return m3d_ArenaMeshCollision();
    if (!arena) return native;
    memset(&collision, 0, sizeof(collision));
    memset(&joint, 0, sizeof(joint));
    memset(lines, 0, sizeof(lines));
    scale = Ground_801C0498();
    for (i = 0; i < 4; i++) {
        points[i].x = (i == 0 || i == 3 ? -82.0f : 82.0f) / scale;
        points[i].y = (i < 2 ? arena->top : arena->bottom) / scale;
        lines[i].v0_idx = v0[i];
        lines[i].v1_idx = v1[i];
        lines[i].prev_id0 = lines[i].prev_id1 = prev[i];
        lines[i].next_id0 = lines[i].next_id1 = next[i];
        lines[i].hi_flags = 1 << i;
        lines[i].lo_flags = i == 0 ? LINE_FLAG_LEDGE : 0;
        joint.ranges[i].start = collision.ranges[i].start = i;
        joint.ranges[i].count = collision.ranges[i].count = 1;
    }
    joint.left_bound = -200000;
    joint.right_bound = 200000;
    joint.bottom_bound = arena->bottom / scale - 30;
    joint.top_bound = arena->top / scale + 30;
    joint.vtx_count = 4;
    DP_SET(collision.verts, points);
    collision.vert_count = 4;
    DP_SET(collision.lines, lines);
    collision.line_count = 4;
    DP_SET(collision.joints, &joint);
    collision.joint_count = 1;
    return &collision;
}

static void render(HSD_GObj* gobj, intptr_t pass)
{
    int i;
    /* Match the native stage layer. The camera revisits GX link 3 for several
     * layers; a depth-disabled sky must never repaint the later fighter pass. */
    if (pass != 0 || !m3d_ArenaActive() || Camera_8003108C() != 0) return;
    if (m3d_ArenaVisualRender() || !arena) return;
    HSD_StateInvalidate(-1);
    HSD_StateInitTev();
    GXSetColorUpdate(GX_ENABLE);
    GXSetAlphaUpdate(GX_DISABLE);
    GXSetBlendMode(GX_BM_NONE, GX_BL_ONE, GX_BL_ZERO, GX_LO_NOOP);
    GXSetAlphaCompare(GX_ALWAYS, 0, GX_AOP_AND, GX_ALWAYS, 0);
    GXSetZMode(GX_ENABLE, GX_LEQUAL, GX_ENABLE);
    GXSetZCompLoc(GX_ENABLE);
    GXSetNumTexGens(0);
    GXSetNumTevStages(1);
    GXSetTevOrder(GX_TEVSTAGE0, GX_TEXCOORD_NULL, GX_TEXMAP_NULL, GX_COLOR0A0);
    GXSetTevOp(GX_TEVSTAGE0, GX_PASSCLR);
    GXSetNumChans(1);
    GXSetChanCtrl(GX_COLOR0A0, GX_DISABLE, GX_SRC_REG, GX_SRC_VTX, 0,
                  GX_DF_NONE, GX_AF_NONE);
    GXSetCullMode(GX_CULL_NONE);
    GXClearVtxDesc();
    GXSetVtxAttrFmt(GX_VTXFMT0, GX_VA_POS, GX_POS_XYZ, GX_F32, 0);
    GXSetVtxAttrFmt(GX_VTXFMT0, GX_VA_CLR0, GX_CLR_RGBA, GX_RGBA8, 0);
    GXSetVtxDesc(GX_VA_POS, GX_DIRECT);
    GXSetVtxDesc(GX_VA_CLR0, GX_DIRECT);
    GXLoadPosMtxImm(HSD_CObjGetViewingMtxPtrDirect(HSD_CObjGetCurrent()), 0);
    GXSetCurrentMtx(0);
    GXBegin(GX_TRIANGLES, GX_VTXFMT0, arena->triangles * 3);
    for (i = 0; i < arena->triangles * 3; i++) {
        M3dArenaVertex* v = &vertices[i];
        GXPosition3f32(v->pos.x, v->pos.y, v->pos.z);
        GXColor4u8(v->color.r, v->color.g, v->color.b, v->color.a);
    }
    GXEnd();
    HSD_StateInvalidate(-1);
    HSD_StateInitTev();
}

void m3d_ArenaInit(void)
{
    int i;
    HSD_GObj* gobj;
    /* Load the archive's locator holders for native spawn, camera and KO
     * metadata. Do not attach its geometry renderer, animations or hazards. */
    for (i = 0; i < 4; i++) Ground_GetStageGObj(i);
    gobj = GObj_Create(3, 5, 0);
    GObj_SetupGXLink(gobj, render, 3, 0);
    Ground_801C39C0();
    Ground_801C3BB4();
    m3d_ArenaMeshBounds();
    Camera_800311DC(1);
    Camera_800311CC(30000);
}
