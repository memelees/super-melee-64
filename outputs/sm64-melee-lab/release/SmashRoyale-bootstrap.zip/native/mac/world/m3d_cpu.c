/* Native source port of the shared melee3d overlay; first stage gate: FD. */
/// A scoped lane view for Melee's native CPU perception and command planner.
#include "m3d.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <melee/ft/inlines.h>
#include <melee/ft/types.h>
#include <melee/ft/kinds/ftCommon/ftCo_0A01.h>
#include <melee/it/types.h>
#include <melee/it/item.h>
#include <melee/pl/player.h>
#include <sysdolphin/baselib/gobj.h>

#define M3D_CPU_FIGHTERS (GM_MAX_PLAYERS * 2)
#define M3D_CPU_ITEMS 256

typedef struct M3dCpuMemory {
    Fighter* fp;
    Vec3 goal, previous_goal;
    int frames, timer;
} M3dCpuMemory;

static M3dCpuMemory memories[GM_MAX_PLAYERS][2];
static struct {
    Fighter* fp;
    M3dCpuMemory* memory;
    Vec3 origin;
    float lx, lz;
    int nf, ni;
    struct {
        Fighter* fp;
        Vec3 pos, prev, delta, kb;
        float facing;
    } fighters[M3D_CPU_FIGHTERS];
    struct {
        Item* ip;
        Vec3 pos, vel;
    } items[M3D_CPU_ITEMS];
} view;

void m3d_CpusReset(void)
{
    int i, j;
    view.fp = NULL;
    for (i = 0; i < GM_MAX_PLAYERS; i++) {
        for (j = 0; j < 2; j++) memories[i][j].fp = NULL;
    }
}

static void to_local(Vec3* p)
{
    float perpendicular = -(p->x - view.origin.x) * view.lz +
                           (p->z - view.origin.z) * view.lx;
    m3d_MapToLocal(p);
    p->z = perpendicular;
}

static void to_world(Vec3* p)
{
    float perpendicular = p->z;
    m3d_MapToWorld(p);
    p->x -= perpendicular * view.lz;
    p->z += perpendicular * view.lx;
}

static void local_vector(Vec3* p)
{
    float x = p->x, z = p->z;
    p->x = x * view.lx + z * view.lz;
    p->z = -x * view.lz + z * view.lx;
}

bool m3d_CpuIsActive(void)
{
    return view.fp != NULL;
}

bool m3d_CpuBegin(Fighter* fp)
{
    HSD_GObj* gobj;
    Fighter* target = NULL;
    Fighter* current_target = NULL;
    M3dCpuMemory* memory;
    float best = 1.0e30f;
    float previous_lx, previous_lz;
    Vec3 goal;
    int i;

    /* Native combat and native partner AI share this spatial view. */
    if (!m3d_FighterIs3D(fp) ||
        (Player_GetPlayerSlotType(fp->player_idx)!=Gm_PKind_Cpu && fp->cpu.kind!=CpuKind_Nana) ||
        (fp->cpu.kind != CpuKind_4 && fp->cpu.kind != CpuKind_Nana) ||
        view.fp != NULL) {
        return false;
    }
    m3d_GetLane(fp, &previous_lx, &previous_lz);
    view.nf = view.ni = 0;
    for (gobj = HSD_GObjPLinkHead[HSD_GOBJ_PLINK_FIGHTER]; gobj != NULL;
         gobj = gobj->next)
    {
        Fighter* other = GET_FIGHTER(gobj);
        float dx, dy, dz, dist;
        if (view.nf == M3D_CPU_FIGHTERS) return false;
        view.fighters[view.nf++].fp = other;
        if (other == fp || other->is_sleeping || ftCo_IsAlly(fp, other)) {
            continue;
        }
        if (other == fp->cpu.x44) current_target = other;
        dx = other->cur_pos.x - fp->cur_pos.x;
        dy = other->cur_pos.y - fp->cur_pos.y;
        dz = other->cur_pos.z - fp->cur_pos.z;
        dist = dx * dx + dy * dy + dz * dz;
        if (dist < best) {
            best = dist;
            target = other;
        }
    }
    if (current_target != NULL) target = current_target;
    if((m3d_DelfinoActive()||m3d_ReferenceOverlayActive())&&fp->cpu.kind!=CpuKind_Nana){target=m3d_DelfinoNavTarget(fp,target);if(target)fp->cpu.x44=fp->cpu.x48=target;}
    if (fp->cpu.kind == CpuKind_Nana) {
        HSD_GObj* leader = Player_GetEntityAtIndex(fp->player_idx, 0);
        target = leader == NULL ? NULL : GET_FIGHTER(leader);
        if (target == fp || (target != NULL && target->is_sleeping)) target = NULL;
        /* Delayed native inputs are expressed in the leader's lane. */
        if (target != NULL && fp->cpu.xFA_b7) m3d_CopyLane(fp, target);
    }
    for (gobj = HSD_GObjPLinkHead[HSD_GOBJ_PLINK_ITEM]; gobj != NULL;
         gobj = gobj->next)
    {
        if (gobj->user_data == NULL) continue;
        if (view.ni == M3D_CPU_ITEMS) return false;
        view.items[view.ni++].ip = gobj->user_data;
    }
    if (target != NULL || (fp->cpu.x4C && fp->cpu.xF9_b7) || (m3d_DelfinoActive()||m3d_ReferenceOverlayActive())) {
        goal = target ? target->cur_pos : fp->cur_pos;
        if (fp->cpu.kind!=CpuKind_Nana && fp->item_gobj==NULL && fp->cpu.xF9_b7) {
            for (i=0;i<view.ni;i++) {
                Item* item=view.items[i].ip;
                if (item==fp->cpu.x4C && Item_IsGrabbable(item->entity)) {
                    goal=item->pos;
                    break;
                }
            }
        }
        {static int trace=-1;if(trace<0)trace=getenv("MELEE3D_NATIVE_ITEM_AI_TRACE")!=NULL;
         if(trace&&m3d_match_frame%300==(int)fp->player_idx*7%300){Item* it=fp->cpu.x4C;
            fprintf(stderr,"M3D ITEM AI slot=%d x4C=%d kind=%d seek=%d held=%d item_d=%.1f target_d=%.1f x2C=%d\n",fp->player_idx,it!=NULL,it?it->kind:-1,fp->cpu.xF9_b7,fp->item_gobj!=NULL,
                it?hypotf(it->pos.x-fp->cur_pos.x,it->pos.z-fp->cur_pos.z):-1.f,target?hypotf(target->cur_pos.x-fp->cur_pos.x,target->cur_pos.z-fp->cur_pos.z):-1.f,(int)fp->cpu.x2C);}}
        /* Native recovery decisions still choose the jump/special. Give
         * recovery a lane toward the stage instead of chasing offstage. */
        if (fp->cpu.x18 == 4 && !(m3d_DelfinoActive()||m3d_ReferenceOverlayActive())) {
            goal.x = goal.z = 0.0f;
        }
        bool routed=(m3d_DelfinoActive()||m3d_ReferenceOverlayActive())&&m3d_DelfinoNavRoute(fp,target,&goal);
        if(!routed)m3d_CpuRecoveryGoal(fp, &goal);
        if (fp->cpu.kind != CpuKind_Nana || !fp->cpu.xFA_b7) {
            m3d_CpuAim(fp, &goal);
        }
    }
    m3d_GetLane(fp, &view.lx, &view.lz);
    view.origin = fp->cur_pos;
    if (!m3d_MapBegin(&view, &fp->cur_pos, view.lx, view.lz)) {
        m3d_SetLane(fp, previous_lx, previous_lz);
        return false;
    }
    view.fp = fp;
    memory = &memories[fp->player_idx][fp->is_sub_fighter ? 1 : 0];
    if (memory->fp != fp || memory->timer > fp->cpu.x7C) {
        memory->fp = fp;
        memory->frames = 0;
        memory->goal.x = fp->cpu.x54.x;
        memory->goal.y = fp->cpu.x54.y;
        memory->goal.z = fp->cur_pos.z;
        memory->previous_goal.x = fp->cpu.x64.x;
        memory->previous_goal.y = fp->cpu.x64.y;
        memory->previous_goal.z = fp->cur_pos.z;
    }
    view.memory = memory;
    goal = memory->goal;
    to_local(&goal);
    fp->cpu.x54.x = goal.x;
    fp->cpu.x54.y = goal.y;
    goal = memory->previous_goal;
    to_local(&goal);
    fp->cpu.x64.x = goal.x;
    fp->cpu.x64.y = goal.y;
    to_local(&fp->cpu.x98);
    for (i = 0; i < 30; i++) to_local(&fp->cpu.xFC[i].cur_pos);
    for (i = 0; i < view.nf; i++) {
        Fighter* other = view.fighters[i].fp;
        float lx, lz, along;
        view.fighters[i].pos = other->cur_pos;
        view.fighters[i].prev = other->prev_pos;
        view.fighters[i].delta = other->pos_delta;
        view.fighters[i].kb = other->x8c_kb_vel;
        view.fighters[i].facing = other->facing_dir;
        to_local(&other->cur_pos);
        to_local(&other->prev_pos);
        local_vector(&other->pos_delta); /* already a world displacement */
        if (other != fp && m3d_GetLane(other, &lx, &lz)) {
            along = lx * view.lx + lz * view.lz;
            other->x8c_kb_vel.x *= along;
            if (along < 0.0f) other->facing_dir = -other->facing_dir;
        }
    }
    for (i = 0; i < view.ni; i++) {
        Item* ip = view.items[i].ip;
        view.items[i].pos = ip->pos;
        view.items[i].vel = ip->x40_vel;
        to_local(&ip->pos);
        /* Item velocities are native lane-local; leave their tuning intact. */
    }
    return true;
}

void m3d_CpuEnd(Fighter* fp, bool began)
{
    Vec3 point;
    int i;
    if (!began || view.fp != fp) return;
    point.x = fp->cpu.x54.x;
    point.y = fp->cpu.x54.y;
    point.z = 0.0f;
    to_world(&point);
    view.memory->goal = point;
    point.x = fp->cpu.x64.x;
    point.y = fp->cpu.x64.y;
    point.z = 0.0f;
    to_world(&point);
    view.memory->previous_goal = point;
    /* Native Vec2 caches remain world X/Y between decision windows. Their
     * depth lives in the overlay, so a later lane turn can reproject them. */
    fp->cpu.x54.x = view.memory->goal.x;
    fp->cpu.x64.x = view.memory->previous_goal.x;
    to_world(&fp->cpu.x98);
    for (i = 0; i < 30; i++) to_world(&fp->cpu.xFC[i].cur_pos);
    for (i = 0; i < view.nf; i++) {
        Fighter* other = view.fighters[i].fp;
        other->cur_pos = view.fighters[i].pos;
        other->prev_pos = view.fighters[i].prev;
        other->pos_delta = view.fighters[i].delta;
        other->x8c_kb_vel = view.fighters[i].kb;
        other->facing_dir = view.fighters[i].facing;
    }
    for (i = 0; i < view.ni; i++) {
        Item* ip = view.items[i].ip;
        ip->pos = view.items[i].pos;
        ip->x40_vel = view.items[i].vel;
    }
    view.memory->frames++;
    view.memory->timer = fp->cpu.x7C;
    m3d_MapEnd(&view);
    view.fp = NULL;
    if((m3d_DelfinoActive()||m3d_ReferenceOverlayActive())){m3d_DelfinoNavDrive(fp);m3d_PartyHold(fp);}
}

int m3d_CpuFrames(Fighter* fp)
{
    M3dCpuMemory* memory;
    if (fp->player_idx >= GM_MAX_PLAYERS) return 0;
    memory = &memories[fp->player_idx][fp->is_sub_fighter ? 1 : 0];
    return memory->fp == fp ? memory->frames : 0;
}

/* The native partner input-copy helper can enter a special, so run it with
 * fighters in world space. Only its history-X correction needs projection. */
void m3d_CpuCompanion(Fighter* fp, void (*native)(Fighter*))
{
    Vec3 history, before;
    float lx, lz, dx;
    if (!m3d_FighterIs3D(fp) || fp->cpu.kind != CpuKind_Nana ||
        !fp->cpu.xFA_b7 || fp->cpu.x448 == NULL ||
        !m3d_GetLane(fp, &lx, &lz))
    {
        native(fp);
        return;
    }
    before = fp->cur_pos;
    history = fp->cpu.x448->cur_pos;
    fp->cpu.x448->cur_pos.x = before.x +
        (history.x - before.x) * lx + (history.z - before.z) * lz;
    native(fp);
    fp->cpu.x448->cur_pos = history;
    dx = fp->cur_pos.x - before.x;
    fp->cur_pos.x = before.x + dx * lx;
    fp->cur_pos.z += dx * lz;
}

/* Native floor indices belong to transient slices, not permanent world
 * islands. Compare their actual support surfaces when planning an item grab. */
bool m3d_CpuSameFloor(Fighter* fp, Item* ip)
{
    Vec3 a=fp->cur_pos,b=ip->pos,fa,fb;
    if (view.fp) { to_world(&a); to_world(&b); }
    else if (m3d_MapIsActive(fp)) m3d_MapToWorld(&a);
    /* The CPU view already owns the collision slice. Imported surface queries
     * are independent of it; native FD has a single support floor. */
    if (!m3d_ArenaMeshActive()) {
        /* Compare support points, not an item's elevated model origin (the
         * grounded Hammer's origin is 8.5 units above the same FD floor). */
        b.y+=ip->x378_itemColl.ecb.bottom.y;
        return fabsf(a.y-b.y)<8;
    }
    a.y+=2; b.y+=2;
    if (!m3d_GroundBelow(&a,&fa) || !m3d_GroundBelow(&b,&fb)) return false;
    return fabsf(fa.y-fb.y)<8;
}

/* On the Delfino map the native item search would otherwise pick the best
 * item anywhere in the district. Keep it to items this CPU can reach soon;
 * damaged fighters look further for healing. Positions here are world space
 * (the CPU view stores the originals while its lane-local copy is active). */
bool m3d_CpuIgnoreItem(Fighter* fp, Item* ip)
{
    Vec3 a = fp->cur_pos, b = ip->pos;
    float radius;
    int i;
    if (!(m3d_DelfinoActive()||m3d_ReferenceOverlayActive())) return false;
    if (view.fp == fp) {
        a = view.origin;
        for (i = 0; i < view.ni; i++) if (view.items[i].ip == ip) { b = view.items[i].pos; break; }
    }
    radius = 140;
    if (fp->dmg.x1830_percent >= 60 &&
        (ip->kind == It_Kind_Heart || ip->kind == It_Kind_Tomato || ip->kind == It_Kind_Foods))
        radius = 240;
    return hypotf(a.x - b.x, a.z - b.z) > radius || fabsf(a.y - b.y) > 45;
}

/* Melee's default CPU only walks to top-priority items (healing, Starman,
 * Hammer, Poke Ball...). Map drops are the battle-royale loot, so on the
 * Delfino map CPUs also go for ordinary weapons (Beam Sword, Bat, Fan, Fire
 * Flower, Star Rod...); containers, shells and bombs stay opportunistic. */
int m3d_CpuItemInterest(Fighter* fp, int native)
{
    (void) fp;
    if (!(m3d_DelfinoActive()||m3d_ReferenceOverlayActive())) return native;
    return native > 3 ? 3 : native;
}

bool m3d_PickupRange(Fighter* fp, Vec3* pos, DiscVec4* offset,float xr,float yr)
{
    Vec3 origin=fp->cur_pos;
    float lx=1,lz=0,dx,dz,radius=offset->z+xr;
    if (!view.fp) {
        m3d_GetLane(fp,&lx,&lz);
        if (m3d_MapIsActive(fp)) m3d_MapToWorld(&origin);
    }
    dx=pos->x-origin.x-fp->facing_dir*offset->x*lx;
    dz=pos->z-origin.z-fp->facing_dir*offset->x*lz;
    return dx*dx+dz*dz<radius*radius &&
           pos->y>origin.y+offset->y-offset->w-yr &&
           pos->y<origin.y+offset->y+offset->w+yr;
}
