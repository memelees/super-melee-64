/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef M3D_COMBAT_RULES_H
#define M3D_COMBAT_RULES_H
#include <math.h>
#define M3D_COMBAT_RAD .01745329252f
typedef struct {float spent;int active,overridden;} M3dAimBudget;
/* Independent world-horizontal stick and vertical shoulder modifier. The
 * direction is normalized so a diagonal cannot increase a move's speed. */
static void m3d_combat_spatial_aim(float horizontal,float vertical,float deadzone,float* x,float* y) {
    horizontal=horizontal>=deadzone?fminf(1,horizontal):0;
    *x=horizontal;*y=vertical;
    float length=hypotf(*x,*y);
    if(length<.001f){*x=0;*y=1;}
    else if(length>1){*x/=length;*y/=length;}
}
static float m3d_combat_angle(float a) {
    return atan2f(sinf(a),cosf(a));
}
/* Absolute travel counts towards the cap, including reversals. */
static float m3d_combat_turn(M3dAimBudget* b,float delta,float rate,int active,int frozen) {
    if(active)b->active=1;
    if(b->active||b->overridden||frozen)return 0;
    float room=fmaxf(0,30*M3D_COMBAT_RAD-b->spent);
    float step=fmaxf(-fminf(room,rate),fminf(fminf(room,rate),m3d_combat_angle(delta)));
    b->spent+=fabsf(step);return step;
}
static void m3d_combat_di(float* x,float* y) {
    float len=hypotf(*x,*y);if(len>1){*x/=len;*y/=len;}
}
/* Constant curvature with a soft final 25 units; independent of speed.
 * No extra range, collision size, vertical pitch or native item lifetime. */
static float m3d_combat_projectile_turn(float speed,float travelled) {
    return fminf(4*M3D_COMBAT_RAD,fabsf(speed)/100)*fmaxf(0,fminf(1,(100-travelled)/25));
}
#endif
