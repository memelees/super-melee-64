/* SPDX-License-Identifier: GPL-3.0-or-later
 * Deterministic party scoring. Positions are world-space feet, never CPU slices.
 * This header has no engine dependencies so the real rules can be checked alone. */
#ifndef M3D_PARTY_RULES_H
#define M3D_PARTY_RULES_H
#include <math.h>
#include <string.h>
#define M3D_PARTY_PLAYERS 32
#define M3D_PARTY_TOKENS 32
#define M3D_PARTY_HZ 60
/* Battle retains the existing native rules; the other modes own their scores. */
enum { M3D_PARTY_BATTLE, M3D_PARTY_HILL, M3D_PARTY_COLLECT, M3D_PARTY_SURVIVAL, M3D_PARTY_COIN,
       M3D_PARTY_TIME, M3D_PARTY_STOCK, M3D_PARTY_BONUS };
typedef struct { float x,y,z; } M3dPartyPoint;
/* dealt = total percent this fighter has dealt; kos / falls = native totals.
 * Only the Brawl Hill rule reads them. */
typedef struct { M3dPartyPoint pos; int active,alive; unsigned blocked_tokens; float dealt; int kos,falls;
                 int present,stocks,damage,self_destructs; } M3dPartyBody;
/* Hill scoring rules. SOLO = Halo King: 1 point a second, only while alone.
 * SHARED = everyone on the hill scores. SPLIT = the second is divided among
 * everyone on that hill. BRAWL = SPLIT on several hills, plus 1 point per 10%
 * dealt and 5 per KO while on a hill, minus 25% of your points when KO'd, and
 * an away counter the game turns into damage. */
enum { M3D_HILL_SOLO, M3D_HILL_SHARED, M3D_HILL_SPLIT, M3D_HILL_BRAWL };
#define M3D_PARTY_HILLS 4
typedef struct {
    int mode,tick,limit,duration,hill_period,storm_duration,finished,winner,occupants,owner;
    int score[M3D_PARTY_PLAYERS],coins[M3D_PARTY_PLAYERS],held[M3D_PARTY_PLAYERS],outside[M3D_PARTY_PLAYERS],respawn[32];
    M3dPartyPoint hill,storm,tokens[32];
    float hill_radius,storm_start,storm_end,storm_radius;
    int adaptive_zone,phase,phase_tick,zone_initial_alive;
    float zone_radii[33],phase_from,phase_target;
    int hill_rule,hill_count,primed,hill_occupants[M3D_PARTY_HILLS],on_hill[M3D_PARTY_PLAYERS],away[M3D_PARTY_PLAYERS];
    M3dPartyPoint hills[M3D_PARTY_HILLS]; /* hills[0] mirrors hill */
    float partial[M3D_PARTY_PLAYERS],last_dealt[M3D_PARTY_PLAYERS];
    int last_kos[M3D_PARTY_PLAYERS],last_falls[M3D_PARTY_PLAYERS];
    int sd_penalty,sudden_death;
    unsigned contenders;
} M3dPartyRules;
static float m3d_party_distance(M3dPartyPoint a,M3dPartyPoint b) {return hypotf(a.x-b.x,a.z-b.z);}
/* One geometry contract for damage, rendering and the lethal outer curtain.
 * The safe circle is crossable. Density/damage increase through the band;
 * its outer edge is a blast boundary, independent of altitude or exposure time. */
static float m3d_party_storm_width(const M3dPartyRules* s) {
    return fmaxf(160,fminf(480,s->storm_radius*.3f));
}
static float m3d_party_storm_outer(const M3dPartyRules* s) {
    return s->storm_radius+m3d_party_storm_width(s);
}
static float m3d_party_storm_depth(const M3dPartyRules* s,M3dPartyPoint p) {
    return fmaxf(0,fminf(1,(m3d_party_distance(p,s->storm)-s->storm_radius)/m3d_party_storm_width(s)));
}
static int m3d_party_storm_lethal(const M3dPartyRules* s,M3dPartyPoint p) {
    return m3d_party_distance(p,s->storm)>=m3d_party_storm_outer(s);
}
static float m3d_party_storm_dose(const M3dPartyRules* s,M3dPartyPoint p) {
    return 2+6*m3d_party_storm_depth(s,p)+4*fminf(1,s->tick/(float)(1200+s->storm_duration));
}
/* A future circle is a forecast, not an instruction to abandon a fight.
 * Reserve enough time to cover a detour at native running speed before the
 * lethal edge arrives. Shallow storm fights remain possible while holding. */
static int m3d_party_zone_notice(const M3dPartyRules* s);
static int m3d_party_storm_flee(const M3dPartyRules* s,M3dPartyPoint p,float run_speed) {
    if(s->mode!=M3D_PARTY_SURVIVAL||s->finished)return 0;
    float d=m3d_party_distance(p,s->storm),outer=m3d_party_storm_outer(s);
    float depth=m3d_party_storm_depth(s,p);
    if(depth>=.55f||outer-d<48)return 1;
    if(m3d_party_zone_notice(s)!=-1)return 0;
    float escape=fmaxf(0,d-s->storm_radius+48)*1.6f/fmaxf(.5f,run_speed)+120;
    return outer-d<.5f*escape+36;
}
static void m3d_party_storm_camera(const M3dPartyRules* s,M3dPartyPoint focus,M3dPartyPoint* eye) {
    float limit=m3d_party_storm_outer(s)-.1f;
    if(m3d_party_distance(focus,s->storm)>=limit||m3d_party_distance(*eye,s->storm)<=limit)return;
    float x=focus.x-s->storm.x,z=focus.z-s->storm.z,dx=eye->x-focus.x,dz=eye->z-focus.z;
    float a=dx*dx+dz*dz,b=2*(x*dx+z*dz),c=x*x+z*z-limit*limit;
    if(a<.0001f)return;
    float t=fmaxf(0,fminf(1,(-b+sqrtf(fmaxf(0,b*b-4*a*c)))/(2*a)));
    eye->x=focus.x+t*dx;eye->y=focus.y+t*(eye->y-focus.y);eye->z=focus.z+t*dz;
}
static void m3d_party_reset(M3dPartyRules* s,int mode,int duration,int limit,int hill_period,int storm_duration) {
    memset(s,0,sizeof(*s));s->mode=mode;s->winner=s->owner=-1;
    s->duration=duration;s->limit=limit;s->hill_period=hill_period;s->storm_duration=storm_duration;
    s->hill_radius=44;s->storm_start=3000;s->storm_end=80;s->storm_radius=s->storm_start;
}
static int m3d_party_in_hill(M3dPartyRules* s,M3dPartyPoint h,M3dPartyPoint p) {
    return m3d_party_distance(p,h)<=s->hill_radius&&p.y>=h.y-6&&p.y<=h.y+32;
}
static int m3d_party_hill_total(M3dPartyRules* s){return s->hill_count<1?1:s->hill_count>M3D_PARTY_HILLS?M3D_PARTY_HILLS:s->hill_count;}
static M3dPartyPoint m3d_party_hill_at(M3dPartyRules* s,int k){return k==0?s->hill:s->hills[k];}
/* Which hill a point stands on, or -1. */
static int m3d_party_hill_index(M3dPartyRules* s,M3dPartyPoint p) {
    for(int k=0;k<m3d_party_hill_total(s);k++)if(m3d_party_in_hill(s,m3d_party_hill_at(s,k),p))return k;
    return -1;
}
static int m3d_party_inside(M3dPartyRules* s,M3dPartyPoint p) {return m3d_party_hill_index(s,p)>=0;}
/* Positive: seconds until motion; -1: actually shrinking; 0: holding.
 * Read the same phase/timing as the simulation, including rate-limited
 * arrival. A new phase that cannot reduce the radius needs no warning. */
static int m3d_party_zone_notice(const M3dPartyRules* s) {
    if(s->mode!=M3D_PARTY_SURVIVAL||s->finished)return 0;
    if(!s->adaptive_zone)return s->tick>20*60&&s->storm_radius>s->storm_end+.01f?-1:0;
    if(s->phase<1||s->phase_target>=s->phase_from-.01f)return 0;
    int remaining=10*60-(s->tick-s->phase_tick);
    if(remaining>0)return (remaining+59)/60;
    return s->storm_radius>s->phase_target+.01f?-1:0;
}
static void m3d_party_finish(M3dPartyRules* s) {
    int best=-1,winner=-1;
    for(int i=0;i<M3D_PARTY_PLAYERS;i++) {if(s->score[i]>best){best=s->score[i];winner=i;}else if(s->score[i]==best)winner=-1;}
    s->finished=1;s->winner=winner;
}
/* Retail Time = KOs - opponent-caused falls - configured SD penalty.
 * Timed Stock compares lives, then lower damage. Tied leaders continue at
 * 300% with one stock; unused seats must never participate in a score tie. */
static int m3d_match_time_score(int kos,int falls,int self_destructs,int sd_penalty) {
    return kos-(falls-self_destructs)-self_destructs*sd_penalty;
}
static void m3d_party_standard(M3dPartyRules* s,const M3dPartyBody* b) {
    int alive=0,last=-1;
    for(int i=0;i<32;i++)if(b[i].present&&b[i].alive&&(!s->sudden_death||(s->contenders&(1u<<i)))){alive++;last=i;}
    if((s->mode==M3D_PARTY_STOCK||s->sudden_death)&&s->tick>120&&alive<=1){s->finished=1;s->winner=last;return;}
    if(s->sudden_death)return;
    if(s->mode==M3D_PARTY_TIME)for(int i=0;i<32;i++)s->score[i]=m3d_match_time_score(b[i].kos,b[i].falls,b[i].self_destructs,s->sd_penalty);
    if(s->mode==M3D_PARTY_STOCK)for(int i=0;i<32;i++)s->score[i]=b[i].stocks;
    if(!s->duration||s->tick<s->duration)return;
    int best=0,best_damage=0,winner=-1;unsigned tied=0;
    for(int i=0;i<32;i++)if(b[i].present&&(s->mode!=M3D_PARTY_STOCK||b[i].alive)) {
        int score=s->score[i],damage=s->mode==M3D_PARTY_STOCK?b[i].damage:0;
        if(winner<0||score>best||(score==best&&damage<best_damage)){best=score;best_damage=damage;winner=i;tied=1u<<i;}
        else if(score==best&&damage==best_damage)tied|=1u<<i;
    }
    if(tied&&(tied&(tied-1))){s->sudden_death=1;s->contenders=tied;return;}
    s->finished=1;s->winner=winner;
}
/* Called once per completed, unpaused native logic frame. Each entry represents one player; sub-fighters must not
 * be passed as additional opponents or award a second capture score. */
static void m3d_party_step(M3dPartyRules* s,const M3dPartyBody bodies[M3D_PARTY_PLAYERS]) {
    if(!s->mode||s->finished)return;
    ++s->tick;s->occupants=0;s->owner=-1;
    if(s->mode==M3D_PARTY_COIN||s->mode>=M3D_PARTY_TIME){m3d_party_standard(s,bodies);return;}
    int alive=0,last=-1;
    for(int k=0;k<M3D_PARTY_HILLS;k++)s->hill_occupants[k]=0;
    for(int i=0;i<M3D_PARTY_PLAYERS;i++){if(bodies[i].alive){alive++;last=i;}s->on_hill[i]=-1;if(!bodies[i].active)continue;
        int k=m3d_party_hill_index(s,bodies[i].pos);s->on_hill[i]=k;
        if(k>=0){s->hill_occupants[k]++;s->occupants++;s->owner=i;}
    }
    if(s->occupants!=1)s->owner=-1;
    if(s->mode==M3D_PARTY_HILL&&s->hill_rule==M3D_HILL_SOLO&&s->owner>=0&&++s->held[s->owner]>=60){s->held[s->owner]-=60;s->score[s->owner]++;}
    if(s->mode==M3D_PARTY_HILL&&s->hill_rule!=M3D_HILL_SOLO) {
        if(!s->primed){for(int i=0;i<M3D_PARTY_PLAYERS;i++){s->last_dealt[i]=bodies[i].dealt;s->last_kos[i]=bodies[i].kos;s->last_falls[i]=bodies[i].falls;}s->primed=1;}
        for(int i=0;i<M3D_PARTY_PLAYERS;i++) {
            int k=s->on_hill[i];
            if(k>=0)s->partial[i]+=s->hill_rule==M3D_HILL_SHARED?1.0f/60:1.0f/(60.0f*s->hill_occupants[k]);
            if(s->hill_rule==M3D_HILL_BRAWL) {
                float dealt=bodies[i].dealt-s->last_dealt[i];
                if(dealt>0&&k>=0)s->partial[i]+=dealt/10;
                if(bodies[i].kos>s->last_kos[i]&&k>=0)s->partial[i]+=5.0f*(bodies[i].kos-s->last_kos[i]);
                if(bodies[i].falls>s->last_falls[i]){s->score[i]-=s->score[i]/4;s->partial[i]=0;}
                s->away[i]=bodies[i].active&&k<0?s->away[i]+1:0;
            }
            s->last_dealt[i]=bodies[i].dealt;s->last_kos[i]=bodies[i].kos;s->last_falls[i]=bodies[i].falls;
            while(s->partial[i]>=1-1e-4f){s->partial[i]-=1;s->score[i]++;}  /* epsilon: 60 x (1/60) in float */
        }
    }
    if(s->mode==M3D_PARTY_COLLECT)for(int j=0;j<32;j++) {
        if(s->respawn[j]>0){s->respawn[j]--;continue;}
        /* Nearest claimant wins a same-frame tie; stable slot tie-break. */
        int claimant=-1;float best=9;
        for(int i=0;i<M3D_PARTY_PLAYERS;i++)if(bodies[i].active&&!(bodies[i].blocked_tokens&(1u<<j))&&fabsf(bodies[i].pos.y-s->tokens[j].y)<15) {
            float d=m3d_party_distance(bodies[i].pos,s->tokens[j]);if(d<best){best=d;claimant=i;}
        }
        if(claimant>=0){s->coins[claimant]++;if(s->mode==M3D_PARTY_COLLECT)s->score[claimant]++;s->respawn[j]=12*60;}
    }
    if(s->mode==M3D_PARTY_SURVIVAL) {
        float t=(s->tick-20*60)/(float)s->storm_duration;t=fmaxf(0,fminf(1,t));
        if(!s->adaptive_zone)s->storm_radius=s->storm_start+(s->storm_end-s->storm_start)*t;
        else {
            int elapsed=s->tick-20*60;
            if(elapsed>=0) {
                int phase=elapsed/(30*60)+1;
                if(phase!=s->phase) {
                    s->phase=phase;s->phase_tick=s->tick;s->phase_from=s->storm_radius;
                    float density=s->zone_radii[alive<1?1:alive];
                    float clock=s->storm_start+(s->storm_end-s->storm_start)*t;
                    s->phase_target=fmaxf(s->storm_end,fminf(s->storm_radius,fminf(density,clock)));
                }
                /* Ten seconds of notice, twenty seconds of motion. Arrival
                 * can take multiple phases; never jump or grow after a KO. */
                float f=fmaxf(0,fminf(1,(s->tick-s->phase_tick-10*60)/(20.0f*60)));
                float wanted=s->phase_from+(s->phase_target-s->phase_from)*f;
                s->storm_radius=fmaxf(s->storm_radius-30.0f/60,fminf(s->storm_radius,wanted));
            }
        }
        for(int i=0;i<M3D_PARTY_PLAYERS;i++)s->outside[i]=bodies[i].active&&m3d_party_distance(bodies[i].pos,s->storm)>s->storm_radius?s->outside[i]+1:0;
        if(alive<=1&&s->tick>120){s->finished=1;s->winner=last;}
    } else {
        for(int i=0;i<M3D_PARTY_PLAYERS;i++)if(s->score[i]>=s->limit){s->finished=1;s->winner=i;break;}
        if(!s->finished&&s->duration&&s->tick>=s->duration)m3d_party_finish(s);
    }
}
#endif
