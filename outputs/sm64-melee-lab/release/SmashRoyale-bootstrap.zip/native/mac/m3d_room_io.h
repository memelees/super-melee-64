/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef M3D_ROOM_IO_H
#define M3D_ROOM_IO_H
#include <stdint.h>
int m3d_room_enabled(void);
int m3d_room_local(void);
int m3d_room_humans(void);
void m3d_room_exchange(const uint8_t input[12], uint32_t checksum,
                       uint8_t inputs[32 * 12], uint32_t* seed);
#endif
