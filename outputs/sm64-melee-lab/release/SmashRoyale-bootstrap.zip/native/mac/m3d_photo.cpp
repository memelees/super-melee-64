/* Read back the native renderer: menu thumbnails or staged gameplay atlas. */
#include "m3d_photo.h"
#include "m3d_theater.h"
#include <aurora/gfx.hpp>
#include <aurora/gfx.h>
#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <memory>
#include <vector>
#include <cmath>
#include <csignal>
#ifdef _WIN32
#include <fcntl.h>
#include <io.h>
#else
#include <unistd.h>
#endif

static std::atomic<int> state{0};
static std::atomic<int> video_state{0};
static std::atomic<unsigned> video_frames{0};
static unsigned frame_created,frame_pending;
// Aurora updates these public counter fields through atomic_ref internally.
// Pair those writes with atomic loads, including on the encoder worker.
static uint32_t pipeline_stat(const uint32_t& value){
    return std::atomic_ref<uint32_t>(const_cast<uint32_t&>(value)).load(std::memory_order_acquire);
}
extern "C" void m3d_TheaterVideoBegin(void){
    // Snapshot before this presentation's simulation/draw recording. The
    // worker checks again after encoding its draws; idle-on-the-main-thread
    // alone can race a newly requested world-material pipeline.
    const auto* stats=aurora_get_stats();frame_created=pipeline_stat(stats->createdPipelines);frame_pending=pipeline_stat(stats->queuedPipelines);
}
extern "C" unsigned m3d_TheaterVideoFrames(void){return video_frames.load();}
extern "C" int m3d_TheaterVideoState(void){return video_state.load();}
extern "C" int m3d_PhotoActive(void) {return std::getenv("MELEE3D_NATIVE_STAGE_PHOTO")!=nullptr;}
extern "C" int m3d_GameplayCaptureActive(void) {return std::getenv("MELEE3D_NATIVE_GAMEPLAY_CAPTURE")!=nullptr;}
extern "C" int m3d_PhotoState(void) {return state.load();}
struct Photo {
    wgpu::Texture source;
    wgpu::Buffer buffer;
    uint32_t width,height,stride;
    bool bgra,theater,retry;
    unsigned begin_created,begin_pending;
    aurora::gfx::EncoderTaskId task=aurora::gfx::InvalidEncoderTask;
};
static std::unique_ptr<Photo> photo,video_photo;
static FILE* video_pipe;
static FILE* theater_pipe(){
    if(video_pipe)return video_pipe;
#ifdef _WIN32
    const char* handle=std::getenv("MELEE3D_THEATER_VIDEO_HANDLE");if(!handle)return nullptr;
    int fd=_open_osfhandle(static_cast<intptr_t>(std::strtoull(handle,nullptr,10)),_O_BINARY|_O_WRONLY);
    if(fd>=0)video_pipe=_fdopen(fd,"wb");
#else
    const char* number=std::getenv("MELEE3D_THEATER_VIDEO_FD");if(!number)return nullptr;
    std::signal(SIGPIPE,SIG_IGN);
    int fd=dup(std::atoi(number));if(fd>=0)video_pipe=fdopen(fd,"wb");
#endif
    return video_pipe;
}
static void save(Photo& p) {
    const auto* pixels=static_cast<const uint8_t*>(p.buffer.GetConstMappedRange());
    if(p.theater){
        constexpr unsigned width=1920,height=1080;
        std::vector<uint8_t> rgb(width*height*3,0);
        // Fit the native camera without stretching a 4:3 gameplay image.
        double scale=std::min(double(width)/p.width,double(height)/p.height);
        unsigned fit_w=std::min(width,unsigned(std::lround(p.width*scale)));
        unsigned fit_h=std::min(height,unsigned(std::lround(p.height*scale)));
        unsigned left=(width-fit_w)/2,top=(height-fit_h)/2;
        for(unsigned y=0;y<fit_h;y++)for(unsigned x=0;x<fit_w;x++){
            unsigned sx=std::min(p.width-1,unsigned((x+.5)*p.width/fit_w));
            unsigned sy=std::min(p.height-1,unsigned((y+.5)*p.height/fit_h));
            auto* src=pixels+sy*p.stride+sx*4;auto* dst=rgb.data()+((top+y)*width+left+x)*3;
            dst[0]=src[p.bgra?2:0];dst[1]=src[1];dst[2]=src[p.bgra?0:2];
        }
        p.buffer.Unmap();FILE* f=theater_pipe();
        bool ok=f&&std::fwrite(rgb.data(),1,rgb.size(),f)==rgb.size()&&std::fflush(f)==0;
        if(ok)video_frames.fetch_add(1);
        video_state.store(ok?1:-1);return;
    }
    if(m3d_GameplayCaptureActive()) {
        FILE* f=std::fopen(std::getenv("MELEE3D_NATIVE_GAMEPLAY_CAPTURE"),"wb");
        bool ok=f!=nullptr;
        if(f) {
            ok=std::fprintf(f,"P6\n%u %u\n255\n",p.width,p.height)>0;
            std::vector<uint8_t> row(p.width*3);
            for(uint32_t y=0;y<p.height;y++) {
                for(uint32_t x=0;x<p.width;x++) {
                    const auto* c=pixels+y*p.stride+x*4;
                    row[x*3]=c[p.bgra?2:0];row[x*3+1]=c[1];row[x*3+2]=c[p.bgra?0:2];
                }
                ok=std::fwrite(row.data(),row.size(),1,f)==1&&ok;
            }
            ok=std::fclose(f)==0&&ok;
        }
        p.buffer.Unmap();
        std::fprintf(stderr,"M3D GAMEPLAY CAPTURE %s source=%ux%u staged=%d\n",ok?"PASS":"FAIL",p.width,p.height,
                     std::getenv("MELEE3D_NATIVE_CAPTURE_UNSTAGED")?0:1);
        state.store(ok?1:-1);return;
    }
    constexpr uint32_t width=256,height=160;
    std::vector<uint8_t> small(width*height*4);
    for(uint32_t y=0;y<height;y++)for(uint32_t x=0;x<width;x++) {
        uint64_t sum[3]={0,0,0};unsigned count=0;
        uint32_t left=x*p.width/width,right=std::max(left+1,(x+1)*p.width/width);
        uint32_t top=y*p.height/height,bottom=std::max(top+1,(y+1)*p.height/height);
        for(uint32_t sy=top;sy<std::min(bottom,p.height);sy++)for(uint32_t sx=left;sx<std::min(right,p.width);sx++) {
            const auto* c=pixels+sy*p.stride+sx*4;
            sum[0]+=c[p.bgra?2:0];sum[1]+=c[1];sum[2]+=c[p.bgra?0:2];count++;
        }
        auto* c=small.data()+(y*width+x)*4;
        for(int k=0;k<3;k++)c[k]=sum[k]/std::max(1u,count);c[3]=255;
    }
    FILE* f=std::fopen(std::getenv("MELEE3D_NATIVE_STAGE_PHOTO"),"wb");
    bool ok=f!=nullptr;
    if(f) {
        const uint32_t header[3]={0x31543342,width,height};ok=std::fwrite(header,sizeof header,1,f)==1;
        for(unsigned by=0;by<height;by+=4)for(unsigned bx=0;bx<width;bx+=4) {
            uint8_t tile[64];
            for(unsigned y=0;y<4;y++)for(unsigned x=0;x<4;x++) {
                const auto* c=small.data()+((by+y)*width+bx+x)*4;unsigned i=(y*4+x)*2;
                tile[i]=255;tile[i+1]=c[0];tile[32+i]=c[1];tile[33+i]=c[2];
            }
            ok=std::fwrite(tile,sizeof tile,1,f)==1&&ok;
        }
        ok=std::fclose(f)==0&&ok;
    }
    p.buffer.Unmap();
    std::fprintf(stderr,"M3D STAGE PHOTO %s renderer=game fighters=0 hud=0 source=%ux%u\n",ok?"PASS":"FAIL",p.width,p.height);
    state.store(ok?1:-1);
}
static void capture(bool theater) {
    auto& output=theater?video_photo:photo;
    if(output)return;
    if(pipeline_stat(aurora_get_stats()->queuedPipelines)&&!std::getenv("MELEE3D_NATIVE_CAPTURE_LIVE"))return;
    aurora::gfx::ResolvedTargets target;
    if(!aurora::gfx::resolve_pass({.color=true},target))return;
    bool bgra=target.colorFormat==wgpu::TextureFormat::BGRA8Unorm||target.colorFormat==wgpu::TextureFormat::BGRA8UnormSrgb;
    bool rgba=target.colorFormat==wgpu::TextureFormat::RGBA8Unorm||target.colorFormat==wgpu::TextureFormat::RGBA8UnormSrgb;
    if((!bgra&&!rgba)||!target.width||!target.height||uint64_t(target.width)*target.height>16777216){(theater?video_state:state).store(-1);return;}
    output=std::make_unique<Photo>();auto& p=*output;p.theater=theater;
    p.begin_created=frame_created;p.begin_pending=frame_pending;
    p.source=target.colorTexture;p.width=target.width;p.height=target.height;p.bgra=bgra;p.stride=(p.width*4+255)&~255u;
    wgpu::BufferDescriptor descriptor{.label="Stage photo",.usage=wgpu::BufferUsage::CopyDst|wgpu::BufferUsage::MapRead,.size=uint64_t(p.stride)*p.height};
    p.buffer=aurora::gfx::device().CreateBuffer(&descriptor);
    auto task=aurora::gfx::register_encoder_task_type({
        .label="Capture real stage",
        .callback=[](const aurora::gfx::EncoderTaskContext&,const wgpu::CommandEncoder& cmd,const void*,size_t,void* userdata) {
            auto& p=*static_cast<Photo*>(userdata);
            if(p.theater){
                const auto* stats=aurora_get_stats();
                if(p.begin_pending||pipeline_stat(stats->queuedPipelines)||pipeline_stat(stats->createdPipelines)!=p.begin_created){p.retry=true;return;}
            }
            wgpu::TexelCopyTextureInfo source{.texture=p.source};
            wgpu::TexelCopyBufferInfo dest{.layout={.offset=0,.bytesPerRow=p.stride,.rowsPerImage=p.height},.buffer=p.buffer};
            wgpu::Extent3D extent{p.width,p.height,1};cmd.CopyTextureToBuffer(&source,&dest,&extent);
        },
        .userdata=&p,
        .afterSubmit=[](const aurora::gfx::EncoderTaskCompletionContext&,const void*,size_t,void* userdata) {
            auto* p=static_cast<Photo*>(userdata);
            if(p->retry){video_state.store(0);return;}
            p->buffer.MapAsync(wgpu::MapMode::Read,0,uint64_t(p->stride)*p->height,wgpu::CallbackMode::AllowSpontaneous,
                [p](wgpu::MapAsyncStatus status,wgpu::StringView) {if(status==wgpu::MapAsyncStatus::Success)save(*p);else (p->theater?video_state:state).store(-1);});
        }
    });
    p.task=task;
    if(!aurora::gfx::push_encoder_task(task,nullptr,0))(theater?video_state:state).store(-1);
}

extern "C" void m3d_PhotoCapture(void){
    if(m3d_PhotoActive()||m3d_GameplayCaptureActive())capture(false);
}
extern "C" void m3d_TheaterVideoCapture(unsigned index){
    if(video_state.load()==2||video_state.load()<0||video_frames.load()!=index)return;
    if(video_photo&&video_photo->task)aurora::gfx::unregister_encoder_task_type(video_photo->task);
    video_photo.reset();video_state.store(2);capture(true);
    // A missing render pass or newly queued shader is retried at this exact tick.
    if(!video_photo)video_state.store(0);
}
