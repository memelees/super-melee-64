#include "m3d_menu.h"
#include "m3d_lab.h"
#include <sysdolphin/baselib/gobj.h>
#include <sysdolphin/baselib/gobjplink.h>
#include <melee/mn/types.h>
#include <melee/mn/mnmain.h>
#include <melee/mn/mnmainrule.h>
#include <melee/mn/inlines.h>
#include <melee/gm/gmscene.h>
#include <melee/gm/gm_1A3F.h>
#include <melee/gm/types.h>
#include <melee/pl/forward.h>
#include <sysdolphin/baselib/sislib.h>
#include <sysdolphin/baselib/jobj.h>
#include <sysdolphin/baselib/dobj.h>
#include <sysdolphin/baselib/mobj.h>
#include <sysdolphin/baselib/tobj.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "m3d_player_roster.inc"
#include "m3d_stage_choices.h"
#include <sysdolphin/baselib/controller.h>
#include "m3d_css_policy.h"
#include "m3d_akaneia.h"
#include "m3d_room_io.h"
#include <melee/ft/ftdata.h>
#include <melee/pl/player.h>
static M3dCssPreferences css_preferences={38,0,M3D_CSS_RANDOM};
static int css_preferences_ready;static unsigned css_match_number;
static void match_soak_options(void);
static void css_preferences_path(char* out,size_t size){const char* p=getenv("MELEE3D_NATIVE_MENU_SETTINGS");if(!p)p=getenv("MELEE3D_NATIVE_PICK_FILE");if(!p)p="native-menu.state";snprintf(out,size,"%s.fighters",p);}
static void css_preferences_init(void){if(css_preferences_ready)return;css_preferences_ready=1;
 const char* name=getenv("MELEE3D_NATIVE_CHARACTER");for(unsigned i=0;name&&i<33;i++)if(!strcmp(name,m3d_playable[i].name))css_preferences.human=m3d_playable[i].character;
 char path[4096];css_preferences_path(path,sizeof path);FILE* f=fopen(path,"r");if(f){m3d_css_read(f,&css_preferences);fclose(f);}}
static void css_preferences_save(void){char path[4096],tmp[4108];css_preferences_path(path,sizeof path);snprintf(tmp,sizeof tmp,"%s.tmp",path);FILE* f=fopen(tmp,"w");if(!f)return;m3d_css_write(f,&css_preferences);int ok=!ferror(f);if(fclose(f))ok=0;
#ifdef _WIN32
 if(ok)remove(path);
#endif
 if(ok&&rename(tmp,path))perror("save fighter choices");}
bool m3d_MenuActive(void) {const char* s=getenv("MELEE3D_NATIVE_MENUS");return s&&!strcmp(s,"1");}
int m3d_MenuSelection(void){css_preferences_init();return css_preferences.human;}
int m3d_MenuCharacter(void){int choice=m3d_MenuSelection();return choice==M3D_CSS_RANDOM?38:choice;}
void m3d_MenuChoose(int character){css_preferences_init();if(!m3d_css_valid_character(character))return;if(css_preferences.human!=character)css_preferences.costume=0;css_preferences.human=character;css_preferences_save();}
int m3d_MenuCpuCharacter(void){css_preferences_init();return css_preferences.cpu;}
void m3d_MenuCpuChoose(int character){css_preferences_init();if(m3d_css_valid_character(character)&&css_preferences.cpu!=character){css_preferences.cpu=character;css_preferences_save();}}
int m3d_MenuCostumeCount(int character){if(character<0)return 1;int kind=Player_800325C8(character,false);int count=kind>=33&&kind<40?m3d_akaneia_costume_count(kind):kind>=0&&kind<Ft_Kind_Max?CostumeListsForeachCharacter[kind].numCostumes:0;return count>0?count:1;}
int m3d_MenuCostume(void){css_preferences_init();return m3d_css_costume(css_preferences.costume,m3d_MenuCostumeCount(m3d_MenuSelection()));}
void m3d_MenuCostumeSet(int costume){css_preferences_init();css_preferences.costume=m3d_css_costume(costume,m3d_MenuCostumeCount(m3d_MenuSelection()));css_preferences_save();}
void m3d_MenuCostumeChange(int direction){int count=m3d_MenuCostumeCount(m3d_MenuSelection());css_preferences.costume=(m3d_MenuCostume()+count+(direction<0?-1:1))%count;css_preferences_save();}
void m3d_MenuRoster(StartMeleeData* start) {
 if(!m3d_MenuActive())return;match_soak_options();css_preferences_init();
 unsigned seed=getenv("MELEE_SEED")?(unsigned)strtoul(getenv("MELEE_SEED"),NULL,10):1;seed^=++css_match_number*0x9e3779b9u;
 int humans[32],roster[32],count=m3d_room_enabled()?m3d_room_humans():1;for(int i=0;i<count;i++)humans[i]=m3d_room_enabled()?start->players[i].ckind:m3d_MenuSelection();m3d_css_fill(roster,humans,count,m3d_MenuCpuCharacter(),seed);
 for(int i=0;i<32;i++){start->players[i].ckind=roster[i];start->players[i].slot_type=i<count?Gm_PKind_Human:Gm_PKind_Cpu;start->players[i].slot=0;start->players[i].cpu_level=9;if(i>=count)start->players[i].color=0;else if(!m3d_room_enabled())start->players[i].color=m3d_MenuCostume();}
 start->rules.stkind=m3d_MenuStage();
 fprintf(stderr,"M3D MENU MATCH fighters=32 human=%d costume=%d cpu_choice=%d stage=%d\n",roster[0],start->players[0].color,m3d_MenuCpuCharacter(),m3d_MenuStage());
}
void m3d_MenuText(void* context,const char* value,float x,float y,float scale) {
    HSD_Text* t=HSD_SisLib_803A6754(0,(intptr_t)context);
    t->default_kerning=1;t->pos_x=x;t->pos_y=y;t->font_size.x=t->font_size.y=scale;
    HSD_SisLib_803A6B98(t,0,0,"%s",value);
}
#include "m3d_title.inc"

GXColor m3d_MenuColour(int seat) {
    static const GXColor base[4]={{240,65,70,255},{65,130,255,255},{255,205,55,255},{65,220,105,255}};
    if(seat<4)return base[seat<0?0:seat];
    float h=fmodf(seat*.61803398875f,1)*6,s=seat&1?.76f:.46f,v=seat&2?1:.80f;
    int sector=(int)h;float f=h-sector,p=v*(1-s),q=v*(1-s*f),t=v*(1-s*(1-f));
    float rgb[6][3]={{v,t,p},{q,v,p},{p,v,t},{p,q,v},{t,p,v},{v,p,q}};
    return (GXColor){rgb[sector][0]*255,rgb[sector][1]*255,rgb[sector][2]*255,255};
}
static HSD_ImageDesc preview_images[M3D_STAGE_CHOICES];static unsigned char* preview_pixels[M3D_STAGE_CHOICES];
static int stage_choice,stage_hit;static HSD_Text* stage_caption;
static float stage_cursor_x,stage_cursor_y;static int stage_grid_phase,stage_grid_hold,stage_grid_done;
static const char* const stage_variables[M3D_STAGE_CHOICES]={"MELEE3D_NATIVE_DELFINO","MELEE3D_NATIVE_ONETT_OVERLAY","MELEE3D_NATIVE_CASTLE_OVERLAY","MELEE3D_NATIVE_BIANCO","MELEE3D_NATIVE_SIRENA","MELEE3D_NATIVE_PIANTA"};
static const char* const stage_previews[M3D_STAGE_CHOICES]={"MELEE3D_NATIVE_STAGE_PREVIEW","MELEE3D_NATIVE_ONETT_PREVIEW","MELEE3D_NATIVE_CASTLE_PREVIEW","MELEE3D_NATIVE_BIANCO_PREVIEW","MELEE3D_NATIVE_SIRENA_PREVIEW","MELEE3D_NATIVE_PIANTA_PREVIEW"};
static const char* const stage_keys[M3D_STAGE_CHOICES]={"delfino","onett","castle","bianco","sirena","pianta"};
static const int stage_order[M3D_STAGE_CHOICES]={0,3,4,5,1,2};
static bool stage_available(int choice){const char* p=choice>=0&&choice<M3D_STAGE_CHOICES?getenv(stage_variables[choice]):NULL;return choice==0||(p&&*p);}
static const char* stage_name(int i){static const char* names[M3D_STAGE_CHOICES]={"Delfino Plaza","Onett","Princess Peach's Castle","Bianco Hills","Sirena Beach","Pianta Village"};return names[i];}
int m3d_MenuLargeFD(void){const char* direct=getenv("MELEE3D_NATIVE_LARGE_FD");return direct&&!strcmp(direct,"1");}
int m3d_MenuStage(void){if(!stage_available(stage_choice))stage_choice=0;return m3d_stage_choice_id(stage_choice);}
static int sunshine_choice(void){
    int choice=m3d_MenuActive()?stage_choice:0;
    if(!m3d_MenuActive()){const char* direct=getenv("MELEE3D_NATIVE_SUNSHINE_MAP");for(int i=0;direct&&i<M3D_STAGE_CHOICES;i++)if(!strcmp(direct,stage_keys[i]))choice=i;}
    if(choice==1||choice==2||!stage_available(choice))choice=0;
    return choice;
}
const char* m3d_MenuSunshineBank(void){return getenv(stage_variables[sunshine_choice()]);}
float m3d_MenuSunshineKillDepth(void){return m3d_stage_sunshine_kill_depth(sunshine_choice());}
static unsigned stage_mask(void){unsigned mask=0;for(int i=0;i<M3D_STAGE_CHOICES;i++)if(stage_available(i))mask|=1u<<i;return mask;}
static void stage_labels(void){
    const char* name=stage_name(stage_choice);float scale=stage_choice==2?.38f:.48f;
    HSD_SisLib_803A70A0(stage_caption,0,"%s",name);
    HSD_SisLib_803A7548(stage_caption,0,scale,scale);
    /* Centre the selected name below the large photograph, above the grid. */
    HSD_SisLib_803A746C(stage_caption,0,320-(float)strlen(name)*scale*8,212);
}
int m3d_MenuStageTile(int cell,float* x,float* y){
    int choice=m3d_stage_grid_choice(cell,stage_mask());
    return m3d_stage_grid_center(choice,stage_mask(),x,y)?choice:-1;
}
void m3d_MenuStageCursor(float* x,float* y){*x=stage_cursor_x;*y=stage_cursor_y;}
bool m3d_MenuStageHighlight(float* x,float* y){return stage_hit>=0&&m3d_stage_grid_center(stage_hit,stage_mask(),x,y);}
bool m3d_MenuStageConfirm(void){return stage_hit>=0;}
bool m3d_MenuStageCheckReady(void){
    const char* check=getenv("MELEE3D_NATIVE_STAGE_CHECK");
    if(check&&!strcmp(check,"grid-preview"))return false;
    return !check||strcmp(check,"grid")||stage_grid_done;
}
void m3d_MenuStagesInit(void){
    const char* check=getenv("MELEE3D_NATIVE_STAGE_CHECK");
    if(check&&!strcmp(check,"sunshine-cycle")){
        static unsigned visit;static const int sequence[5]={0,3,4,5,0};
        for(int i=3;i<6;i++)if(!stage_available(i)){fprintf(stderr,"M3D MENU FAIL sunshine cycle missing bank\n");exit(2);}
        stage_choice=sequence[visit++%5];
    }else for(int i=0;check&&i<M3D_STAGE_CHOICES;i++)if(!strcmp(check,stage_keys[i]))stage_choice=stage_available(i)?i:0;
    stage_grid_phase=stage_grid_hold=stage_grid_done=0;m3d_MenuStage();
    m3d_stage_grid_center(stage_choice,stage_mask(),&stage_cursor_x,&stage_cursor_y);stage_hit=stage_choice;
    HSD_SisLib_803A62A0(0,"SdMenu.usd","SIS_MenuData");HSD_SisLib_803A611C(0,NULL,9,0xD,0,0xE,0,0x13);
    stage_caption=HSD_SisLib_803A6754(0,0);stage_caption->default_kerning=1;
    HSD_SisLib_803A6B98(stage_caption,220,212," ");
    int count=0;for(int i=0;i<M3D_STAGE_CHOICES;i++)count+=stage_available(i);
    if(check&&!strcmp(check,"grid")&&count!=M3D_STAGE_CHOICES){fprintf(stderr,"M3D MENU GRID FAIL requires six maps\n");exit(2);}
    stage_labels();fprintf(stderr,"M3D MENU SSS native_scene=1 available=%d selected=%d map=%s\n",count,m3d_MenuStage(),stage_keys[stage_choice]);
    fprintf(stderr,"M3D MENU STAGE GRID columns=3 tiles=%d circular_picker=1\n",count);
}
void m3d_MenuStagesInput(void){
    HSD_PadStatus* pad=&HSD_PadCopyStatus[0];
    float ax=pad->nml_stickX,ay=pad->nml_stickY;
    unsigned arrows=pad->repeat&(HSD_PAD_DPADLEFT|HSD_PAD_DPADRIGHT|HSD_PAD_DPADUP|HSD_PAD_DPADDOWN);
    arrows|=pad->trigger&(HSD_PAD_DPADLEFT|HSD_PAD_DPADRIGHT|HSD_PAD_DPADUP|HSD_PAD_DPADDOWN);
    const char* check=getenv("MELEE3D_NATIVE_STAGE_CHECK");
    /* This bounded fixture drives the same stick/dead-zone/hit-test path as a
     * controller, visiting every photo, then a gap, D-pad neighbours and Pianta. */
    bool trial=check&&!strcmp(check,"grid")&&!stage_grid_done;
    float tx=0,ty=0;
    if(trial){
        int target=stage_grid_phase<6?m3d_stage_grid_choice(stage_grid_phase,stage_mask()):5;
        if(stage_grid_phase==6){tx=24;ty=14;}
        else m3d_stage_grid_center(target,stage_mask(),&tx,&ty);
        if(stage_grid_phase>=7&&stage_grid_phase<=10){
            static const unsigned keys[]={HSD_PAD_DPADLEFT,HSD_PAD_DPADUP,HSD_PAD_DPADRIGHT,HSD_PAD_DPADDOWN};
            ax=ay=0;arrows=stage_grid_hold==0?keys[stage_grid_phase-7]:0;
        }else{ax=fmaxf(-1,fminf(1,(tx-stage_cursor_x)*.7f));ay=fmaxf(-1,fminf(1,(ty-stage_cursor_y)*.7f));arrows=0;}
    }
    int old=stage_choice;
    if(arrows){
        int dx=arrows&HSD_PAD_DPADLEFT?-1:arrows&HSD_PAD_DPADRIGHT?1:0;
        int dy=arrows&HSD_PAD_DPADUP?1:arrows&HSD_PAD_DPADDOWN?-1:0;
        stage_choice=m3d_stage_grid_step(stage_choice,dx,dy,stage_mask());
        m3d_stage_grid_center(stage_choice,stage_mask(),&stage_cursor_x,&stage_cursor_y);
    }else{
        stage_cursor_x=m3d_stage_cursor_clamp(stage_cursor_x+m3d_stage_cursor_axis(ax),27);
        stage_cursor_y=m3d_stage_cursor_clamp(stage_cursor_y+m3d_stage_cursor_axis(ay),19);
    }
    stage_hit=m3d_stage_grid_hit(stage_cursor_x,stage_cursor_y,stage_mask());
    if(stage_hit>=0)stage_choice=stage_hit;
    if(old!=stage_choice){stage_labels();sfxMove();fprintf(stderr,"M3D MENU STAGE selected=%d map=%s name=%s\n",m3d_MenuStage(),stage_keys[stage_choice],stage_name(stage_choice));}
    if(trial){
        bool resting=stage_grid_phase>=7&&stage_grid_phase<=10;
        if(resting||(fabsf(stage_cursor_x-tx)<.35f&&fabsf(stage_cursor_y-ty)<.35f)){
            if(++stage_grid_hold>=10){
                fprintf(stderr,"M3D MENU GRID CHECK phase=%d map=%s hover=%d cursor=%.2f,%.2f\n",stage_grid_phase,stage_keys[stage_choice],stage_hit,stage_cursor_x,stage_cursor_y);
                static const int expected[]={0,3,4,5,1,2,-1,1,3,4,2,5};
                if(stage_hit!=expected[stage_grid_phase]){fprintf(stderr,"M3D MENU GRID FAIL phase=%d wrong hover=%d\n",stage_grid_phase,stage_hit);exit(2);}
                if(stage_grid_phase==6&&m3d_MenuStageConfirm()){fprintf(stderr,"M3D MENU GRID FAIL gap confirmed\n");exit(2);}
                stage_grid_phase++;stage_grid_hold=0;
                if(stage_grid_phase==12){stage_grid_done=1;fprintf(stderr,"M3D MENU GRID PASS selected=%s\n",stage_keys[stage_choice]);}
            }
        }
    }
}

void m3d_MenuPreviewChoice(void* object,int choice) {
    HSD_JObj* j=object;if(!j||!stage_available(choice))return;
    HSD_ImageDesc* image=&preview_images[choice];
    if(!preview_pixels[choice]){const char* path=getenv(stage_previews[choice]);if(!path)return;
        FILE* f=fopen(path,"rb");if(!f)return;unsigned header[3];
        if(fread(header,4,3,f)!=3||memcmp(header,"B3T1",4)||header[1]!=256||header[2]!=160){fclose(f);return;}
        preview_pixels[choice]=malloc(256*160*4);if(!preview_pixels[choice]||fread(preview_pixels[choice],1,256*160*4,f)!=256*160*4){free(preview_pixels[choice]);preview_pixels[choice]=NULL;fclose(f);return;}fclose(f);
        DP_SET(image->image_ptr,preview_pixels[choice]);image->width=256;image->height=160;image->format=GX_TF_RGBA8;image->minLOD=image->maxLOD=0;}
    for(HSD_JObj* node=j;node;node=node->next){
        for(HSD_DObj* d=node->u.dobj;d;d=d->next)if(d->mobj)for(HSD_TObj* t=d->mobj->tobj;t;t=t->next){
            bool replacement=false;for(int i=0;i<M3D_STAGE_CHOICES;i++)if(t->imagedesc==&preview_images[i])replacement=true;
            if(t->imagedesc&&((t->imagedesc->width==64&&t->imagedesc->height==56)||replacement)){
                t->imagedesc=image;t->tlut=NULL;
            }
        }
        if(node->child)m3d_MenuPreviewChoice(node->child,choice);
    }
}
void m3d_MenuPreview(void* object){m3d_MenuPreviewChoice(object,stage_choice);}

/* Reuse Melee's menu scenes. Only labels, options and their actions change. */
static const char* const menu_labels[]={"SOLO PLAY","HOST MATCH","JOIN MATCH","THEATER","QUIT"};
static const char* const menu_help[]={"You and 31 CPUs. Choose rules, then a fighter.","Host friends on LAN or VPN; CPUs fill spare seats.","Join a friend's match with a room code.","Watch saved matches with a free camera.","Close Smash Royale."};
static char theater_labels[5][64],theater_help[5][160];
static bool theater_browser(void){return getenv("MELEE3D_THEATER_BROWSER")!=NULL;}
static void theater_index(void){
    if(theater_labels[0][0])return;
    FILE* f=fopen(getenv("MELEE3D_THEATER_BROWSER"),"r");if(!f)return;
    char line[256];for(int i=0;i<5&&fgets(line,sizeof line,f);i++){
        line[strcspn(line,"\r\n")]=0;char* help=strchr(line,'\t');if(help)*help++=0;
        snprintf(theater_labels[i],sizeof theater_labels[i],"%.63s",line);
        snprintf(theater_help[i],sizeof theater_help[i],"%.159s",help?help:"");
    }fclose(f);
}
#include "m3d_settings.h"
#include <melee/gm/gmmain_lib.h>
#include <melee/gm/gm_1601.h>
#include <melee/mn/mnitemsw.h>
#include <melee/sc/types.h>
static const char* const mode_labels[]={"Plaza Party","Battle Royale","Coin","Free Battle","Time","Stock","Bonus"};
static const char* const item_labels[]={"None","Very Low","Low","Medium","High","Very High"};
static M3dSettings config;
static void match_load(M3dSettings* out);
static int config_ready,hosting,rule_page,handicap_seat;
enum {RULE_MAIN,RULE_MORE,RULE_STAGE,RULE_EXTRAS,RULE_HANDICAPS,RULE_RANDOM};
enum {RULE_MORE_ACTION=100,RULE_STAGE_ACTION,RULE_EXTRAS_ACTION,RULE_ITEMS_ACTION,RULE_CONTINUE_ACTION,RULE_BACK_ACTION,RULE_HANDICAPS_ACTION,RULE_SEAT_ACTION,RULE_LEVEL_ACTION,RULE_RANDOM_ACTION,RULE_MAP_ACTION,RULE_FIGHTERS_ACTION};
typedef struct {const char* label;int field;} RuleRow;
static const RuleRow rule_rows[][7]={
    {{"Rules",BMR_MODE},{"Time / Stock",BMR_MINUTES},{"Handicap",BMR_HANDICAP},{"Damage Ratio",BMR_DAMAGE},{"Item Switch",RULE_ITEMS_ACTION},{"Additional Rules",RULE_MORE_ACTION},{"Continue",RULE_CONTINUE_ACTION}},
    {{"Stock Time Limit",BMR_STOCK_MINUTES},{"Friendly Fire",BMR_FRIENDLY},{"Pause",BMR_PAUSE},{"Score Display",BMR_SCORE},{"SD Penalty",BMR_SD},{"Stage Settings",RULE_STAGE_ACTION},{"Extra Settings",RULE_EXTRAS_ACTION}},
    {{"Stage Selection",BMR_STAGE},{"Random Stages",RULE_RANDOM_ACTION},{"Stage",RULE_MAP_ACTION},{"Human Players",BMR_HUMANS},{"Fighters",RULE_FIGHTERS_ACTION},{"Handicap Levels",RULE_HANDICAPS_ACTION},{"Back",RULE_BACK_ACTION}},
    {{"CPU Level",BMR_CPU},{"Gravity",BMR_GRAVITY},{"Movement Speed",BMR_MOVE},{"Game Speed",BMR_SPEED},{"Human Players",BMR_HUMANS},{"Handicap Levels",RULE_HANDICAPS_ACTION},{"Back",RULE_BACK_ACTION}},
    {{"Player",RULE_SEAT_ACTION},{"Handicap Level",RULE_LEVEL_ACTION},{"Back",RULE_BACK_ACTION}},
    {{"Delfino Plaza",RULE_MAP_ACTION},{"Back",RULE_BACK_ACTION}}
};
static void menu_env(const char* key,const char* value) {
#ifdef _WIN32
    _putenv_s(key,value);
#else
    setenv(key,value,1);
#endif
}
static void menu_number(const char* key,int value){char s[24];snprintf(s,sizeof s,"%d",value);menu_env(key,s);}
static void menu_physics(const char* key,int value){char s[24];snprintf(s,sizeof s,"%.2f",value/100.0f);menu_env(key,s);}
static void menu_retail(M3dSettings* c) {
    GameRules* r=gmMainLib_GetGameRules();int m=c->v[BMR_MODE];
    r->mode=m==5||m==1?1:m==2?2:m==6?3:0;
    r->time_limit=c->v[BMR_MINUTES];r->stock_count=c->v[BMR_STOCKS];
    r->handicap=c->v[BMR_HANDICAP];r->damage_ratio=c->v[BMR_DAMAGE];r->stage_sel=c->v[BMR_STAGE];
    r->stock_time_limit=c->v[BMR_STOCK_MINUTES];r->friendly_fire=c->v[BMR_FRIENDLY];
    r->pause=c->v[BMR_PAUSE];r->score_display=c->v[BMR_SCORE];
    r->unk_xc=(int[]){1,0,2}[c->v[BMR_SD]]; /* retail index 0 means -1 */
    gmMainLib_GetGamePrefs()->item_freq=c->v[BMR_ITEMS]-1;
    gmMainLib_GetGamePrefs()->item_mask=c->items;
}
static void menu_apply(void) {
    menu_env("MELEE3D_NATIVE_PARTY",bmr_modes[config.v[BMR_MODE]]);menu_env("MELEE3D_NATIVE_ITEMS",bmr_items[config.v[BMR_ITEMS]]);
    menu_number("MELEE3D_NATIVE_ROUND_SECONDS",config.v[BMR_MINUTES]*60);
    static const char* const keys[]={"STOCKS","HANDICAP","DAMAGE_RATIO","STAGE_SELECTION","STOCK_MINUTES","FRIENDLY_FIRE","PAUSE","SCORE_DISPLAY","SD_PENALTY","CPU_LEVEL"};
    for(int i=BMR_STOCKS;i<=BMR_CPU;i++){char k[64];snprintf(k,sizeof k,"MELEE3D_NATIVE_%s",keys[i-BMR_STOCKS]);menu_number(k,config.v[i]);}
    menu_physics("MELEE3D_NATIVE_GRAVITY",config.v[BMR_GRAVITY]);menu_physics("MELEE3D_NATIVE_MOVE_SPEED",config.v[BMR_MOVE]);menu_physics("MELEE3D_NATIVE_GAME_SPEED",config.v[BMR_SPEED]);
    char mask[24],levels[128]={0};snprintf(mask,sizeof mask,"%u",config.items);menu_env("MELEE3D_NATIVE_ITEM_MASK",mask);
    int n=0;for(int i=0;i<32;i++)n+=snprintf(levels+n,sizeof levels-n,"%s%d",i?",":"",config.handicap[i]);menu_env("MELEE3D_NATIVE_HANDICAPS",levels);
    menu_env("MELEE3D_NATIVE_RESPAWN",config.v[BMR_MODE]==0?"action":"spread");menu_env("MELEE3D_NATIVE_SURGE",config.v[BMR_MODE]==0?"on":"off");menu_retail(&config);
}
static void menu_config(void) {
    if(config_ready)return;config_ready=1;match_load(&config);
    const char* s;
    s=getenv("MELEE3D_NATIVE_MENU_SETTINGS");FILE* f=s?fopen(s,"r"):NULL;
    if(f){bmr_read(f,&config);fclose(f);}menu_apply();
}
static void menu_save(void) {
    const char* path=getenv("MELEE3D_NATIVE_MENU_SETTINGS");if(!path)return;
    char tmp[4096];if(snprintf(tmp,sizeof tmp,"%s.tmp",path)>=(int)sizeof tmp)return;
    FILE* f=fopen(tmp,"w");if(f){bmr_write(f,&config);int ok=!ferror(f);if(fclose(f))ok=0;if(ok){
#ifdef _WIN32
        remove(path);
#endif
        if(rename(tmp,path))perror("save rules");}}
}
void m3d_MenuItemsSave(void) {
    if(!m3d_MenuActive())return;menu_config();config.items=(uint32_t)gmMainLib_GetGamePrefs()->item_mask;
    config.v[BMR_ITEMS]=gmMainLib_GetGamePrefs()->item_freq+1;menu_apply();menu_save();rule_page=RULE_MAIN;
    fprintf(stderr,"M3D MENU ITEMS frequency=%d mask=%08x\n",config.v[BMR_ITEMS]-1,config.items);
}
static void menu_request(const char* action) {
    menu_config();menu_save();const char* path=getenv("MELEE3D_NATIVE_MENU_REQUEST");
    if(path){FILE* f=fopen(path,"w");if(!f){perror("menu request");exit(2);}
        fprintf(f,"%s ",action);bmr_write(f,&config);fclose(f);}
    fprintf(stderr,"M3D MENU REQUEST action=%s\n",action);fflush(stderr);exit(0);
}
const char* m3d_MenuLabel(int kind,int selection) {
    if(m3d_MenuActive()&&kind==MENU_KIND_MAIN&&selection>=0&&selection<5&&theater_browser()){theater_index();return theater_labels[selection];}
    return m3d_MenuActive()&&kind==MENU_KIND_MAIN&&selection>=0&&selection<5?menu_labels[selection]:NULL;
}
const char* m3d_MenuDescription(int kind,int selection) {
    if(m3d_MenuActive()&&kind==MENU_KIND_MAIN&&selection>=0&&selection<5&&theater_browser()){theater_index();return theater_help[selection];}
    return m3d_MenuActive()&&kind==MENU_KIND_MAIN&&selection>=0&&selection<5?menu_help[selection]:NULL;
}
void m3d_MenuMainInput(unsigned buttons) {
    menu_config();
    if(buttons&(MenuInput_Confirm|MenuInput_AButton|MenuInput_StartButton)) {
        int i=mn_804A04F0.hovered_selection;sfxForward();
        if(theater_browser()){menu_request(i==0?"watch0":i==1?"watch1":i==2?"watch2":i==3?"theater-next":"theater-back");return;}
        if(i==0||i==1){hosting=i==1;mn_804D6BC8.cooldown=15;mn_80231714();HSD_GObjFree(HSD_GObj_CurrentInvokedProcGObj);}
        else menu_request(i==2?"join":i==3?"theater":"quit");
    }else if(buttons&MenuInput_Back){if(theater_browser()){menu_request("theater-back");return;}MenuExitData* d=gm_GetCurrentSceneExitData();d->pending_mode=GM_TITLE;gm_801A4B60();sfxBack();}
    else if(buttons&(MenuInput_Up|MenuInput_Down)){mn_804A04F0.hovered_selection=(mn_804A04F0.hovered_selection+((buttons&MenuInput_Up)?4:1))%5;sfxMove();}
}
int m3d_MenuRuleCount(void){return rule_page==RULE_HANDICAPS?3:rule_page==RULE_RANDOM?2:7;}
int m3d_MenuRule(int row){menu_config();return row>=0&&row<m3d_MenuRuleCount()?rule_rows[rule_page][row].field:-1;}
const char* m3d_MenuRuleLabel(int row){
    if(row==1&&rule_page==RULE_MAIN)return config.v[BMR_MODE]==5?"Stock":"Time Limit";
    return rule_rows[rule_page][row].label;
}
bool m3d_MenuRuleBack(void){if(!rule_page)return false;rule_page=rule_page==RULE_RANDOM?RULE_STAGE:rule_page==RULE_HANDICAPS?RULE_EXTRAS:RULE_MAIN;return true;}
void m3d_MenuRuleChange(int row,int direction) {
    menu_config();int field=m3d_MenuRule(row);if(field<0||field>=BMR_FIELDS||(field==BMR_HUMANS&&!hosting))return;
    if(rule_page==RULE_MAIN&&row==1){if(config.v[BMR_MODE]==1||config.v[BMR_MODE]==3)return;if(config.v[BMR_MODE]==5)field=BMR_STOCKS;}
    int step=field==BMR_GRAVITY||field==BMR_SPEED?5:field==BMR_MOVE?10:1;
    int v=config.v[field]+step*direction;if(v>bmr_high[field])v=bmr_low[field];if(v<bmr_low[field])v=bmr_high[field];config.v[field]=v;
    if(field==BMR_HANDICAP&&v==1)for(int i=0;i<32;i++)config.handicap[i]=5;
    menu_apply();menu_save();sfxMove();
}
/* Returns true only when opening the original Item Switch scene. */
bool m3d_MenuRuleActivate(int row) {
    int field=m3d_MenuRule(row);
    switch(field){
    case RULE_MORE_ACTION:rule_page=RULE_MORE;break;case RULE_STAGE_ACTION:rule_page=RULE_STAGE;break;
    case RULE_EXTRAS_ACTION:rule_page=RULE_EXTRAS;break;case RULE_HANDICAPS_ACTION:rule_page=RULE_HANDICAPS;break;
    case RULE_RANDOM_ACTION:rule_page=RULE_RANDOM;break;case RULE_BACK_ACTION:m3d_MenuRuleBack();break;
    case RULE_CONTINUE_ACTION:m3d_MenuContinue();return false;
    case RULE_ITEMS_ACTION:menu_retail(&config);return true;
    case RULE_SEAT_ACTION:handicap_seat=(handicap_seat+1)%32;break;
    case RULE_LEVEL_ACTION:config.handicap[handicap_seat]=config.handicap[handicap_seat]%9+1;menu_apply();menu_save();break;
    default:m3d_MenuRuleChange(row,1);return false;
    }sfxForward();return false;
}
void m3d_MenuRuleAdjust(int row,int direction){
    int f=m3d_MenuRule(row);if(f==RULE_SEAT_ACTION){handicap_seat=(handicap_seat+direction+32)%32;sfxMove();}
    else if(f==RULE_LEVEL_ACTION){config.handicap[handicap_seat]=(config.handicap[handicap_seat]-1+direction+9)%9+1;menu_apply();menu_save();sfxMove();}
    else m3d_MenuRuleChange(row,direction);
}
const char* m3d_MenuRuleValue(int row) {
    menu_config();static char out[7][64];char* s=out[row];int f=m3d_MenuRule(row),v=f>=0&&f<BMR_FIELDS?config.v[f]:0;
    if(rule_page==RULE_MAIN&&row==1){if(config.v[BMR_MODE]==5){snprintf(s,64,"%d",config.v[BMR_STOCKS]);return s;}if(config.v[BMR_MODE]==1||config.v[BMR_MODE]==3)return "Unlimited";}
    switch(f){case BMR_MODE:return mode_labels[v];case BMR_ITEMS:return item_labels[v];
    case BMR_MINUTES:case BMR_STOCK_MINUTES:if(!v)return "None";snprintf(s,64,"%d min",v);return s;
    case BMR_HANDICAP:return (const char*[]){"Off","Auto","On"}[v];case BMR_DAMAGE:snprintf(s,64,"%.1f",v/10.0);return s;
    case BMR_STAGE:return (const char*[]){"On","Random","Ordered","Turns","Loser"}[v];
    case BMR_FRIENDLY:case BMR_PAUSE:case BMR_SCORE:return v?"On":"Off";
    case BMR_SD:snprintf(s,64,v?"-%d":"0",v);return s;
    case BMR_CPU:snprintf(s,64,"%d",v);return s;
    case BMR_GRAVITY:case BMR_MOVE:case BMR_SPEED:snprintf(s,64,"%d%%",v);return s;
    case BMR_HUMANS:snprintf(s,64,hosting?"%d + CPUs":"1 + 31 CPUs",v);return s;
    case RULE_ITEMS_ACTION:return item_labels[config.v[BMR_ITEMS]];
    case RULE_MORE_ACTION:case RULE_STAGE_ACTION:case RULE_EXTRAS_ACTION:case RULE_HANDICAPS_ACTION:case RULE_RANDOM_ACTION:return "Open";
    case RULE_SEAT_ACTION:snprintf(s,64,"P%d",handicap_seat+1);return s;
    case RULE_LEVEL_ACTION:snprintf(s,64,"%d",config.handicap[handicap_seat]);return s;
    case RULE_MAP_ACTION:return rule_page==RULE_RANDOM?"All available":"Choose a stage";
    case RULE_FIGHTERS_ACTION:return "32";case RULE_BACK_ACTION:return "Return";
    default:return hosting?"Create lobby":"Choose fighter";}
}
void m3d_MenuContinue(void) {
    menu_apply();menu_save();
    fprintf(stderr,"M3D MENU RULES mode=%s items=%s seconds=%d humans=%d fighters=32 stocks=%d cpu=%d\n",bmr_modes[config.v[BMR_MODE]],bmr_items[config.v[BMR_ITEMS]],config.v[BMR_MINUTES]*60,hosting?config.v[BMR_HUMANS]:1,config.v[BMR_STOCKS],config.v[BMR_CPU]);
    if(hosting){menu_request("host");return;}
    MenuExitData* d=gm_GetCurrentSceneExitData();d->pending_mode=GM_VS;gm_801A4B60();sfxForward();
}
#include "m3d_match.inc"
/* Optional repeated-match regression: exercise the normal rule conversion,
 * stage loading, results and CSS lifecycle with a different setup each round. */
static void match_soak_options(void) {
    if(!getenv("MELEE3D_NATIVE_MATCH_SOAK"))return;
    static unsigned round;unsigned n=round++;
    const int modes[]={0,1,4,5,2,6},characters[]={38,6,11,2,34,39};
    menu_config();config.v[BMR_MODE]=modes[n%6];config.v[BMR_ITEMS]=(n%3)*2;
    config.v[BMR_STOCKS]=1+n%5;config.v[BMR_CPU]=3+3*(n%3);
    config.v[BMR_GRAVITY]=75+25*(n%3);config.v[BMR_MOVE]=75+25*((n+1)%3);
    config.v[BMR_SPEED]=100;config.v[BMR_SD]=n%3;config.v[BMR_MINUTES]=5;
    const char* stage_check=getenv("MELEE3D_NATIVE_STAGE_CHECK");
    if(stage_check&&!strcmp(stage_check,"sunshine-cycle")){config.v[BMR_MODE]=0;config.v[BMR_SD]=0;}
    menu_apply();menu_save();m3d_MenuChoose(characters[n%6]);
    fprintf(stderr,"M3D MATCH SOAK round=%u mode=%s character=%d items=%s stocks=%d cpu=%d gravity=%d speed=%d\n",round,bmr_modes[config.v[BMR_MODE]],m3d_MenuCharacter(),bmr_items[config.v[BMR_ITEMS]],config.v[BMR_STOCKS],config.v[BMR_CPU],config.v[BMR_GRAVITY],config.v[BMR_MOVE]);
}

/* Bounded input fixtures use the same action handlers as real controllers. */
unsigned m3d_MenuCheckInput(const char* screen,unsigned buttons) {
    static int main_tick,rule_tick;const char* check=getenv("MELEE3D_NATIVE_FRONTEND_CHECK");if(!check)return buttons;
    int t=!strcmp(screen,"main")?++main_tick:++rule_tick;
    if(!strcmp(screen,"main")){
        if(!strcmp(check,"main-preview"))return 0;
        if(t==45){if(!strcmp(check,"host")||!strcmp(check,"rules-extra"))mn_804A04F0.hovered_selection=1;
            else if(!strcmp(check,"join"))mn_804A04F0.hovered_selection=2;
            else if(!strcmp(check,"theater"))mn_804A04F0.hovered_selection=3;
            else if(!strcmp(check,"quit"))mn_804A04F0.hovered_selection=4;
            return MenuInput_Confirm;}return 0;}
    if(!strcmp(check,"rules-preview"))return buttons;
    if(!strcmp(check,"items")) {
        if(t==40||t==55||t==70||t==85)return MenuInput_Down;
        if(t==105)return MenuInput_AButton;if(t==150)return MenuInput_Back;return 0;
    }
    if(!strcmp(check,"rules-extra")) {
        if(t==40||t==55||t==85)return MenuInput_Up;
        if(t==70||t==100)return MenuInput_AButton;
        if(t==115||t==175)return MenuInput_Right;
        if(t==130||t==160||t==190)return MenuInput_Down;
        if(t==145||t==205)return MenuInput_Left;
        if(t==230)return MenuInput_StartButton;return 0;
    }
    if(!strcmp(check,"stock")) {
        if(t==40||t==55)return MenuInput_Left;if(t==70)return MenuInput_Down;
        if(t==85)return MenuInput_Right;if(t==120)return MenuInput_StartButton;return 0;
    }
    if(!strcmp(check,"back")&&t==70)return MenuInput_Back;
    if(t==40||t==65||t==90)return MenuInput_Right;
    if(t==55||t==80)return MenuInput_Down;
    if(!strcmp(check,"host")&&t==105)return MenuInput_Down;
    if(!strcmp(check,"host")&&t==120)return MenuInput_Right;
    if(t==160)return MenuInput_StartButton;return 0;
}
unsigned m3d_MenuItemCheckInput(unsigned buttons) {
    static int t;const char* c=getenv("MELEE3D_NATIVE_FRONTEND_CHECK");if(!c||strcmp(c,"items"))return buttons;
    t++;return t==45?MenuInput_AButton:t==60?MenuInput_Back:0;
}
