/* SPDX-License-Identifier: GPL-3.0-or-later
 * Borrowed retail-fighter views for original custom target selection. These
 * objects retain their native initialization, move tables and private unions.
 * Named public fields are refreshed/committed on access, never copied wholesale.
 */
#include "m3d_targets.h"
#include "m3d_hitboxes.h"
#include "m3d_items.h"
#include "m3d_akaneia.h"
#include "m3d_vm.h"
#include "m3d_guest_memory.h"
#include "m3d_native_calls.h"
#include <melee/ft/types.h>
#include <melee/ft/ftdata.h>
#include <melee/ft/ftparts.h>
#include <melee/ft/ftcommon.h>
#include <melee/ft/kinds/ftCommon/forward.h>
#include <melee/gm/forward.h>
#include <sysdolphin/baselib/gobj.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static struct { HSD_GObj* object; uint32_t view,bones; uint32_t callbacks[26];void* callback_owners[26]; } targets[GM_MAX_PLAYERS];
_Static_assert(GM_MAX_PLAYERS<=32,"Borrowed fighter metadata covers the full roster");
static unsigned target_count;
static void target_callback(HSD_GObj* object,unsigned slot)
{
    for(unsigned i=0;i<target_count;++i)if(targets[i].object==object) {
        if(!targets[i].callbacks[slot] || !targets[i].callback_owners[slot])m3d_vm_fail("Retired borrowed fighter callback");
        uint32_t argument=m3d_akaneia_object_export(object,1);
        m3d_akaneia_call(targets[i].callback_owners[slot],targets[i].callbacks[slot],&argument,1);return;
    }
    m3d_vm_fail("Unregistered borrowed fighter callback");
}
#define TARGET_CALLBACKS(X) \
 X(0x2190,grab_cb,0) X(0x2194,x2194,1) \
 X(0x219c,input_cb,2) X(0x21a0,anim_cb,3) X(0x21a4,phys_cb,4) X(0x21a8,coll_cb,5) X(0x21ac,cam_cb,6) \
 X(0x21b0,accessory1_cb,7) X(0x21b4,accessory2_cb,8) X(0x21b8,accessory3_cb,9) X(0x21bc,accessory4_cb,10) \
 X(0x21c0,deal_dmg_cb,11) X(0x21c4,shield_hit_cb,12) X(0x21c8,reflect_hit_cb,13) X(0x21cc,x21CC,14) \
 X(0x21d0,hitlag_cb,15) X(0x21d4,pre_hitlag_cb,16) X(0x21d8,post_hitlag_cb,17) X(0x21dc,take_dmg_cb,18) \
 X(0x21e0,death1_cb,19) X(0x21e4,death2_cb,20) X(0x21e8,death3_cb,21) X(0x21ec,x21EC,22) \
 X(0x21f0,take_dmg_2_cb,23) X(0x21f4,hurtbox_detect_cb,24) X(0x21f8,x21F8,25)
#define DECLARE_TARGET_CALLBACK(off,member,index) static void target_##member(HSD_GObj* object) { target_callback(object,index); }
TARGET_CALLBACKS(DECLARE_TARGET_CALLBACK)
void m3d_targets_track(void* pointer)
{
    HSD_GObj* object=pointer;
    Fighter* fp=object->user_data;
    uint32_t v;
    unsigned i;
    static const struct { unsigned at,size; } fields[]={
        {0,0xc},{0xc,1},{0x10,0x10},{0x2c,20},{0x74,0x90},{0x10c,4},{0x180,4},{0x5e8,4},{0x620,0x50},{0x670,0x1c},
        {0x6f0,0x19c},{0x894,0xc},{0x8a4,4},{0x2c4,8},{0x182c,0x3c},{0x1974,0x18},{0x1a4c,4},{0x1a58,12},{0x1a68,4},{0x1a70,0x18},{0x2190,8},{0x219c,0x60},{0x2218,0x14},{0x2340,0x38}
    };
    for(i=0;i<target_count;++i)if(targets[i].object==object)return;
    for(i=0;i<target_count&&targets[i].object;i++) {}
    if(i==GM_MAX_PLAYERS || !fp || fp->kind<0 || fp->kind>=33)
        m3d_vm_fail("Invalid borrowed retail target");
    if(i==target_count)target_count++;
    memset(&targets[i],0,sizeof targets[i]);
    unsigned index=i;
    v=m3d_guest_identity(0x4000);
    targets[index].object=object;targets[index].view=v;
    m3d_native_bind_object(v,fp,2);
    m3d_native_bind_object(v+0x6f0,&fp->coll_data,8);
    m3d_native_bind_object(v+0x408,&fp->x408,10); m3d_native_bind_object(v+0x488,&fp->x488,10); m3d_native_bind_object(v+0x508,&fp->x508,10);
    m3d_guest_view(v,0x3000);
    m3d_hitboxes_track(object,v);
    for(i=0;i<sizeof fields/sizeof fields[0];++i)m3d_guest_field(v+fields[i].at,fields[i].size);
    _Static_assert(offsetof(Fighter,x68C_transNPos)-offsetof(Fighter,active_timer)==0x1c,"Pointer-free native input timer bytes");
    m3d_guest_region_host(v+0x670,0x1c,&fp->active_timer);
    uint32_t bones=targets[index].bones=m3d_guest_identity(0x1000);
    m3d_guest_view(bones,MAX_FT_PARTS*16);
    for(i=0;i<MAX_FT_PARTS;++i)m3d_guest_field(bones+i*16,4);
    fprintf(stderr,"M3D LIVE TARGET slot=%u kind=%d view=%08x\n",fp->player_idx,fp->kind,v);
}
uint32_t m3d_targets_view(void* object)
{
    unsigned i;
    for(i=0;i<target_count;++i)if(targets[i].object==object)return targets[i].view;
    m3d_vm_fail("Unregistered retail target view"); return 0;
}
int m3d_targets_grab_flags(uint32_t identity,int16_t flags)
{
    for(unsigned i=0;i<target_count;++i)if(targets[i].object &&
        (identity==targets[i].view || identity==m3d_akaneia_object_export(targets[i].object,1))) {
        ftCommon_8007E2F4(targets[i].object->user_data,flags);return 1;
    }
    return 0;
}
static struct { HSD_GObj* owner; struct ftData_80085FD4_ret* pointer; uint32_t handle; } descriptors[256];
static unsigned descriptor_count;
uint32_t m3d_targets_motion(void* pointer,int motion)
{
    Fighter* fp=pointer;
    unsigned count=fp->x1C_actionStateList==ftData_803C52A0 ? 14 : ftData_Table_Unk0[fp->kind].count;
    if(motion<0 || (unsigned)motion>=count)m3d_vm_fail("Original animation descriptor index outside native table");
    struct ftData_80085FD4_ret* row=ftData_80085FD4(fp,motion);
    for(unsigned i=0;i<descriptor_count;++i)if(descriptors[i].owner==fp->gobj && descriptors[i].pointer==row)return descriptors[i].handle;
    unsigned i;for(i=0;i<descriptor_count&&descriptors[i].owner;i++) {}
    if(i==256)m3d_vm_fail("Borrowed motion descriptor arena exhausted");
    if(i==descriptor_count)descriptor_count++;
    uint32_t handle=m3d_guest_identity(0x20);
    descriptors[i].owner=fp->gobj; descriptors[i].pointer=row; descriptors[i].handle=handle;
    m3d_guest_view(handle,0x18); m3d_guest_field(handle+8,4);
    return handle;
}
static int observe_descriptor(uint32_t address,size_t size,int writing)
{
    unsigned i;
    for(i=0;i<descriptor_count;i++)if(descriptors[i].owner&&address>=descriptors[i].handle&&address-descriptors[i].handle<0x18)break;
    if(i==descriptor_count)return 0;
    if(writing || address!=descriptors[i].handle+8 || size!=4)m3d_vm_fail("Unbound animation descriptor field/write");
    m3d_vm_write32(address,descriptors[i].pointer->x8); return 1;
}
void m3d_targets_removed(void* object)
{
    unsigned i;
    for(i=0;i<descriptor_count;++i)if(descriptors[i].owner==object) {
        m3d_guest_retire(descriptors[i].handle,0x20); descriptors[i].owner=NULL; descriptors[i].pointer=NULL;
    }
    for(i=0;i<target_count;++i)if(targets[i].object==object) {
        m3d_native_unbind_object(targets[i].view+0x408); m3d_native_unbind_object(targets[i].view+0x488); m3d_native_unbind_object(targets[i].view+0x508);
        m3d_native_unbind_object(targets[i].view); m3d_guest_retire(targets[i].view,0x4000);
        m3d_native_unbind_object(targets[i].view+0x6f0);
        m3d_guest_retire(targets[i].bones,0x1000);
        m3d_hitboxes_removed(object);
        targets[i].object=NULL;
    }
}
void m3d_targets_scene_reset(void)
{
    for(unsigned i=0;i<target_count;i++)if(targets[i].object)m3d_targets_removed(targets[i].object);
}
static void scalar(uint32_t at,void* host,int writing)
{
    uint32_t v;
    if(writing) { v=m3d_vm_read32(at); memcpy(host,&v,4); }
    else { memcpy(&v,host,4); m3d_vm_write32(at,v); }
}
static void object_field(uint32_t at,HSD_GObj** host,int writing)
{
    if(writing)*host=m3d_native_object(m3d_vm_read32(at),1);
    else m3d_vm_write32(at,m3d_akaneia_object_export(*host,1));
}
int m3d_targets_observe(uint32_t address,size_t size,int writing)
{
    if(observe_descriptor(address,size,writing))return 1;
    for(unsigned index=0;index<target_count;index++)if(targets[index].object&&address>=targets[index].bones&&address-targets[index].bones<MAX_FT_PARTS*16) {
        unsigned bone=(address-targets[index].bones)/16;
        if(size!=4||(address-targets[index].bones)%16)m3d_vm_fail("Invalid borrowed native bone access");
        Fighter* fp=targets[index].object->user_data;
        if(writing)fp->parts[bone].joint=m3d_native_object(m3d_vm_read32(address),3);
        else m3d_vm_write32(address,m3d_akaneia_owned_export(fp->parts[bone].joint,3,targets[index].object));
        return 1;
    }
    unsigned i,at,offset;
    uint32_t v;
    Fighter* fp;
    for(i=0;i<target_count;++i)if(targets[i].object && address>=targets[i].view && address-targets[i].view<0x3000)break;
    if(i==target_count)return 0;
    v=targets[i].view; offset=address-v; fp=targets[i].object->user_data;
    if(offset>=0x670 && offset+size<=0x68c)return 1;
    if(offset>=0x2218 && offset<0x222c && size<=0x222c-offset) {
        unsigned char flags[0x14]={0};
        for(unsigned phase=0;phase<(writing ? 2u : 1u);++phase) {
            if(phase)m3d_vm_copy_out(flags+offset-0x2218,address,size);
#define M3D_FLAG(off,bit,width,member) \
            if(!phase) { unsigned b; for(b=0;b<width;++b) flags[off-0x2218+(bit+b)/8] |= \
                ((fp->member>>(width-1-b))&1) << (7-(bit+b)%8); } \
            else { unsigned b,value=0; for(b=0;b<width;++b)value=(value<<1)|((flags[off-0x2218+(bit+b)/8]>>(7-(bit+b)%8))&1); fp->member=value; }
#include "m3d_live_flags.inc"
#undef M3D_FLAG
        }
        if(!writing)m3d_vm_copy_in(v+0x2218,flags,sizeof flags);
        return 1;
    }
    if(offset==12 && size==1) {
        unsigned char p;
        if(writing) { m3d_vm_copy_out(&p,v+12,1); if(p!=fp->player_idx)m3d_vm_fail("Changed borrowed target slot"); }
        else m3d_vm_copy_in(v+12,&fp->player_idx,1);
        return 1;
    }
    for(at=offset&~3u;at<offset+size;at+=4) {
        if(at>=0x6f0 && at<0x88c) { m3d_items_collision_word(v+at,&fp->coll_data,at-0x6f0,writing);continue; }
#define WORD(off,member) if(at==off) { scalar(v+at,&fp->member,writing); continue; }
#define RANGE(off,member,bytes) if(at>=off && at<off+bytes) { scalar(v+at,(char*)&fp->member+at-off,writing); continue; }
#define OBJECT(off,member) if(at==off) { object_field(v+at,&fp->member,writing); continue; }
#define TARGET_FIELD(off,member,index) \
        if(at==off) { \
            if(writing) { \
                uint32_t function=m3d_vm_read32(v+at); \
                void (*native)(void)=m3d_native_callback_decode_typed(function,1,M3D_VOID,1); \
                targets[i].callbacks[index]=function;targets[i].callback_owners[index]=m3d_akaneia_current_actor(); \
                fp->member=native ? (HSD_GObjEvent)native:function ? target_##member:NULL; \
            } else { \
                if(fp->member!=target_##member)targets[i].callbacks[index]=m3d_native_callback_encode_typed((void(*)(void))fp->member,1,M3D_VOID,1); \
                m3d_vm_write32(v+at,targets[i].callbacks[index]); \
            } \
            continue; \
        }
        TARGET_CALLBACKS(TARGET_FIELD)
#undef TARGET_FIELD
        if(at==0x1a68) {
            if(writing) { uint32_t bits=m3d_vm_read32(v+at); fp->x1A68=bits>>16; fp->x1A6A=bits; }
            else m3d_vm_write32(v+at,((uint32_t)fp->x1A68<<16)|fp->x1A6A);
            continue;
        }
        OBJECT(0,gobj)
        if(at==4) { if(writing && m3d_vm_read32(v+4)!=(uint32_t)fp->kind)m3d_vm_fail("Changed borrowed target kind"); if(!writing)m3d_vm_write32(v+4,fp->kind); continue; }
        if(at==0x1c) {
            uint32_t identity=fp->x1C_actionStateList==ftData_MotionStateList ? 0x803c2800 : fp->x1C_actionStateList==ftData_803C52A0 ? 0x803c52a0 : 0;
            if(!identity || (writing && m3d_vm_read32(v+at)!=identity))m3d_vm_fail("Unbound borrowed common-motion table");
            if(!writing)m3d_vm_write32(v+at,identity); continue;
        }
        WORD(8,x8_spawnNum) WORD(0x10,motion_id) WORD(0x14,anim_id) WORD(0x18,x18)
        if(at==0x10c) {
            uint32_t data=m3d_akaneia_guest_data(fp->ft_data);
            if(writing && m3d_vm_read32(v+at)!=data)m3d_vm_fail("Changed borrowed fighter archive ownership");
            if(!writing)m3d_vm_write32(v+at,data);continue;
        }
        if(at==0x180) {
            /* Original Diddy monkey-flip latch uses the victim's aerial
             * friction. Keep the borrowed common attribute read-only. */
            if(writing)m3d_vm_fail("Write to borrowed fighter aerial friction");
            float friction=fp->co_attrs.aerial_friction;
            scalar(v+at,&friction,0);
            if(getenv("MELEE3D_NATIVE_SEQUENCE_PROFILE") &&
               !strcmp(getenv("MELEE3D_NATIVE_SEQUENCE_PROFILE"),"latch"))
                fprintf(stderr,"M3D LATCH FRICTION slot=%u value=%.6f\n",fp->player_idx,fp->co_attrs.aerial_friction);
            continue;
        }
        if(at==0x5e8) {
            uint32_t bones=targets[i].bones;
            if(writing && m3d_vm_read32(v+at)!=bones)m3d_vm_fail("Changed borrowed bone ownership");
            if(!writing)m3d_vm_write32(v+at,bones);continue;
        }
        if(at>=0x2340 && at<0x2378) {
            if(at<0x2358 && fp->motion_id>=ftCo_MS_DamageHi1 && fp->motion_id<=ftCo_MS_DamageFlyRoll) {
                /* Common damage-state numeric prefix. Original trip logic
                 * replaces these callbacks and uses its first word as a
                 * counter; preserve the bits in the native damage union. */
                scalar(v+at,(char*)&fp->mv.co.damage+at-0x2340,writing);continue;
            }
            if(at<0x234c && (fp->victim_gobj || fp->x1A5C)) {
                /* Pointer-free common capture scratch prefix. Custom capture
                 * callbacks initialise it before replacing the native state. */
                scalar(v+at,(char*)&fp->mv.co.capturewait+at-0x2340,writing);continue;
            }
            if(fp->motion_id!=ftCo_MS_CaptureKirby && fp->motion_id!=ftCo_MS_CaptureWaitKirby)
                m3d_vm_fail("Borrowed private union outside supported native capture state");
            if(at==0x2358) {
                if(writing)fp->mv.co.capturekirby.x18=m3d_vm_read32(v+at)!=0;
                else m3d_vm_write32(v+at,fp->mv.co.capturekirby.x18);
            } else scalar(v+at,(char*)&fp->mv.co.capturekirby+at-0x2340,writing);
            continue;
        }
        RANGE(0x2c,facing_dir,20) RANGE(0x74,x74_self_accel,0x90) RANGE(0x620,input,0x50)
        RANGE(0x894,cur_anim_frame,12) WORD(0x8a4,x8A4_animBlendFrames) RANGE(0x2c4,x2C4,8) RANGE(0x182c,dmg.x182c_behavior,0x3c)
        OBJECT(0x1974,item_gobj) OBJECT(0x1978,x1978) OBJECT(0x197c,x197C) OBJECT(0x1980,x1980) OBJECT(0x1984,x1984_heldItemSpec)
        RANGE(0x1a70,x1A70,12) RANGE(0x1a7c,x1A7C,12)
        WORD(0x1988,x1988)
        WORD(0x1a4c,grab_timer)
        OBJECT(0x1a58,victim_gobj) OBJECT(0x1a5c,x1A5C) OBJECT(0x1a60,target_item_gobj)
        m3d_vm_fail("Unbound borrowed retail fighter field");
#undef WORD
#undef RANGE
#undef OBJECT
    }
    return 1;
}
