"""Decode static F3D/F3DZEX2 meshes, optionally capturing F3D materials/lights.

Matrices are rejected; callers apply scene/object transforms explicitly.
The initial material capture supports the LoadBlock path used by Bowser.
"""
import struct
import math


def display_mesh(banks, address, name, newer=False, virtual=None, capture_materials=False, environment=None):
    vertices, attributes, triangles, cache, unresolved = [], [], [], {}, set()
    budget = [100000]
    materials, tiles, loads, lights = [], {}, {}, {}
    state = dict(image=None, enabled=False, tile=0, scale=[65535,65535], geometry=0x20000, palette=None,primitive=[255]*4,environment=[255]*4,combine=None)

    def resolve(pointer):
        if virtual is not None and pointer >= virtual[0]:
            return virtual[1], pointer-virtual[0]
        segment, offset = pointer >> 24, pointer & 0xFFFFFF
        if segment not in banks: return None
        return banks[segment], offset

    def triangle(ids):
        if any(i not in cache for i in ids): raise ValueError('Display-list triangle uses an unloaded vertex')
        tri = dict(indices=[cache[i] for i in ids])
        if capture_materials:
            material = None
            if state['enabled']:
                tile = dict(tiles.get(state['tile'], {}))
                image = loads.get(tile.get('tmem'))
                if not image or 'width' not in tile:
                    raise ValueError('Textured triangle has no resolved render tile')
                material = dict(tile, image=image, scale=list(state['scale']),geometry=state['geometry'],
                                primitive=list(state['primitive']),environment=list(state['environment']),combine=state['combine'])
                if tile['format']==2:
                    if state['palette'] is None:raise ValueError('CI texture has no source palette')
                    material['palette_load']=state['palette']
            if material not in materials: materials.append(material)
            tri['material'] = materials.index(material)
            tri['render_state']={k:state[k] for k in ('geometry','primitive','environment','combine')}
        triangles.append(tri)

    def shade(raw):
        if not state['geometry'] & 0x20000: return list(raw)
        # RSP lighting is evaluated when vertices enter the cache. Preserve
        # that timing, including changes to lights between vertex loads.
        if environment is not None:
            normal=[x if x<128 else x-256 for x in raw[:3]]
            rgb=list(environment['ambient'])
            for prefix in ('light1','light2'):
                direction=environment[prefix+'_direction'];length=math.sqrt(sum(x*x for x in direction))
                amount=max(0,sum(a*b for a,b in zip(normal,direction))/(127*length)) if length else 0
                for i in range(3):rgb[i]+=environment[prefix+'_color'][i]*amount
            return [min(255,round(v)) for v in rgb]+[raw[3]]
        if 0x86 not in lights or 0x88 not in lights:
            raise ValueError('Lit vertex has unresolved source lighting')
        diffuse, ambient = lights[0x86], lights[0x88]
        normal = [x if x < 128 else x-256 for x in raw[:3]]
        direction = [x if x < 128 else x-256 for x in diffuse[8:11]]
        length = math.sqrt(sum(x*x for x in direction))
        intensity = max(0, sum(a*b for a,b in zip(normal,direction))/(127*length)) if length else 0
        return [min(255, round(ambient[i]+diffuse[i]*intensity)) for i in range(3)]+[raw[3]]

    def run(pointer, depth=0):
        if depth > 32: raise ValueError('Display-list recursion limit')
        resolved = resolve(pointer)
        if resolved is None:
            unresolved.add(pointer)
            return
        data, offset = resolved
        while budget[0] > 0:
            budget[0] -= 1
            w0, w1 = struct.unpack_from('>II', data, offset); offset += 8
            op = w0 >> 24
            if op == (0xDF if newer else 0xB8): return
            if op == (0xDE if newer else 0x06):
                run(w1, depth+1)
                if (w0 >> 16) & 255: return
            elif op == (0x01 if newer else 0x04):
                count = (w0 >> 12) & 255 if newer else ((w0 >> 20) & 15)+1
                first = ((w0 >> 1) & 127)-count if newer else (w0 >> 16) & 15
                src = resolve(w1)
                if src is None: raise ValueError('Unresolved vertex bank')
                bank, start = src
                if first < 0 or first+count > 32: raise ValueError('Invalid vertex cache range')
                for i in range(count):
                    xyz = list(struct.unpack_from('>hhh', bank, start+i*16))
                    cache[first+i] = len(vertices); vertices.append(xyz)
                    attributes.append(dict(st_fixed=list(struct.unpack_from('>hh',bank,start+i*16+8)),
                                           rgba_or_normal=list(bank[start+i*16+12:start+i*16+16])))
                    if capture_materials:
                        attributes[-1]['lit_rgba'] = shade(bank[start+i*16+12:start+i*16+16])
            elif op == (0x05 if newer else 0xBF):
                word = w0 if newer else w1
                divisor = 2 if newer else 10
                triangle([((word >> shift) & 255)//divisor for shift in (16,8,0)])
            elif (newer and op in (0x06,0x07)) or (not newer and op==0xB1):
                divisor = 2 if newer else 10
                for word in (w0,w1):
                    triangle([((word >> shift) & 255)//divisor for shift in (16,8,0)])
            elif op == (0xDA if newer else 0x01):
                raise ValueError('Static inspection decoder does not implement matrix commands')
            elif capture_materials:
                if op == 0xFA:state['primitive']=[(w1>>shift)&255 for shift in (24,16,8,0)]
                elif op == 0xFB:state['environment']=[(w1>>shift)&255 for shift in (24,16,8,0)]
                elif op == 0xFC:state['combine']=[w0,w1]
                elif op == 0xFD:
                    state['image'] = dict(address=w1, format=(w0>>21)&7, size=(w0>>19)&3,
                                          image_width=(w0&4095)+1)
                elif op == 0xF5:
                    tile = (w1>>24)&7
                    old = tiles.setdefault(tile,{})
                    old.update(format=(w0>>21)&7, size=(w0>>19)&3, tmem=w0&511,
                               wrap_t=(w1>>18)&3, mask_t=(w1>>14)&15, shift_t=(w1>>10)&15,
                               palette=(w1>>20)&15, wrap_s=(w1>>8)&3, mask_s=(w1>>4)&15, shift_s=w1&15)
                elif op == 0xF2:
                    tile = tiles.setdefault((w1>>24)&7,{})
                    ul_s,ul_t = (w0>>12)&4095,w0&4095
                    tile.update(width=(((w1>>12)&4095)-ul_s)//4+1,
                                height=((w1&4095)-ul_t)//4+1, ul_s=ul_s,ul_t=ul_t)
                elif op == 0xF3:
                    tile = tiles.get((w1>>24)&7)
                    if not tile or state['image'] is None: raise ValueError('Unresolved texture load')
                    loads[tile['tmem']] = dict(state['image'])
                elif op == 0xF4:raise ValueError('LoadTile cropping needs an additional decoder')
                elif op == 0xF0:
                    tile=tiles.get((w1>>24)&7)
                    if not tile or state['image'] is None:raise ValueError('unresolved source palette')
                    state['palette']=dict(image=state['image'],count=((w1>>14)&1023)+1,first=tile['tmem']-256)
                elif op == (0xD7 if newer else 0xBB):
                    state.update(enabled=bool(w0&255), tile=(w0>>8)&7,
                                 scale=[w1>>16,w1&65535])
                elif not newer and op == 0x03 and ((w0>>16)&255) in (0x86,0x88):
                    resolved = resolve(w1)
                    if resolved is None: raise ValueError('Unresolved lighting bank')
                    b,o = resolved
                    lights[(w0>>16)&255] = b[o:o+16]
                elif newer and op == 0xD9: state['geometry'] = (state['geometry'] & (w0&0xffffff)) | w1
                elif not newer and op == 0xB6: state['geometry'] &= ~w1
                elif not newer and op == 0xB7: state['geometry'] |= w1
        raise ValueError('Display-list command limit')

    run(address)
    return dict(name=name, vertices=vertices, vertex_attributes=attributes, triangles=triangles,
                unresolved_material_lists=sorted(unresolved),
                materials=materials if capture_materials else 'untextured inspection mesh')
