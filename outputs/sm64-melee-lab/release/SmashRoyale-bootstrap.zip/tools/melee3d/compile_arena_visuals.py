#!/usr/bin/env python3
"""Build the private presentation bank: source materials, UVs and panorama.

M3V1 is independent of M3A1 collision. The initial converter accepts the RGBA16
materials used by Bowser; unsupported source materials fail explicitly.
"""
import argparse
import json
from pathlib import Path
import struct


def rgba16(data, width, height):
    if len(data) != width*height*2: raise ValueError('truncated RGBA16 texture')
    return [((n>>11)*255//31, ((n>>6)&31)*255//31, ((n>>1)&31)*255//31,
             (n&1)*255) for (n,) in struct.iter_unpack('>H',data)]


def gx_rgb5a3(pixels, width, height):
    if width%4 or height%4 or len(pixels) != width*height:
        raise ValueError('invalid GX tiled texture dimensions')
    out = bytearray()
    for by in range(0,height,4):
        for bx in range(0,width,4):
            for y in range(4):
                for x in range(4):
                    r,g,b,a = pixels[(by+y)*width+bx+x]
                    n = (0x8000 | ((r*31+127)//255)<<10 | ((g*31+127)//255)<<5 | (b*31+127)//255) if a==255 else (
                        (a*7//255)<<12 | (r>>4)<<8 | (g>>4)<<4 | b>>4)
                    out += struct.pack('>H',n)
    return bytes(out)


def sky_panorama(bank):
    # Native sky bank: 64 texture tiles followed by an 8x10 pointer table.
    # The two repeated columns and each tile's duplicate border are omitted.
    if len(bank) < 320: raise ValueError('missing sky table')
    table = struct.unpack('>80I',bank[-320:])
    tiles = []
    for row in range(8):
        for col in range(8):
            ptr = table[row*10+col]
            off = ptr&0xffffff
            if ptr>>24 != 10 or off+2048 > len(bank)-320:
                raise ValueError('invalid sky tile pointer')
            tiles.append(rgba16(bank[off:off+2048],32,32))
    # Use a power-of-two panorama with wrap-compatible GX sampling. Each source
    # tile covers 31 unique texels; native rendering samples its shared border.
    pixels=[]
    for y in range(256):
        sy=y*248//256
        for x in range(256):
            sx=x*248//256
            pixels.append(tiles[(sy//31)*8+sx//31][(sy%31)*32+sx%31])
    return pixels


def build(source, scale=.025, height=307):
    banks={int(p.stem[7:],16):p.read_bytes() for p in source.glob('segment*.bin')}
    meshes=json.loads((source/'visual_meshes.json').read_text())
    props=source/'prop_visual_meshes.json'
    if props.exists(): meshes += json.loads(props.read_text())
    materials, images, triangles, billboards = [], [], [], []
    def material(desc):
        if desc is None: raise ValueError('untextured material is not supported in M3V1')
        if desc['format'] != 0 or desc['size'] != 2:
            raise ValueError('source material needs an additional N64 pixel decoder')
        width,height=desc['width'],desc['height']
        if not 4 <= width <= 512 or not 4 <= height <= 512:
            raise ValueError('invalid material dimensions')
        ptr=desc['image']['address'];bank=banks[ptr>>24];off=ptr&0xffffff
        pixels=rgba16(bank[off:off+width*height*2],width,height)
        # N64 wrap flags: bit 1 clamp, bit 0 mirror. GX enum: clamp/repeat/mirror.
        wrap=lambda flags:0 if flags&2 else (2 if flags&1 else 1)
        key=(width,height,wrap(desc['wrap_s']),wrap(desc['wrap_t']),gx_rgb5a3(pixels,width,height))
        if key not in materials:
            materials.append(key);images.append((width,height,pixels))
        return materials.index(key)
    for mesh in meshes:
        if mesh.get('unresolved_material_lists'):
            raise ValueError('cannot compile an incomplete display-list graph')
        mapping=[material(m) for m in mesh['materials']]
        center=mesh.get('billboard_center')
        group=0
        if center is not None:
            billboards.append((center[0]*scale,(center[1]-height)*scale,center[2]*scale))
            group=len(billboards)
            if group>255: raise ValueError('too many billboard groups')
        for tri in mesh['triangles']:
            desc=mesh['materials'][tri['material']]
            face=bytearray(struct.pack('>I',mapping[tri['material']]|(group<<16)))
            for index in tri['indices']:
                v=mesh['vertices'][index];a=mesh['vertex_attributes'][index]
                uv=[]
                for axis,key in enumerate(('s','t')):
                    shift=desc['shift_'+key]
                    multiplier=1/(1<<shift) if shift<=10 else 1<<(16-shift)
                    uv.append((a['st_fixed'][axis]/32*desc['scale'][axis]/65536*multiplier-
                               desc['ul_'+key]/4)/desc[('width','height')[axis]])
                position=[(v[i]-center[i])*scale for i in range(3)] if center is not None else [v[0]*scale,(v[1]-height)*scale,v[2]*scale]
                face+=struct.pack('>3f4B2f',*position,
                                  *a['lit_rgba'],*uv)
            triangles.append(face)
    sky=sky_panorama(banks[10]);sky_id=len(materials)
    materials.append((256,256,1,0,gx_rgb5a3(sky,256,256)));images.append((256,256,sky))
    if len(materials)>128 or len(triangles)>4096: raise ValueError('runtime limits exceeded')
    anchors=b''.join(struct.pack('>3fI',*c,0) for c in billboards)
    data_start=(32+len(materials)*32+len(triangles)*76+len(anchors)+31)&~31
    body=bytearray();descriptors=[]
    for w,h,ws,wt,data in materials:
        descriptors.append(struct.pack('>8I',w,h,ws,wt,data_start+len(body),len(data),0,0))
        body+=data
        body+=bytes((-len(body))%32)
    size=data_start+len(body)
    if size>=524256: raise ValueError('visual bank exceeds runtime buffer')
    head=struct.pack('>8I',0x4d335631,2,len(materials),len(triangles),size,sky_id,data_start,len(billboards))
    result=head+b''.join(descriptors)+b''.join(triangles)+anchors
    result+=bytes(data_start-len(result))+body
    return result,images,dict(format='M3V1',materials=len(materials),triangles=len(triangles),
                              sky_material=sky_id,billboards=len(billboards),bytes=size,source='source RGBA16, UVs and RSP lighting')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--previews',type=Path)
    a=p.parse_args();data,images,report=build(a.source)
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_bytes(data)
    a.output.with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
    if a.previews:
        from PIL import Image
        a.previews.mkdir(parents=True,exist_ok=True)
        for i,(w,h,pixels) in enumerate(images):
            im=Image.new('RGBA',(w,h));im.putdata(pixels);im.save(a.previews/f'material-{i}.png')
    print(json.dumps(report))


if __name__=='__main__':main()
