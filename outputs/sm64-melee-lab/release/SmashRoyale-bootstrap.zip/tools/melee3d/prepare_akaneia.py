#!/usr/bin/env python3
"""Prepare the official Akaneia 1.0.1 ISO in isolated build storage.

This installs upstream Akaneia, not a combined Akaneia/3D build. The two DOLs
cannot be stacked. No files in the interactive Melee 3D disc are modified.
"""

import argparse
import hashlib
from pathlib import Path
import shutil
import ssl
import sys
import subprocess
import tempfile
import urllib.request


VERSION = "1.0.1"
BASE_MD5 = "0e63d4223b01d9aba596259dc155a174"
PATCHED_MD5 = "63ea8e113e451c9369f17f7a49012412"
RELEASE_URL = "https://github.com/akaneia/akaneia-build/releases/tag/1.0.1"
ASSET_URL = (
    "https://github.com/akaneia/akaneia-build/releases/download/1.0.1/"
    "Akaneia.Builder.1.0.1.7z"
)
from player_paths import payload
ROOT = payload()


def digest(path, algorithm="md5"):
    result = hashlib.new(algorithm)
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def verify(path, expected):
    actual = digest(path)
    if actual != expected:
        raise ValueError(f"Checksum mismatch for {path}: {actual}; expected {expected}")


def wine_path(path):
    return "Z:" + str(Path(path).resolve()).replace("/", "\\")


def prepare(base_iso, directory, archive=None):
    # Check before downloading, unpacking, or creating any output ISO.
    verify(base_iso, BASE_MD5)
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / f"Akaneia-{VERSION}.iso"
    if target.exists():
        verify(target, PATCHED_MD5)
        return target
    sevenzip = shutil.which("7zz") or shutil.which("7z")
    xdelta = shutil.which("xdelta3")
    wine = shutil.which("wine64")
    if not sevenzip or (not xdelta and not wine):
        raise RuntimeError("Requires 7z/7zz and either xdelta3 or wine64")
    archive = archive or directory / f"Akaneia.Builder.{VERSION}.7z"
    if not archive.exists():
        partial = archive.with_suffix(".download")
        try:
            context=ssl.create_default_context()
            # A frozen Python has no developer OpenSSL install. Use macOS's
            # system trust bundle; Windows' default context uses its root store.
            if sys.platform=='darwin':context.load_verify_locations('/etc/ssl/cert.pem')
            with urllib.request.urlopen(ASSET_URL,timeout=45,context=context) as response, partial.open("wb") as out:
                shutil.copyfileobj(response, out)
            partial.replace(archive)
        except OSError as error:
            raise RuntimeError("Could not download Akaneia. Check your connection, or choose Use offline patch in Setup with the official Akaneia 1.0.1 builder .7z.") from error
        finally:
            partial.unlink(missing_ok=True)
    with tempfile.TemporaryDirectory(prefix="prepare-", dir=directory) as temp:
        temp = Path(temp)
        subprocess.run(
            [sevenzip, "x", "-y", f"-o{temp}", str(archive.resolve())],
            check=True, stdout=subprocess.DEVNULL,
        )
        builder = temp / "Akaneia Builder"
        patch = builder / "patch.xdelta"
        staged = temp / "patched.iso"
        if xdelta:
            command = [xdelta, "-d", "-s", str(base_iso.resolve()), str(patch), str(staged)]
        else:
            command = [
                wine, str(builder / "Windows/xdelta.exe"), "-d", "-s",
                wine_path(base_iso), wine_path(patch), wine_path(staged),
            ]
        subprocess.run(command, check=True)
        verify(staged, PATCHED_MD5)
        # Publish only the verified result; never replace an existing installation.
        # link() also refuses a destination created by a concurrent invocation.
        target.hardlink_to(staged)
    return target


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-iso", required=True, type=Path)
    parser.add_argument("--directory", type=Path, default=ROOT / "build/akaneia")
    parser.add_argument("--archive", type=Path)
    args = parser.parse_args()
    try:
        iso = prepare(args.base_iso, args.directory.resolve(), args.archive)
    except (ValueError, RuntimeError, OSError, subprocess.CalledProcessError) as error:
        parser.exit(1, f"Akaneia preparation failed: {error}\n")
    print(f"Verified upstream Akaneia {VERSION}: {iso}")
    print("3D integration is not present in this ISO; the existing Melee 3D build is unchanged.")


if __name__ == "__main__":
    main()
