#!/usr/bin/env python3
"""Native player-hosted room preview. LAN/direct IPv4; no hosted service.

Invite files contain a private room key, rules and hashes, never game data.
All peers must already have matching locally imported games and native build.
"""
import argparse
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import signal
import shutil
import sys
from player_paths import game_command
import subprocess
import threading
import time
import uuid

from native_compatibility import ROOT, WORK, DISC, sha, write_json
from native_mac import verify_build, bundle
from native_roster import inventory, asset_identity
from native_live import stage_assets
from native_lineup import BY_NAME, lineup, room_lineup
from player_room import Room
from sunshine_extract import CACHE

INSTALLATION=None
EXECUTABLE=None


def configure_installation(directory,binary=None):
    global INSTALLATION,EXECUTABLE,CACHE,DISC,WORK
    if directory is None:return
    from player_install import ready_install as verify_install
    from player_play import binary_path
    INSTALLATION=directory.expanduser().resolve()
    metadata=verify_install(INSTALLATION)
    EXECUTABLE=binary_path(binary)
    CACHE=INSTALLATION/'sunshine';DISC=Path(metadata['melee_path'])
    WORK=INSTALLATION.parent/'multiplayer';WORK.mkdir(parents=True,exist_ok=True)


def local_identity():
    if INSTALLATION is not None:
        metadata=json.loads((INSTALLATION/'player-install.json').read_text())
        from player_stage import visual_bank
        bank=visual_bank(INSTALLATION,metadata)
        game_files={k:v for k,v in metadata['files'].items() if not k.endswith(('.json','.log','.wav'))}
        if (bank/'report.json').is_file():
            for name,value in json.loads((bank/'report.json').read_text())['files'].items():game_files['sunshine/native-preview/'+name]=value
        return dict(executable=sha(EXECUTABLE),melee=metadata['melee_sha256'],game_files=game_files)
    build=verify_build()
    report=json.loads((CACHE/'native-preview/report.json').read_text())
    for name,value in report['files'].items():
        if sha(CACHE/'native-preview'/name)!=value:raise ValueError('Plaza cache changed: '+name)
    music=json.loads((CACHE/'music-report.json').read_text())
    if sha(CACHE/'delfino_plaza.wav')!=music['wav_sha256']:raise ValueError('Plaza music changed')
    return dict(executable=build['executable_sha256'],akaneia=asset_identity(inventory()),
                plaza=report['files'],melee=sha(DISC))


def compatibility(invite):
    if not isinstance(invite.get('humans'),int) or not 2<=invite['humans']<=32:raise ValueError('Invalid room capacity')
    value={k:invite[k] for k in ('version','identity','humans','fighters','characters','lineup','mode','items','seed','delay','frames')}
    value['seconds']=invite.get('seconds',max(10,invite['frames']//60-8))
    from player_rules import validate as validate_rules
    value['rules']=validate_rules(invite.get('rules'))
    value['names']=invite.get('names',[f'P{i+1}' for i in range(invite['humans'])])
    if 'selection' in invite:
        from player_rules import selection
        value['selection']=selection(invite['selection'],invite['humans'])
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def create(humans=2,fighters=32,characters=('sonic','link'),mode='survival',items='medium',seed=1,delay=4,frames=36000,identity=None,seconds=None,names=None,rules=None,selection=None):
    from player_lobby import player_name
    if not 2<=humans<=32 or fighters not in (2,16,24,32) or humans>fighters:
        raise ValueError('Requires 2–32 humans, within the selected fighter capacity')
    names=names if names is not None else [f'P{i+1}' for i in range(humans)]
    if not isinstance(names,(list,tuple)) or len(names)!=humans:raise ValueError('Choose one name per human player.')
    names=[player_name(n) or f'P{i+1}' for i,n in enumerate(names)]
    if not 2<=humans<=32 or fighters not in (2,16,24,32) or humans>fighters:
        raise ValueError('Requires 2–32 humans, within the selected fighter capacity')
    preferences=None
    if selection is not None:
        from player_rules import selection as validate_selection,resolved_selection
        preferences=validate_selection(selection,humans);characters=resolved_selection(preferences,humans,seed)
    if len(characters)!=humans or any(c not in BY_NAME for c in characters):
        raise ValueError('Choose one supported character per human')
    if not 1<=delay<=12 or not 0<=seed<=0xffffffff or not (frames==0 or 120<=frames<=432000):
        raise ValueError('Invalid room delay, seed or duration')
    chosen=room_lineup(fighters,characters,seed)
    if preferences and preferences["cpu"]!="random":chosen=chosen[:humans]+[BY_NAME[preferences["cpu"]]]*(fighters-humans)
    value=dict(version=1,identity=identity or local_identity(),humans=humans,fighters=fighters,characters=list(characters),
               lineup=[r[1] for r in chosen],mode=mode,items=items,seed=seed,delay=delay,frames=frames,seconds=seconds if seconds is not None else max(10,frames//60-8),key=secrets.token_hex(32))
    from player_rules import validate as validate_rules
    value['rules']=validate_rules(rules)
    if preferences:value['selection']=preferences
    value['names']=names;value['compatibility']=compatibility(value)
    return value


def validate(invite):
    from player_lobby import player_name
    # Validate untrusted invitations before starting a game or allocating a room.
    if invite.get('version')!=1 or invite.get('compatibility')!=compatibility(invite):raise ValueError('Invalid room invitation')
    names=invite.get('names',[f'P{i+1}' for i in range(invite['humans'])])
    if not isinstance(names,list) or len(names)!=invite['humans'] or any(not player_name(n) for n in names):raise ValueError('Invalid human player names')
    if invite['mode'] not in ('battle','hill','survival','coin','time','stock','bonus') or invite['items'] not in ('off','verylow','low','medium','high','veryhigh'):
        raise ValueError('Unsupported room rules')
    if not 2<=invite['humans']<=32 or invite['fighters'] not in (2,16,24,32) or invite['humans']>invite['fighters']:
        raise ValueError('Invalid room capacity')
    if len(invite['lineup'])!=invite['fighters'] or any(k not in {r[1] for r in BY_NAME.values()} for k in invite['lineup']):
        raise ValueError('Invalid room roster')
    if (len(invite['characters'])!=invite['humans'] or any(c not in BY_NAME for c in invite['characters'])
            or invite['lineup'][:invite['humans']]!=[BY_NAME[c][1] for c in invite['characters']]):
        raise ValueError('Invalid human character selection')
    if 'selection' in invite:
        from player_rules import selection,resolved_selection
        preferences=selection(invite['selection'],invite['humans'])
        if resolved_selection(preferences,invite['humans'],invite['seed'])!=invite['characters']:raise ValueError('Invalid Random fighter resolution')
        if preferences['cpu']!='random' and any(c!=BY_NAME[preferences['cpu']][1]for c in invite['lineup'][invite['humans']:]):raise ValueError('Invalid shared CPU roster')
    if len(bytes.fromhex(invite['key']))!=32:raise ValueError('Invalid room key')
    if not 1<=invite['delay']<=12 or not 0<=invite['seed']<=0xffffffff or not (invite['frames']==0 or 120<=invite['frames']<=432000):
        raise ValueError('Invalid room timing')
    if type(invite.get('seconds')) is not int or not 0<=invite['seconds']<=5940:raise ValueError('Invalid round duration')
    if invite['identity']!=local_identity():raise ValueError('This machine has a different build or imported game content')


def launch(invite,seat,host,port,folder,files,script=False):
    game=folder if INSTALLATION else bundle(folder/'Smash Royale Multiplayer.app')
    game.mkdir(parents=True,exist_ok=True)
    cache=WORK/'caches'/f'player-{seat}';cache.mkdir(parents=True,exist_ok=True)
    binary=EXECUTABLE if INSTALLATION else game/'melee'
    akaneia=INSTALLATION/'akaneia/files' if INSTALLATION else ROOT/'build/akaneia/disc/files'
    from player_stage import visual_bank
    bank=visual_bank(INSTALLATION) if INSTALLATION else CACHE/'native-preview'
    env={k:v for k,v in os.environ.items() if not k.startswith(('MELEE_','MELEE3D_'))}
    env.update(MELEE_BOOT_SCENE='vs',MELEE_DEBUG_VS_STAGE='32',MELEE3D_NATIVE_LAB=str(invite['fighters']),
               MELEE3D_NATIVE_PLAYER_NAMES='|'.join(invite.get('names',[f'P{i+1}' for i in range(invite['humans'])])),
               MELEE3D_NATIVE_ROSTER='akaneia',MELEE3D_NATIVE_HUMAN='1',MELEE3D_NATIVE_CHARACTER=invite['characters'][0],
               MELEE3D_NATIVE_LINEUP=','.join(map(str,invite['lineup'])),MELEE_SEED=str(invite['seed']),
               MELEE3D_NATIVE_3D='1',MELEE3D_NATIVE_CAMERA='combat',MELEE3D_NATIVE_CAMERA_TURN='snap',
               MELEE3D_NATIVE_INPUTS='spatial',MELEE3D_NATIVE_AKANEIA='1',MELEE3D_NATIVE_DELFINO=str(bank),
               MELEE3D_AKANEIA_FILES=str(akaneia),MELEE_FILES_DIR=str(files),
               MELEE_LOG_FILE=str(folder/'game.log'),MELEE_CACHE_DIR=str(cache),
               MELEE_WINDOW_TITLE=f'Smash Royale Multiplayer — Player {seat+1}',MELEE_FPS='1',
               MELEE3D_ROOM_FRAMES=str(invite['frames']),MELEE3D_NATIVE_PARTY=invite['mode'],
               MELEE3D_NATIVE_ITEMS=invite['items'],MELEE3D_NATIVE_RESULTS='off',MELEE3D_NATIVE_RETURN_TO_MENU='1',
               MELEE3D_NATIVE_ROUND_SECONDS=str(invite.get('seconds',max(10,invite['frames']//60-8))),
               MELEE3D_NATIVE_ASSIST='startup',MELEE3D_NATIVE_PROJECTILES='distance',MELEE3D_NATIVE_DI='fixed',
               MELEE3D_NATIVE_ZONE='adaptive',MELEE3D_NATIVE_HILL_RULE='brawl',
               MELEE3D_NATIVE_RESPAWN='action' if invite['mode']=='hill' else 'spread',
               MELEE3D_NATIVE_SURGE='on' if invite['mode']=='hill' else 'off',
               MELEE3D_ROOM=f'{host}:{port}',MELEE3D_ROOM_SEAT=str(seat),MELEE3D_ROOM_HUMANS=str(invite['humans']),
               MELEE3D_ROOM_KEY=invite['key'],MELEE3D_ROOM_IDENTITY=invite['compatibility'])
    from player_rules import environment as rule_environment
    env.update(rule_environment(invite.get('rules')))
    if 'selection' in invite:env['MELEE3D_NATIVE_HUMAN_COSTUMES']=','.join(map(str,invite['selection']['costumes']))
    if not invite['frames']:env.pop('MELEE3D_ROOM_FRAMES',None)
    # Music stays at the user's cache. This local test bundle ships no audio.
    music=game/'music';music.mkdir(exist_ok=True)
    if not (music/'delfino_plaza.wav').exists():shutil.copy2(CACHE/'delfino_plaza.wav',music/'delfino_plaza.wav')
    if sys.platform=='darwin':env['MELEE_BACKEND']='metal'
    if script:env['MELEE3D_ROOM_SCRIPT']='1'
    log=(folder/'stdout.txt').open('w')
    process=subprocess.Popen(game_command(binary,DISC),cwd=game,env=env,stdout=log,stderr=subprocess.STDOUT)
    return process,log


def run(invite,host='127.0.0.1',port=41032,seat=0,hosting=False,local_test=False,script=False,report_callback=None):
    validate(invite)
    ipaddress.IPv4Address(host)
    if not 0<=seat<invite['humans'] or not 1<=port<=65535:raise ValueError('Invalid player seat or host port')
    from player_session import session_lock
    session=session_lock(WORK/'seats'/f'player-{seat}');session.__enter__()
    folder=WORK/'multiplayer'/(str(time.time_ns())+'-'+uuid.uuid4().hex[:8]);folder.mkdir(parents=True)
    processes=[];room=None;thread=None
    try:
        files=INSTALLATION/'akaneia/files' if INSTALLATION else stage_assets(inventory(),True)
        if hosting or local_test:
            room=Room((host,0 if local_test else port),invite['humans'],bytes.fromhex(invite['key']),
                      bytes.fromhex(invite['compatibility']),delay=invite['delay'],seed=invite['seed'],max_frames=invite['frames'])
            port=room.address[1]
            thread=threading.Thread(target=room.run,daemon=True);thread.start()
        for index in (range(invite['humans']) if local_test else (seat,)):
            processes.append(launch(invite,index,host,port,folder/f'player-{index}',files,local_test or script))
        deadline=time.monotonic()+invite['frames']/20+180 if invite['frames'] else None
        while any(p.poll() is None for p,_ in processes):
            if deadline is not None and time.monotonic()>deadline:raise TimeoutError('Native multiplayer watchdog expired')
            if room and room.result.get('error'):raise RuntimeError(room.result['error'])
            if any(p.poll() not in (None,0) for p,_ in processes):raise RuntimeError('The game stopped unexpectedly. Open Logs for details.')
            time.sleep(.2)
        codes=[p.returncode for p,_ in processes]
        logs=[(folder/f'player-{index}/stdout.txt').read_text() for index in (range(invite['humans']) if local_test else (seat,))]
        expected_npcs=set(range(invite['humans'],invite['fighters']))
        npc_evidence=[{int(slot) for slot,level in re.findall(r'M3D CPU DIFFICULTY slot=(\d+) level=(\d+)',s) if int(level)==invite.get('rules',{}).get('cpu_level',9)} for s in logs]
        npc_checked=invite['frames']==0 or invite['frames']>=600
        report=dict(passed=all(code==0 for code in codes) and all('M3D ROOM FRAME frame=' in s and 'M3D ROOM COMPLETE frames=' in s for s in logs),
                    exit_codes=codes,humans=invite['humans'],npcs=len(expected_npcs),fighters=invite['fighters'],local_test=local_test,
                    npc_difficulty_checked=npc_checked,npc_slots=[sorted(slots) for slots in npc_evidence],
                    observed_frames=[len(re.findall('M3D ROOM FRAME frame=',s)) for s in logs],
                    scope='Native game instances; localhost only' if local_test else 'Direct player-hosted native preview')
        ending=re.search(r'M3D PARTY END tick=(\d+) winner=(-?\d+)',logs[0])
        if ending:
            winner=int(ending[2]);name=next((name for name,kind,_ in BY_NAME.values() if winner>=0 and kind==invite['lineup'][winner]),'Draw')
            report['round']=dict(winner=name,seconds=int(ending[1])//60,you_won=winner==seat)
        from player_rules import adjusted_handicaps
        adjusted=adjusted_handicaps(logs[0],invite.get('rules'))
        if adjusted:report['options']=dict(mode=invite['mode'],items=invite['items'],seconds=invite['seconds'],humans=invite['humans'],rules=adjusted)
        if npc_checked:report['passed']=report['passed'] and all(slots==expected_npcs for slots in npc_evidence)
    except (RuntimeError,TimeoutError,OSError,ValueError) as error:
        report=dict(passed=False,error=str(error),humans=invite['humans'],fighters=invite['fighters'])
    finally:
        for process,log in processes:
            if process.poll() is None:
                process.terminate()
                try:process.wait(timeout=5)
                except subprocess.TimeoutExpired:process.kill();process.wait()
            log.close()
        if thread:thread.join(2)
        if room:write_json(folder/'room.json',room.result)
        session.__exit__(None,None,None)
    if INSTALLATION:
        if sha(EXECUTABLE)!=invite['identity']['executable']:raise ValueError('Native executable changed during match')
    else:verify_build()
    write_json(folder/'result.json',report)
    if report_callback:report_callback(report)
    print(json.dumps(report,indent=2));print(folder/'result.json')
    if not report['passed'] and not local_test:raise RuntimeError(report.get('error','The game did not complete the multiplayer session.'))
    return report['passed']


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--installation',type=Path);p.add_argument('--binary',type=Path)
    sub=p.add_subparsers(dest='command',required=True)
    make=sub.add_parser('create');make.add_argument('invite',type=Path);make.add_argument('--humans',type=int,default=2)
    make.add_argument('--fighters',type=int,choices=(2,16,24,32),default=32)
    make.add_argument('--characters',help='Comma-separated human choices; default Sonic then a varied roster');make.add_argument('--mode',choices=('battle-royale','battle','hill','survival','coin','time','stock','bonus'),default='battle-royale')
    make.add_argument('--items',choices=('off','verylow','low','medium','high','veryhigh'),default='medium')
    make.add_argument('--delay',type=int,default=4);make.add_argument('--seed',type=int,default=1);make.add_argument('--frames',type=int,default=36000)
    for command in ('host','join','local-test'):
        s=sub.add_parser(command);s.add_argument('invite',type=Path);s.add_argument('--host',default='127.0.0.1')
        s.add_argument('--port',type=int,default=41032);s.add_argument('--seat',type=int,default=1 if command=='join' else 0)
    a=p.parse_args()
    if a.command=='create' and a.mode=='battle-royale':a.mode='survival'
    configure_installation(a.installation,a.binary)
    if a.command=='create':
        names=a.characters.split(',') if a.characters else ['sonic']+[c for c in BY_NAME if c!='sonic'][:a.humans-1]
        value=create(a.humans,a.fighters,names,a.mode,a.items,a.seed,a.delay,a.frames)
        fd=os.open(a.invite,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        with os.fdopen(fd,'w') as stream:json.dump(value,stream,indent=2);stream.write('\n')
        print('Private invite saved. Share with your players only; it contains the room access key.');return
    invite=json.loads(a.invite.read_text())
    raise SystemExit(0 if run(invite,a.host,a.port,a.seat,a.command=='host',a.command=='local-test') else 1)


if __name__=='__main__':main()
