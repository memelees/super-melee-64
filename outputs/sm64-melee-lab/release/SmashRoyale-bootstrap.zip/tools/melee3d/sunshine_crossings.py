"""A fixed wooden footbridge connecting Plaza's western canal banks.

The donor pier atlas stays in the owner's private stage bank. Visible faces
and collision share the same deck; the normal navigation builder handles it.
"""
import copy
import math

VERSION=5
REFERENCE_SCALE=.08190640965783352
CROSSINGS=(dict(name='west-canal',group=2,center=(-445,28.667,-168),size=(64,272)),)
# Native pad diagnostics, including a destination deep inside the district.
ROUTES=(
    ((128,25,-470),(-156,25,-470)),
    ((128,25,-322),(-224,25,-322)),
    ((-445,25,0),(-445,25,-336)),
    ((-445,25,0),(-640,25,-592)),
)


def pier_material(directory):
    from sunshine_scene import static_model
    from sunshine_compile import materials
    parsed=static_model((directory/'map/map/map.bmd').read_bytes())
    material=copy.deepcopy(next(m for m in materials(parsed['chunks']) if m['texture']['name']=='A_objA09'))
    material['name']='Plaza blue painted wooden footbridge';material['rgba']=(255,255,255,255)
    material['flags']=0
    return material


def crossing_models(directory,scale=REFERENCE_SCALE):
    material=pier_material(directory);ratio=scale/REFERENCE_SCALE;result=[]
    for spec in CROSSINGS:
        triangles=[];colliders=[]
        def quad(points,color=(255,255,255,255),uv=((.28,.173),(.48,.173),(.48,.181),(.28,.181))):
            for ids in ((0,1,2),(0,2,3)):
                ps=[tuple(v*ratio for v in points[i]) for i in ids]
                # J3D's rendered front winding is opposite collision normals.
                # Otherwise the underside appears as the deck, with a false rail.
                triangles.append((0,tuple(reversed(tuple((p,color,uv[i]) for p,i in zip(ps,ids))))))
                a,b,c=ps;u=[b[i]-a[i] for i in range(3)];v=[c[i]-a[i] for i in range(3)]
                n=(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]);length=math.sqrt(sum(t*t for t in n))
                if length<1e-9:
                    triangles.pop();continue
                colliders.append((ps,tuple(t/length for t in n),0x7000+spec['group'],0))
        x=spec['center'][0];left,right=x-20,x+20
        base=24.5719229;top=base+4.0953205
        def clamp(v):return max(0,min(1,v))
        def deck(z):
            # Both ramps start inland and clear the entire stone bank lip.
            return base+(top-base)*min(1,(-32-z)/32,(z+304)/32)
        def section(z):
            y=deck(z)
            if z<-240:
                wing=12*clamp((-240-z)/8);edge=base+(top-base)*clamp((z+256)/8)
            elif z>-80:
                wing=12*clamp((z+80)/16);edge=base+(top-base)*clamp((-64-z)/16)
            else:wing=0;edge=y
            return [(left-wing,edge,z),(left,y,z),(right,y,z),(right+wing,edge,z)]
        # Open edges; side approaches slope down to street level as well.
        # Blue boards are visual seams only, never raised collision strips.
        ends=sorted(set([-304,-272,-256,-248,-240,-80,-64,-32]+list(range(-304,-31,6))))
        for i,(a,b) in enumerate(zip(ends,ends[1:])):
            p,q=section(a),section(b);join=section(min(a+.08,b))
            tint=255 if i%2 else 235
            for j in range(3):
                quad([p[j],join[j],join[j+1],p[j+1]],(100,120,155,255))
                quad([join[j],q[j],q[j+1],join[j+1]],(tint,tint,tint,255))
                low=lambda v:(v[0],v[1]-3,v[2])
                quad([low(p[j]),low(p[j+1]),low(q[j+1]),low(q[j])],(145,160,190,255))
            quad([(p[0][0],p[0][1]-3,a),(q[0][0],q[0][1]-3,b),q[0],p[0]],(190,200,220,255))
            quad([(p[3][0],p[3][1]-3,a),p[3],q[3],(q[3][0],q[3][1]-3,b)],(190,200,220,255))
        # Piles sit entirely beneath the deck, clear of the walking surface.
        for cx in (left+3,right-3):
            for cz in (-230,-98):
                a,b=cx-2,cx+2;c,d=cz-2,cz+2;y=deck(cz)-3;bottom=-8
                quad([(a,bottom,c),(a,bottom,d),(a,y,d),(a,y,c)],(185,195,210,255))
                quad([(b,bottom,c),(b,y,c),(b,y,d),(b,bottom,d)],(185,195,210,255))
                quad([(a,bottom,c),(a,y,c),(b,y,c),(b,bottom,c)],(185,195,210,255))
                quad([(a,bottom,d),(b,bottom,d),(b,y,d),(a,y,d)],(185,195,210,255))
        # Flush ends and open sides: ordinary stage edges remain usable in combat.
        for z,reverse in ((-304,False),(-32,True)):
            points=section(z)
            for a,b in zip(points,points[1:]):
                ps=[(a[0],a[1]-3,z),a,b,(b[0],b[1]-3,z)]
                quad(list(reversed(ps)) if reverse else ps,(190,200,220,255))
        result.append(dict(spec=spec,materials=[material],triangles=triangles,colliders=colliders))
    return result
