#!/usr/bin/env python3
"""Build/run the isolated Apple Silicon capacity laboratory (2D, retail roster).

The patch and owned modules are retained in native/mac. This does not install
over the canonical 3D/Akaneia game. The complete native 3D/Akaneia integration
is a separate gate; a capacity-lab pass cannot certify it.
"""
import argparse
import json
import os
from pathlib import Path
import plistlib
import re
import shutil
import subprocess

from native_compatibility import ROOT, WORK, DISC, bounded, sha, write_json, stage_module

SOURCE = WORK / "melee-pc"
MODULES = ROOT / "native/mac"
GAME_MODULES = ("m3d_css_policy.h", "m3d_pause.h", "m3d_photo.h", "m3d_photo.cpp", "m3d_menu.h", "m3d_menu.c", "m3d_css.inc", "m3d_rules.inc", "m3d_settings.h", "m3d_match.inc", "m3d_title.inc", "m3d_control_labels.h", "m3d_title_mesh.inc", "m3d_throw_flags.h", "m3d_wave_loop.h", "m3d_lab.c", "m3d_lab.h", "m3d_akaneia.c", "m3d_akaneia.h", "m3d_math.c", "m3d_effects.c", "m3d_items.c", "m3d_items.h", "m3d_targets.c", "m3d_targets.h", "m3d_scene.c", "m3d_scene.h", "m3d_scene_pool.h", "m3d_hitboxes.c", "m3d_hitboxes.h")
RUNTIME_MODULES = ("m3d_guest_memory.c", "m3d_guest_memory.h", "m3d_native_calls.c", "m3d_native_calls.h", "m3d_vm.c", "m3d_vm.h")
WORLD_MODULES=tuple('world/'+name for name in ('m3d.h','m3d.c','m3d_move.c','m3d_cpu.c','m3d_item.c','m3d_onett_traffic.c','m3d_onett_traffic_math.h','m3d_arena.c','m3d_arena_mesh.c','m3d_arena_visual.c','m3d_native.c','m3d_reference.c','m3d_recovery.c','m3d_delfino.c','m3d_delfino_nav.c','m3d_party.c','m3d_party_rules.h','m3d_goop_rules.h','m3d_goop_visual.inc','m3d_objective.h','m3d_combat_rules.h','m3d_surface.h','m3d_playable_regions.h','m3d_holes.h','m3d_tether.h'))
GAME_MODULES+=("m3d_stage_choices.h","m3d_respawn.h","m3d_sound.h","m3d_audio.cpp","m3d_theater.h","m3d_theater.c","m3d_theater_timing.h")
GAME_MODULES+=WORLD_MODULES+("m3d_windows.manifest",)
GAME_MODULES+=("m3d_room.c", "m3d_room.h", "m3d_room_io.c", "m3d_room_io.h")


def stage():
    metadata = json.loads((MODULES / "capacity.json").read_text())
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=SOURCE, text=True).strip()
    if revision != metadata["base_revision"] or sha(MODULES / "capacity.patch") != metadata["patch_sha256"]:
        raise ValueError("Unexpected native source revision or patch")
    changed=set(subprocess.check_output(["git","diff","--name-only"],cwd=SOURCE,text=True).splitlines())
    if changed-set(metadata["patched_files"]):
        raise ValueError("Unexpected native source edits outside the recorded patch; preserve and review them first")
    patch = str(MODULES / "capacity.patch")
    if all(sha(SOURCE / name) == value for name, value in metadata["patched_files"].items()):
        pass
    else:
        subprocess.run(["git", "apply", "--check", patch], cwd=SOURCE, check=True)
        subprocess.run(["git", "apply", patch], cwd=SOURCE, check=True)
    for name, value in metadata["patched_files"].items():
        if sha(SOURCE / name) != value:
            raise ValueError("Patched source differs: " + name)
    for name in GAME_MODULES:
        stage_module(MODULES / name, SOURCE / "src/pc" / name)
    return metadata


def verify_build():
    metadata=json.loads((WORK / "native-mac-build.json").read_text())
    patch=json.loads((MODULES / "capacity.json").read_text())
    if metadata["patch_sha256"]!=patch["patch_sha256"] or sha(MODULES / "capacity.patch")!=patch["patch_sha256"]:
        raise ValueError("Native patch changed; build first")
    for name,value in patch["patched_files"].items():
        if sha(SOURCE/name)!=value:raise ValueError("Native source changed: "+name)
    for name,value in metadata["modules"].items():
        if sha(MODULES/name)!=value:raise ValueError("Native adapter changed: "+name)
    for name,value in metadata.get("generators",{}).items():
        if sha(ROOT / "tools/melee3d" / name)!=value:raise ValueError("Native generator changed; build first")
    for name,value in metadata.get("generated",{}).items():
        if sha(WORK/name)!=value:raise ValueError("Native generated source changed; build first")
    if sha(SOURCE / "build/macos-proof/melee")!=metadata["executable_sha256"]:
        raise ValueError("Native executable differs from the recorded build")
    return metadata


def build():
    metadata = stage()
    from native_bridge import prepare_bridge
    from native_roster import generate as generate_roster, asset_identity
    from native_bindings import generate as generate_bindings
    runtime, runtime_source = prepare_bridge(destination=WORK / "mac-runtime")
    from native_reference import generate as generate_reference
    reference=generate_reference()
    roster=generate_roster()
    generate_bindings()
    directory = SOURCE / "build/macos-proof"
    subprocess.run(["cmake", "-S", str(SOURCE), "-B", str(directory), "-G", "Ninja",
                    "-DCMAKE_BUILD_TYPE=RelWithDebInfo", "-DCMAKE_C_COMPILER=clang", "-DCMAKE_CXX_COMPILER=clang++",
                    "-DCMAKE_OSX_DEPLOYMENT_TARGET=15.0", "-DAURORA_DAWN_PROVIDER=package",
                    "-DAURORA_NOD_PROVIDER=package", "-DAURORA_SDL3_PROVIDER=system"], check=True)
    subprocess.run(["ninja", "-C", str(directory), "-j", "6", "melee"], check=True)
    subprocess.run(["clang++", "-std=c++20", "-DTARGET_PC=1", "-I" + str(SOURCE / "src"),
                    "-I" + str(SOURCE / "extern/aurora/include"), str(MODULES / "test_native_addresses.cpp"),
                    "-o", str(WORK / "native-address-test")], check=True)
    subprocess.run([str(WORK / "native-address-test")], check=True)
    for name in GAME_MODULES:
        if sha(MODULES/name)!=sha(SOURCE/'src/pc'/name):
            raise ValueError('Native adapter changed during build: '+name)
    write_json(WORK / "native-mac-build.json", {
        "base_revision": metadata["base_revision"], "patch_sha256": metadata["patch_sha256"],
        "executable_sha256": sha(directory / "melee"),
        "modules": {name: sha(MODULES / name) for name in GAME_MODULES + RUNTIME_MODULES},
        "generators": {name: sha(ROOT / "tools/melee3d" / name) for name in ("native_roster.py", "native_lineup.py", "native_bindings.py", "native_bridge.py", "native_reference.py")},
        "generated": {str(path.relative_to(WORK)): sha(path) for path in list(runtime.glob("*.c")) + list(runtime.glob("*.h")) +
                      [reference] + [SOURCE / "src/pc" / name for name in GAME_MODULES] + [SOURCE / "src/pc" / name for name in ("m3d_player_roster.inc", "m3d_roster_data.inc", "m3d_roster_tables.inc", "m3d_live_flags.inc", "m3d_effect_data.inc", "m3d_engine_calls.c")]},
        "runtime_source": runtime_source,
        "akaneia_asset_sources":asset_identity(roster),
        "player_capacity": 32, "physical_ports": 4, "aram_bytes": 128*1024*1024,
        "akaneia_integrated": False, "akaneia_live_dispatch": True, "third_person_3d": False,
        "native_fd_3d_source": True, "reference_3d_parity": False,
    })


def bundle(path=None):
    path = Path(path) if path is not None else WORK / "Melee3D Native Lab.app"
    game, resources = path / "Contents/MacOS", path / "Contents/Resources"
    game.mkdir(parents=True, exist_ok=True)
    resources.mkdir(parents=True, exist_ok=True)
    subprocess.run(["cp", "-c", str(SOURCE / "build/macos-proof/melee"), str(game / "melee")], check=True)
    # Automated workers deliberately exercise failure paths. A shared app ID
    # makes AppKit's crash-restoration modal block unrelated later tests.
    # The playable Plaza launcher supplies its own stable identity afterwards.
    import uuid
    identity="dev.melee3d.native-lab.run-"+uuid.uuid4().hex
    (path / "Contents/Info.plist").write_bytes(plistlib.dumps({
        "CFBundleExecutable": "melee", "CFBundleIdentifier": identity,
        "CFBundleName": "Melee3D Native Lab", "CFBundlePackageType": "APPL",
        "NSHighResolutionCapable": True, "LSMinimumSystemVersion": "15.0",
    }))
    if not (resources / "resources").exists():
        (resources / "resources").symlink_to(SOURCE / "resources", target_is_directory=True)
    (resources / "portable.txt").write_text("Private native fighter-capacity laboratory.\n")
    return game


def judge(code, log, count, frames, human=False, roster="fox"):
    summaries = [tuple(map(int, row)) for row in re.findall(
        r"M3D LAB SUMMARY tick=(\d+) present=(\d+) moved=(\d+) damaged=(\d+)", log)]
    pairs = {(int(a), int(b)) for a, b in re.findall(r"M3D LAB HIT attacker=(\d+) victim=(\d+)", log)}
    identities = {(int(slot), int(kind)) for slot, kind in re.findall(r"M3D LAB FRAME tick=\d+ slot=(\d+) kind=(\d+)", log)}
    expected_kinds = min(count,16) if roster == "full" else min(count,4) if roster == "mixed" else 1 if roster == "fox" else count
    identity_ok = ({slot for slot, _ in identities} == set(range(count))
                   and len({kind for _, kind in identities}) == expected_kinds
                   and all(0 <= a < count and 0 <= b < count and a != b for a,b in pairs))
    evidence = bool(summaries) and summaries[-1][0] >= 600 and all(s[1] == count for s in summaries)
    combat = evidence and summaries[-1][2] >= count-int(human) and summaries[-1][3] >= count//2
    passed = (code == 0 and f"MELEE_EXIT_AFTER_FRAMES: reached frame {frames}, exiting" in log
              and not any(marker in log for marker in ("M3D LAB FAIL", "PANIC", "FATAL", "texture no exist!", 'assertion "'))
              and combat and identity_ok)
    return {"passed": passed, "summaries": summaries, "observed_pairs": sorted(pairs),
            "observed_identities": sorted(identities),
            "scope": "Native Mac rendered capacity lab; existing 2D retail fighters"}


def run(args):
    metadata = verify_build()
    with args.disc.expanduser().open("rb") as disc:
        header = disc.read(8)
    if header[:6] != b"GALE01" or header[7] != 2:
        raise ValueError("Requires Melee NTSC-U rev2")
    mode="human" if args.human else "cpu"
    fixture="-kirby" if args.kirby_copy else ""
    if args.ko_credit: fixture+="-ko"
    case = WORK / "runs" / f"mac-lab-{args.fighters}-{args.roster}-{mode}-seed{args.seed}-{args.frames}{fixture}-{metadata['executable_sha256'][:10]}"
    game = bundle()
    env = dict(os.environ, MELEE_BOOT_SCENE="vs", MELEE_DEBUG_VS_STAGE="32", MELEE3D_NATIVE_LAB=str(args.fighters),
               MELEE3D_NATIVE_ROSTER=args.roster, MELEE_EXIT_AFTER_FRAMES=str(args.frames), MELEE_SEED=str(args.seed),
               MELEE_BACKEND="metal", MELEE_LOG_FILE=str(case / "game.log"), MELEE_FILES_DIR=str(case / "no-loose-files"))
    env.pop("MELEE3D_NATIVE_HUMAN", None)
    env.pop("MELEE3D_NATIVE_KIRBY_COPY", None)
    env.pop("MELEE3D_NATIVE_KO_TEST", None)
    for name in ("MELEE3D_NATIVE_AKANEIA", "MELEE3D_AKANEIA_FILES", "MELEE3D_NATIVE_SPAWN_ONLY"):
        env.pop(name,None)
    if args.human:
        env["MELEE3D_NATIVE_HUMAN"] = "1"
    if args.kirby_copy:
        env["MELEE3D_NATIVE_KIRBY_COPY"] = "1"
    if args.ko_credit:
        env["MELEE3D_NATIVE_KO_TEST"] = "1"
    code, log, seconds = bounded([str(game / "melee"), "--no-card", str(args.disc.expanduser())], game, env, case,
                                 timeout=args.frames/30+40)
    result = dict(judge(code, log, args.fighters, args.frames, args.human, args.roster), exit_code=code, seconds=seconds,
                  build=metadata, humans=int(args.human), cpus=args.fighters-int(args.human), roster=args.roster,
                  log=str(case / "stdout.txt"), seed=args.seed, frames=args.frames,
                  combined_native_3d_akaneia_ready=False)
    if args.kirby_copy:
        result["kirby_copy_fixture_passed"]="M3D LAB KIRBY COPY PASS" in log
        result["passed"] = result["passed"] and result["kirby_copy_fixture_passed"]
    if args.ko_credit:
        result["ko_credit_fixture_passed"]=all(f"M3D LAB KO CREDIT PASS attacker={a} victim={v}" in log
                                                  for a,v in [(6,args.fighters-1),(args.fighters-1,args.fighters-2),(metadata['player_capacity'],args.fighters-3)])
        result["passed"] = result["passed"] and result["ko_credit_fixture_passed"] and f"M3D LAB ITEM TRACK PASS fighters={args.fighters} capacity={2*metadata['player_capacity']} guards=2" in log
    write_json(case / "result.json", result)
    print(json.dumps(result, indent=2))
    return result["passed"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["build", "run"])
    parser.add_argument("--fighters", type=int, choices=range(2,33), default=16)
    parser.add_argument("--roster", choices=["fox", "mixed", "full"], default="full")
    parser.add_argument("--human", action="store_true")
    parser.add_argument("--kirby-copy", action="store_true", help="Immediately exercise Kirby's copied-hat setup and texture callback")
    parser.add_argument("--ko-credit", action="store_true", help="Exercise real death bookkeeping across low/high player slots and self-destructs")
    parser.add_argument("--frames", type=int, default=2400)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--disc", type=Path, default=DISC)
    args = parser.parse_args()
    if not 900 <= args.frames <= 36000:
        parser.error("Frame bound must be 900 through 36000")
    if args.ko_credit and (args.fighters<8 or args.frames<1200):
        parser.error("KO-credit fixture requires at least eight fighters and 1200 frames")
    if args.kirby_copy and (args.roster!="full" or args.fighters<5):
        parser.error("Kirby fixture requires the full roster with at least five fighters")
    lock = WORK / ".probe-running"
    with lock.open("x") as handle:
        handle.write(str(os.getpid()))
    try:
        if args.command == "build": build()
        elif not run(args): raise SystemExit(1)
    finally:
        lock.unlink()


if __name__ == "__main__":
    main()
