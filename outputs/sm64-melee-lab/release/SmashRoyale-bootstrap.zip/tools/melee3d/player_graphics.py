"""Package the pinned upstream pipeline descriptors, never a user's GPU cache."""
import gzip
import hashlib
import re
import subprocess
import time


SEED_NAME = 'initial_pipeline_cache.db'
UPSTREAM_REVISION = '0cc24fee6b8e7dd7a9233daa126829d374fe1f40'
ARCHIVE_SHA256 = '2f71e52170a0ea669ac55ac454d06ca705224f48f7dde9b2141b2dbfd879f8b3'
SEED_SHA256 = '61bca55d2b1c299dba9775f0261f64334732df0b459e58b33735d5898038a080'


def validate_seed(path):
    if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != SEED_SHA256:
        raise ValueError('Unexpected initial pipeline cache; only the pinned upstream seed may be packaged')
    return SEED_SHA256


def install_seed(source, resources):
    archive = (source / 'tools' / (SEED_NAME + '.gz')).read_bytes()
    if hashlib.sha256(archive).hexdigest() != ARCHIVE_SHA256:
        raise ValueError('Upstream initial pipeline cache archive changed; review its provenance before packaging')
    data = gzip.decompress(archive)
    if hashlib.sha256(data).hexdigest() != SEED_SHA256:
        raise ValueError('Unexpected decompressed initial pipeline cache')
    target = resources / SEED_NAME
    target.write_bytes(data)
    validate_seed(target)
    return dict(source='melee-pc/tools/' + SEED_NAME + '.gz',
                upstream_revision=UPSTREAM_REVISION, archive_sha256=ARCHIVE_SHA256,
                sha256=SEED_SHA256, content='upstream graphics pipeline descriptors')


def prepare_graphics(binary, environment, profile, progress=lambda value, message: None, timeout=300):
    """Prepare on the recipient's GPU; retain logs and bound failed workers."""
    from player_paths import game_command
    profile.mkdir(parents=True,exist_ok=True)
    log_path=profile/'graphics-prepare.log'
    env=dict(environment,MELEE_PREPARE_GRAPHICS='1')
    # Preparing never loads a stage, consumes diagnostic frames or opens a room.
    for key in ('MELEE_EXIT_AFTER_FRAMES','MELEE3D_NATIVE_STAGE_PHOTO'):
        env.pop(key,None)
    progress(5,'Preparing graphics — first launch may take a minute…')
    # Use a file rather than a pipe: the child cannot block on a full log buffer,
    # and timeout/cancel remain responsive even if it stops producing output.
    with log_path.open('w',encoding='utf-8') as stream:
        command=game_command(binary)  # no disc is read in preparation mode
        with subprocess.Popen(command,cwd=profile,env=env,stdout=stream,stderr=subprocess.STDOUT) as child:
            deadline=time.monotonic()+timeout
            try:
                with log_path.open(encoding='utf-8',errors='replace') as reader:
                    while child.poll() is None:
                        if time.monotonic()>deadline:
                            raise TimeoutError('Graphics preparation timed out. Log: '+str(log_path))
                        for line in reader:
                            match=re.search(r'M3D GRAPHICS PREPARE pending=(\d+) total=(\d+)',line)
                            if match:
                                pending,total=map(int,match.groups())
                                value=5+65*(1-pending/max(1,total))
                                progress(min(70,max(5,value)),'Preparing graphics…')
                        time.sleep(.1)
            except BaseException:
                child.terminate()
                try:child.wait(timeout=5)
                except subprocess.TimeoutExpired:child.kill();child.wait()
                raise
    log=log_path.read_text(errors='replace')
    if child.returncode or 'M3D GRAPHICS READY pending=0' not in log:
        raise RuntimeError('Graphics preparation did not complete. Log: '+str(log_path))
    progress(70,'Graphics ready')
