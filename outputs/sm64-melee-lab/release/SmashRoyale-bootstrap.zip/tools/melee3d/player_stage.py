"""Derive a versioned private stage without changing a verified disc import."""
import hashlib,json,os,tempfile
from pathlib import Path
from native_compatibility import sha
from player_paths import source_file


def visual_bank(installation,metadata=None):
 from sunshine_compile import PRESENTATION_VERSION,COLLISION_VERSION
 from sunshine_crossings import VERSION as CROSSINGS_VERSION
 from sunshine_navigation import VERSION as NAVIGATION_VERSION
 installation=Path(installation);original=installation/'sunshine/native-preview'
 if not (original/'report.json').is_file():return original
 report=json.loads((original/'report.json').read_text())
 current_layout=report.get('crossings_version',0)==CROSSINGS_VERSION and report.get('collision_version',1)==COLLISION_VERSION
 current_navigation=report.get('navigation_version',1)==NAVIGATION_VERSION
 if report.get('presentation_version',0)>=PRESENTATION_VERSION and current_layout and current_navigation:return original
 modules=('sunshine_compile.py','sunshine_scene.py','sunshine_scale.py','sunshine_occlusion.py','sunshine_water.py','sunshine_navigation.py','sunshine_crossings.py')
 version={name:sha(source_file(name)) for name in modules}
 identity=hashlib.sha256(json.dumps(dict(source=report['files'],tools=version),sort_keys=True).encode()).hexdigest()[:24]
 cache=installation.parent/'stage-cache';cache.mkdir(parents=True,exist_ok=True);target=cache/identity
 def valid():
  if not (target/'report.json').is_file():return False
  current=json.loads((target/'report.json').read_text())
  return current.get('navigation_version',1)==NAVIGATION_VERSION and current.get('presentation_version')==PRESENTATION_VERSION and current.get('collision_version',1)==COLLISION_VERSION and current.get('crossings_version',0)==CROSSINGS_VERSION and all((target/name).is_file() and sha(target/name)==value for name,value in current['files'].items())
 if valid():return target
 if target.exists():raise ValueError('Derived stage cache changed: '+str(target))
 from sunshine_compile import compile_scene
 with tempfile.TemporaryDirectory(prefix='.plaza-',dir=cache) as temporary:
  output=Path(temporary)/'bank'
  compile_scene(installation/'sunshine',melee_files=installation/'akaneia/files',output=output,reuse_collision=original if current_layout else None)
  if current_layout:
   for name in ('delfino.dlc','delfino.dls')+(('delfino.dln',) if current_navigation else ()):
    if sha(output/name)!=report['files'][name]:raise ValueError('Visual update changed collision/navigation: '+name)
  try:output.rename(target)
  except OSError:
   if not valid():raise
 if not valid():raise ValueError('Derived stage verification failed')
 return target
