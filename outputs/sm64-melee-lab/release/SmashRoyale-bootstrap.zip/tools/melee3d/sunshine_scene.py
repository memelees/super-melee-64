#!/usr/bin/env python3
"""Bounded Sunshine scene, COL and static J3D inspection from local-disc data.

Format references: doldecomp/sms (CC0) MapCollisionEntry and noclip.website
(MIT) J3DLoader/sms_scenes. No game data or downloaded models are embedded.
"""
from __future__ import annotations
from collections import Counter
import math
from pathlib import Path
import struct


class Reader:
    def __init__(self, data): self.data = data
    def get(self, fmt, offset):
        size = struct.calcsize('>'+fmt)
        if offset < 0 or offset+size > len(self.data): raise ValueError('Truncated '+fmt)
        return struct.unpack_from('>'+fmt, self.data, offset)
    def u16(self, o): return self.get('H', o)[0]
    def u32(self, o): return self.get('I', o)[0]
    def string(self, o, encoding='shift_jis'):
        size = self.u16(o)
        if o+2+size > len(self.data): raise ValueError('Truncated string')
        return self.data[o+2:o+2+size].decode(encoding), o+2+size


def collision(data):
    r = Reader(data)
    count, start, groups, table = r.get('4I', 0)
    if count > 100000 or groups > 10000 or start+12*count > len(data) or table+24*groups > len(data):
        raise ValueError('Invalid COL tables')
    vertices = [r.get('3f', start+i*12) for i in range(count)]
    if any(not math.isfinite(v) for p in vertices for v in p): raise ValueError('Nonfinite COL vertex')
    faces = []
    for group in range(groups):
        surface, number, flags, _, indices, sounds, attributes, extra = r.get('4H4I', table+24*group)
        if indices+number*6 > len(data) or sounds+number > len(data) or attributes+number > len(data):
            raise ValueError('Invalid COL group')
        for i in range(number):
            ids = r.get('3H', indices+i*6)
            if max(ids) >= count: raise ValueError('COL index outside vertex table')
            faces.append(dict(indices=ids, surface=surface, sound=data[sounds+i], attributes=data[attributes+i],
                              additional=r.u16(extra+i*2) if extra else None))
    return vertices, faces


def scene(data):
    """Read the authored group hierarchy; unrecognised records stay visible."""
    r = Reader(data)
    def node(start, stop, depth=0):
        if depth > 64: raise ValueError('Scene hierarchy too deep')
        size = r.u32(start)
        if size < 12 or start+size > stop: raise ValueError('Invalid scene object extent')
        klass, o = r.string(start+6)
        name, o = r.string(o+2)
        obj = dict(klass=klass, name=name, offset=start, size=size, children=[])
        if klass in ('GroupObj', 'LightAry', 'Strategy', 'AmbAry', 'IdxGroup', 'MarScene'):
            if klass in ('IdxGroup', 'MarScene'): o += 4
            count = r.u32(o); o += 4
            if count > 10000: raise ValueError('Scene child count exceeds limit')
            for _ in range(count):
                child = node(o, start+size, depth+1); obj['children'].append(child); o += child['size']
        elif klass in ('Light', 'AmbColor'):
            if klass == 'Light': obj['position'] = r.get('3f', o); o += 12
            obj['rgba'] = r.get('4B', o)
        else:
            # MapObj classes share the LiveActor transform/manager/flags/model
            # prefix. A record that fails this contract is never guessed into
            # a renderable prop (NPCs and managers can have other layouts).
            try:
                transform = r.get('9f', o)
                manager, end = r.string(o+36)
                flags = r.u32(end)
                model, end = r.string(end+4)
                if end > start+size or not model or any(not math.isfinite(x) or abs(x)>1e7 for x in transform):
                    raise ValueError('No map-object prefix')
                obj.update(position=transform[:3], rotation=transform[3:6], scale=transform[6:], manager=manager, flags=flags, model=model)
            except (ValueError, UnicodeError): pass
        return obj
    root = node(0, len(data))
    if root['size'] != len(data): raise ValueError('Trailing scene data')
    return root


def flatten(root):
    yield root
    for child in root['children']: yield from flatten(child)


def identity(): return [[float(i==j) for j in range(4)] for i in range(4)]
def multiply(a, b): return [[sum(a[i][k]*b[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
def transform(m, p): return tuple(sum(m[i][j]*p[j] for j in range(3))+m[i][3] for i in range(3))


def matrix(position, rotation, scale):
    x, y, z = rotation
    sx,cx,sy,cy,sz,cz = math.sin(x),math.cos(x),math.sin(y),math.cos(y),math.sin(z),math.cos(z)
    # J3D / scene.bin XYZ Euler, Rz * Ry * Rx, column vectors.
    m = [[cy*cz, sx*sy*cz-cx*sz, cx*sy*cz+sx*sz,position[0]],
         [cy*sz, sx*sy*sz+cx*cz, cx*sy*sz-sx*cz,position[1]],
         [-sy,sx*cy,cx*cy,position[2]],[0,0,0,1]]
    for i in range(3):
        for j in range(3): m[i][j] *= scale[j]
    return m


def chunks(data):
    r=Reader(data)
    if data[:4] != b'J3D2' or r.u32(8) != len(data): raise ValueError('Invalid J3D header')
    count, offset, result = r.u32(12), 32, {}
    for _ in range(count):
        tag = data[offset:offset+4].decode('ascii'); size = r.u32(offset+4)
        if size < 8 or offset+size > len(data) or tag in result: raise ValueError('Invalid J3D chunk')
        result[tag] = data[offset:offset+size]; offset += size
    if offset != len(data): raise ValueError('Trailing J3D data')
    return result


def strings(data, start):
    r=Reader(data)
    count = r.u16(start)
    result=[]
    for i in range(count):
        off=start+r.u16(start+4+i*4+2)
        try: end=data.index(b'\0',off)
        except ValueError: raise ValueError('Truncated J3D name')
        result.append(data[off:end].decode('shift_jis'))
    return result


def joints(cs):
    r=Reader(cs['JNT1']); count=r.u16(8); table=r.u32(12); remap=r.u32(16)
    transforms=[]; bounds=[]
    for i in range(count):
        offset=table+r.u16(remap+i*2)*64
        transforms.append(matrix(r.get('3f',offset+24),[v*math.pi/32768 for v in r.get('3h',offset+16)],r.get('3f',offset+4)))
        bounds.append(r.get('6f',offset+40))
    h=Reader(cs['INF1']); o=h.u32(20); stack=[identity()]; current=identity(); materials={}; parents={}; mat=-1
    while True:
        kind,index=h.get('2H',o);o+=4
        if kind == 0: break
        if kind == 1:stack.append(current)
        elif kind == 2:
            if len(stack)<2:raise ValueError('Invalid J3D hierarchy stack')
            stack.pop();current=stack[-1]
        elif kind == 16:
            current=multiply(stack[-1],transforms[index]);parents[index]=current
        elif kind == 17:mat=index
        elif kind == 18:materials[index]=mat
        else:raise ValueError('Unknown J3D hierarchy node')
    return [parents.get(i,transforms[i]) for i in range(count)],bounds,materials


def static_model(data, bind_skin=False):
    """Decode static rigid J3D primitives. Weighted skins fail explicitly.

    This geometry conversion is a preview, not a full J3D material renderer.
    All source material/animation files remain in the cache for that renderer.
    """
    cs=chunks(data); joint_matrices,_,shape_mats=joints(cs)
    v=Reader(cs['VTX1']); arrays={};o=v.u32(8)
    attrs=[9,10,25,11,12,13,14,15,16,17,18,19,20]
    offsets={a:v.u32(12+i*4) for i,a in enumerate(attrs)}
    while True:
        a,c,t,shift=v.get('3IB',o);o+=16
        if a==255:break
        arrays[a]=(c,t,shift,offsets[a])
    def value(a,index):
        c,t,shift,start=arrays[a]
        if a in (11,12):
            if t==5:return v.get('4B',start+index*4)
            if t==1:return (*v.get('3B',start+index*3),255)
            raise ValueError('Unsupported J3D vertex colour format '+str(t))
        n=(2 if c==0 else 3) if a==9 else 3 if a in (10,25) else 1 if c==0 else 2
        fmt={0:'B',1:'b',2:'H',3:'h',4:'f'}[t]
        values=v.get(str(n)+fmt,start+index*n*struct.calcsize(fmt))
        return tuple(x/(1<<shift) if t!=4 else x for x in values)
    d=Reader(cs['DRW1']); drw_count=d.u16(8); types=d.u32(12); ids=d.u32(16)
    matrices=[];envelopes=[]
    if bind_skin:
        e=Reader(cs['EVP1']);counts,indices,weights,inverse=(e.u32(o) for o in (12,16,20,24));cursor=0
        for i in range(e.u16(8)):
            blended=[[0.]*4 for _ in range(4)]
            for j in range(e.data[counts+i]):
                bone=e.u16(indices+cursor*2);weight=e.get('f',weights+cursor*4)[0];cursor+=1
                rows=[list(e.get('4f',inverse+bone*48+k*16)) for k in range(3)]+[[0,0,0,1]]
                m=multiply(joint_matrices[bone],rows)
                for y in range(4):
                    for x in range(4):blended[y][x]+=m[y][x]*weight
            envelopes.append(blended)
    for i in range(drw_count):
        if d.data[types+i] and not bind_skin:raise ValueError('Weighted J3D model requires skin renderer')
        matrices.append((envelopes if d.data[types+i] else joint_matrices)[d.u16(ids+i*2)])
    s=Reader(cs['SHP1']); triangles=[]; unsupported=[]
    shape_table,decls,mtx_table,display,mtx_init,draw_init=(s.u32(o) for o in (12,24,28,32,36,40))
    for shape in range(s.u16(8)):
        so=shape_table+shape*40;kind=s.data[so];groups,decl,mi,di=s.get('4H',so+2)
        if kind in (1,2):unsupported.append(dict(shape=shape,reason='billboard'))
        declaration=[];p=decls+decl
        while True:
            attr,typ=s.get('2I',p);p+=8
            if attr==255:break
            if typ not in (1,2,3):raise ValueError('Unsupported GX attribute declaration')
            declaration.append((attr,typ))
        table=[]
        for group in range(groups):
            _,number,first=s.get('2HI',mtx_init+(mi+group)*8)
            replacement=s.get(str(number)+'H',mtx_table+first*2)
            table=[old if new==65535 else new for old,new in zip(table+[0]*max(0,number-len(table)),replacement)]
            length,start=s.get('2I',draw_init+(di+group)*8);p=display+start;end=p+length
            while p<end:
                op=s.data[p];p+=1
                if op==0:continue
                primitive=op & 0xf8
                if primitive not in (0x80,0x90,0x98,0xa0,0xa8,0xb0,0xb8):raise ValueError('Unsupported GX primitive '+hex(op))
                count=s.u16(p);p+=2;verts=[]
                for _ in range(count):
                    fields={}
                    for attr,typ in declaration:
                        if typ==1:
                            if attr<=8:fields[attr]=s.data[p];p+=1
                            else:raise ValueError('Direct nonmatrix J3D attribute')
                        else:
                            index=s.data[p] if typ==2 else s.u16(p);p+=typ-1
                            fields[attr]=value(attr,index)
                    pos=fields[9];pos=(*pos,0)[:3]
                    selected=fields.get(0,0)//3
                    if selected>=len(table):raise ValueError('Invalid J3D matrix palette')
                    pos=transform(matrices[table[selected]],pos)
                    uv=fields.get(13,(0,0));uv=(*uv,0)[:2]
                    verts.append((pos,fields.get(11,(255,255,255,255)),uv))
                if p>end:raise ValueError('GX primitive exceeds packet')
                faces=[]
                if primitive==0x90:faces=[(i,i+1,i+2) for i in range(0,count,3)]
                elif primitive==0x80:faces=[q for i in range(0,count,4) for q in [(i,i+1,i+2),(i,i+2,i+3)]]
                elif primitive==0x98:faces=[(i,i+1,i+2) if i%2==0 else (i+1,i,i+2) for i in range(count-2)]
                elif primitive==0xa0:faces=[(0,i,i+1) for i in range(1,count-1)]
                else:unsupported.append(dict(shape=shape,reason='line or point primitive'))
                for face in faces:triangles.append((shape_mats[shape],tuple(verts[i] for i in face)))
    return dict(chunks=cs,triangles=triangles,unsupported=unsupported)


def bounds(points):
    return [[min(p[i] for p in points) for i in range(3)], [max(p[i] for p in points) for i in range(3)]]


def scene_report(directory):
    root=scene((directory/'map/scene.bin').read_bytes()); objects=list(flatten(root))
    vertices,faces=collision((directory/'map/map.col').read_bytes())
    models=[]
    for name in ('map','sea','seaindirect','sky'):
        parsed=static_model((directory/f'map/map/{name}.bmd').read_bytes())
        models.append(dict(name=name,triangles=len(parsed['triangles']),bounds=bounds([v[0] for _,t in parsed['triangles'] for v in t]),unsupported=parsed['unsupported']))
    return dict(scene='dolpic1',classes=dict(Counter(o['klass'] for o in objects)),objects=objects,
                collision=dict(vertices=len(vertices),triangles=len(faces),bounds=bounds(vertices),surfaces=dict(Counter(f['surface'] for f in faces))),
                models=models,full_j3d_material_parity=False,placed_object_parity=False)
