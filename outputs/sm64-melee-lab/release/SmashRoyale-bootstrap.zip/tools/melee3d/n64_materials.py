"""N64 source texture decoding and the static room's RDP combine expressions."""
from compile_arena_visuals import rgba16


def decode_texture(desc,resolve):
    width,height=desc['width'],desc['height'];count=width*height
    fmt,size=desc['format'],desc['size'];data=resolve(desc['image']['address'])
    length=(count*(4<<size)+7)//8
    if len(data)<length:raise ValueError('truncated source texture')
    data=data[:length]
    if fmt==0 and size==2:return rgba16(data,width,height)
    if fmt==0 and size==3:return [tuple(data[i:i+4]) for i in range(0,len(data),4)]
    if size==0:values=[n for b in data for n in (b>>4,b&15)][:count]
    elif size==1:values=list(data)
    else:raise ValueError(f'unsupported N64 texture {fmt}/{size}')
    if fmt==2:
        load=desc['palette_load'];palette=rgba16(resolve(load['image']['address'])[:load['count']*2],load['count'],1)
        offset=(desc['palette']*16 if size==0 else 0)-load['first']
        if any(not 0<=v+offset<len(palette) for v in values):raise ValueError('CI index outside source palette')
        return [palette[v+offset] for v in values]
    if fmt==4:
        return [(v*(17 if size==0 else 1),)*3+(v*(17 if size==0 else 1),) for v in values]
    if fmt==3:
        if size==0:return [((v>>1)*255//7,)*3+((v&1)*255,) for v in values]
        return [((v>>4)*17,)*3+((v&15)*17,) for v in values]
    raise ValueError(f'unsupported N64 texture {fmt}/{size}')


def combine(state,shade,tex=1.0):
    """Evaluate both static cycles with a scalar texture test value.

    The writer verifies that RGB/alpha reduce to texture times vertex color;
    it rejects a material needing an additional TEV expression.
    """
    if state.get('combine') is None:return [v/255 for v in shade]
    w0,w1=state['combine'];prim=[v/255 for v in state['primitive']];env=[v/255 for v in state['environment']];shade=[v/255 for v in shade]
    rgb=[0.]*3;alpha=0.
    rgb_cycles=[((w0>>20)&15,(w1>>28)&15,(w0>>15)&31,(w1>>15)&7),((w0>>5)&15,(w1>>24)&15,w0&31,(w1>>6)&7)]
    alpha_cycles=[((w0>>12)&7,(w1>>12)&7,(w0>>9)&7,(w1>>9)&7),((w1>>21)&7,(w1>>3)&7,(w1>>18)&7,w1&7)]
    for fields,afields in zip(rgb_cycles,alpha_cycles):
        oldrgb,oldalpha=rgb,alpha
        def color(code,slot,k):
            if code==0:return oldrgb[k]
            if code==1:return tex
            if code==2:raise ValueError('material uses a second texture')
            if code==3:return prim[k]
            if code==4:return shade[k]
            if code==5:return env[k]
            if slot=='c':
                if code==7:return oldalpha
                if code==8:return tex
                if code==10:return prim[3]
                if code==11:return shade[3]
                if code==12:return env[3]
                if code==31:return 0.
            elif code==6:return 1.
            elif code in (7,15):return 0.
            raise ValueError(f'unsupported combine source {code}/{slot}')
        def aval(code,slot):
            if slot=='c':
                if code==0:return 0. # static LOD fraction
                if code==6:return 0.
            if code==0:return oldalpha
            if code==1:return tex
            if code==2:raise ValueError('alpha uses a second texture')
            if code==3:return prim[3]
            if code==4:return shade[3]
            if code==5:return env[3]
            if code==6:return 1.
            return 0.
        a,b,c,d=fields
        rgb=[(color(a,'a',k)-color(b,'b',k))*color(c,'c',k)+color(d,'d',k) for k in range(3)]
        a,b,c,d=afields;alpha=(aval(a,'a')-aval(b,'b'))*aval(c,'c')+aval(d,'d')
    return [max(0,min(1,v)) for v in rgb]+[max(0,min(1,alpha))]
