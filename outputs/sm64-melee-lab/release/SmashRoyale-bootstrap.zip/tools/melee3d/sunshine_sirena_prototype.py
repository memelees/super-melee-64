#!/usr/bin/env python3
"""Build a separate Sirena Beach prototype with reviewed water and spawn data.

No installed maps change. This is a private native-bank prototype, not release
acceptance. Native CPU traversal and material captures remain separate gates.
"""
import argparse
from collections import Counter,defaultdict
import hashlib,json,math,struct,time
from pathlib import Path
from player_paths import payload,source_file

from sunshine_survey_psn import DEFAULT,private,convert
from sunshine_scene import bounds
from sunshine_compile import ledges
from sunshine_navigation import build,encode,components,height,segment_hit


def read_collision(path):
    data=path.read_bytes();magic,version,count=struct.unpack_from('<4s2I',data)
    if (magic,version)!=(b'DLC1',1) or len(data)!=12+count*56:raise ValueError('Invalid collision bank')
    result=[]
    for i in range(count):
        v=struct.unpack_from('<12f2I',data,12+i*56);result.append(([v[:3],v[3:6],v[6:9]],v[9:12],v[12],v[13]))
    return result


def write_collision(path,triangles):
    path.write_bytes(struct.pack('<4s2I',b'DLC1',1,len(triangles))+b''.join(struct.pack('<12f2I',*(v for p in ps for v in p),*n,s,f) for ps,n,s,f in triangles))


def sirena_water(triangles,margin=64):
    """Retain donor sea height, shallow elevated inland pools, cover outer sea.

    Sirena's sea and pools share type0x100, so type-only classification is not
    valid. Guard the known donor topology and report every changed category.
    """
    water=[(i,t) for i,t in enumerate(triangles) if t[3]&1]
    ocean=[(i,t) for i,t in water if max(abs(p[1]) for p in t[0])<.001]
    inland=[(i,t) for i,t in water if max(abs(p[1]) for p in t[0])>=.001]
    if len(ocean)!=2 or len(inland)!=58 or {t[2] for _,t in water}!={0x100}:raise ValueError('Sirena water contract changed; manual review required')
    lo,hi=bounds([p for ps,*_ in triangles for p in ps]);sea_lo,sea_hi=bounds([p for _,t in ocean for p in t[0]])
    if sea_lo[2]<690 or sea_hi[2]<2200:raise ValueError('Unexpected Sirena sea footprint')
    target_lo=lo[0]-margin;target_hi=hi[0]+margin;target_seaward=max(hi[2],sea_hi[2])+margin
    result=[];beds=[];ocean_ids={i for i,_ in ocean};inland_ids={i for i,_ in inland}
    for i,(ps,n,s,f) in enumerate(triangles):
        if i in ocean_ids:
            extended=[]
            for x,y,z in ps:
                if abs(x-sea_lo[0])<.01:x=target_lo
                elif abs(x-sea_hi[0])<.01:x=target_hi
                if abs(z-sea_hi[2])<.01:z=target_seaward
                extended.append((x,y,z))
            ps=extended
        elif i in inland_ids:
            f|=8
            if n[1]>.65:beds.append(([tuple(v-4 if k==1 else v for k,v in enumerate(p)) for p in ps],n,0,0))
        result.append((ps,n,s,f))
    return result+beds,dict(deep_ocean_triangles=2,inland_shallow_triangles=58,bed_triangles=len(beds),sea_height=0,
                            original_sea_bounds=[sea_lo,sea_hi],expanded_sea_bounds=[[target_lo,0,sea_lo[2]],[target_hi,0,target_seaward]],
                            rationale='Extend only seaward/side edges to cover offshore collision outside the narrow donor water rectangle; original landward shore edge and sea height remain unchanged')


class Queries:
    def __init__(self,triangles):
        self.triangles=triangles;self.grid=defaultdict(list)
        for i,(ps,n,s,f) in enumerate(triangles):
            for x in range(math.floor(min(p[0] for p in ps)/64),math.floor(max(p[0] for p in ps)/64)+1):
                for z in range(math.floor(min(p[2] for p in ps)/64),math.floor(max(p[2] for p in ps)/64)+1):self.grid[x,z].append(i)
    def levels(self,x,z,water=False):
        out=[]
        for i in self.grid.get((math.floor(x/64),math.floor(z/64)),[]):
            ps,n,s,f=self.triangles[i]
            if (not f&1 if water else f&3 or n[1]<.64):continue
            y=height(ps,n,x,z)
            if y is not None:out.append(y)
        return out
    def dry(self,p):
        x,y,z=p
        # Source sea waves/foam span Y4.91..8.60 and begin at Z563.94.
        # Their washed shoreline is traversable, but never a spawn/goal.
        if y<0 or z>=563.94 and y<=10.6:return False
        return not any(y<h+.5 for h in self.levels(x,z,True))
    def body_clear(self,p,radius=16,height_above=40):
        if not self.dry(p):return False
        x,y,z=p
        floors=self.levels(x,z)
        if not floors or abs(max(floors)-y)>.5:return False
        # Sample eight complete radial support profiles, not just ring ends.
        verticals=[p]
        for k in range(8):
            a=k*math.pi/4;last=y
            for step in range(1,9):
                r=radius*step/8;qx,qz=x+math.cos(a)*r,z+math.sin(a)*r
                options=self.levels(qx,qz)
                if not options:return False
                h=max(options)
                if abs(h-last)>.5 or abs(h-y)>6 or not self.dry((qx,h,qz)):return False
                last=h
            verticals.append((qx,last,qz))
        for qx,last,qz in verticals:
            start=(qx,last+1,qz);end=(qx,last+height_above,qz)
            ids=self.grid.get((math.floor(qx/64),math.floor(qz/64)),[])
            for i in ids:
                ps,n,s,f=self.triangles[i]
                if f&3:continue
                if segment_hit(start,end,ps):return False
        return True


def filter_graph(nodes,edges,query):
    keep=[i for i,p in enumerate(nodes) if query.dry(p)];remap={old:new for new,old in enumerate(keep)}
    filtered=[[(remap[j],kind) for j,kind in edges[i] if j in remap] for i in keep]
    # Preserve original navigation semantics: SCCs are ordinary walk/jump/drop
    # components. Extended ability-gated links do not join weak fighters' SCCs.
    groups=components([[(j,k) for j,k in links if k<=2] for links in filtered])
    return [nodes[i] for i in keep],filtered,groups,len(nodes)-len(keep)


def select_spawns(nodes,edges,groups,query,count=32):
    sizes=Counter(groups)
    if not sizes:raise ValueError('No dry route graph')
    main=max(sizes,key=sizes.get)
    candidates=[i for i,p in enumerate(nodes) if groups[i]==main and query.body_clear(p)]
    if len(candidates)<count:raise ValueError('Insufficient dry, clear, strongly connected spawn candidates')
    center=min(candidates,key=lambda i:(nodes[i][0]-32)**2+(nodes[i][2]-128)**2)
    chosen=[];next_id=center
    while len(chosen)<count:
        chosen.append(next_id)
        next_id=max((i for i in candidates if i not in chosen),key=lambda i:min(sum((nodes[i][k]-nodes[j][k])**2 for k in range(3)) for j in chosen),default=None)
    separation=min(math.dist(nodes[i],nodes[j]) for a,i in enumerate(chosen) for j in chosen[a+1:])
    return center,dict(count=count,component=main,component_nodes=sizes[main],eligible_candidates=len(candidates),minimum_separation=separation,
                       body_radius=16,vertical_clearance=40,radial_support_samples=64,source='Mutually reachable ordinary walk/jump/drop SCC; dry point/footprint, highest exposed support and vertical clearance checks',
                       slots=[dict(slot=k,node=i,position=nodes[i]) for k,i in enumerate(chosen)])


def convert_candidate(cache,target,scale):
    cache=private(Path(cache));target=private(Path(target))
    if target.exists():raise ValueError('Use a fresh private output directory to preserve prior trial evidence')
    start=time.monotonic()
    conversion=convert(cache,'sirena1',scale,output=target,sirena_quality=True)
    triangles,water=sirena_water(read_collision(target/'delfino.dlc'));write_collision(target/'delfino.dlc',triangles)
    queries=Queries(triangles);nodes,edges,groups,nav=build(triangles,step=32)
    nodes,edges,groups,removed=filter_graph(nodes,edges,queries);center,spawns=select_spawns(nodes,edges,groups,queries)
    (target/'delfino.dln').write_bytes(encode(nodes,edges,groups,32))
    boundary=ledges(triangles);point=nodes[center]
    (target/'delfino.dls').write_bytes(struct.pack('<4sIf3fI',b'DLS1',2,scale,*point,len(boundary))+b''.join(struct.pack('<9f',*(v for p in line for v in p)) for line in boundary))
    (target/'spawn-candidates.json').write_text(json.dumps(spawns,indent=2)+'\n')
    report=dict(scene='sirena1',status='Experimental private prototype; no native runtime/material acceptance yet',water=water,
                material_policy=conversion['omitted_material_passes'],material_audit=conversion['material_audit'],
                navigation=dict(nodes=len(nodes),edges=sum(map(len,edges)),components=len(set(groups)),ordinary_scc=True,removed_marine_or_washed_shore_nodes=removed,source_unfiltered=nav),
                spawn_candidates=spawns,ledge_candidates=len(boundary),spawn_center=point,seconds=round(time.monotonic()-start,2),
                files={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in target.glob('delfino.*')},
                source_tools={name:hashlib.sha256(source_file(name).read_bytes()).hexdigest() for name in ('sunshine_survey_psn.py','sunshine_sirena_prototype.py')},
                limitations=['Coarse32-unit geometric routes; native CPU traversal and recovery diversity pending','Single-texture pool approximation omits unsupported donor subtractive TEV pass; not full J3D parity','Spawn candidates are static geometric evidence; native random spawn selection still requires a runtime audit','No menu registration, installation or public release changes'])
    (target/'prototype-report.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cache',type=Path,default=DEFAULT);p.add_argument('--output',type=Path);a=p.parse_args()
    from sunshine_scale import measure
    scale=measure(Path.home()/'Library/Application Support/Memelees/game-data/sunshine')['scale']
    report=convert_candidate(a.cache,a.output or a.cache/'prototype-sirena1-v1',scale)
    print(json.dumps({k:report[k] for k in ('scene','status','water','navigation','ledge_candidates','spawn_center','seconds')},indent=2))

if __name__=='__main__':main()
