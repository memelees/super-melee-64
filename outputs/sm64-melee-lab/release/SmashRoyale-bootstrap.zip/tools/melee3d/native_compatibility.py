#!/usr/bin/env python3
"""Isolated native-port feasibility probes; never installs over the Dolphin game.

prepare --build-macos fetches pinned code and builds the Apple Silicon baseline.
macos runs a bounded four-CPU FD match. units, akaneia and six use the native Windows
port through a dedicated CrossOver bottle. The latter are headless 2D probes;
neither candidate currently supplies our combined 3D engine or 16-player mode.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import plistlib
import re
import shutil
import subprocess
import time
import zipfile

from player_paths import payload
ROOT = payload()
WORK = ROOT / "build/native-proof"
CACHE = Path.home() / "Library/Application Support/melee3d/cache/native-proof"
BOTTLE = "Melee3D-Native-Proof"
DISC = Path.home() / "Downloads/Super Smash Bros. Melee (USA) (En,Ja) (Rev 2).iso"
SOURCES = {
    "melee-pc": ("999sian/melee-pc", "master", "0cc24fee6b8e7dd7a9233daa126829d374fe1f40"),
    "gd-melee": ("GurekamDhillon/melee", "pc-port", "f5662df14c3534652b68bca94e5e0d35e2a24962"),
    "gd-workspace": ("GurekamDhillon/gd-melee-workspace", "master", "dc9dcbc5391b1f14be259fa5b58f0da22b7a9e57"),
}
ZIP_NAME = "GDMelee-0.3.0-win64.zip"
ZIP_URL = "https://github.com/GurekamDhillon/gd-melee-workspace/releases/download/v0.3.0/" + ZIP_NAME
ZIP_SHA = "3e6c41bf555bd3e5ceb7bbb2d53a5a86572a3de359757e47dbc9c5f1b48db13c"
EXE_SHA = "91b7c24151be97759ec3f944e0ec5cd88e7df8301a8034f5f99eee5b1d3d7c61"
MAP_SHA = "b98fab9939f133ed96cad0764207cdc663926c87a29f0ab97b72fc3c655c69ca"
# Pinned MSVC x86 ABI: [esp+4] = output pointer, [esp+8/+12] = timepoint.
# Return the timepoint unchanged: host calendar timestamps become UTC. This
# avoids std::chrono::current_zone's unavailable Windows ICU dependency in Wine.
# It is not a change to OSGetTime, frame pacing, RNG, or fighter simulation.
CALENDAR_OFFSET = 0x77D190
CALENDAR_BEFORE = bytes.fromhex("83ec44a1c06dc01033c489442440538b5c24")
CALENDAR_UTC = bytes.fromhex("8b4424048b4c24088b54240c8908895004c3")
NAMES = ["wolf", "diddy", "charizard", "lucas", "sonic", "dedede", "tails"]


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def stage_module(source, destination):
    """Refresh changed modules without preserving stale source timestamps."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not destination.exists() or sha(source) != sha(destination):
        shutil.copyfile(source, destination)



def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def windows_path(path):
    return "Z:" + str(Path(path).resolve()).replace("/", "\\")


def crossover():
    for parent in (Path.home() / "Applications", Path("/Applications")):
        path = parent / "CrossOver.app/Contents/SharedSupport/CrossOver/bin"
        if (path / "wine").is_file():
            return path
    raise RuntimeError("CrossOver was not found in Applications")


def utc_patch(executable):
    if hashlib.sha256(executable).hexdigest() != EXE_SHA:
        raise ValueError("Calendar compatibility patch requires the pinned GD v0.3.0 executable")
    if executable[CALENDAR_OFFSET:CALENDAR_OFFSET + len(CALENDAR_BEFORE)] != CALENDAR_BEFORE:
        raise ValueError("Unexpected host calendar helper prologue")
    result = bytearray(executable)
    result[CALENDAR_OFFSET:CALENDAR_OFFSET + len(CALENDAR_UTC)] = CALENDAR_UTC
    return bytes(result)


def judge_windows(kind, code, log, native_kind=None):
    """Require completed simulation evidence, not just a successful process exit."""
    if code != 0 or "FATAL" in log or "PANIC" in log:
        return False
    if kind == "units":
        summaries = re.findall(r"TESTS: pass=(\d+) fail=(\d+) total=(\d+)", log)
        return len(summaries) == 1 and tuple(map(int, summaries[0])) == (407, 0, 407)
    if kind == "six":
        completed = re.search(r"NATIVE SIX PASS frames=900 moved=6 damaged=([3-6])", log)
        return (completed is not None and "NATIVE SIX FAIL" not in log
                and all(f"NATIVE SIX FRAME 900 slot={slot} kind={slot+32} " in log
                        for slot in range(1, 7)))
    return (f"NATIVE CHECK PASS identity_neutral_jump_recovery kind={native_kind}" in log
            and "NATIVE CHECK FAIL" not in log and f"NATIVE FRAME 780 kind={native_kind} " in log
            and f"interp: special_n kind={native_kind} invocation 1 ran" in log)


def judge_macos(code, log, frames):
    return (code == 0 and "FATAL" not in log and "PANIC" not in log
            and f"MELEE_EXIT_AFTER_FRAMES: reached frame {frames}, exiting" in log
            and "boot scene: state 1 scene 2" in log)


def source_identity(folder):
    source = WORK / folder
    revision = subprocess.check_output(["git", "-C", str(source), "rev-parse", "HEAD"], text=True).strip()
    changed = subprocess.check_output(["git", "-C", str(source), "status", "--porcelain", "--untracked-files=no"], text=True)
    return {"repository": SOURCES[folder][0], "revision": revision,
            "tracked_sources_changed": bool(changed), "expected_revision": SOURCES[folder][2]}


def stage_windows():
    archive = WORK / ZIP_NAME
    if not archive.exists():
        temporary = archive.with_suffix(".download")
        subprocess.run(["curl", "-fL", "--retry", "2", "-o", str(temporary), ZIP_URL], check=True)
        if sha(temporary) != ZIP_SHA:
            raise ValueError("Downloaded native-port release checksum mismatch")
        temporary.replace(archive)
    if sha(archive) != ZIP_SHA:
        raise ValueError("Native-port release archive checksum mismatch")
    destination = WORK / "crossover-proof"
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as archive_file:
        for info in archive_file.infolist():
            parts = Path(info.filename).parts
            if not parts or parts[0] != "GDMelee-0.3.0-win64" or ".." in parts:
                raise ValueError("Unexpected release archive path")
            if len(parts) == 1:
                continue
            target = destination.joinpath(*parts[1:])
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            elif target.name != "melee-pc.exe":
                target.parent.mkdir(parents=True, exist_ok=True)
                content = archive_file.read(info)
                # These paths contain release resources only. Generated logs,
                # settings and caches have different names and stay private.
                if not target.exists() or target.read_bytes() != content:
                    target.write_bytes(content)
        original = archive_file.read("GDMelee-0.3.0-win64/melee-pc.exe")
    patched = utc_patch(original)
    (destination / "melee-pc.exe").write_bytes(patched)
    if sha(destination / "melee-pc.map") != MAP_SHA:
        raise ValueError("Native-port map checksum mismatch")
    write_json(destination / "melee3d-proof.json", {
        "base_executable_sha256": EXE_SHA, "executable_sha256": hashlib.sha256(patched).hexdigest(),
        "calendar_patch": {"address": "0x1077DD90", "file_offset": CALENDAR_OFFSET,
                           "before": CALENDAR_BEFORE.hex(), "after": CALENDAR_UTC.hex(),
                           "policy": "UTC host calendar timestamps"},
        "scope": "Native Windows game through CrossOver; headless compatibility only",
        "combined_3d_engine": False, "simultaneous_player_slots": 6,
    })
    return destination


def stage_akaneia():
    source = ROOT / "build/akaneia/disc"
    if sha(source / "sys/main.dol") != "f604e1399f2dc88e2fbbaa2b3441867ca34d00b99b82e16bee4e4ef108604805":
        raise ValueError("Requires the existing verified local Akaneia 1.0.1 extraction")
    destination = CACHE / "mods/akaneia"
    count = 0
    for item in (source / "files").rglob("*"):
        if item.is_file():
            target = destination / "files" / item.relative_to(source / "files")
            target.parent.mkdir(parents=True, exist_ok=True)
            if not target.exists():
                os.link(item, target)
            elif not os.path.samefile(item, target):
                raise ValueError("Existing Akaneia cache is not the expected immutable local link: " + str(target))
            count += 1
    write_json(destination / "mod.json", {"id": "akaneia", "name": "Local Akaneia 1.0.1 compatibility proof",
               "kind": "base", "version": "1.0.1", "pack": "akaneia"})
    return {"files": count, "root": str(destination), "method": "local immutable hardlinks"}


def prepare(build_macos=False):
    WORK.mkdir(parents=True, exist_ok=True)
    for folder, (repo, branch, commit) in SOURCES.items():
        destination = WORK / folder
        if not destination.exists():
            subprocess.run(["git", "clone", "--depth", "1", "--branch", branch,
                            "https://github.com/" + repo + ".git", str(destination)], check=True)
            subprocess.run(["git", "-C", str(destination), "fetch", "--depth", "1", "origin", commit], check=True)
            subprocess.run(["git", "-C", str(destination), "checkout", "--detach", commit], check=True)
        actual = subprocess.check_output(["git", "-C", str(destination), "rev-parse", "HEAD"], text=True).strip()
        if actual != commit:
            # Fetch the pin explicitly; never reset or discard a changed tree.
            raise RuntimeError(f"Expected {repo} at {commit}, found {actual}; preserve local changes and check out the pin explicitly")
    stage_windows()
    assets = stage_akaneia()
    bottle = Path.home() / "Library/Application Support/CrossOver/Bottles" / BOTTLE
    if not bottle.exists():
        subprocess.run([str(crossover() / "cxbottle"), "--bottle", BOTTLE, "--create", "--template", "win10_64",
                        "--description", "Isolated Melee 3D native compatibility tests"], check=True)
    config = (bottle / "cxbottle.conf").read_text()
    if "Isolated Melee 3D native compatibility tests" not in config:
        raise RuntimeError("The proof bottle name belongs to another configuration")
    if build_macos:
        source = WORK / "melee-pc"
        build_dir = source / "build/macos-proof"
        subprocess.run(["cmake", "-S", str(source), "-B", str(build_dir), "-G", "Ninja",
                        "-DCMAKE_BUILD_TYPE=RelWithDebInfo", "-DCMAKE_C_COMPILER=clang", "-DCMAKE_CXX_COMPILER=clang++",
                        "-DCMAKE_OSX_DEPLOYMENT_TARGET=15.0", "-DAURORA_DAWN_PROVIDER=package",
                        "-DAURORA_NOD_PROVIDER=package", "-DAURORA_SDL3_PROVIDER=system"], check=True)
        subprocess.run(["ninja", "-C", str(build_dir), "-j", "6", "melee"], check=True)
    write_json(WORK / "preparation.json", {"sources": SOURCES, "windows_release_sha256": ZIP_SHA,
               "local_akaneia": assets, "target_players": 16, "implemented_players": 6})


def bounded(command, cwd, env, directory, timeout=55, cancel=None):
    if os.uname().sysname == "Darwin" and Path(command[0]).name == "melee":
        # Per-process Cocoa defaults: never block an unattended run on a
        # restoration dialog after a deliberately failed diagnostic.
        command=[command[0],"-ApplePersistenceIgnoreState","YES",
                 "-NSQuitAlwaysKeepsWindows","NO",*command[1:]]
    directory.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    with (directory / "stdout.txt").open("w") as output:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT)
        write_json(directory / "process.json", {"pid": process.pid, "command": command})
        def stop_owned():
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        try:
            if cancel is None:
                code = process.wait(timeout=timeout)
            else:
                deadline = started + timeout
                while True:
                    if cancel.is_set():
                        stop_owned()
                        code = 130
                        break
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise subprocess.TimeoutExpired(command, timeout)
                    try:
                        code = process.wait(timeout=min(.2, remaining))
                        break
                    except subprocess.TimeoutExpired:
                        pass
        except subprocess.TimeoutExpired:
            stop_owned()
            code = 124
            if Path(command[0]).name == "wine":
                # Every caller uses the dedicated test bottle. Never stop
                # another bottle, the global Wine server, or user Dolphin.
                prefix = Path.home() / "Library/Application Support/CrossOver/Bottles" / BOTTLE
                stop_env = dict(os.environ, WINEPREFIX=str(prefix), CX_BOTTLE=BOTTLE)
                subprocess.run([str(crossover() / "wineserver"), "-k"], env=stop_env, timeout=10,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except BaseException:
            if process.poll() is None:
                stop_owned()
            raise
    return code, (directory / "stdout.txt").read_text(errors="replace"), round(time.monotonic() - started, 3)


def run_windows(kind, disc, character=None):
    game = WORK / "crossover-proof"
    marker = json.loads((game / "melee3d-proof.json").read_text())
    if sha(game / "melee-pc.exe") != marker["executable_sha256"]:
        raise ValueError("Staged native executable changed; prepare and verify it first")
    label = kind if kind in ("units", "six") else character
    case = WORK / "runs" / ("native-" + label)
    case.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, MELEE_MODS_DIR=windows_path(CACHE / "mods"), MELEE_VOLUME="0",
               MELEE_UNATTENDED="1", MELEE_MAX_SECONDS="35", MELEE_PAD_IGNORE_ADAPTER="1",
               MELEE_NO_ONBOARD="1", GW_ROOT=windows_path(WORK / "gd-workspace"),
               GW_MELEE=windows_path(WORK / "gd-melee"))
    command = [str(crossover() / "wine"), "--bottle", BOTTLE, "--no-gui", "--workdir", str(game),
               str(game / "melee-pc.exe")]
    if kind == "units":
        command.append("--test")
    else:
        index = NAMES.index(character) if kind == "akaneia" else 0
        source = ROOT / "tools/melee3d" / ("native_six_smoke.lua" if kind == "six" else "native_akaneia_smoke.lua")
        script = case / "smoke.lua"
        script.write_text(source.read_text().replace("EXPECTED_KIND", str(index + 33)))
        scene = f"mode=workbench;p1=mexext:{index+26}/hu;p2=fox/cpu0/idle;stage=fd;time=0;items=off"
        if kind == "six":
            scene = "mode=workbench;stage=fd;time=0;items=off;cpus=fight;" + ";".join(
                f"p{slot}=mexext:{slot+25}/cpu6" for slot in range(1, 7))
        env.update(MELEE_SCENE=scene,
                   MELEE_WB_HEADLESS="1", MELEE_WB_DIR=windows_path(case), MELEE_SCRIPTS="0",
                   MELEE_SCRIPT=windows_path(script), MELEE_SCRIPT_DATA_DIR=windows_path(case / "script-data"),
                   MELEE_LOG="core,scene,mex")
    command += ["--iso", str(disc)]
    code, log, seconds = bounded(command, game, env, case)
    passed = judge_windows(kind, code, log, None if kind == "units" else index + 33)
    result = {"passed": passed, "exit_code": code, "seconds": seconds, "log": str(case / "stdout.txt"),
              "executable_sha256": sha(game / "melee-pc.exe"), "kind": kind, "character": character,
              "scope": "Headless native Windows port through CrossOver; existing 2D mechanics",
              "calendar_policy": "UTC", "combined_3d_engine": False, "sixteen_players": False}
    if kind != "units":
        result["fixture_sha256"] = sha(source)
    if kind == "akaneia":
        result["interpreted_air_up_override_observed"] = f"interp: special_hi_air kind={index+33} invocation 1 ran" in log
    write_json(case / "result.json", result)
    print(label + ": " + ("PASS" if passed else "FAIL"), flush=True)
    return result


def capacity_layout():
    source = WORK / "melee-pc"
    compiler = next((shutil.which(f"gcc-{version}") for version in range(20, 12, -1)
                     if shutil.which(f"gcc-{version}")), None)
    if compiler is None:
        raise RuntimeError("Native layout probe requires Homebrew GCC (brew install gcc)")
    fixture = ROOT / "tools/melee3d/native_capacity_layout.c"
    executable = WORK / "capacity-layout"
    subprocess.run([compiler, "-O2", "-fsigned-char", "-DAURORA", "-DTARGET_PC=1", "-DMELEE_PC=1",
                    "-Wno-scalar-storage-order", "-include", str(source / "src/pc/compat.h"),
                    "-I" + str(source / "extern/aurora/include"), "-I" + str(source / "src"),
                    "-I" + str(source / "src/sdk_include"), str(fixture), "-o", str(executable)], check=True)
    layout = json.loads(subprocess.check_output([str(executable)], text=True))
    report = {"scope": "Compiled native headers; capacity/ABI evidence, not a 16-fighter runtime test",
              "source_revision": SOURCES["melee-pc"][2], "layout": layout,
              "source_identity": source_identity("melee-pc"),
              "target_players": 16, "supports_target": layout["player_slots"] >= 16,
              "guest_baseline": {"pointer_bytes": 4, "static_player_bytes": 0xE90,
                                 "hit_capsule_bytes": 0x138, "fighter_position_offset": 0xB0},
              "fixture_sha256": sha(fixture)}
    write_json(WORK / "capacity-layout.json", report)
    print(json.dumps(report, indent=2))
    return report


def run_macos(disc, frames):
    game = WORK / "melee-pc/build/macos-proof"
    case = WORK / "runs/native-macos-four"
    case.mkdir(parents=True, exist_ok=True)
    (game / "portable.txt").write_text("Private native compatibility proof.\n")
    env = dict(os.environ, MELEE_BOOT_SCENE="vs", MELEE_DEBUG_VS="cpu4", MELEE_EXIT_AFTER_FRAMES=str(frames),
               MELEE_SEED="1", MELEE_BACKEND="metal", MELEE_LOG_FILE=str(case / "game.log"),
               MELEE_FILES_DIR=str(case / "no-loose-files"))
    code, log, seconds = bounded([str(game / "melee"), "--no-card", str(disc)], game, env, case,
                                 timeout=frames / 60 + 30)
    passed = judge_macos(code, log, frames)
    result = {"passed": passed, "exit_code": code, "frames": frames, "seconds": seconds,
              "executable_sha256": sha(game / "melee"), "log": str(case / "stdout.txt"),
              "scope": "Apple Silicon / Metal baseline, four retail CPUs, 2D Final Destination",
              "source": source_identity("melee-pc"),
              "akaneia": False, "combined_3d_engine": False, "sixteen_players": False}
    write_json(case / "result.json", result)
    print("macos: " + ("PASS" if passed else "FAIL"), flush=True)
    return result


def compatibility_report():
    """Summarize measured component gates without passing the combined goal."""
    reports = {}
    for name in ("macos", "units", "akaneia", "six"):
        path = WORK / ("suite-" + name + ".json")
        reports[name] = json.loads(path.read_text()) if path.exists() else None
    layout_path = WORK / "capacity-layout.json"
    layout = json.loads(layout_path.read_text()) if layout_path.exists() else None
    native_lab=[]
    for path in sorted((WORK / "runs").glob("mac-lab-*/result.json")):
        result=json.loads(path.read_text())
        native_lab.append(dict(result,report=str(path)))
    bridge_path=WORK / "mac-bridge/suite.json"
    isa_path=WORK / "mac-bridge/isa-suite.json"
    build_path=WORK/'native-mac-build.json'
    build=json.loads(build_path.read_text()) if build_path.exists() else None
    live=[]
    for path in sorted((WORK/'runs').glob('mac-live-*/result.json'),key=lambda p:p.stat().st_mtime):
        result=json.loads(path.read_text())
        live.append(dict(result,report=str(path),current_build=bool(build and result.get('executable_sha256')==build['executable_sha256'])))
    specials=[]
    for path in sorted((WORK/'runs').glob('mac-specials-*.json'),key=lambda p:p.stat().st_mtime):
        result=json.loads(path.read_text())
        specials.append(dict(result,report=str(path),current_build=bool(build and result.get('executable_sha256')==build['executable_sha256'])))
    sequences=[]
    for path in sorted((WORK/'runs').glob('mac-sequences-*/suite.json'),key=lambda p:p.stat().st_mtime):
        result=json.loads(path.read_text())
        sequences.append(dict(result,report=str(path),current_build=bool(build and result.get('executable_sha256')==build['executable_sha256'])))
    article_path=WORK/'mac-articles/suite.json'
    articles=json.loads(article_path.read_text()) if article_path.exists() else None
    if articles:
        articles['matches_game_loader']=bool(build and articles.get('production_loader_sha256')==build.get('modules',{}).get('m3d_vm.c'))
    report = {
        "target": {"total_players": 16, "humans": 1, "npcs": 15,
                   "native_macos": True, "akaneia": True, "third_person_3d": True},
        "combined_native_3d_16_ready": False,
        "sources": {folder: source_identity(folder) for folder in SOURCES},
        "component_results": reports, "compiled_capacity_layout": layout,
        "native_mac_laboratory_runs": native_lab,
        "native_mac_build":build,
        "native_mac_live_akaneia_runs":live,
        "native_special_smoke_suites":specials,
        "native_special_sequence_suites":sequences,
        "original_article_loader":articles,
        "arm64_module_bridge": json.loads(bridge_path.read_text()) if bridge_path.exists() else None,
        "arm64_instruction_tests": json.loads(isa_path.read_text()) if isa_path.exists() else None,
        "remaining_gates": [
            "Finish remaining live Akaneia move/effect/aggregate contracts, shared native/guest state, audio and complete-move validation",
            "Port the reference 3D stage, combat and input adaptations to the chosen native engine",
            "Harden sixteen-slot lifecycle, UI/results, transforms, followers and all interactions beyond the retail FD laboratory",
            "Expanded-roster arbitrary-pair hits, throws, ownership, KOs and respawns in native 3D",
            "Measured native Delfino rendering, memory, audio and performance with sixteen fighters",
        ],
        "crossover_graphics": "Not passed: renderer initialization failed on Wine/DXVK and DXMT",
        "delfino_imported": False,
        "scope": "Component feasibility evidence only. Does not certify a combined native Mac Akaneia 3D game.",
    }
    write_json(WORK / "compatibility-report.json", report)
    print(WORK / "compatibility-report.json")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["prepare", "macos", "units", "akaneia", "six", "layout", "report"])
    parser.add_argument("--build-macos", action="store_true")
    parser.add_argument("--disc", type=Path, default=DISC)
    parser.add_argument("--character", choices=NAMES)
    parser.add_argument("--frames", type=int, default=1800)
    args = parser.parse_args()
    WORK.mkdir(parents=True, exist_ok=True)
    if args.command == "prepare":
        prepare(args.build_macos)
        return
    if args.command == "layout":
        capacity_layout()
        return
    if args.command == "report":
        compatibility_report()
        return
    disc = args.disc.expanduser().resolve()
    with disc.open("rb") as stream:
        header = stream.read(8)
    if header[:6] != b"GALE01" or header[7] != 2:
        parser.error("Requires the user's Melee NTSC-U rev2 disc")
    lock = WORK / ".probe-running"
    try:
        with lock.open("x") as owner:
            owner.write(str(os.getpid()))
    except FileExistsError:
        parser.error("Another native probe owns .probe-running; do not run cases concurrently")
    try:
        if args.command == "macos":
            if not 120 <= args.frames <= 3600:
                parser.error("Frame bound must be between 120 and 3600")
            results = [run_macos(disc, args.frames)]
        elif args.command in ("units", "six"):
            results = [run_windows(args.command, disc)]
        else:
            results = [run_windows("akaneia", disc, name) for name in ([args.character] if args.character else NAMES)]
        write_json(WORK / ("suite-" + args.command + ".json"), {
            "passed": all(r["passed"] for r in results), "results": results,
            "target_players": 16, "combined_native_3d_16_ready": False,
        })
        raise SystemExit(0 if all(r["passed"] for r in results) else 1)
    finally:
        lock.unlink()


if __name__ == "__main__":
    main()
