#!/usr/bin/env python3
"""Extract the nine canonical stages' authored surfaces from verified local data.

No geometry is checked into source control. The generated include retains the
original polygon, underside profile, native line ids and joint associations.
"""
import json,struct,os
from pathlib import Path
from native_compatibility import ROOT,WORK,sha,write_json
from inspect_walz0 import PAYLOAD_BASE,PAYLOAD_SHA256,SURFACE_TABLES,REFERENCE_SHA256,filesystem,read_at
from native_roster import Archive
from install_canonical import DEFAULT_DISC,MARKER,verify_files

STAGES={32:('fd','GrNLa.dat'),3:('stadium','GrPs.dat'),8:('story','GrSt.dat'),
        2:('fountain','GrIz.dat'),28:('dreamland','GrOp.dat'),17:('greens','GrGr.dat'),
        16:('island','GrYt.dat'),10:('mutecity','GrMc.dat'),9:('onett','GrOt.dat')}

def reference_source():
    """Use an installed canonical disc or derive assets from the pinned release.

    A fresh native build needs the reference stage archives, not a previously
    installed/tested Dolphin executable. Verify the complete reference image
    before extracting its nine authored stages. Never invent an installation
    marker or replace an existing canonical installation/cache.
    """
    marker=DEFAULT_DISC/MARKER
    if marker.exists():
        metadata=json.loads(marker.read_text())
        verify_files(DEFAULT_DISC,metadata)
        return DEFAULT_DISC/'files',{name:value for name,value in metadata['stage_assets'].items() if name.startswith('Gr')}
    reference=ROOT/'build/references/walz0-v1.0.iso'
    if sha(reference)!=REFERENCE_SHA256:raise ValueError('Requires the pinned walz0 v1.0 reference ISO')
    destination=ROOT/'build/references/walz0-stage-assets'
    assets={}
    with reference.open('rb') as stream:
        entries=filesystem(stream)
        for name in sorted({name for _,name in STAGES.values()}):
            data=read_at(stream,*entries[name])
            target=destination/name
            if target.exists():
                if target.read_bytes()!=data:raise ValueError('Reference stage cache changed: '+name)
            else:
                destination.mkdir(parents=True,exist_ok=True)
                with target.open('xb') as output:output.write(data)
            assets[name]=sha(target)
    write_json(destination/'source.json',dict(reference_sha256=REFERENCE_SHA256,stage_assets=assets,
        scope='Verified reference stage assets for native builds; not a canonical Dolphin installation'))
    return destination,assets

def triangulate(points):
    """Ear clipping for simple authored polygons; never fan across a concavity."""
    cross=lambda a,b,c:(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    area=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(points,points[1:]+points[:1]))
    if abs(area)<1e-8:raise ValueError('Degenerate canonical surface')
    sign=1 if area>0 else -1
    remaining=list(range(len(points)));triangles=[]
    while len(remaining)>3:
        for k,b in enumerate(remaining):
            a,c=remaining[k-1],remaining[(k+1)%len(remaining)]
            turn=sign*cross(points[a],points[b],points[c])
            if abs(turn)<1e-8:
                remaining.pop(k);break
            if turn<0:continue
            if any(all(sign*cross(points[x],points[y],points[p])>=-1e-8 for x,y in [(a,b),(b,c),(c,a)])
                   for p in remaining if p not in (a,b,c)):continue
            triangles.append((a,b,c));remaining.pop(k);break
        else:raise ValueError('Non-simple canonical surface')
    if len(remaining)==3:triangles.append(tuple(remaining))
    return triangles

def extract():
    payload=ROOT/'build/references/walz0-payload.bin'
    if sha(payload)!=PAYLOAD_SHA256:raise ValueError('Canonical surface payload changed')
    files,assets=reference_source()
    blob=payload.read_bytes();out=[]
    for st,name,address,count in SURFACE_TABLES:
        if st not in STAGES:continue
        key,filename=STAGES[st];archive=Archive(files/filename)
        at=archive.public['coll_data'];vp,nv,lp,nl=struct.unpack_from('>4I',archive.payload,at)
        jp,nj=struct.unpack_from('>2I',archive.payload,at+36)
        verts=[struct.unpack_from('>2f',archive.payload,vp+i*8) for i in range(nv)]
        lines=[struct.unpack_from('>8h',archive.payload,lp+i*16) for i in range(nl)]
        joints=[struct.unpack_from('>10h4f2h',archive.payload,jp+i*40) for i in range(nj)]
        def owner(line):
            for j,v in enumerate(joints):
                if any(v[k]<=line<v[k]+v[k+1] for k in range(0,10,2)):return j
            raise ValueError('Unowned source line')
        surfaces=[]
        for i in range(count):
            o=address-PAYLOAD_BASE+i*88;ptr,n,y,main=struct.unpack_from('>IIfI',blob,o)
            flags=struct.unpack_from('>I',blob,o+36)[0]
            xyz=[struct.unpack_from('>2f',blob,ptr-PAYLOAD_BASE+k*8) for k in range(n)]
            bounds=struct.unpack_from('>4f',blob,o+16)
            line_ptr,line_count,profile_ptr,profile_count=struct.unpack_from('>4I',blob,o+40)
            ids=list(struct.unpack_from('>'+str(line_count)+'h',blob,line_ptr-PAYLOAD_BASE)) if line_ptr else []
            profile=[struct.unpack_from('>3f',blob,profile_ptr-PAYLOAD_BASE+k*12) for k in range(profile_count)] if profile_ptr else []
            morph_ptr,morph_count=struct.unpack_from('>2I',blob,o+76)
            morph=[struct.unpack_from('>2f',blob,morph_ptr-PAYLOAD_BASE+k*8) for k in range(morph_count)] if morph_ptr else []
            surfaces.append(dict(points=xyz,triangles=triangulate(xyz),height=y,main=main,flags=flags,bounds=bounds,lines=ids,profile=profile,
                morph=morph,morph_z=struct.unpack_from('>2f',blob,o+68),joint=-1))
        mapping=[]
        for li,line in enumerate(lines):
            a,b=verts[line[0]],verts[line[1]];selected=count-1
            for i,s in enumerate(surfaces[:-1]):
                lo,hi,bottom,top=s['bounds'];j=(s['flags']>>8)-1
                match=li in s['lines'] if s['lines'] else all(lo<=p[0]<=hi and bottom<=p[1]<=top for p in (a,b))
                if match and (j<0 or owner(li)==j):selected=i;break
            mapping.append(selected)
        for i,s in enumerate(surfaces):
            owners={owner(li) for li,si in enumerate(mapping) if si==i}
            s['joint']=next(iter(owners)) if len(owners)==1 else -1
            s['source_x']=[min((verts[v][0] for li,si in enumerate(mapping) if si==i for v in lines[li][:2]),default=-1),
                           max((verts[v][0] for li,si in enumerate(mapping) if si==i for v in lines[li][:2]),default=1)]
        out.append(dict(stage=st,key=key,name=name,archive=filename,archive_sha256=assets[filename],
                        vertex_count=nv,line_count=nl,joint_count=nj,surfaces=surfaces,line_surfaces=mapping))
    return out

def castle_reference():
    """Topology adapter only; actual Castle physics comes from its OVL bank.

    No two-dimensional Castle lane is expanded into an invented rectangle.
    The sentinel surface is completely masked when the verified source-mesh
    overlay is selected; the runtime requires that bank for external stage4.
    """
    from player_install import DEFAULT
    candidates=(DEFAULT/'akaneia/files/GrCs.dat',ROOT/'build/akaneia/disc/files/GrCs.dat')
    path=next((p for p in candidates if p.is_file()),None)
    if path is None:return None
    a=Archive(path);at=a.public['coll_data'];_,nv,_,nl=struct.unpack_from('>4I',a.payload,at)
    _,nj=struct.unpack_from('>2I',a.payload,at+36)
    if (nv,nl,nj)!=(60,51,15):raise ValueError('Unsupported Castle source collision topology')
    surface=dict(points=[(-1,-1),(-1,1),(1,1),(1,-1)],triangles=[(0,1,2),(0,2,3)],height=0.,main=1,flags=0,bounds=[-1,1,-1,1],lines=list(range(nl)),profile=[],morph=[],morph_z=[0,0],joint=-1,source_x=[-1,1])
    return dict(stage=4,key='castle',name="Princess Peach's Castle",archive='GrCs.dat',archive_sha256=sha(path),vertex_count=nv,line_count=nl,joint_count=nj,surfaces=[surface],line_surfaces=[0]*nl,requires_private_overlay=True)


def generate():
    if os.environ.get('MELEE3D_BUILD_PLAZA_ONLY')=='1':
        dest=WORK/'melee-pc/src/pc/world/m3d_reference_data.inc'
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_text('/* Plaza uses its locally imported mesh, without optional legacy arenas. */\nstatic const RefStage ref_stages[]={{-1,0,0,0,NULL,NULL}};\n')
        write_json(WORK/'reference-stages.json',dict(stages=[],plaza_only=True))
        return dest
    stages=extract();castle=castle_reference()
    if castle:stages.append(castle)
    dest=WORK/'melee-pc/src/pc/world/m3d_reference_data.inc';parts=[]
    f=lambda v:float(v).hex()+'f'
    for st in stages:
        tag='ref_'+st['key']
        for i,s in enumerate(st['surfaces']):
            for name,width,values in [('points',2,s['points']),('profile',3,s['profile']),('morph',2,s['morph'])]:
                if values:parts.append(f'static const float {tag}_{i}_{name}[][{width}]={{'+','.join('{'+','.join(map(f,p))+'}' for p in values)+'};')
            parts.append(f'static const unsigned short {tag}_{i}_triangles[][3]={{'+','.join('{'+','.join(map(str,p))+'}' for p in s['triangles'])+'};')
        parts.append(f'static const RefSurface {tag}_surfaces[]={{')
        for i,s in enumerate(st['surfaces']):
            arr=lambda n: f'{tag}_{i}_{n}' if s[n] else 'NULL'
            parts.append('{'+f"{arr('points')},{len(s['points'])},{f(s['height'])},{s['main']},{s['flags']},{s['joint']},"+
                '{'+','.join(map(f,s['source_x']))+'},'+f"{arr('profile')},{len(s['profile'])},{arr('morph')},{len(s['morph'])},"+'{'+','.join(map(f,s['morph_z']))+'},'+f"{tag}_{i}_triangles,{len(s['triangles'])}"+'},')
        parts.append('};')
        parts.append(f'static const short {tag}_lines[]={{'+','.join(map(str,st['line_surfaces']))+'};')
    parts.append('static const RefStage ref_stages[]={')
    for s in stages:
        tag='ref_'+s['key'];parts.append('{'+f"{s['stage']},{len(s['surfaces'])},{s['line_count']},{s['joint_count']},{tag}_surfaces,{tag}_lines"+'},')
    parts.append('};\n')
    dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text('\n'.join(parts))
    write_json(WORK/'reference-stages.json',dict(payload_sha256=PAYLOAD_SHA256,stages=stages))
    return dest
if __name__=='__main__':print(generate())
