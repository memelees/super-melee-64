"""OS-owned session locks automatically release after a crash or force quit."""
from contextlib import contextmanager
import os


@contextmanager
def session_lock(profile):
    profile.mkdir(parents=True,exist_ok=True)
    with (profile/'.session-lock').open('a+b') as stream:
        stream.seek(0);stream.write(b'\0');stream.flush();stream.seek(0)
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError as error:raise RuntimeError('A game is already using this profile. Close its window first.') from error
        try:yield
        finally:
            if os.name=='nt':
                stream.seek(0);msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)
            else:fcntl.flock(stream,fcntl.LOCK_UN)
