#!/usr/bin/env python3
"""Extract selected Sunshine files from the owner's ISO/7z without unpacking it.

Cache only: no Nintendo data is generated inside the repository. NKit's GC FST
already contains physical file offsets; this does not recover a Redump ISO.
"""
from __future__ import annotations
import argparse
import contextlib
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import struct
import subprocess
from player_paths import payload

CACHE = Path.home() / 'Library/Application Support/melee3d/cache/sunshine'
DEFAULT = Path.home() / 'Downloads/Super Mario Sunshine.zip'
MAX_FILE = 64 * 1024 * 1024


def u32(data, offset):
    if offset < 0 or offset + 4 > len(data):
        raise ValueError('Truncated unsigned integer')
    return struct.unpack_from('>I', data, offset)[0]


def safe_path(name):
    path = PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or '\\' in name or not path.parts:
        raise ValueError('Unsafe source path: ' + name)
    return path


@contextlib.contextmanager
def disc_stream(source):
    with source.open('rb') as f:
        magic = f.read(6)
    if magic == b"7z\xbc\xaf\x27\x1c":
        seven = shutil.which('7zz') or shutil.which('7z')
        if not seven:
            raise ValueError('7z is required for this compressed disc')
        listing = subprocess.run([seven, 'l', '-slt', str(source)], capture_output=True, text=True, check=True).stdout
        members = [line[7:] for line in listing.splitlines() if line.startswith('Path = ')][1:]
        if len(members) != 1 or not members[0].lower().endswith('.iso'):
            raise ValueError('Expected exactly one ISO member')
        process = subprocess.Popen([seven, 'x', '-so', str(source), members[0]], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        try:
            yield process.stdout, members[0]
        finally:
            process.stdout.close()
            if process.poll() is None:
                process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
    else:
        with source.open('rb') as f:
            yield f, source.name


def exact(stream, size):
    result = bytearray()
    while len(result) < size:
        chunk = stream.read(min(size-len(result), 1024*1024))
        if not chunk:
            raise ValueError('Truncated disc stream')
        result.extend(chunk)
    return bytes(result)


def skip(stream, size):
    if size < 0:
        raise ValueError('Disc reads must be ordered')
    while size:
        chunk = stream.read(min(size, 1024*1024))
        if not chunk:
            raise ValueError('Truncated disc stream')
        size -= len(chunk)


def filesystem(fst):
    count = u32(fst, 8)
    if not 1 <= count <= 100000 or count * 12 > len(fst):
        raise ValueError('Invalid FST entry count')
    strings = fst[count*12:]
    stack, files = [], []
    for index in range(1, count):
        while stack and index >= stack[-1][1]:
            stack.pop()
        word, offset, size = struct.unpack_from('>III', fst, index*12)
        start = word & 0xffffff
        try:
            name = strings[start:strings.index(b'\0', start)].decode('ascii')
        except (ValueError, UnicodeError) as e:
            raise ValueError('Invalid FST name') from e
        safe_path(name)
        path = '/'.join([s[0] for s in stack] + [name])
        if word >> 24:
            if word >> 24 != 1 or not index < size <= count or (stack and size > stack[-1][1]):
                raise ValueError('Invalid directory extent')
            stack.append((name, size))
        else:
            files.append(dict(path=path, offset=offset, size=size))
    return files


def yaz0(data):
    if data[:4] != b'Yaz0':
        return data
    size = u32(data, 4)
    if size > MAX_FILE:
        raise ValueError('Yaz0 output exceeds scene limit')
    out, pos = bytearray(), 16
    while len(out) < size:
        if pos >= len(data):
            raise ValueError('Truncated Yaz0 control')
        code, pos = data[pos], pos+1
        for bit in range(7, -1, -1):
            if len(out) == size:
                break
            if pos >= len(data):
                raise ValueError('Truncated Yaz0 token')
            if code & (1 << bit):
                out.append(data[pos]); pos += 1
            else:
                if pos+2 > len(data):
                    raise ValueError('Truncated Yaz0 backreference')
                a, b = data[pos:pos+2]; pos += 2
                distance = ((a & 15) << 8 | b) + 1
                length = a >> 4
                if length == 0:
                    if pos >= len(data):
                        raise ValueError('Truncated Yaz0 length')
                    length = data[pos]+18; pos += 1
                else:
                    length += 2
                if distance > len(out) or len(out)+length > size:
                    raise ValueError('Invalid Yaz0 backreference')
                for _ in range(length):
                    out.append(out[-distance])
    return bytes(out)


def rarc(data):
    """RARC directory records, with offsets relative to their documented bases."""
    if data[:4] != b'RARC' or u32(data, 4) != len(data):
        raise ValueError('Invalid RARC header')
    base = u32(data, 8)
    payload = base + u32(data, 12)
    nodes, node_offset = u32(data, base), base+u32(data, base+4)
    entries, entry_offset = u32(data, base+8), base+u32(data, base+12)
    string_size, string_offset = u32(data, base+16), base+u32(data, base+20)
    if not (0 < nodes < 10000 and entries < 100000 and node_offset+nodes*16 <= len(data)
            and entry_offset+entries*20 <= len(data) and string_offset+string_size <= len(data)):
        raise ValueError('Invalid RARC tables')
    strings = data[string_offset:string_offset+string_size]
    files, visited = {}, set()
    def walk(index, prefix):
        if index >= nodes or index in visited:
            raise ValueError('Invalid RARC directory graph')
        visited.add(index)
        _, _, _, number, first = struct.unpack_from('>4sIHHI', data, node_offset+index*16)
        if first+number > entries:
            raise ValueError('Invalid RARC entry range')
        for i in range(first, first+number):
            _, _, flags_name, offset, size, _ = struct.unpack_from('>HHIIII', data, entry_offset+i*20)
            name_start = flags_name & 0xffffff
            try:
                name = strings[name_start:strings.index(b'\0', name_start)].decode('shift_jis')
            except (ValueError, UnicodeError) as e:
                raise ValueError('Invalid RARC string') from e
            if name in ('.', '..'):
                continue
            safe_path(name)
            path = prefix+name
            if flags_name >> 24 & 2:
                walk(offset, path+'/')
            else:
                start = payload+offset
                if size > MAX_FILE or start+size > len(data) or path in files:
                    raise ValueError('Invalid RARC file extent')
                files[path] = data[start:start+size]
    walk(0, '')
    return files


def extract(source, cache, wanted):
    source, cache = source.expanduser().resolve(), cache.expanduser().resolve()
    repo = payload().resolve()
    if cache == repo or repo in cache.parents:
        raise ValueError('Nintendo asset cache must be outside the repository')
    for path in wanted:
        safe_path(path)
    cache.mkdir(parents=True, exist_ok=True)
    with disc_stream(source) as (stream, member):
        header = exact(stream, 0x440)
        if header[:6] != b'GMSE01' or header[7] != 0 or u32(header, 0x1c) != 0xc2339f3d:
            raise ValueError('Expected US Sunshine GMSE01 revision 0')
        offset, size = u32(header, 0x424), u32(header, 0x428)
        if size > 8*1024*1024 or offset < len(header):
            raise ValueError('Invalid disc FST')
        skip(stream, offset-len(header))
        fst = exact(stream, size)
        files = filesystem(fst)
        selected = sorted((f for f in files if f['path'] in wanted), key=lambda f:f['offset'])
        if {f['path'] for f in selected} != set(wanted):
            raise ValueError('Requested source file missing')
        cursor, extracted = offset+size, []
        for f in selected:
            if f['size'] > MAX_FILE:
                raise ValueError('Selected file exceeds extraction limit')
            skip(stream, f['offset']-cursor)
            data = exact(stream, f['size']); cursor = f['offset']+f['size']
            target = cache/'disc'/f['path']; target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            record = dict(f, sha256=hashlib.sha256(data).hexdigest())
            if data[:4] in (b'Yaz0', b'RARC'):
                contents = rarc(yaz0(data))
                record['members'] = []
                for name, content in sorted(contents.items()):
                    output = cache/'archives'/Path(f['path']).stem/name
                    output.parent.mkdir(parents=True, exist_ok=True); output.write_bytes(content)
                    record['members'].append(dict(path=name, size=len(content), sha256=hashlib.sha256(content).hexdigest()))
            extracted.append(record)
            print('Extracted', f['path'], f['size'], flush=True)
    report = dict(source=str(source), source_bytes=source.stat().st_size, member=member,
                  game_id='GMSE01', revision=0, nkit=header[0x200:0x204] == b'NKIT',
                  fst_sha256=hashlib.sha256(fst).hexdigest(), files=files, extracted=extracted,
                  scope='Local-disc extraction only; rendering, geometry, music and gameplay acceptance remain separate.')
    (cache/'source.json').write_text(json.dumps(report, indent=2)+'\n')
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', type=Path, default=DEFAULT)
    p.add_argument('--cache', type=Path, default=CACHE)
    p.add_argument('--audio', action='store_true', help='Also extract original sequence and wave banks')
    a = p.parse_args()
    wanted = ['data/scene/dolpic1.szs', 'data/mario.szs', 'data/common.szs', 'data/particle.szs', 'data/scene/bianco6.szs', 'data/scenecmn.bin']
    if a.audio:
        wanted += ['data/nintendo.szs', 'AudioRes/mSound.asn', 'AudioRes/Seqs/sequence.arc', 'AudioRes/Banks/w1stLoad_0.aw',
                   'AudioRes/Banks/w2ndLoad_0.aw'] + [f'AudioRes/Banks/wScene_{i}.aw' for i in range(22)]
    result = extract(a.source, a.cache, wanted)
    print(json.dumps(dict(cache=str(a.cache), files=len(result['extracted']), bytes=sum(f['size'] for f in result['extracted'])), indent=2))


if __name__ == '__main__':
    main()
