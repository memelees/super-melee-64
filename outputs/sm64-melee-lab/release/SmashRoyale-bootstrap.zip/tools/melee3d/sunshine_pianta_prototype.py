#!/usr/bin/env python3
"""Build Pianta Village from the owner's clean/day Sunshine episode.

Original geometry and material bytes stay in a private cache. This compiler
freezes identified platform actors at their authored rest poses; it does not
simulate Sunshine's swinging platforms or climbing-fence mechanics.
"""
import argparse
from collections import Counter,defaultdict
import hashlib,json,math,struct,time
from pathlib import Path
from player_paths import payload,source_file

from sunshine_scene import bounds,collision,flatten,joints,matrix,multiply,scene,static_model,transform
from sunshine_compile import MATERIAL_STATE,PASS_THROUGH,WATER,cross,ledges,material_chunks,materials,unique_collision
from sunshine_occlusion import groups as mesh_groups
from sunshine_navigation import build,encode,components,height,segment_hit
from sunshine_water import shallow_collision

DEFAULT=Path.home()/'Library/Application Support/Memelees/map-survey/pianta-corona-extras'
SCALE=0.08190640965783352
VERSION=2
# THangingBridge::initMonte, original 19 boards (metres are not donor units).
BRIDGE=((0,-130,11965,30),(0,-275,12225,29),(0,-415,12490,28),
 (0,-540,12760,26),(0,-660,13035,24),(0,-770,13315,22),
 (0,-875,13595,20),(0,-960,13895,12),(0,-1020,14190,8),
 (0,-1060,14490,4),(0,-1090,14790,2),(0,-1090,15090,0),
 (0,-1080,15395,-4),(0,-1040,15695,-6),(0,-995,15990,-8),
 (0,-945,16285,-8),(0,-900,16580,-8),(0,-855,16880,-8),(0,-800,17175,-10))
ACTORS={'PalmSago':'palmsago','MapObjTreeScale':'bananatree','FruitTree':'fruittree',
 'SwingBoard':'swingboard','JumpMushroom':'jumpkinoko'}


def private(path):
    path=path.expanduser().resolve();repo=payload().resolve()
    if path==repo or repo in path.parents:raise ValueError('Donor output must remain outside repository')
    return path


def write_collision(path,triangles):
    path.write_bytes(struct.pack('<4s2I',b'DLC1',1,len(triangles))+b''.join(
        struct.pack('<12f2I',*(v for p in ps for v in p),*n,s,f) for ps,n,s,f in triangles))


def gameplay_collision(triangles):
    """Remove exactly the lowest fallback quad; mark deep scenery non-solid.

    Upper village is the combat plane. Roots/fences below -85 stay scenery,
    never spawn/route/goop goals. Pianta uses a separate -220 native KO plane
    to leave recovery airspace below its sagging -81 bridge. Preserve the deep
    original world geometry for camera views.
    """
    lowest=min(p[1] for ps,*_ in triangles for p in ps)
    fallback=[t for t in triangles if all(abs(p[1]-lowest)<.01 for p in t[0]) and t[1][1]>.99]
    if len(fallback)!=2 or lowest>-2000:raise ValueError('Pianta lowest fallback contract changed')
    result=[];deep=0
    for t in triangles:
        ps,n,s,f=t
        if t in fallback:continue
        if max(p[1] for p in ps)<-85 and not f&2:f|=2;deep+=1
        result.append((ps,n,s,f))
    return shallow_collision(unique_collision(result)),dict(fallback_triangles_removed=2,fallback_height=lowest,
        deep_scenery_triangles=deep,deep_scenery_cutoff=-85,recovery_plane=-220,river_policy='Original bounded water, four-unit shallow bed; river is not a solid surface')


class Queries:
    def __init__(self,triangles):
        self.triangles=triangles;self.grid=defaultdict(list)
        for i,(ps,n,s,f) in enumerate(triangles):
            if f&2:continue
            for x in range(math.floor(min(p[0] for p in ps)/64),math.floor(max(p[0] for p in ps)/64)+1):
                for z in range(math.floor(min(p[2] for p in ps)/64),math.floor(max(p[2] for p in ps)/64)+1):self.grid[x,z].append(i)
    def levels(self,x,z,water=False):
        result=[]
        for i in self.grid.get((math.floor(x/64),math.floor(z/64)),[]):
            ps,n,s,f=self.triangles[i]
            if (not f&1 if water else f&3 or n[1]<.65):continue
            y=height(ps,n,x,z)
            if y is not None:result.append(y)
        return result
    def dry(self,p):
        return p[1]>-80 and not any(p[1]<y+.5 for y in self.levels(p[0],p[2],True))
    def body_clear(self,p,radius=16,above=40):
        if not self.dry(p):return False
        x,y,z=p
        # Allow stacked canopy surfaces: support must match THIS level and
        # overhead obstruction is checked independently, rather than selecting
        # a tree canopy above a perfectly usable street.
        if not any(abs(h-y)<.5 for h in self.levels(x,z)):return False
        samples=[p]
        for k in range(8):
            a=k*math.pi/4;last=y
            for j in range(1,9):
                r=radius*j/8;qx,qz=x+math.cos(a)*r,z+math.sin(a)*r
                options=[h for h in self.levels(qx,qz) if abs(h-last)<=.5]
                if not options:return False
                h=min(options,key=lambda h:abs(h-last))
                if abs(h-y)>6 or not self.dry((qx,h,qz)):return False
                last=h
            samples.append((qx,last,qz))
        for qx,qy,qz in samples:
            for i in self.grid.get((math.floor(qx/64),math.floor(qz/64)),[]):
                ps,n,s,f=self.triangles[i]
                if not f&3 and segment_hit((qx,qy+1,qz),(qx,qy+above,qz),ps):return False
        return True


def select_spawns(nodes,edges,groups,query,count=32):
    sizes=Counter(groups)
    # Ordinary walk/jump/drop connectivity proves ability-independent return
    # to the village. High trees connected only by recovery links stay optional.
    eligible=defaultdict(list)
    for i,p in enumerate(nodes):
        if query.body_clear(p):eligible[groups[i]].append(i)
    main=max(eligible,key=lambda c:len(eligible[c])) if eligible else -1
    candidates=eligible.get(main,[])
    if len(candidates)<count:raise ValueError('Fewer than 32 dry clear spawns in one ordinary route SCC')
    center=min(candidates,key=lambda i:nodes[i][0]**2+nodes[i][2]**2+4*nodes[i][1]**2)
    chosen=[];next_id=center
    while len(chosen)<count:
        chosen.append(next_id)
        next_id=max((i for i in candidates if i not in chosen),key=lambda i:min(math.dist(nodes[i],nodes[j]) for j in chosen),default=None)
    return center,dict(count=count,component=main,component_nodes=sizes[main],eligible_candidates=len(candidates),
        minimum_separation=min(math.dist(nodes[i],nodes[j])for k,i in enumerate(chosen)for j in chosen[k+1:]),
        body_radius=16,vertical_clearance=40,radial_support_samples=64,
        slots=[dict(slot=k,node=i,position=nodes[i])for k,i in enumerate(chosen)])


def convert(directory,target,scale=SCALE,navigation=True):
    start=time.monotonic();target=private(target);target.mkdir(parents=True,exist_ok=True)
    objects=list(flatten(scene((directory/'map/scene.bin').read_bytes())))
    geometry=[];draws=[];textures=[];texkeys={};colliders=[];models=[];facegroups=[];groupcount=0
    identity=matrix((0,0,0),(0,0,0),(1,1,1))
    def model(path,mt,sky=False,water=False):
        nonlocal groupcount
        parsed=static_model(path.read_bytes())
        if parsed['unsupported']:raise ValueError('Unsupported Pianta actor geometry: '+path.name)
        cs,override=material_chunks(path,parsed['chunks']);mats=materials(cs);lookup=[]
        for mat in mats:
            texture=mat['texture'];state=dict(mat['state']);flags=mat['flags']|(2 if sky else 0)|(5 if water else 0)
            if water:state.update(cull=0,depth_write=0,blend_mode=1,blend_src=4,blend_dst=5)
            key=(texture['width'],texture['height'],texture['format'],texture['wrap_s'],texture['wrap_t'],hashlib.sha256(texture['data']).hexdigest(),flags,tuple(state[k]for k in MATERIAL_STATE))
            if key not in texkeys:texkeys[key]=len(textures);textures.append(dict(texture,state=state,flags=flags))
            lookup.append(texkeys[key])
        grouped=defaultdict(list)
        for material,tri in parsed['triangles']:
            out=[]
            for p,color,uv in tri:
                point=tuple(v*scale for v in transform(mt,p));rgba=tuple(round(color[i]*mats[material]['rgba'][i]/255)for i in range(4));out.append((point,rgba,uv))
            grouped[lookup[material]].append(out)
        first=len(geometry)
        for material,triangles in grouped.items():draws.append((material,len(geometry),len(triangles)));geometry.extend(triangles)
        assigned=mesh_groups(geometry[first:],whole=sky or path.stem!='map');facegroups.extend(groupcount+i for i in assigned)
        if assigned:groupcount+=max(assigned)+1
        models.append(dict(model=path.relative_to(directory).as_posix(),render_triangles=len(parsed['triangles']),material_override=override.relative_to(directory).as_posix()if override else None))
    def collider(path,mt):
        vertices,faces=collision(path.read_bytes());vertices=[tuple(v*scale for v in transform(mt,p))for p in vertices]
        for face in faces:
            s=face['surface'];base=s&0x3fff
            if base in PASS_THROUGH:continue
            ps=[vertices[i]for i in face['indices']];n=cross(*ps);length=math.sqrt(sum(v*v for v in n))
            if length<1e-8:continue
            f=(1 if s in WATER or base in WATER else 0)|(2 if base in(0x600,0x800)else 0)|(4 if base==6 else 0)
            colliders.append((ps,tuple(v/length for v in n),s,f))
    collider(directory/'map/map.col',identity)
    for p in sorted((directory/'map/map').glob('*.col')):collider(p,identity)
    # Source sky has depth testing disabled, so it must render first.
    for p in sorted((directory/'map/map').glob('*.bmd'),key=lambda p:(p.stem!='sky',p.name)):
        model(p,identity,sky=p.stem=='sky',water=p.stem in('monteriver','seaindirect'))
    actors=[]
    for obj in objects:
        if obj['klass'] not in ACTORS:continue
        name=ACTORS[obj['klass']];path=directory/f'mapobj/{name}.bmd'
        mt=matrix(obj['position'],[v*math.pi/180 for v in obj['rotation']],obj['scale'])
        model(path,mt);collider(path.with_suffix('.col'),mt)
        leaf_count={'palmsago':12,'bananatree':8}.get(name,0)
        if leaf_count:
            # TMapObjTree::initMapObj binds leaf i to joint leaf_count-i.
            # These are real donor collision banks, not leaf-sized boxes.
            joint_matrices=joints(static_model(path.read_bytes())['chunks'])[0]
            if len(joint_matrices)!=leaf_count+1:raise ValueError('Pianta tree joint contract changed')
            for i in range(leaf_count):
                collider(directory/f'mapobj/{name}leaf{i+1:02d}.col',multiply(mt,joint_matrices[leaf_count-i]))
        actors.append(dict(klass=obj['klass'],model=name,position=[v*scale for v in obj['position']],mode='Frozen original rest pose'))
    if sum(o['klass']=='HangingBridge'for o in objects)!=1:raise ValueError('Pianta bridge declaration changed')
    for x,y,z,rx in BRIDGE:
        mt=matrix((x,y,z),(math.radians(rx),0,0),(1,1,1));model(directory/'mapobj/mon_bri.bmd',mt);collider(directory/'mapobj/mon_bri.col',mt)
    colliders,physical=gameplay_collision(colliders)
    raw=bytearray(struct.pack('<4s4I',b'DLV1',2,len(textures),len(draws),len(geometry)))
    for t in textures:raw+=struct.pack('<7I',t['width'],t['height'],t['format'],t['wrap_s'],t['wrap_t'],t['flags'],len(t['data']))+struct.pack('<14I',*(t['state'][k]for k in MATERIAL_STATE))+t['data']
    raw+=b''.join(struct.pack('<3I',*d)for d in draws)
    raw+=b''.join(struct.pack('<3f4B2f',*p,*c,*uv)for tri in geometry for p,c,uv in tri)
    (target/'delfino.dlv').write_bytes(raw);write_collision(target/'delfino.dlc',colliders)
    (target/'delfino.dlg').write_bytes(struct.pack('<4s3I',b'DLG1',1,len(geometry),groupcount)+struct.pack('<'+str(len(facegroups))+'I',*facegroups))
    report=dict(version=VERSION,scene='monte7',name='Pianta Village',scale=scale,render_triangles=len(geometry),collision_triangles=len(colliders),textures=len(textures),draws=len(draws),
        actors=actors,bridge_boards=len(BRIDGE),models=models,physical=physical,water_triangles=sum(bool(t[3]&1)for t in colliders),
        source_sha256={p.relative_to(directory).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in(directory/'map/scene.bin',directory/'map/map.col',directory/'map/map/map.bmd')},
        converter_sha256=hashlib.sha256(source_file('sunshine_pianta_prototype.py').read_bytes()).hexdigest(),
        limitations=['Platform actors are static; no swaying/swinging or Sunshine fence-climbing mechanic',
          'Deep underside roots/fences below -85 are scenery, never navigation or spawn targets; native Pianta bottom KO is separately -220',
          'No extra custom bridge shortcuts; original 19-board hanging bridge restored from decomp positions',
          'Shared progressive goop initially uses the existing brown material; original Pianta fire goop particles remain a later presentation improvement',
          'Native 32-fighter route and complete-round acceptance pending'])
    if navigation:
        print('Building Pianta navigation',flush=True);nodes,edges,groups,nav=build(colliders,step=32)
        queries=Queries(colliders);center,spawns=select_spawns(nodes,edges,groups,queries)
        (target/'delfino.dln').write_bytes(encode(nodes,edges,groups,32));point=nodes[center]
        (target/'spawn-candidates.json').write_text(json.dumps(spawns,indent=2)+'\n');report.update(navigation=nav,spawn_candidates=spawns,spawn_center=point)
    else:point=(0,0,0)
    boundary=ledges(colliders)
    (target/'delfino.dls').write_bytes(struct.pack('<4sIf3fI',b'DLS1',2,scale,*point,len(boundary))+b''.join(struct.pack('<9f',*(v for p in line for v in p))for line in boundary))
    report.update(ledge_candidates=len(boundary),seconds=round(time.monotonic()-start,2),files={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in target.glob('delfino.*')})
    (target/'prototype-report.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--cache',type=Path,default=DEFAULT);parser.add_argument('--output',type=Path);parser.add_argument('--no-navigation',action='store_true');a=parser.parse_args()
    cache=private(a.cache);target=private(a.output or cache/'prototype-pianta-v1')
    if target.exists():raise ValueError('Use a fresh private target')
    result=convert(cache/'archives/monte7',target,navigation=not a.no_navigation)
    print(json.dumps({k:v for k,v in result.items()if k not in('models','actors','spawn_candidates')},indent=2))
if __name__=='__main__':main()
