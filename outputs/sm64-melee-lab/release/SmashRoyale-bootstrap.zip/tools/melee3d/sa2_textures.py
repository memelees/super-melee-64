"""Bounded PRS and native GameCube GVR archive reader.

GVR header/format layout follows X-Hax/sa_tools b72d52f, TextureLib/GVR.
Texture blocks retain their native GX tiling; no lossy re-encoding is needed.
"""
import struct


def prs(data, limit=32*1024*1024, header_only=False):
    pos=mask=bits=0
    out=bytearray()
    def byte():
        nonlocal pos
        if pos>=len(data): raise ValueError('truncated PRS stream')
        b=data[pos];pos+=1;return b
    def bit():
        nonlocal mask,bits
        if not mask: bits=byte();mask=1
        b=bool(bits&mask);mask=(mask<<1)&255;return b
    while True:
        if bit(): out.append(byte())
        else:
            if bit():
                word=byte()|(byte()<<8)
                if word==0:return bytes(out)
                offset=(word>>3)-8192
                length=(word&7)+2
                if length==2:length=byte()+1
            else:
                length=(int(bit())<<1)|int(bit());length+=2
                offset=byte()-256
            if not -len(out)<=offset<0: raise ValueError('invalid PRS back-reference')
            for _ in range(length):out.append(out[offset])
        if len(out)>limit:raise ValueError('PRS output exceeds limit')
        if header_only and len(out)>=4:
            if out[:4]!=b'GVMH':return b''
            if len(out)>=8 and len(out)>=8+struct.unpack_from('<I',out,4)[0]:return bytes(out)


def gvm_header(archive):
    if archive[:4]!=b'GVMH': raise ValueError('expected GVM archive')
    pos=8+struct.unpack_from('<I',archive,4)[0]
    flags,count=struct.unpack_from('>HH',archive,8)
    names=[];entry=12
    for i in range(count):
        index=struct.unpack_from('>H',archive,entry)[0];entry+=2
        if index!=i:raise ValueError('nonsequential GVM indices')
        name=None
        if flags&8:
            name=archive[entry:entry+28].split(b'\0')[0].decode('ascii');entry+=28
        if flags&4:entry+=2
        if flags&2:entry+=2
        if flags&1:entry+=4
        names.append(name)
    if entry>pos:raise ValueError('GVM entries exceed header')
    return names,pos


def textures(archive):
    """Read textures in archive order (the material's local texture index)."""
    names,pos=gvm_header(archive)
    count=len(names)
    result=[]
    while pos<len(archive):
        tag=archive[pos:pos+4]
        size=struct.unpack_from('<I',archive,pos+4)[0]
        if pos+8+size>len(archive):raise ValueError('truncated GVR chunk')
        if tag==b'GVRT':
            flags,fmt=archive[pos+10:pos+12]
            width,height=struct.unpack_from('>HH',archive,pos+12)
            if flags&10: raise ValueError('paletted GVR needs palette conversion')
            if fmt not in (0,1,2,3,4,5,6,14):raise ValueError('unsupported GVR format')
            if width<4 or height<4 or width>1024 or height>1024:raise ValueError('invalid GVR size')
            # Ignore optional mip levels: the base level is first, native GX.
            pixels=width*height
            length=pixels//2 if fmt in (0,14) else pixels*(4 if fmt==6 else 2 if fmt in (3,4,5) else 1)
            raw=archive[pos+16:pos+16+length]
            if len(raw)!=length or length>size-8:raise ValueError('truncated GVR texture')
            result.append(dict(name=names[len(result)],width=width,height=height,format=fmt,data=raw))
        elif tag not in (b'GCIX',b'GBIX'):raise ValueError(f'unknown GVM chunk {tag!r}')
        pos+=8+size
    if len(result)!=count: raise ValueError(f'GVM count mismatch: {len(result)} != {count}')
    return result


def decode_pixels(texture):
    """Inspection decoder for the native CMPR/RGB5A3 formats used here."""
    w,h,fmt,data=(texture[k] for k in ('width','height','format','data'))
    result=[None]*(w*h)
    if fmt==14:
        pos=0
        def rgb(n):return ((n>>11)*255//31,((n>>5)&63)*255//63,(n&31)*255//31,255)
        for by in range(0,h,8):
            for bx in range(0,w,8):
                for sy,sx in [(0,0),(0,4),(4,0),(4,4)]:
                    a,b,bits=struct.unpack_from('>HHI',data,pos);pos+=8
                    ca,cb=rgb(a),rgb(b)
                    palette=[ca,cb]
                    if a>b:palette += [tuple((ca[k]*2+cb[k])//3 for k in range(4)),tuple((ca[k]+cb[k]*2)//3 for k in range(4))]
                    else:palette += [tuple((ca[k]+cb[k])//2 for k in range(4)),(0,0,0,0)]
                    for y in range(4):
                        for x in range(4):
                            if by+sy+y<h and bx+sx+x<w:result[(by+sy+y)*w+bx+sx+x]=palette[(bits>>(30-2*(y*4+x)))&3]
    elif fmt==5:
        pos=0
        for by in range(0,h,4):
            for bx in range(0,w,4):
                for y in range(4):
                    for x in range(4):
                        n=struct.unpack_from('>H',data,pos)[0];pos+=2
                        color=(((n>>10)&31)*255//31,((n>>5)&31)*255//31,(n&31)*255//31,255) if n&32768 else (((n>>8)&15)*17,((n>>4)&15)*17,(n&15)*17,((n>>12)&7)*255//7)
                        if bx+x<w and by+y<h:result[(by+y)*w+bx+x]=color
    else:raise ValueError('inspection pixel decoder not implemented for this GX format')
    return result
