"""Derive playable Castle grounds from the user's original Melee archive.

Retains native HSD rendering, texture data, UVs, scene joints and callbacks.
Only missing rear masonry is added, using existing brick/cornice materials.
All donor and generated binary bytes stay in the user's private stage cache.
"""
import argparse, collections, hashlib, json, math, struct
from pathlib import Path
from native_roster import Archive
from peach_castle_source import triangles,normal
from sunshine_scene import Reader
from sunshine_navigation import build as navigation, encode, segment_hit
from native_onett_overlay import simplify_coplanar
from player_paths import source_file

VERSION=4
STAGE=4


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def rear_geometry(a,rows):
    """Close the measured central rear opening, beneath its original roof edge.

    The donor supplies both the bounds and texture density: no rear billboard,
    culling override or untextured box is used. Existing towers already have
    full circular meshes and are preserved without duplication.
    """
    wall=[t for t in rows if t['joint']==0x2ee08 and t['symbols']==['GrdCastleWall1_CMPR_image']]
    trim=[t for t in rows if t['joint']==0x2ee08 and t['symbols']==['GrdCastleWall2_CMPR_image']]
    if not wall or not trim:raise ValueError('Unsupported Castle donor masonry layout')
    # Main back roof's exact unpaired edge: broad central cavity between towers.
    edges=collections.Counter()
    for t in rows:
        if t['joint']!=0x2ee08 or not any('Wall' in s or 'Roof' in s for s in t['symbols']):continue
        ps=[tuple(round(v,3)for v in p)for p in t['points']]
        for u,v in zip(ps,ps[1:]+ps[:1]):edges[tuple(sorted((u,v)))]+=1
    candidates=[e for e,n in edges.items()if n==1 and abs(e[0][2]-e[1][2])<.001 and abs(e[0][1]-e[1][1])<.001 and e[1][0]-e[0][0]>100 and e[0][2]<-40]
    if len(candidates)!=1:raise ValueError('Missing or ambiguous source rear roof edge')
    top=candidates[0];x0,x1=top[0][0],top[1][0];z=top[0][2];ytop=top[0][1]
    lower=min(p[1]for t in wall for p in t['points']);split=max(p[1]for t in wall for p in t['points'])
    if not (100<x1-x0<150 and 0<=lower<1 and 60<split<ytop<70):raise ValueError('Unexpected measured Castle rear dimensions')
    result=[]
    for label,y0,y1,donors in [('rear-brick',lower,split,wall),('rear-cornice',split,ytop,trim)]:
        donor=max((t for t in donors if abs(t['normal'][2])>.99),key=lambda t:abs(t['points'][1][0]-t['points'][0][0])+abs(t['points'][2][0]-t['points'][0][0]))
        # Fit original S/T as affine functions in the source facade's X/Y.
        p,q,s=donor['vertices'];det=(q[0]-p[0])*(s[1]-p[1])-(s[0]-p[0])*(q[1]-p[1])
        if abs(det)<1e-6:raise ValueError('Degenerate Castle UV donor')
        def uv(x,y):
            u=((x-p[0])*(s[1]-p[1])-(s[0]-p[0])*(y-p[1]))/det
            v=((q[0]-p[0])*(y-p[1])-(x-p[0])*(q[1]-p[1]))/det
            return [p[k]+u*(q[k]-p[k])+v*(s[k]-p[k])for k in (3,4)]
        # Original GX convention is clockwise; actual physical outward -Z.
        ps=[(x0,y0,z),(x1,y0,z),(x1,y1,z),(x0,y1,z)]
        for ids in ((0,1,2),(0,2,3)):
            vs=[[*ps[i],*uv(ps[i][0],ps[i][1]),*donor['vertices'][0][5:9]]for i in ids]
            result.append(dict(vertices=vs,points=[v[:3]for v in vs],normal=(0,0,1),group=3,joint=-1,dobj=donor['dobj'],material=donor['material'],symbols=donor['symbols'],feature=label))
    return result,dict(measured_opening=dict(x=[x0,x1],y=[lower,ytop],z=z),faces=len(result),materials=['GrdCastleWall1_CMPR_image','GrdCastleWall2_CMPR_image'],uv_method='Original facade affine texture density and vertex colour; original material reused')


def patch_archive(a,faces,scenery=None):
    """Append one normal HSD joint with native textured triangle display lists."""
    r=Reader(a.payload);data=bytearray(a.payload);nr=struct.unpack_from('>I',a.data,8)[0]
    relocs=set(struct.unpack_from('>'+str(nr)+'I',a.data,32+a.size))
    def alloc(blob):
        data.extend(bytes((-len(data))%4));p=len(data);data.extend(blob);return p
    def ptr(at,value):
        struct.pack_into('>I',data,at,value)
        if value:relocs.add(at)
        else:relocs.discard(at)
    ds=[];scale=r.get('f',a.public['grGroundParam'])[0]
    for material,items in __import__('itertools').groupby(sorted(faces,key=lambda t:t['material']),key=lambda t:t['material']):
        items=list(items);vs=[v for t in items for v in t['vertices']]
        pos=alloc(b''.join(struct.pack('>3f',*(v[k]/scale for k in range(3)))for v in vs));uv=alloc(b''.join(struct.pack('>2f',*v[3:5])for v in vs));decl=alloc(bytes(96))
        for i,(attr,typ,cnt,ctype,stride,start)in enumerate([(9,3,1,4,12,pos),(11,1,1,5,4,0),(13,3,1,4,8,uv)]):
            struct.pack_into('>4IBxHI',data,decl+i*24,attr,typ,cnt,ctype,0,stride,start)
            if start:relocs.add(decl+i*24+20)
        struct.pack_into('>I',data,decl+72,255);cmd=bytearray(b'\x90'+struct.pack('>H',len(vs)))
        for i,v in enumerate(vs):cmd.extend(struct.pack('>H4BH',i,*(max(0,min(255,round(c)))for c in v[5:9]),i))
        cmd.extend(bytes((-len(cmd))%32));display=alloc(cmd);source=items[0]['dobj'];po=r.u32(source+12);newpo=alloc(a.payload[po:po+24])
        for offset in (0,):
            value=r.u32(po+offset)
            if value:ptr(newpo+offset,value)
        ptr(newpo+4,0);ptr(newpo+8,decl);ptr(newpo+16,display);ptr(newpo+20,0)
        struct.pack_into('>H',data,newpo+14,len(cmd)//32)
        dobj=alloc(a.payload[source:source+16]);ptr(dobj,0);ptr(dobj+4,0);ptr(dobj+8,material);ptr(dobj+12,newpo);ds.append(dobj)
    for i,dobj in enumerate(ds):ptr(dobj+4,ds[i+1]if i+1<len(ds)else 0)
    joint=alloc(bytes(64));struct.pack_into('>I',data,joint+4,0x70140008);ptr(joint+16,ds[0]);struct.pack_into('>3f',data,joint+32,1,1,1)
    root=r.u32(r.u32(a.public['map_head']+8)+3*52);last=r.u32(root+8)
    while r.u32(last+12):last=r.u32(last+12)
    ptr(last+12,joint)
    # Add shoreline PObjs to the original grass/rock DObjs, keeping their
    # loaded material instances, texture density and both texture channels.
    if scenery:
        for source,items in scenery['additions'].items():
            vs=[v for t in items for v in t['vertices']]
            if len(vs)>65535:raise ValueError('Castle extension GX indexed16 capacity')
            pos=alloc(b''.join(struct.pack('>3f',*(v[k]/scale for k in range(3)))for v in vs));uv=alloc(b''.join(struct.pack('>2f',*v[3:5])for v in vs));decl=alloc(bytes(120))
            for i,(attr,typ,cnt,ctype,stride,start)in enumerate([(9,3,1,4,12,pos),(11,1,1,5,4,0),(13,3,1,4,8,uv),(14,3,1,4,8,uv)]):
                struct.pack_into('>4IBxHI',data,decl+i*24,attr,typ,cnt,ctype,0,stride,start)
                if start:relocs.add(decl+i*24+20)
            struct.pack_into('>I',data,decl+96,255);cmd=bytearray(b'\x90'+struct.pack('>H',len(vs)))
            for i,v in enumerate(vs):cmd.extend(struct.pack('>H4BHH',i,*(max(0,min(255,round(c)))for c in v[5:9]),i,i))
            cmd.extend(bytes((-len(cmd))%32));display=alloc(cmd);po=r.u32(source+12);newpo=alloc(a.payload[po:po+24])
            ptr(newpo,0);ptr(newpo+4,0);ptr(newpo+8,decl);ptr(newpo+16,display);ptr(newpo+20,0)
            struct.pack_into('>H',data,newpo+14,len(cmd)//32)
            if source in scenery.get('replace_sky_dobjs',set()):ptr(source+12,newpo)
            else:
                lastpo=po
                while r.u32(lastpo+4):lastpo=r.u32(lastpo+4)
                ptr(lastpo+4,newpo)
    rel=sorted(relocs);tail=a.data[32+a.size+nr*4:];header=bytearray(a.data[:32]);struct.pack_into('>3I',header,0,32+len(data)+len(rel)*4+len(tail),len(data),len(rel))
    return bytes(header)+data+struct.pack('>'+str(len(rel))+'I',*rel)+tail,joint


def clip_above(points,level):
    """Keep the actual dry part of a source triangle; never floor the moat."""
    result=[];previous=points[-1];a=previous[1]-level
    for p in points:
        b=p[1]-level
        if (a>=0)!=(b>=0):
            t=a/(a-b);result.append(tuple(previous[k]+(p[k]-previous[k])*t for k in range(3)))
        if b>=0:result.append(tuple(p))
        previous,a=p,b
    return result


def collision(rows,repairs):
    colliders=[];sources=[];seen=set();skipped=collections.Counter()
    water=[t for t in rows if 'GrdCastleWater1na_RGB565_image'in t['symbols']]
    water_level=max(p[1]for t in water for p in t['points'])+.06
    for t in [*rows,*repairs]:
        symbols=' '.join(t['symbols'])
        if any(k in symbols for k in ('Sky','Water','Mtwtr','Gdntr','Gdnfrw','Gdnrail','Pole','Wmk','stain')):
            skipped['nonstructural']+=1;continue
        # Backdrop mountains remain scenic. Retain Castle mass, front garden
        # and its shore. The distant forest is intentionally not a new map.
        if t['group']!=3 and not t.get('extension_solid'):skipped['backdrop']+=1;continue
        if not t.get('extension_solid')and any(abs(p[0])>450 or p[2]<-270 or p[2]>390 for p in t['points']):skipped['remote_terrain']+=1;continue
        ps=list(reversed(t['points']));n=normal(ps)
        if n is None:continue
        if n[1]>=.64:
            poly=clip_above(ps,water_level)
            candidates=[[poly[0],poly[i],poly[i+1]]for i in range(1,len(poly)-1)]
            if not candidates:skipped['submerged_floor']+=1
        else:candidates=[ps]
        for ps in candidates:
            n=normal(ps)
            if n is None:continue
            key=(tuple(sorted(tuple(round(v,4)for v in p)for p in ps)),tuple(round(v,4)for v in n))
            if key in seen:skipped['duplicate']+=1;continue
            seen.add(key);colliders.append((ps,n,0,0));sources.append(dict(group=t['group'],joint=hex(t['joint'])if t['joint']>=0 else'authored-rear',dobj=hex(t['dobj']),symbols=t['symbols'],feature=t.get('feature','original-source')))
    colliders,sources,simplification=simplify_coplanar(colliders,sources)
    return colliders,sources,dict(skipped=dict(skipped),water_level=water_level,water_triangles=len(water),simplification=simplification)


def build(source,output,step=16.):
    source=Path(source);output=Path(output)
    if output.exists():raise ValueError('Choose a fresh output directory')
    a=Archive(source);rows=triangles(a);faces,repair=rear_geometry(a,rows)
    from peach_castle_shoreline import scenery as shoreline_scenery
    scenery=shoreline_scenery(rows)
    from peach_castle_horizon import extend
    scenery=extend(rows,scenery);raw,joint=patch_archive(a,faces,scenery)
    colliders,provenance,physics=collision(rows,[*faces,*scenery['land']])
    counts=collections.Counter('floor'if n[1]>=.64 else'ceiling'if n[1]<=-.64 else'wall'for ps,n,_,_ in colliders)
    native_lines=51+counts['floor']+counts['ceiling']+counts['wall']*2
    if native_lines>16380:raise ValueError('Castle native collision budget exceeded')
    lo=[min(p[k]for ps,n,_,_ in colliders for p in ps)for k in range(3)];hi=[max(p[k]for ps,n,_,_ in colliders for p in ps)for k in range(3)]
    print(json.dumps(dict(stage=STAGE,triangles=len(colliders),native_lines=native_lines,bounds=[lo,hi])),flush=True)
    nodes,edges,groups,nav=navigation(colliders,step=step,radius=5.)
    if len(nodes)<32:raise ValueError('Castle lacks32 grounded route nodes')
    output.mkdir(parents=True);art=output/'art';overlay=output/'overlay';art.mkdir();overlay.mkdir()
    (art/'GrCs.dat').write_bytes(raw);identity=digest(art/'GrCs.dat')
    # Assert serialised authored art actually decodes into exactly the same
    # world-space faces used by the physics bank, with original texture names.
    actual=[t for t in triangles(Archive(art/'GrCs.dat'),(3,))if t['joint']==joint]
    if len(actual)!=len(faces)or any(math.dist(v,w)>1e-4 for t,u in zip(sorted(actual,key=lambda t:t['material']),sorted(faces,key=lambda t:t['material']))for v,w in zip(t['points'],u['points'])):raise ValueError('Castle render/physics rear repair mismatch')
    (overlay/'castle.ovl').write_bytes(struct.pack('<4s2I6f',b'OVL1',1,len(colliders),*lo,*hi)+b''.join(struct.pack('<12f',*(v for p in ps for v in p),*n)for ps,n,_,_ in colliders))
    (overlay/'delfino.dln').write_bytes(encode(nodes,edges,groups,step))
    # Original water geometry is private metadata for splash/fall-through
    # acceptance. It never joins OVL solid floors or CPU spawn candidates.
    water=scenery['water_contacts']
    (overlay/'castle.wtr').write_bytes(struct.pack('<4s2I',b'CWT1',1,len(water))+b''.join(struct.pack('<9f',*(v for p in t['points']for v in p))for t in water))
    tool_names=('build_peach_castle.py','peach_castle_source.py','peach_castle_shoreline.py','peach_castle_horizon.py','sunshine_navigation.py','native_onett_overlay.py','native_reference.py','sunshine_scene.py')
    report=dict(schema_version=1,compiler_version=VERSION,stage=STAGE,source_sha256=digest(source),archive_sha256=identity,original_lines=51,original_joints=15,native_total_lines=native_lines,native_bounds=[lo,hi],collision_triangles=len(colliders),counts=dict(counts),navigation=nav,physics=physics,shoreline=scenery['report'],rear_repair=dict(repair,render_joint=hex(joint),render_physics_equivalent=True),files={p.name:digest(p)for p in overlay.iterdir()},tools={n:digest(source_file(n))for n in tool_names},limitations=['Native render,32-fighterplay and CPU route acceptance require a live check; compilation alone is not gameplay acceptance','Original Castle hazards and moving platforms must be disabled for this static structural conversion','Distant forest/sky remain scenic; moat water falls through to the normal low blast zone; no swimming animation is invented','Dense decorative trim remains nonphysical; structural roof/wall/courtyard source mesh is solid'])
    (art/'report.json').write_text(json.dumps(dict(output_sha256=identity,source_sha256=digest(source),stage=STAGE,rear_repair=report['rear_repair'],shoreline=scenery['report']),indent=2)+'\n')
    (overlay/'overlay-report.json').write_text(json.dumps(report,indent=2)+'\n')
    (overlay/'source-provenance.json').write_text(json.dumps(provenance,separators=(',',':'))+'\n')
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path);p.add_argument('output',type=Path);p.add_argument('--step',type=float,default=16.);a=p.parse_args();print(json.dumps(build(a.source,a.output,a.step),indent=2))
if __name__=='__main__':main()
