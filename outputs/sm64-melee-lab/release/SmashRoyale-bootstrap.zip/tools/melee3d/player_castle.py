"""Verified local Melee Castle conversion and incremental stage-file mounting."""
import hashlib,json,os,shutil,tempfile
from pathlib import Path
from player_paths import source_file


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_castle(art,overlay):
    art=Path(art);overlay=Path(overlay);report=json.loads((overlay/'overlay-report.json').read_text())
    if report.get('stage')!=4 or report.get('archive_sha256')!=digest(art/'GrCs.dat'):raise ValueError('Castle donor/art identity mismatch')
    for name in ('castle.ovl','delfino.dln','castle.wtr'):
        if report.get('files',{}).get(name)!=digest(overlay/name):raise ValueError('Castle private bank identity mismatch: '+name)
    if report.get('native_total_lines',16381)>16380 or report.get('navigation',{}).get('nodes',0)<32:raise ValueError('Castle bank capacity/navigation contract invalid')
    return report


def bank(installation):
    from build_peach_castle import VERSION,build
    installation=Path(installation);source=installation/'akaneia/files/GrCs.dat'
    if not source.is_file():return None
    tools=('build_peach_castle.py','peach_castle_source.py','peach_castle_shoreline.py','peach_castle_horizon.py','sunshine_navigation.py','native_onett_overlay.py','native_reference.py','sunshine_scene.py')
    identity=hashlib.sha256(json.dumps(dict(source=digest(source),version=VERSION,tools={n:digest(source_file(n))for n in tools}),sort_keys=True).encode()).hexdigest()[:24]
    cache=installation.parent/'stages/peach-castle';cache.mkdir(parents=True,exist_ok=True);target=cache/identity
    if target.is_dir():verify_castle(target/'art',target/'overlay');return target
    with tempfile.TemporaryDirectory(prefix='.castle-',dir=cache)as temporary:
        output=Path(temporary)/'bank';build(source,output)
        verify_castle(output/'art',output/'overlay')
        try:output.rename(target)
        except OSError:
            if not target.is_dir():raise
            verify_castle(target/'art',target/'overlay')
    return target


def configure(installation,metadata,profile,env):
    from player_stage_preview import native_menu_assets
    native_menu_assets(installation,metadata)
    target=bank(installation)
    if target is None:return
    report=verify_castle(target/'art',target/'overlay');directory=Path(profile)/'stage-files';directory.mkdir(exist_ok=True)
    # Reuse Onett's mounted directory if present. Never erase another map's
    # replacement archives or profile controls while adding Castle.
    imported=Path(installation)/'akaneia/files'
    for source in imported.rglob('*'):
        if not source.is_file()or source.name in('GrCs.dat','GrCs.usd'):continue
        dest=directory/source.relative_to(imported)
        if dest.is_file():continue
        dest.parent.mkdir(parents=True,exist_ok=True)
        try:os.link(source,dest)
        except OSError:shutil.copy2(source,dest)
    for name in('GrCs.dat','GrCs.usd'):
        dest=directory/name
        if dest.is_file()and digest(dest)==report['archive_sha256']:continue
        dest.unlink(missing_ok=True);shutil.copy2(target/'art/GrCs.dat',dest)
    from player_stage_preview import preview
    env.update(MELEE_FILES_DIR=str(directory),MELEE3D_NATIVE_CASTLE_OVERLAY=str((target/'overlay').resolve()),MELEE3D_NATIVE_CASTLE_PREVIEW=str(preview(Path(installation).parent/'ui-cache',stage='castle')))
