"""Build the goop art bank from the player's already imported Sunshine files.

Original GX texture blocks stay local. No Nintendo texture data is shipped.
"""
import hashlib,struct,os,tempfile,math
from pathlib import Path
from sunshine_scene import Reader,chunks,strings

VERSION=5
LAYOUT={0:(8,8,4),1:(8,4,8),2:(8,4,8),3:(4,4,16),4:(4,4,16),5:(4,4,16),6:(4,4,32),14:(8,8,4)}

def texture(data,offset=0,*,mips=False):
 r=Reader(data);fmt,_,w,h,ws,wt=r.get('2B2H2B',offset)
 if fmt not in LAYOUT or not 1<=w<=1024 or not 1<=h<=1024 or ws>2 or wt>2:raise ValueError('Invalid goop texture')
 tw,th,bits=LAYOUT[fmt];levels=max(1,data[offset+24]) if mips else 1
 if levels>1+int(math.log2(max(w,h))):raise ValueError('Invalid goop mip count')
 size=sum(((max(1,w>>i)+tw-1)//tw)*((max(1,h>>i)+th-1)//th)*tw*th*bits//8 for i in range(levels))
 start=offset+r.u32(offset+28)
 if start<offset+32 or start+size>len(data):raise ValueError('Truncated goop texture')
 return struct.pack('<6I',w,h,fmt,ws,wt,size)+data[start:start+size]

def particle_chunks(data):
 if data[:8]!=b'JEFFjpa1' or len(data)<32:raise ValueError('Invalid Sunshine particle')
 pos=32;result=[]
 while pos<len(data):
  if pos+8>len(data):raise ValueError('Truncated Sunshine particle')
  size=struct.unpack_from('>I',data,pos+4)[0]
  if size<8 or pos+size>len(data):raise ValueError('Invalid Sunshine particle chunk')
  result.append((data[pos:pos+4],data[pos:pos+size]));pos+=size
 return result

def ripple(data):
 """Sunshine's sink-in-pollution ripple: original mask, displacement and curves.

 The black P_ms_fb placeholder is replaced by a live framebuffer in Sunshine;
 the native adapter does the same rather than drawing a ring approximation.
 Offsets follow sms JPAEmitter/BaseShape/ExtraShape/ExTexShape readers.
 """
 parts=particle_chunks(data);blocks=dict(parts)
 tex=[b for tag,b in parts if tag==b'TEX1']
 if len(tex)!=3 or len(blocks.get(b'ESP1',b''))<0x65 or len(blocks.get(b'BSP1',b''))<0x98 or len(blocks.get(b'BEM1',b''))<0x42 or len(blocks.get(b'ETX1',b''))<0x34:raise ValueError('Incomplete Sunshine goop ripple')
 base,extra,emitter,ind=(blocks[k] for k in (b'BSP1',b'ESP1',b'BEM1',b'ETX1'))
 def fix(o):
  v=struct.unpack_from('>h',extra,o)[0]
  return 1. if v==32767 else round(v/32768,4)
 life=struct.unpack_from('>h',emitter,0x40)[0]
 if not 1<=life<=240 or base[0x30]!=1 or ind[0x10:0x12]!=bytes((1,1)) or ind[0x1f]!=2 or ind[0x30]!=1 or ind[0x33]!=1:raise ValueError('Unsupported Sunshine goop ripple profile')
 profile=[life,*struct.unpack_from('>2f',base,0x18),*[fix(o) for o in (0x14,0x16,0x18,0x1a,0x1c,0x36,0x38)],fix(0x44)*10,fix(0x3a)*10,fix(0x48)*10,fix(0x3e)*10]
 if not all(math.isfinite(v) for v in profile):raise ValueError('Invalid Sunshine ripple curve')
 matrix=[(1 if v==32767 else round(v/32768,4)) for v in struct.unpack_from('>6h',ind,0x12)]
 profile+=matrix+[struct.unpack_from('>b',ind,0x1e)[0]]
 return texture(tex[1],32)+texture(tex[2],32),struct.pack('<21f4B',*profile,*base[0x64:0x68])

def water_animation(data):
 """Bake Bianco's two looping BTK transforms using J3D Hermite keys.

 The frame table stays private with the texture bank. No animation source or
 donor asset bytes are placed in a public release.
 """
 if data[:8]!=b'J3D1btk1' or len(data)<128 or struct.unpack_from('>I',data,8)[0]!=len(data):raise ValueError('Invalid Sunshine water animation')
 r=Reader(data[32:])
 if r.data[:4]!=b'TTK1' or r.u32(4)!=len(r.data):raise ValueError('Invalid water animation block')
 loop,shift,frames,tracks,ns,nr,nt=r.get('2B5H',8)
 if loop!=2 or shift>15 or not 1<=frames<=4096 or tracks!=6:raise ValueError('Unsupported water animation')
 scale=r.get(str(ns)+'f',r.u32(0x28));rot=r.get(str(nr)+'h',r.u32(0x2c));trans=r.get(str(nt)+'f',r.u32(0x30))
 table=[r.get('9H',r.u32(0x14)+i*18) for i in range(6)]
 centers=r.get('6f',r.u32(0x24))
 def value(track,channel,values,t,default):
  count,index,kind=table[track][channel*3:channel*3+3]
  if count==0:return default
  if index>=len(values) or kind not in (0,1):raise ValueError('Invalid water key')
  if count==1:return values[index]
  stride=3+kind
  if index+count*stride>len(values):raise ValueError('Truncated water keys')
  keys=[values[index+i*stride:index+(i+1)*stride] for i in range(count)]
  if any(b[0]<=a[0] for a,b in zip(keys,keys[1:])):raise ValueError('Unordered water keys')
  if t<=keys[0][0]:return keys[0][1]
  if t>=keys[-1][0]:return keys[-1][1]
  for a,b in zip(keys,keys[1:]):
   if t>b[0]:continue
   span=b[0]-a[0];u=(t-a[0])/span
   return (2*u**3-3*u**2+1)*a[1]+(u**3-2*u**2+u)*span*a[-1]+(-2*u**3+3*u**2)*b[1]+(u**3-u**2)*span*b[2]
 matrices=[]
 for frame in range(frames):
  for i in range(2):
   sx=value(i*3,0,scale,frame,1);sy=value(i*3+1,0,scale,frame,1)
   angle=int(value(i*3+2,1,rot,frame,0))*(1<<shift)*math.pi/32768
   tx=value(i*3,2,trans,frame,0);ty=value(i*3+1,2,trans,frame,0);cx,cy=centers[i*3:i*3+2]
   a=sx*math.cos(angle);b=-sx*math.sin(angle);c=sy*math.sin(angle);d=sy*math.cos(angle)
   matrices.extend((a,b,cx-a*cx-b*cy+tx,c,d,cy-c*cx-d*cy+ty))
 if not all(math.isfinite(v) and abs(v)<1000 for v in matrices):raise ValueError('Invalid water transform')
 return struct.pack('<I',frames)+struct.pack('<'+str(len(matrices))+'f',*matrices)

def bank(installation):
 root=Path(installation)/'sunshine/archives'
 model=(root/'dolpic1/map/pollution/pollution00.bmd').read_bytes()
 foot=(root/'dolpic1/map/pollution/ms_m_ashios.jpa').read_bytes()
 # The material uses a coverage map, B_RAK_choco2 and an indirect glint map.
 t=Reader(chunks(model)['TEX1']);names=strings(t.data,t.u32(16))
 i=names.index('B_RAK_choco2');paint=texture(t.data,t.u32(12)+i*32,mips=True)
 i=names.index('B_ind_metal');flow=texture(t.data,t.u32(12)+i*32,mips=True)
 # JEFF's TEX1 chunk has a 0x20-byte header, then an ordinary ResTIMG.
 pos=32;footprint=None
 while pos<len(foot):
  if pos+8>len(foot):raise ValueError('Truncated goop particle')
  tag,size=foot[pos:pos+4],struct.unpack_from('>I',foot,pos+4)[0]
  if size<8 or pos+size>len(foot):raise ValueError('Invalid goop particle chunk')
  if tag==b'TEX1' and b'footmark' in foot[pos+8:pos+32]:footprint=texture(foot[pos:pos+size],32);break
  pos+=size
 if footprint is None:raise ValueError('Sunshine muddy footprint is missing')
 # Sunshine uses H_ma_rak for Mario's visible body coating. Preserve its
 # RGB and build eight increasing alpha masks for Melee's existing UVs.
 from sa2_textures import decode_pixels
 body=(root/'dolpic1/map/pollution/h_ma_rak.bti').read_bytes();raw=texture(body)
 w,h,fmt,ws,wt,size=struct.unpack_from('<6I',raw)
 pixels=decode_pixels(dict(width=w,height=h,format=fmt,data=raw[24:]));layers=[]
 for level in range(1,9):
  tiled=bytearray(w*h*4)
  for y in range(h):
   for x in range(w):
    r,g,b,a=pixels[y*w+x];brightness=(r+g+b)/(3*255)
    rank=.48+.31*math.sin(x*.061+math.sin(y*.08))+.15*math.cos(y*.079+math.sin(x*.07))+.05*brightness
    alpha=round(190*max(0,min(1,(level/8-rank)*9)))
    tile=((y//4)*(w//4)+x//4)*64;pixel=((y%4)*4+x%4)*2
    tiled[tile+pixel:tile+pixel+2]=bytes((alpha,r));tiled[tile+32+pixel:tile+34+pixel]=bytes((g,b))
  layers.append(struct.pack('<6I',w,h,6,0,0,len(tiled))+tiled)
 ripple_path=root/'particle/ms_mari_rakuhamon.jpa'
 if not ripple_path.is_file():raise ValueError('Sunshine ripple files need a one-time game-file reimport with your Sunshine image.')
 ripple_art,profile=ripple(ripple_path.read_bytes())
 lake=root/'bianco6/map/map'
 if not (lake/'biawaetrpollution.btk').is_file():raise ValueError('Sunshine polluted-water files need a one-time game-file reimport with your Sunshine image.')
 lt=Reader(chunks((lake/'biawaterpollution.bmd').read_bytes())['TEX1']);ln=strings(lt.data,lt.u32(16))
 if texture(lt.data,lt.u32(12)+ln.index('B_RAK_choco2')*32,mips=True)!=paint or texture(lt.data,lt.u32(12)+ln.index('B_ind_metal')*32,mips=True)!=flow:raise ValueError('Sunshine land/lake texture identity mismatch')
 water=water_animation((lake/'biawaetrpollution.btk').read_bytes())
 data=struct.pack('<4sII',b'GPV1',VERSION,13)+paint+footprint+b''.join(layers)+flow+ripple_art+profile+water
 identity=hashlib.sha256(data).hexdigest();cache=Path(installation).parent/'effect-cache';cache.mkdir(parents=True,exist_ok=True)
 target=cache/('goop-'+identity+'.bin')
 if target.is_file() and target.read_bytes()==data:return target
 with tempfile.NamedTemporaryFile(dir=cache,delete=False) as f:
  temporary=Path(f.name);f.write(data)
 try:os.replace(temporary,target)
 finally:temporary.unlink(missing_ok=True)
 return target

def configure(installation,env):env['MELEE3D_NATIVE_GOOP_ART']=str(bank(installation))
