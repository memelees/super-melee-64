#!/usr/bin/env python3
"""Build an opt-in native Delfino geometry preview from the owner's cache.

Static single-texture preview only. Original J3D files are retained separately;
this output does not certify TEV, animated materials, lighting or audio parity.
"""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import struct
from sunshine_extract import CACHE
from player_paths import source_file
from sunshine_scene import Reader, bounds, chunks, collision, flatten, matrix, scene, static_model, strings, transform


def ledges(colliders):
    """Walkable boundary edges with a character-height drop; no internal seams."""
    floor=[t for t in colliders if not t[3]&3 and t[1][1]>=math.cos(math.radians(50))]
    grid={};edges={}
    for points,n,surface,flags in floor:
        xs=[p[0] for p in points];zs=[p[2] for p in points]
        for x in range(math.floor(min(xs)/64),math.floor(max(xs)/64)+1):
            for z in range(math.floor(min(zs)/64),math.floor(max(zs)/64)+1):grid.setdefault((x,z),[]).append((points,n))
        for a,b in zip(points,points[1:]+points[:1]):
            key=tuple(sorted(tuple(round(v,3) for v in p) for p in (a,b)))
            edges.setdefault(key,[]).append((a,b,flags))
    def ground(x,z,y):
        best=-1e20
        for ps,n in grid.get((math.floor(x/64),math.floor(z/64)),[]):
            sign=0;inside=True
            for a,b in zip(ps,ps[1:]+ps[:1]):
                d=(b[0]-a[0])*(z-a[2])-(b[2]-a[2])*(x-a[0])
                if abs(d)<1e-5:continue
                if sign*d<0:inside=False;break
                sign=d
            if not inside:continue
            h=ps[0][1]-(n[0]*(x-ps[0][0])+n[2]*(z-ps[0][2]))/n[1]
            if h<=y+.1:best=max(best,h)
        return best
    result=[]
    for owners in edges.values():
        if len(owners)!=1:continue
        a,b,flags=owners[0]
        if flags&4:continue
        dx,dz=b[0]-a[0],b[2]-a[2];length=math.hypot(dx,dz)
        if length<2:continue
        inward=(dz/length,0,-dx/length)
        x,y,z=[(a[i]+b[i])/2 for i in range(3)]
        if ground(x-inward[0]*1.5,z-inward[2]*1.5,y)>y-12:continue
        result.append((a,b,inward))
    return result

PRESENTATION_VERSION=5
COLLISION_VERSION=3


def unique_collision(colliders):
    """Drop exact repeated surfaces, retaining winding and material semantics."""
    result=[];seen=set()
    for points,normal,surface,flags in colliders:
        key=(tuple(sorted(tuple(p) for p in points)),tuple(normal),surface,flags)
        if key in seen:continue
        seen.add(key);result.append((points,normal,surface,flags))
    return result

WATER={0x100,0x101,0x102,0x103,0x104,0x105,0x4104}
PASS_THROUGH={0x200,0x201,0x202,0x203,0x400,0x801}
# Explicit physical scenery policy. Never silently treat every LiveActor as a
# prop: NPCs/fruit/coins/triggers all have the same transform prefix.
PROP_CLASSES={'MapStaticObj','Manhole','Palm','WoodBox','JellyGate','Billboard',
              'MonumentShine','BellDolpicTV','BellDolpicPolice','DolWeathercock',
              'DptMonteFence','TurboNozzleDoor','FruitsBoat'}
ALIASES={'Palm':'palmnormal','WoodBox':'kibako','FruitsBoat':'shipdolpic',
         'Billboard':'billboardsun','TurboNozzleDoor':'nozzledoor'}


def prop_model_candidates(obj):
    """Honor the scene's model name before class fallbacks (Palm includes leaves)."""
    name=obj['model'];alias=ALIASES.get(obj['klass'],name)
    candidates=[f'mapobj/{name}.bmd',f'map/map/{name}.bmd',f'{name}/{name}.bmd']
    if obj['klass']=='FruitsBoat':candidates.insert(0,'fruitsboat/shipdolpic.bmd')
    if alias.lower()!=name.lower():candidates.extend((f'mapobj/{alias}.bmd',f'{alias}/{alias}.bmd'))
    return candidates


MATERIAL_STATE=('cull','depth_test','depth_func','depth_write','blend_mode','blend_src','blend_dst','blend_logic','alpha_comp0','alpha_ref0','alpha_op','alpha_comp1','alpha_ref1','z_comp_loc')


def material_state(m,o):
    """J3D MAT3 raster state; offsets verified against the cached J3D loader.

    Preserve coplanar decal depth tests/writes instead of assigning every
    surface the same opaque LEQUAL pass. TEV animation remains separate.
    """
    cull=m.u32(m.u32(0x1c)+m.data[o+1]*4)
    z=m.u32(0x74)+m.data[o+6]*4;depth_test,depth_func,depth_write=m.get('3B',z)
    b=m.u32(0x70)+m.u16(o+0x148)*4;blend=m.get('4B',b)
    a=m.u32(0x6c)+m.u16(o+0x146)*8;alpha=m.get('5B',a)
    zloc=m.data[m.u32(0x78)+m.data[o+5]]
    values=(cull,depth_test,depth_func,depth_write,*blend,*alpha,zloc)
    limits=(3,1,7,1,3,7,7,15,7,255,3,7,255,1)
    if any(v>limit for v,limit in zip(values,limits)):raise ValueError('Invalid MAT3 raster state')
    return dict(zip(MATERIAL_STATE,values))


def materials(cs, clean_monument=False):
    t=Reader(cs['TEX1']);to=t.u32(12);names=strings(t.data,t.u32(16));textures=[]
    for i in range(t.u16(8)):
        o=to+i*32;fmt,alpha,w,h,ws,wt=t.get('2B2H2B',o);off=t.u32(o+28)
        tw,th,bits={0:(8,8,4),1:(8,4,8),2:(8,4,8),3:(4,4,16),4:(4,4,16),5:(4,4,16),6:(4,4,32),14:(8,8,4)}.get(fmt,(0,0,0))
        if not tw: raise ValueError('Paletted or unsupported texture '+names[i])
        size=((w+tw-1)//tw)*((h+th-1)//th)*tw*th*bits//8
        if o+off+size>len(t.data):raise ValueError('Truncated J3D texture')
        textures.append(dict(name=names[i],width=w,height=h,format=fmt,wrap_s=ws,wrap_t=wt,data=t.data[o+off:o+off+size]))
    m=Reader(cs['MAT3']);base=m.u32(12);remap=m.u32(16);texno=m.u32(72);colors=m.u32(32)
    result=[]
    material_names=strings(m.data,m.u32(20))
    for i in range(m.u16(8)):
        o=base+m.u16(remap+i*2)*0x14c
        ti=m.u16(o+0x84);idx=m.u16(texno+ti*2) if ti!=65535 else -1
        color=m.u16(o+8);rgba=m.get('4B',colors+color*4) if color!=65535 else (255,255,255,255)
        if idx>=len(textures):raise ValueError('Invalid material texture reference')
        result.append(dict(name=material_names[i],texture=textures[idx] if idx>=0 else dict(name='white',width=4,height=4,format=6,wrap_s=0,wrap_t=0,data=b'\xff'*64),
                           rgba=rgba,flags=1 if m.data[o]==4 else 0,state=material_state(m,o)))
    if clean_monument:
        # Sunshine TMonumentShine::initMapObj uses KCOLOR0.a=0 after the
        # gate is cleaned. Its first texture is paint, not the clean surface.
        # Preserve the original mesh/eyes and bake the donor's gold register
        # into our static single-texture material. Environment glints remain
        # a static approximation, not full animated J3D TEV parity.
        for i,material in enumerate(result):
            if material['name']!='_mat_shine_body':continue
            o=base+m.u16(remap+i*2)*0x14c;register=m.u16(o+0xdc)
            if register==65535:raise ValueError('Missing clean monument gold register')
            gold=m.get('4h',m.u32(0x50)+register*8)
            material['texture']=dict(name='clean_monument_gold',width=4,height=4,format=6,wrap_s=0,wrap_t=0,data=b'\xff'*64)
            material['rgba']=tuple(max(0,min(255,v)) for v in gold[:3])+(255,)
            material['clean_gold']=True
    return result


def cross(a,b,c):
    u=[b[i]-a[i] for i in range(3)];v=[c[i]-a[i] for i in range(3)]
    return (u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])


def material_chunks(path, base, override=None):
    """J3D props can ship placeholder MAT3/TEX1 banks inside the BMD.

    Sunshine loads a companion BMT over those banks (notably kibako). Keep
    the BMD's geometry/hierarchy and use the donor's authored material data.
    """
    material=Path(override) if override is not None else Path(path).with_suffix('.bmt')
    if override is None and not material.is_file():return base,None
    return dict(base,**chunks(material.read_bytes())),material


def compile_scene(cache, scale=None, melee_files=None, output=None, reuse_collision=None):
    from sunshine_scale import measure
    calibration=measure(cache,melee_files)
    measured=scale is None
    if measured:scale=calibration['scale']
    directory=cache/'archives/dolpic1';root=scene((directory/'map/scene.bin').read_bytes());objects=list(flatten(root))
    files={p.relative_to(directory).as_posix().lower():p for p in directory.rglob('*') if p.is_file()}
    geometry=[];colliders=[];props=[];missing=[];textures=[];texture_keys={};draws=[];model_cache={};face_groups=[];group_count=0;material_files={}
    def model(path, mt, sky=False, override=None, whole=True, water=False, clean_monument=False, extra=None):
        nonlocal group_count
        start=len(geometry)
        if extra is None and path not in model_cache:model_cache[path]=static_model(path.read_bytes())
        parsed=extra if extra is not None else model_cache[path]
        if parsed['unsupported']:raise ValueError('Unsupported static geometry: '+str(path))
        cs,material_file=material_chunks(path,parsed['chunks'],override) if extra is None else ({},None)
        if material_file is not None:material_files[path.relative_to(directory).as_posix()]=material_file.relative_to(directory).as_posix()
        mats=materials(cs,clean_monument=clean_monument) if extra is None else extra['materials'];lookup=[]
        for m in mats:
            m.setdefault('state',dict(zip(MATERIAL_STATE,(0,1,3,1,0,1,0,0,7,0,0,7,0,1))))
        if water:
            for m in mats:
                m['flags']|=5  # Animated, translucent donor water.
                if 'taki' in m['name']:m['flags']|=8
                m['rgba']=(185,225,245,185) if 'taki' in m['name'] else (180,235,250,125) if 'beach' in m['name'] else (70,170,215,195)
                m['state'].update(cull=0,depth_write=0,blend_mode=1,blend_src=4,blend_dst=5,alpha_comp0=7,alpha_ref0=0,alpha_op=0,alpha_comp1=7,alpha_ref1=0)

        for m in mats:
            t=m['texture'];key=(t['width'],t['height'],t['format'],t['wrap_s'],t['wrap_t'],hashlib.sha256(t['data']).hexdigest(),m['flags'],sky,tuple(m['state'][k] for k in MATERIAL_STATE))
            if key not in texture_keys:
                texture_keys[key]=len(textures);textures.append(dict(t,flags=m['flags']|(2 if sky else 0),state=m['state']))
            lookup.append(texture_keys[key])
        grouped={}
        for material,tri in parsed['triangles']:
            if material<0 or material>=len(mats):raise ValueError('Invalid shape material')
            converted=[];shade=1
            if mats[material].get('clean_gold'):
                points=[transform(mt,v[0]) for v in tri];normal=cross(*points);length=math.sqrt(sum(n*n for n in normal))
                if length>1e-9:shade=.72+.28*max(0,-(normal[0]*.25+normal[1]*.9+normal[2]*.35)/length)
            for point,color,uv in tri:
                point=transform(mt,point)
                point=tuple(v*(scale if extra is None else 1) for v in point)
                rgba=tuple(round(color[i]*mats[material]['rgba'][i]/255*(shade if i<3 else 1)) for i in range(4))
                converted.append((point,rgba,uv))
            grouped.setdefault(lookup[material],[]).append(converted)
        for material,triangles in grouped.items():
            first=len(geometry);geometry.extend(triangles)
            draws.append((material,first,len(triangles)))
        from sunshine_occlusion import groups as occlusion_groups
        assigned=occlusion_groups(geometry[start:],whole=whole)
        face_groups.extend(group_count+g for g in assigned)
        if assigned:group_count+=max(assigned)+1
    def collider(path,mt):
        vertices,faces=collision(path.read_bytes())
        vertices=[tuple(v*scale for v in transform(mt,p)) for p in vertices]
        for f in faces:
            surface=f['surface'];base=surface&0x3fff
            if base in PASS_THROUGH:continue
            points=[vertices[i] for i in f['indices']];n=cross(*points);length=math.sqrt(sum(v*v for v in n))
            if length<1e-8:continue
            n=tuple(v/length for v in n)
            flags=(1 if surface in WATER or base in WATER else 0)|(2 if base in (0x600,0x800) else 0)|(4 if base==6 else 0)
            colliders.append((points,n,surface,flags))
    identity=matrix((0,0,0),(0,0,0),(1,1,1))
    collider(directory/'map/map.col',identity)
    # These donor-authored world-space structures are rendered in map.bmd,
    # but Sunshine keeps their collision separate from the main terrain.
    building_collision=[]
    for name in ('building01','building02'):
        path=directory/f'map/map/{name}.col'
        if not path.is_file():raise ValueError(f'Missing stage collision: {path.name}')
        collider(path,identity);building_collision.append(path.relative_to(directory).as_posix())
    for name in ('sky','map','sea','seaindirect'):
        model(directory/f'map/map/{name}.bmd',matrix((0,0,0),(0,0,0),(1,1,1)),sky=name=='sky',water=name in ('sea','seaindirect'),whole=name!='map',override=directory/'map/map/sky.bmt' if name=='sky' else None)
    for obj in objects:
        if obj['klass'] not in PROP_CLASSES or 'model' not in obj:continue
        name=obj['model'];candidates=prop_model_candidates(obj)
        path=next((files[k.lower()] for k in candidates if k.lower() in files),None)
        if path is None:
            missing.append(dict(klass=obj['klass'],model=name));continue
        mt=matrix(obj['position'],[v*math.pi/180 for v in obj['rotation']],obj['scale'])
        model(path,mt,clean_monument=obj['klass']=='MonumentShine')
        col=path.with_suffix('.col')
        if col.exists():collider(col,mt)
        props.append(dict(klass=obj['klass'],model=name,path=path.relative_to(directory).as_posix(),collision=col.exists()))
    from sunshine_water import shallow_collision
    colliders=shallow_collision(colliders)
    from sunshine_crossings import crossing_models,VERSION as CROSSINGS_VERSION
    for crossing in crossing_models(directory,scale):
        model(None,matrix((0,0,0),(0,0,0),(1,1,1)),extra=dict(crossing,unsupported=[]))
        colliders.extend(crossing['colliders'])
        props.append(dict(klass='WoodenBridge',**crossing['spec'],collision=True))
    before=len(colliders);colliders=unique_collision(colliders);duplicate_collision=before-len(colliders)
    target=Path(output) if output is not None else cache/'native-preview';target.mkdir(parents=True,exist_ok=True)
    # Native-only host bank: explicit little endian, independently versioned.
    # Keep GX texture blocks in their original byte order.
    header=struct.pack('<4s4I',b'DLV1',2,len(textures),len(draws),len(geometry))
    tex=bytearray()
    for t in textures:
        tex+=struct.pack('<7I',t['width'],t['height'],t['format'],t['wrap_s'],t['wrap_t'],t['flags'],len(t['data']))+struct.pack('<14I',*(t['state'][k] for k in MATERIAL_STATE))+t['data']
    raw=bytearray(header+tex+b''.join(struct.pack('<3I',*d) for d in draws))
    for triangle in geometry:
        for p,c,uv in triangle:raw+=struct.pack('<3f4B2f',*p,*c,*uv)
    (target/'delfino.dlv').write_bytes(raw)
    (target/'delfino.dlg').write_bytes(struct.pack('<4s3I',b'DLG1',1,len(geometry),group_count)+struct.pack('<'+str(len(face_groups))+'I',*face_groups))
    from sunshine_navigation import VERSION as NAVIGATION_VERSION
    previous={}
    if reuse_collision is None:
     raw=struct.pack('<4s2I',b'DLC1',1,len(colliders))
     raw+=b''.join(struct.pack('<12f2I',*(v for p in points for v in p),*n,surface,flags) for points,n,surface,flags in colliders)
     (target/'delfino.dlc').write_bytes(raw)
     boundary=ledges(colliders)
     settings=struct.pack('<4sIf3fI',b'DLS1',2,scale,0,0,3250*scale,len(boundary))
     settings+=b''.join(struct.pack('<9f',*(v for p in edge for v in p)) for edge in boundary)
     (target/'delfino.dls').write_bytes(settings)
    else:
        import shutil
        previous=json.loads((Path(reuse_collision)/'report.json').read_text())
        for name in ('delfino.dlc','delfino.dls'):shutil.copy2(Path(reuse_collision)/name,target/name)
        boundary=[None]*previous['ledges'];navigation=previous['navigation']
    if reuse_collision is None or previous.get('navigation_version',1)!=NAVIGATION_VERSION:
        from sunshine_navigation import build as build_navigation,encode as encode_navigation
        nodes,links,groups,navigation=build_navigation(colliders)
        (target/'delfino.dln').write_bytes(encode_navigation(nodes,links,groups,navigation['step']))
    else:shutil.copy2(Path(reuse_collision)/'delfino.dln',target/'delfino.dln')
    report=dict(scene='dolpic1',building_collision=building_collision,duplicate_collision_removed=duplicate_collision,navigation_version=NAVIGATION_VERSION,presentation_version=PRESENTATION_VERSION,collision_version=COLLISION_VERSION,crossings_version=CROSSINGS_VERSION,material_overrides=material_files,clean_shine_gate=True,clean_monument_shader='donor_gold_register_static_lighting',scale=scale,scale_status='measured_mario_bind_height' if measured else 'explicit_override',mario_calibration=calibration,
                source_report_sha256=hashlib.sha256((cache/'source.json').read_bytes()).hexdigest(),
                occlusion_groups=group_count,textures=len(textures),draws=len(draws),render_triangles=len(geometry),collision_triangles=len(colliders),
                collision_bounds=bounds([p for ps,*_ in colliders for p in ps]),
                shallow_beds=sum(bool(flags&8) for *_,flags in colliders),animated_water=True,
                water_triangles=sum(bool(flags&1) for *_,flags in colliders),
                ledges=len(boundary),navigation=navigation,
                surface_histogram=dict(Counter(s for _,_,s,_ in colliders)),included_props=props,missing_props=missing,
                raster_state_preserved=True,raster_states=[t['state'] for t in textures],full_j3d_material_parity=False,animated_materials=False,audio=False,
                files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (target/'delfino.dlv',target/'delfino.dlc',target/'delfino.dls',target/'delfino.dln',target/'delfino.dlg')},
                import_tools={name:hashlib.sha256(source_file(name).read_bytes()).hexdigest() for name in ('sunshine_extract.py','sunshine_scene.py','sunshine_compile.py','sunshine_scale.py','sunshine_navigation.py','sunshine_occlusion.py','sunshine_water.py','sunshine_crossings.py')})
    (target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cache',type=Path,default=CACHE)
    p.add_argument('--scale',type=float,help='Explicit diagnostic override; default matches Mario model heights');a=p.parse_args()
    if a.scale is not None and (not math.isfinite(a.scale) or a.scale<=0):p.error('Positive finite donor-wide scale required')
    r=compile_scene(a.cache.expanduser(),a.scale)
    print(json.dumps({k:v for k,v in r.items() if k not in ('included_props','surface_histogram')},indent=2))
