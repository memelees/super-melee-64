"""Verified private banks for the four supported Sunshine worlds.

Survey outputs never become menu options by accident. Register an exact bank
and its native playtest evidence; ordinary launch only reads the saved registry
and saved preview, and never runs a renderer or searches the original disc.
"""
import argparse,hashlib,json,os,shutil,struct,tempfile
from pathlib import Path
from player_paths import payload,source_file

MAPS={'bianco':('Bianco Hills','MELEE3D_NATIVE_BIANCO'),
      'sirena':('Sirena Beach','MELEE3D_NATIVE_SIRENA'),
      'pianta':('Pianta Village','MELEE3D_NATIVE_PIANTA')}
FILES=('delfino.dlv','delfino.dlc','delfino.dls','delfino.dlg','delfino.dln')
ORDER=('delfino','bianco','sirena','pianta','onett','castle')
GATES=('full_round_32_cpus','routes','recovery','goop_escape')

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def bank_identity(directory):
    directory=Path(directory)
    result={}
    for name in FILES:
        p=directory/name
        if p.is_symlink() or not p.is_file():raise ValueError('Sunshine bank missing regular file: '+name)
        data=p.read_bytes()
        if len(data)<12 or data[:4]!=name[-3:].upper().encode()+b'1':raise ValueError('Invalid Sunshine bank header: '+name)
        result[name]=hashlib.sha256(data).hexdigest()
    # Match native bounds before exposing a choice. The engine performs the
    # complete topology/material checks again when that exact bank is loaded.
    raw=(directory/'delfino.dlc').read_bytes();_,version,count=struct.unpack_from('<4s2I',raw)
    if version!=1 or not 0<count<=30000 or len(raw)!=12+count*56:raise ValueError('Invalid Sunshine collision bank')
    raw=(directory/'delfino.dln').read_bytes();_,version,nodes,links,step=struct.unpack_from('<4s3If',raw)
    if version!=3 or not 32<=nodes<=100000 or links>2000000 or not 4<=step<=32 or len(raw)!=20+nodes*24+links*8:raise ValueError('Invalid Sunshine route bank')
    return result

def registry(installation):return Path(installation).parent/'stages/sunshine'

def verify(directory,key,*,playable=True):
    if key not in MAPS:raise ValueError('Unsupported Sunshine map')
    directory=Path(directory);data=json.loads((directory/'map.json').read_text())
    if data.get('version')!=1 or data.get('key')!=key or data.get('files')!=bank_identity(directory):raise ValueError('Sunshine map registry differs from its private bank: '+key)
    if playable and (data.get('status')!='playable' or not all(data.get('acceptance',{}).get(g) is True for g in GATES)):raise ValueError('Sunshine map has not completed native gameplay acceptance: '+key)
    return data

def register(installation,key,source,acceptance=None):
    if key not in MAPS:raise ValueError('Unsupported Sunshine map')
    source=Path(source).expanduser().resolve();identity=bank_identity(source)
    acceptance=dict(acceptance or {})
    if any(k not in GATES or type(v) is not bool for k,v in acceptance.items()):raise ValueError('Invalid native acceptance gates')
    data=dict(version=1,key=key,name=MAPS[key][0],files=identity,
              status='playable' if all(acceptance.get(g) is True for g in GATES) else 'playtest',acceptance=acceptance)
    root=registry(installation);root.mkdir(parents=True,exist_ok=True)
    target=root/key
    if target.exists():
        current=verify(target,key,playable=False)
        if current==data:return target
        raise ValueError('Preserve the registered map revision before replacing it: '+key)
    with tempfile.TemporaryDirectory(prefix='.'+key+'-',dir=root) as temporary:
        staged=Path(temporary)/'bank';staged.mkdir()
        for name in FILES:shutil.copy2(source/name,staged/name)
        (staged/'map.json').write_text(json.dumps(data,indent=2)+'\n')
        verify(staged,key,playable=False);staged.rename(target)
    return target

def promote(installation,key,contract):
    """Enable an unchanged registered candidate after its review gates pass."""
    directory=registry(installation)/key;data=verify(directory,key,playable=False)
    if data['files']!=contract.get('files') or not all(contract.get('acceptance',{}).get(g)is True for g in GATES):raise ValueError('Sunshine candidate does not match completed native acceptance: '+key)
    data.update(status='playable',acceptance=dict(contract['acceptance']))
    temporary=directory/'map.json.tmp';temporary.write_text(json.dumps(data,indent=2)+'\n');temporary.replace(directory/'map.json')
    verify(directory,key);return directory

def configure(installation,metadata,profile,env,*,playtest=False):
    from player_stage_preview import preview
    for key,(_,variable) in MAPS.items():
        for directory in (registry(installation)/key,Path(installation)/'sunshine/maps'/key):
            if not directory.exists():continue
            data=verify(directory,key,playable=False)
            if not playtest and data.get('status')!='playable':continue
            if not playtest:verify(directory,key)
            env[variable]=str(directory.resolve())
            env[variable+'_PREVIEW']=str(preview(Path(installation).parent/'ui-cache',stage=key));break

def prepare_import_maps(installation,extracted,contracts,progress=None):
    """Compile all three accepted maps inside a new atomic disc import.

    Every byte must match its reviewed contract. Keeping these under the
    installation makes them survive the importer's final directory rename,
    while existing-user trial registrations remain outside that immutable
    import. A supported source revision is never inferred from a filename.
    """
    from sunshine_scale import measure
    from sunshine_bianco_playable import convert as bianco
    from sunshine_sirena_prototype import convert_candidate as sirena
    from sunshine_pianta_prototype import convert as pianta
    if set(contracts)!=set(MAPS):raise ValueError('All three Sunshine maps need reviewed native acceptance contracts')
    report=progress or (lambda value,message:None)
    installation=Path(installation);extracted=Path(extracted);scale=measure(extracted,installation/'akaneia/files')['scale'];result={}
    for i,(key,episode,compiler)in enumerate((('bianco','bianco0',bianco),('sirena','sirena1',sirena),('pianta','monte7',pianta))):
        contract=contracts[key]
        if not all(contract.get('acceptance',{}).get(g) is True for g in GATES):raise ValueError('Sunshine native acceptance is incomplete: '+key)
        target=installation/'sunshine/maps'/key;target.parent.mkdir(parents=True,exist_ok=True)
        report(i*33,'Preparing '+MAPS[key][0]+'…')
        if key=='sirena':compiler(extracted,target,scale)
        else:compiler(extracted/'archives'/episode,target,scale)
        identity=bank_identity(target)
        if identity!=contract.get('files'):raise ValueError('Converted '+MAPS[key][0]+' differs from the reviewed map revision')
        data=dict(version=1,key=key,name=MAPS[key][0],files=identity,status='playable',acceptance=dict(contract['acceptance']))
        (target/'map.json').write_text(json.dumps(data,indent=2)+'\n');verify(target,key);result[key]=target
    report(100,'Four Sunshine maps prepared')
    return result

def prepare_candidates(installation,source,progress=None):
    """Explicit setup step: read exactly three additional owned-disc scenes.

    This is intentionally separate from ordinary launch and registration.
    It creates reviewable private candidates; it never awards acceptance to a
    newly compiled revision merely because conversion exited successfully.
    """
    from sunshine_extract import extract
    from sunshine_scale import measure
    from sunshine_bianco_playable import convert as bianco
    from sunshine_sirena_prototype import convert_candidate as sirena
    from sunshine_pianta_prototype import convert as pianta
    report=progress or (lambda value,message:None)
    installation=Path(installation);root=installation.parent/'stage-sources/sunshine';root.mkdir(parents=True,exist_ok=True)
    report(0,'Reading Bianco Hills, Sirena Beach and Pianta Village…')
    extract(Path(source),root,['data/scene/bianco0.szs','data/scene/sirena1.szs','data/scene/monte7.szs'])
    scale=measure(installation/'sunshine',installation/'akaneia/files')['scale'];result={}
    # Output identity includes extracted scene bytes and all local compiler
    # sources so updating an actor/material policy cannot reuse old banks.
    helpers=source_file('player_sunshine.py').parent
    tools={p.name:digest(p)for p in helpers.glob('sunshine_*.py')}
    for i,(key,episode,compiler)in enumerate((('bianco','bianco0',bianco),('sirena','sirena1',sirena),('pianta','monte7',pianta))):
        directory=root/'archives'/episode
        identity=hashlib.sha256(json.dumps(dict(scale=scale,tools=tools,source={p.relative_to(directory).as_posix():digest(p)for p in sorted(directory.rglob('*'))if p.is_file()}),sort_keys=True).encode()).hexdigest()[:24]
        target=installation.parent/'stages/sunshine-candidates'/key/identity
        if target.is_dir():bank_identity(target);result[key]=target;continue
        target.parent.mkdir(parents=True,exist_ok=True);report(5+i*30,'Preparing '+MAPS[key][0]+'…')
        with tempfile.TemporaryDirectory(prefix='.'+key+'-',dir=target.parent)as temporary:
            staged=Path(temporary)/'bank'
            if key=='sirena':compiler(root,staged,scale)
            else:compiler(directory,staged,scale)
            bank_identity(staged);staged.rename(target)
        result[key]=target
    report(100,'Sunshine map candidates prepared for native playtests')
    return result

def recording_identity(env):
    """Path-independent content identity for deterministic native menu replays."""
    result={'version':1,'order':list(ORDER),'maps':{}}
    for key,variable in [('delfino','MELEE3D_NATIVE_DELFINO')]+[(k,v[1])for k,v in MAPS.items()]:
        if env.get(variable):result['maps'][key]=bank_identity(Path(env[variable]))
    for key in ('onett','castle'):
        variable='MELEE3D_NATIVE_'+key.upper()+'_OVERLAY'
        if not env.get(variable):continue
        directory=Path(env[variable]);names=('delfino.dln',key+'.ovl',key+'.reg',key+'.wtr',key+'.trf')
        files={name:digest(directory/name) for name in names if (directory/name).is_file()}
        archive=Path(env.get('MELEE_FILES_DIR',''))/('GrOt.dat' if key=='onett' else 'GrCs.dat')
        if archive.is_file():files['source_archive']=digest(archive)
        result['maps'][key]=files
    # Goop textures and source stage archives are part of replay identity too.
    for variable in ('MELEE3D_NATIVE_GOOP_ART',):
        if env.get(variable):result[variable]=digest(env[variable])
    return result

def main():
    from player_install import DEFAULT
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('key',choices=tuple(MAPS));p.add_argument('source',type=Path)
    p.add_argument('--installation',type=Path,default=DEFAULT);p.add_argument('--acceptance',type=Path,help='JSON of completed native acceptance gates')
    a=p.parse_args();print(register(a.installation,a.key,a.source,json.loads(a.acceptance.read_text()) if a.acceptance else None))
if __name__=='__main__':main()
