#!/usr/bin/env python3
"""Cross-build our complete native game for Windows x64, including Akaneia VM."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import urllib.request

from native_compatibility import ROOT, WORK, sha, write_json
from native_mac import SOURCE, stage
from native_bridge import prepare_bridge

PREFIX=WORK/'windows-deps'
BUILD=SOURCE/'build/windows-proof'


def ffi():
    prefix=PREFIX/'libffi'
    if (prefix/'lib/libffi.a').is_file():return prefix
    PREFIX.mkdir(parents=True,exist_ok=True)
    archive=PREFIX/'libffi-3.4.8.tar.gz'
    if not archive.exists():
        subprocess.run(['curl','-fL','--retry','2','https://github.com/libffi/libffi/releases/download/v3.4.8/libffi-3.4.8.tar.gz','-o',str(archive)],check=True)
    # Official release tarball, pinned independently of the local build.
    expected='bc9842a18898bfacb0ed1252c4febcc7e78fa139fd27fdc7a3e30d9d9356119b'
    if sha(archive)!=expected:raise ValueError('Unexpected libffi source archive: '+sha(archive))
    source=PREFIX/'libffi-3.4.8'
    if not source.exists():
        with tarfile.open(archive) as t:t.extractall(PREFIX,filter='data')
    subprocess.run(['./configure','--host=x86_64-w64-mingw32','--disable-shared','--enable-static',
                    '--disable-docs',f'--prefix={prefix}'],cwd=source,check=True)
    subprocess.run(['make','-j6'],cwd=source,check=True)
    subprocess.run(['make','install'],cwd=source,check=True)
    return prefix


def build():
    stage();prepare_bridge(destination=WORK/'mac-runtime')
    prefix=ffi()
    subprocess.run(['cmake','-S',str(SOURCE),'-B',str(BUILD),'-G','Ninja',
                    '-DCMAKE_BUILD_TYPE=Release',f'-DCMAKE_TOOLCHAIN_FILE={SOURCE}/cmake/x86_64-w64-mingw32.cmake',
                    '-DAURORA_DAWN_PROVIDER=package','-DAURORA_NOD_PROVIDER=package',
                    '-DAURORA_SDL3_PROVIDER=package',f'-DM3D_FFI_ROOT={prefix}'],check=True)
    subprocess.run(['ninja','-C',str(BUILD),'-j6','melee'],check=True)
    # MinGW threads are a dependency even with static libstdc++.
    threads=subprocess.check_output(['x86_64-w64-mingw32-gcc','-print-file-name=libwinpthread-1.dll'],text=True).strip()
    if not Path(threads).is_file():
        sysroot=Path(subprocess.check_output(['x86_64-w64-mingw32-gcc','-print-sysroot'],text=True).strip())
        threads=sysroot/'x86_64-w64-mingw32/bin/libwinpthread-1.dll'
    if Path(threads).is_file():shutil.copy2(threads,BUILD/'libwinpthread-1.dll')
    write_json(WORK/'native-windows-build.json',dict(platform='Windows-x64',
        executable_sha256=sha(BUILD/'melee.exe'),patch_sha256=sha(ROOT/'native/mac/capacity.patch'),
        execution_verified=False,source='same canonical native modules as Mac'))
    print(BUILD/'melee.exe')


if __name__=='__main__':build()
