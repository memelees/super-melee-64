#!/usr/bin/env python3
"""Compile optional source-model collision and CPU routes for original Onett.

The native stage9 scene, original collision identities and stage callbacks stay
active. This appends structural source triangles; it never installs an FD map.
"""
import argparse, hashlib, json, math, re, struct
from pathlib import Path
from sunshine_navigation import build as navigation, encode
import native_authored_routes
import native_playable_region
import sunshine_navigation as navigation_module
from onett_city_correction.onett_positions import source_triangles
from native_roster import Archive

STRUCTURAL=re.compile(r'GrdOnett(?:W?Roof|Wall|Door|Window|Renga|Tile|Hospital|Hotel|Grd|Ground|Road|Rock|Grass|Stone)')
EXCLUDE=re.compile(r'(Shadow|Signal|Kazamidori|Kanban|Houses|MtTree|Yunbo)')
MAX_LINES=16380

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def physical_triangle(t):
 ps=t['points'];u=[ps[1][k]-ps[0][k]for k in range(3)];v=[ps[2][k]-ps[0][k]for k in range(3)]
 n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];norm=math.sqrt(sum(x*x for x in n))
 if norm<1e-8:return None
 if not all(math.isfinite(x)for p in ps for x in p):raise ValueError('Non-finite source vertex')
 return [ps[0],ps[2],ps[1]],[-x/norm for x in n],0,0

def simplify_coplanar(colliders,provenance):
 """Remove interior triangulation without changing physical plane boundaries.

 Retain groups with overlaps, holes or nonmanifold boundaries unchanged.
 Split T junctions before cancelling shared edges; retain every genuine void.
 """
 from collections import defaultdict,Counter
 from native_reference import triangulate
 groups=defaultdict(list)
 for i,(ps,n,_,_) in enumerate(colliders):
  d=sum(n[k]*ps[0][k]for k in range(3));source=provenance[i]
  owner=source['dobj']if abs(n[1])>=.64 else source['joint']
  groups[owner,*(round(v,4)for v in n),round(d,3)].append(i)
 result=[];sources=[];merged_groups=0
 def untouched(ids):
  result.extend(colliders[i]for i in ids);sources.extend(provenance[i]for i in ids)
 for ids in groups.values():
  if len(ids)<3:untouched(ids);continue
  n=colliders[ids[0]][1];drop=max(range(3),key=lambda k:abs(n[k]));axes=[k for k in range(3)if k!=drop]
  points={tuple(round(v,4)for v in p):p for i in ids for p in colliders[i][0]};keys=list(points);edges=Counter()
  for i in ids:
   ps=colliders[i][0]
   for a,b in zip(ps,ps[1:]+ps[:1]):
    ak=tuple(round(v,4)for v in a);bk=tuple(round(v,4)for v in b);dx=b[axes[0]]-a[axes[0]];dy=b[axes[1]]-a[axes[1]];length=dx*dx+dy*dy
    if length<1e-10:continue
    cut=[]
    for key in keys:
     p=points[key];u=((p[axes[0]]-a[axes[0]])*dx+(p[axes[1]]-a[axes[1]])*dy)/length
     cross=dx*(p[axes[1]]-a[axes[1]])-dy*(p[axes[0]]-a[axes[0]])
     if -1e-6<=u<=1+1e-6 and abs(cross)<.0003*math.sqrt(length):cut.append((max(0,min(1,u)),key))
    cut.sort()
    for (_,u),(_,v)in zip(cut,cut[1:]):
     if u!=v:edges[u,v]+=1
  boundary={e:c-edges[e[1],e[0]]for e,c in edges.items()if c>edges[e[1],e[0]]}
  if any(v!=1 for v in boundary.values()):untouched(ids);continue
  outgoing=defaultdict(list);incoming=Counter()
  for a,b in boundary:outgoing[a].append(b);incoming[b]+=1
  if not outgoing or any(len(v)!=1 or incoming[k]!=1 for k,v in outgoing.items()):untouched(ids);continue
  loops=[];remaining=set(outgoing)
  while remaining:
   start=next(iter(remaining));loop=[];k=start
   while k in remaining:remaining.remove(k);loop.append(k);k=outgoing[k][0]
   if k!=start or len(loop)<3:loops=[];break
   loops.append(loop)
  if not loops:untouched(ids);continue
  def signed_area(loop):return sum(points[a][axes[0]]*points[b][axes[1]]-points[b][axes[0]]*points[a][axes[1]]for a,b in zip(loop,loop[1:]+loop[:1]))/2
  areas=[signed_area(q)for q in loops]
  if any(a*areas[0]<=0 for a in areas):untouched(ids);continue
  source_area=sum(abs(sum(a[axes[0]]*b[axes[1]]-b[axes[0]]*a[axes[1]]for a,b in zip(colliders[i][0],colliders[i][0][1:]+colliders[i][0][:1]))/2)for i in ids)
  if abs(sum(map(abs,areas))-source_area)>max(.01,source_area*.0001):untouched(ids);continue
  simplified=[]
  try:
   for loop in loops:
    changed=True
    while changed and len(loop)>3:
     changed=False
     for i in range(len(loop)):
      a,b,c=[points[loop[k%len(loop)]]for k in (i-1,i,i+1)];cross=(b[axes[0]]-a[axes[0]])*(c[axes[1]]-b[axes[1]])-(b[axes[1]]-a[axes[1]])*(c[axes[0]]-b[axes[0]])
      if abs(cross)<.001:loop.pop(i);changed=True;break
    polygon=[(points[k][axes[0]],points[k][axes[1]])for k in loop]
    for tri in triangulate(polygon):simplified.append(([points[loop[k]]for k in tri],n,0,0))
  except ValueError:untouched(ids);continue
  if len(simplified)>=len(ids):untouched(ids);continue
  # Plane projection preserves the source winding; no visual or texture data
  # is involved because only collision tessellation is simplified.
  result.extend(simplified);sources.extend([dict(provenance[ids[0]],merged_source_triangles=len(ids),boundary_exact=True)]*len(simplified));merged_groups+=1
 return result,sources,dict(groups_merged=merged_groups,triangles_before=len(colliders),triangles_after=len(result),method='Exact coplanar boundary reconstruction; source voids/overlap/nonmanifold groups retained unchanged')

def authored_triangles(path,archive_sha):
 """Return explicitly modelled solid faces before UV-only tessellation."""
 if not path.exists():return set(),[],None
 payload=json.loads(path.read_text())
 if payload.get('archive_sha256')!=archive_sha or payload.get('coordinate_space')!='native-world-scale-applied-once':raise ValueError('Authored geometry archive/coordinate mismatch')
 geometry=payload.get('geometry',[]);joints=set();result=[]
 for face in geometry:
  joint=face.get('render_joint')
  if joint is None:raise ValueError('Authored solid has no exact render joint')
  joint=int(joint,0)if isinstance(joint,str)else int(joint);joints.add(joint)
  ps=[tuple(float(v)for v in p)for p in face['points']]
  if len(ps)not in (3,4)or any(len(p)!=3 or not all(math.isfinite(v)for v in p)for p in ps):raise ValueError('Authored structural face must be finite triangle/quad')
  for indices in ([(0,1,2)]if len(ps)==3 else[(0,1,2),(0,2,3)]):
   p=[ps[i]for i in indices];u=[p[1][k]-p[0][k]for k in range(3)];v=[p[2][k]-p[0][k]for k in range(3)];n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];length=math.sqrt(sum(x*x for x in n))
   if length<1e-8:continue
   n=[v/length for v in n];declared=face.get('normal',n)
   if sum(n[k]*declared[k]for k in range(3))<.999:raise ValueError('Authored face normal/winding mismatch')
   result.append((p,n,dict(group=5,joint=hex(joint),dobj=str(face['source_dobj']),material_symbols=[face.get('material','')],building=face.get('building'),feature=face.get('feature'),collision_role=face.get('collision_role'),stair_flight=face.get('stair_flight'),render_equivalence=face.get('render_equivalence'))))
 return joints,result,payload


def stair_envelopes(faces,payload):
 """Closed thin ramp proxies bounded by the rendered tread/riser spacing."""
 if not payload:return faces,[]
 proxies=[];replace=set();added=[]
 for flight in payload.get('stair_envelopes',[]):
  name=flight['name'];source=[f for f in faces if f[2].get('building','')+'/'+str(f[2].get('stair_flight'))==name]
  if not source:raise ValueError('Stair proxy has no matching rendered source')
  treads=[f for f in source if f[2]['collision_role']=='stair_tread'];unders=[f for f in source if f[2]['collision_role']=='stair_underside']
  if not treads or not unders:raise ValueError('Stair source must include tops and undersides')
  top_y=sorted(set(round(f[0][0][1],6)for f in treads));bottom_y=sorted(set(round(f[0][0][1],6)for f in unders));thicknesses=[min(y-b for b in bottom_y if b<y)for y in top_y];thickness=min(thicknesses)
  if max(thicknesses)-thickness>.0001:raise ValueError('Stair source thickness is not uniform')
  start,end=[tuple(flight[k])for k in ('start','end')];dx,dz=end[0]-start[0],end[2]-start[2];run=math.hypot(dx,dz);width=float(flight['width']);error=float(flight['maximum_visual_riser_error'])
  if run<=0 or width<10 or not 0<error<=2:raise ValueError('Invalid bounded stair envelope')
  def expected(p):return start[1]+((p[0]-start[0])*dx+(p[2]-start[2])*dz)/(run*run)*(end[1]-start[1])
  for ps,n,meta in source:
   role=meta['collision_role']
   if role not in ('stair_tread','stair_riser','stair_underside'):raise ValueError('Stair envelope would swallow unrelated structural wall')
   if role in ('stair_tread','stair_underside') and any(abs(p[1]-(expected(p)-(thickness if role=='stair_underside'else 0)))>error+.0001 for p in ps):raise ValueError('Stair proxy exceeds declared visual error')
  rx,rz=-dz/run*width/2,dx/run*width/2
  top=[(start[0]+rx,start[1],start[2]+rz),(end[0]+rx,end[1],end[2]+rz),(end[0]-rx,end[1],end[2]-rz),(start[0]-rx,start[1],start[2]-rz)]
  # Source CCW top must face upward regardless of flight direction.
  def cross(ps):
   u=[ps[1][k]-ps[0][k]for k in range(3)];v=[ps[2][k]-ps[0][k]for k in range(3)];n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];length=math.sqrt(sum(q*q for q in n));return[q/length for q in n]
  if cross(top)[1]<0:top.reverse()
  bottom=[(x,y-thickness,z)for x,y,z in top];quads=[top,list(reversed(bottom))]+[[top[(j+1)%4],top[j],bottom[j],bottom[(j+1)%4]]for j in range(4)]
  for j,quad in enumerate(quads):
   for ids in ((0,1,2),(0,2,3)):
    points=[quad[k]for k in ids];meta=dict(treads[0][2],collision_role='bounded-stair-envelope',stair_proxy=name,maximum_visual_riser_error=error,render_equivalence='Closed ramp slab within declared rendered tread/riser error',dobj='stair-proxy/'+name+'/'+str(j));added.append((points,cross(points),meta))
  replace.add(name);proxies.append(dict(name=name,source_faces=len(source),proxy_triangles=12,thickness=thickness,maximum_visual_riser_error=error))
 return[f for f in faces if f[2].get('building','')+'/'+str(f[2].get('stair_flight'))not in replace]+added,proxies


def append_stair_routes(nodes,edges,groups,colliders,payload):
 """Append measured footpaths, preserving real floors, body sides and ceilings."""
 if not payload:return dict(added_nodes=0,added_edges=0)
 from collections import defaultdict,Counter
 from sunshine_navigation import height,segment_hit,supporting_plane,components
 grid=defaultdict(list)
 for ps,n,_,flags in colliders:
  if flags&3:continue
  for x in range(math.floor(min(p[0]for p in ps)/64),math.floor(max(p[0]for p in ps)/64)+1):
   for z in range(math.floor(min(p[2]for p in ps)/64),math.floor(max(p[2]for p in ps)/64)+1):grid[x,z].append((ps,n))
 def nearby(x,z):return grid.get((math.floor(x/64),math.floor(z/64)),[])
 def supports(p):return[(ps,n)for ps,n in nearby(p[0],p[2])if n[1]>=.65 and(h:=height(ps,n,p[0],p[2]))is not None and abs(h-p[1])<.5]
 def actual(x,z,y):return any(n[1]>=.65 and(h:=height(ps,n,x,z))is not None and abs(h-y)<3 for ps,n in nearby(x,z))
 def supported(p):
  planes=supports(p)
  if not planes:return False
  if any(segment_hit((p[0],p[1]+.1,p[2]),(p[0],p[1]+19,p[2]),ps)for ps,n in nearby(p[0],p[2])):return False
  for dx,dz in ((5,0),(-5,0),(0,5),(0,-5)):
   x,z=p[0]+dx,p[2]+dz
   if not any(actual(x,z,ps[0][1]-(n[0]*(x-ps[0][0])+n[2]*(z-ps[0][2]))/n[1])for ps,n in planes):
    # A thin stair meets a horizontal landing at a real shared edge. Follow
    # that piecewise source floor across the5u footprint; never extrapolate
    # across a hole or permit a vertical step. Every .5u sample needs a
    # real walkable triangle, with grade bounded by the native .65 normal.
    previous=p[1]
    for j in range(1,11):
     sx,sz=p[0]+dx*j/10,p[2]+dz*j/10
     levels=[h for ps,n in nearby(sx,sz)if n[1]>=.65 and(h:=height(ps,n,sx,sz))is not None and abs(h-previous)<=.6]
     if not levels:return False
     previous=min(levels,key=lambda h:abs(h-previous))
  return True
 def clear(a,b,jump=False):
  dx,dz=b[0]-a[0],b[2]-a[2];length=math.hypot(dx,dz)
  if length<.001:return False
  rx,rz=-dz/length*5,dx/length*5
  candidates=[]
  for x in range(math.floor((min(a[0],b[0])-5)/64),math.floor((max(a[0],b[0])+5)/64)+1):
   for z in range(math.floor((min(a[2],b[2])-5)/64),math.floor((max(a[2],b[2])+5)/64)+1):candidates.extend(grid.get((x,z),[]))
  for t in (0,.25,.5,.75,1):
   q=tuple(a[k]+(b[k]-a[k])*t for k in range(3))
   if not jump and not supported(q):return False
  for side in (-1,1):
   for h in (1,8,17):
    previous=(a[0]+rx*side,a[1]+h,a[2]+rz*side)
    for t in (.25,.5,.75,1):
     q=tuple(a[k]+(b[k]-a[k])*t for k in range(3));p=(q[0]+rx*side,q[1]+h+(24*4*t*(1-t)if jump else 0),q[2]+rz*side)
     for ps,n in candidates:
      if not jump and supporting_plane(ps,n,previous[0]-rx*side,previous[2]-rz*side,previous[1]-h)and supporting_plane(ps,n,*q[::2],q[1]):continue
      if segment_hit(previous,p,ps):return False
     previous=p
  return True
 original=len(nodes);rejected=[];rejected_optional=[]
 candidates=[]
 for flight in payload.get('stair_envelopes',[]):
  a,b=flight['start'],flight['end'];count=math.ceil(math.dist(a,b)/5)+1
  candidates.extend((flight['name'],tuple(a[k]+(b[k]-a[k])*j/(count-1)for k in range(3)))for j in range(count))
 for anchor in payload.get('route_anchors',[]):
  if anchor.get('kind','').endswith('landing') or anchor['name'].endswith('actual-drugstore-roof'):candidates.append((anchor['name'],tuple(anchor['position'])))
  if anchor.get('kind')=='stair-landing':
   x,y,z=anchor['position']
   candidates.extend((anchor['name']+'/turn', (x,y,z+dz))for dz in (-8,8))
  elif anchor.get('kind')=='terrace-bridge-landing':
   x,y,z=anchor['position']
   candidates.extend((anchor['name']+'/approach', (x+dx,y,z+dz))for dx in (-6,0,6)for dz in (-6,0,6)if dx or dz)
 for name,p in candidates:
  if not supported(p):
   (rejected_optional if name.endswith('/turn')or name.endswith('/approach')else rejected).append(dict(name=name,position=p));continue
  if any(math.dist(p,q)<.05 for q in nodes):continue
  nodes.append(p);edges.append([]);groups.append(-1)
 roof_positions=[tuple(a['position'])for a in payload.get('route_anchors',[])if a['name'].endswith('actual-drugstore-roof')]
 endpoint_positions=[tuple(f[k])for f in payload.get('stair_envelopes',[])for k in ('start','end')]
 added_edges=0
 for i in range(original,len(nodes)):
  a=nodes[i];near=sorted((math.dist(a,b),j)for j,b in enumerate(nodes)if j!=i and math.hypot(a[0]-b[0],a[2]-b[2])<=24 and abs(a[1]-b[1])<=24)
  for _,j in near[:24]:
   if any(k==j for k,_ in edges[i]):continue
   kind=0
   if not clear(a,nodes[j]):
    if not(any(math.dist(p,a)<.05 or math.dist(p,nodes[j])<.05 for p in roof_positions)or any(math.dist(p,a)<5 or math.dist(p,nodes[j])<5 for p in endpoint_positions))or abs(a[1]-nodes[j][1])>8 or not clear(a,nodes[j],True):continue
    kind=1
   edges[i].append((j,kind));edges[j].append((i,kind));added_edges+=2
 groups[:]=components([[(j,k)for j,k in e if k!=3]for e in edges])
 return dict(added_nodes=len(nodes)-original,added_edges=added_edges,rejected_samples=rejected,rejected_optional_samples=rejected_optional,components=len(set(groups)),method='Measured source stair/landing footpaths with radius5, real offset floors and17-unit body rays; original extended-jump gates retained')


def compile_overlay(archive,report_path,destination,step=16):
 if destination.exists():raise ValueError('Use a fresh output directory')
 report=json.loads(report_path.read_text());source_hash=digest(archive)
 if report['output_sha256']!=source_hash:raise ValueError('Art archive/report identity mismatch')
 architecture_path=archive.parent/'authored-architecture-collision.json'
 joints,authored,architecture=authored_triangles(architecture_path,source_hash)
 region_path=archive.parent/'playable-region.json'
 region=native_playable_region.compile_contract(region_path,source_hash)if region_path.exists()else None
 if architecture:architecture=dict(architecture,walk_routes=[*architecture.get('walk_routes',[]),*native_authored_routes.routes_from_report(report)])
 if region and region.payload.get('playable_scope')=='city-field-roads':
  if region.payload.get('retained_hill_routes',{}).get('routes'):raise ValueError('City-only contract retains withdrawn hill routes')
  if architecture:
   forbidden=('upper-terrace','hillside-house','hillside_','hill-house','northern-hill')
   names=[str(a.get('name',''))for a in architecture.get('route_anchors',[])]+[str(a.get('name',''))for a in architecture.get('walk_routes',[])]+[str(a.get('name',''))for a in architecture.get('stair_envelopes',[])]
   if any(token in name for name in names for token in forbidden):raise ValueError('City-only architecture retains withdrawn hill/bridge route')
 authored,proxies=stair_envelopes(authored,architecture)
 raw=source_triangles(Archive(archive));colliders=[];provenance=[];seen=set();skipped={}
 for t in raw:
  symbols=' '.join(t['symbols'])
  if t['joint']in joints:
   skipped['explicit_render_joint']=skipped.get('explicit_render_joint',0)+1;continue
  if t['group']!=5 or not STRUCTURAL.search(symbols)or EXCLUDE.search(symbols):
   skipped['nonstructural']=skipped.get('nonstructural',0)+1;continue
  physical=physical_triangle(t)
  if physical is None:skipped['micro_or_degenerate']=skipped.get('micro_or_degenerate',0)+1;continue
  ps,n,_,_=physical
  # Same oriented geometric face, regardless of split material descriptors.
  key=(tuple(sorted(tuple(round(x,4)for x in p)for p in ps)),tuple(round(x,4)for x in n))
  if key in seen:skipped['duplicate']=skipped.get('duplicate',0)+1;continue
  seen.add(key);colliders.append(physical);provenance.append(dict(group=t['group'],joint=hex(t['joint']),dobj=hex(t['dobj']),material_symbols=t['symbols']))
 for ps,n,meta in authored:
  colliders.append((ps,n,0,0));provenance.append(meta)
 colliders,provenance,simplification=simplify_coplanar(colliders,provenance)
 counts={'floor':0,'ceiling':0,'wall':0}
 for ps,n,_,_ in colliders:counts['floor'if n[1]>=.64 else'ceiling'if n[1]<=-.64 else'wall']+=1
 total=105+counts['floor']+counts['ceiling']+2*counts['wall']
 if not colliders or total>MAX_LINES or total*2>32760:raise ValueError(f'Native line budget exceeded: {total}, counts={counts}')
 lo=[min(p[k]for ps,_,_,_ in colliders for p in ps)for k in range(3)];hi=[max(p[k]for ps,_,_,_ in colliders for p in ps)for k in range(3)]
 print(json.dumps(dict(collision_triangles=len(colliders),counts=counts,native_lines=total,native_bounds=[lo,hi]),indent=2),flush=True)
 nodes,edges,components,nav=navigation(colliders,step=step,radius=5)
 stair_routes=append_stair_routes(nodes,edges,components,colliders,architecture)
 walk_routes=native_authored_routes.append_walk_routes(nodes,edges,components,colliders,architecture)
 region_filter=native_playable_region.filter_graph(nodes,edges,components,region)if region else None
 from collections import Counter
 component_sizes=Counter(components);largest=max(component_sizes,key=component_sizes.get)
 nav.update(nodes=len(nodes),edges=sum(map(len,edges)),components=len(set(components)),largest_component=largest,largest_component_nodes=component_sizes[largest],link_kinds=dict(Counter(k for e in edges for _,k in e)),stair_routes=stair_routes,authored_walk_routes=walk_routes,playable_region_filter=region_filter)
 if len(nodes)<16:raise ValueError('Insufficient supported CPU nodes')
 destination.mkdir(parents=True)
 (destination/'onett.ovl').write_bytes(struct.pack('<4s2I6f',b'OVL1',1,len(colliders),*lo,*hi)+b''.join(struct.pack('<12f',*(v for p in ps for v in p),*n)for ps,n,_,_ in colliders))
 (destination/'delfino.dln').write_bytes(encode(nodes,edges,components,step))
 if region:(destination/'onett.reg').write_bytes(region.encode())
 (destination/'source-provenance.json').write_text(json.dumps(dict(archive=str(archive),archive_sha256=source_hash,triangles=provenance),separators=(',',':'))+'\n')
 anchors={}
 authored_anchors={a['name']:a['position']for a in architecture.get('route_anchors',[])}if architecture else{}
 for name,pos in ({**authored_anchors,** {'south_street':(0,0,90),'midtown_road':(-126,8.1,-320),'north_street':(-126,8.1,-460),'hospital_roof':(75,52.65,-530),'northwest_roof':(-200,55,-510)}}).items():
  i=min(range(len(nodes)),key=lambda i:sum((nodes[i][k]-pos[k])**2 for k in range(3)));anchors[name]=dict(node=i,position=nodes[i],walk_component=components[i])
 result=dict(status='Source collision and native CPU route bank; native gameplay acceptance pending',stage=9,original_lines=105,original_joints=24,original_callbacks_preserved=True,original_static_building_surfaces_replaced=[4,5,6,7,9,10,*range(13,25)],retained_original_surfaces=[0,1,2,3,8,11,12,25],archive=str(archive),archive_sha256=source_hash,source_collision_triangles=len(colliders),counts=counts,native_total_lines=total,native_bounds=[lo,hi],navigation=nav,anchors=anchors,filtering=skipped,simplification=simplification,authored_geometry=dict(file=str(architecture_path),sha256=digest(architecture_path),explicit_joints=len(joints),stair_proxies=proxies)if architecture else None,files={p.name:digest(p)for p in destination.iterdir()},playable_region=dict(file=str(region_path),sha256=digest(region_path),binary_file='onett.reg',source_regions=len(region.rows),native_semantics='Outside XZ union KO; grounded feet above matching source caps KO; airborne in-XZ jumps preserved')if region else None,compiler_sha256=digest(Path(__file__)),compiler_dependencies={name:digest(Path(module.__file__))for name,module in [('native_authored_routes.py',native_authored_routes),('native_playable_region.py',native_playable_region),('sunshine_navigation.py',navigation_module)]},limitations=['Original existing stage9 scene and dynamic authored surfaces remain active','Per-triangle static structural collision; source ledge grabbing on new roof boundaries is not authored yet','Terrain slope and roof routes must be validated using actual CPU pads; graph connectivity alone is not gameplay acceptance'])
 (destination/'overlay-report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
 return result

if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('archive',type=Path);ap.add_argument('report',type=Path);ap.add_argument('destination',type=Path);ap.add_argument('--step',type=float,default=16);a=ap.parse_args();compile_overlay(a.archive,a.report,a.destination,a.step)
