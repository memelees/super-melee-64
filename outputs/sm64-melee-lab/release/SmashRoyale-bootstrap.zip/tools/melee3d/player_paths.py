"""Locations shared by source tools and the self-contained desktop launcher."""
import os
from pathlib import Path
import sys


def payload():
    if getattr(sys,'frozen',False):return Path(sys._MEIPASS)/'payload'
    return Path(__file__).resolve().parents[2]


def user_directory():
    if sys.platform=='win32':return Path(os.environ.get('LOCALAPPDATA',Path.home()/'AppData/Local'))/'Memelees'
    if sys.platform=='darwin':return Path.home()/'Library/Application Support/Memelees'
    return Path(os.environ.get('XDG_DATA_HOME',Path.home()/'.local/share'))/'Memelees'


def source_file(name):
    """Hash the exact source shipped with a frozen tool, whose .py lives in PYZ."""
    return payload()/'tools/melee3d'/name


def game_command(binary,disc=None):
    command=[str(binary)]
    if sys.platform=='darwin':command+=['-ApplePersistenceIgnoreState','YES','-NSQuitAlwaysKeepsWindows','NO']
    return command+['--no-card']+([] if disc is None else [str(disc)])


def tool_environment():
    directory=payload()/'bin'
    os.environ['PATH']=str(directory)+os.pathsep+os.environ.get('PATH','')
    # A windowed frozen Windows launcher must not flash consoles for converters.
    if sys.platform=='win32':
        import subprocess
        original=subprocess.Popen
        class QuietProcess(original):
            def __init__(self,*args,**kwargs):
                kwargs['creationflags']=kwargs.get('creationflags',0)|subprocess.CREATE_NO_WINDOW
                kwargs.setdefault('stdin',subprocess.DEVNULL)
                if sys.stdout is not None:kwargs.setdefault('stdout',sys.stdout)
                if sys.stderr is not None:kwargs.setdefault('stderr',sys.stderr)
                super().__init__(*args,**kwargs)
        subprocess.Popen=QuietProcess
