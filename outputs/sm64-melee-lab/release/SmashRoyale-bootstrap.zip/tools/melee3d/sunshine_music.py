#!/usr/bin/env python3
"""Render the owner's Plaza sequence/samples to a native loop-aware WAV.

Uses pinned resource_dasm/phosg (MIT), built locally. Output and donor assets
stay in the Sunshine cache. Rendering approximates JAudio, not bit-exact DSP.
"""
import array,hashlib,json,os,re,struct,subprocess
from pathlib import Path
from sunshine_extract import CACHE,extract
from player_paths import payload,source_file
ROOT=payload()
PINS={'phosg':'66f8c363362e3a0d946e46ae895de337e535aa3e',
      'resource_dasm':'16e50d43dffbe4b87f42e4b76f5d0a14602d69e9'}
LOOP_OLD='''          t->r.go(offset);
        }
        break;
      }

      case 0xC5:'''
LOOP_NEW='''          if (!is_call && offset < t->r.where()) {
            phosg::fwrite_fmt(stderr, "M3D BMS LOOP track={} target={} sample={} tick={}\\n", t->id, offset, this->samples_rendered, this->current_time);
          }
          t->r.go(offset);
        }
        break;
      }

      case 0xC5:'''
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(cmd,log,cwd=None):
    with log.open('w') as f:subprocess.run(list(map(str,cmd)),cwd=cwd,stdout=f,stderr=subprocess.STDOUT,check=True)
def prepare_tools():
    base=ROOT/'build/import-tools'
    for name,revision in PINS.items():
        folder=base/name
        if not folder.exists():
            subprocess.run(['git','clone',f'https://github.com/fuzziqersoftware/{name}.git',str(folder)],check=True)
            subprocess.run(['git','checkout','--detach',revision],cwd=folder,check=True)
        actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=folder,text=True).strip()
        if actual!=revision:raise ValueError('Unexpected audio renderer revision: '+name)
    source=base/'resource_dasm/src/Audio/smssynth.cc'
    original=subprocess.check_output(['git','show','HEAD:src/Audio/smssynth.cc'],cwd=source.parents[2],text=True)
    if LOOP_OLD not in original:raise ValueError('Renderer loop boundary changed')
    expected=original.replace(LOOP_OLD,LOOP_NEW,1)
    if source.read_text() not in (original,expected):raise ValueError('Unreviewed renderer modifications')
    source.write_text(expected)
    prefix=base/'phosg/install'
    run(['cmake','-S',base/'phosg','-B',base/'phosg/build','-G','Ninja','-DCMAKE_BUILD_TYPE=Release',f'-DCMAKE_INSTALL_PREFIX={prefix}'],base/'phosg-configure.log')
    run(['cmake','--build',base/'phosg/build','-j','6'],base/'phosg-build.log')
    run(['cmake','--install',base/'phosg/build'],base/'phosg-install.log')
    run(['cmake','-S',base/'resource_dasm','-B',base/'resource_dasm/build','-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DDISABLE_SDL=1',f'-DCMAKE_PREFIX_PATH={prefix}'],base/'smssynth-configure.log')
    run(['cmake','--build',base/'resource_dasm/build','--target','smssynth','-j','6'],base/'smssynth-build.log')
    return base/'resource_dasm/build/smssynth'
def loop_wav(raw,starts):
    if raw[:4]!=b'RIFF' or raw[8:12]!=b'WAVE':raise ValueError('Renderer did not produce WAV')
    chunks={};at=12
    while at+8<=len(raw):
        name,n=struct.unpack_from('<4sI',raw,at)
        if at+8+n>len(raw):raise ValueError('Truncated rendered audio')
        chunks[name]=raw[at+8:at+8+n];at+=8+n+(n&1)
    fmt=chunks[b'fmt '];kind,channels,rate,_,align,bits=struct.unpack_from('<HHIIHH',fmt)
    if (kind,channels,rate,bits)!=(3,2,32000,32):raise ValueError('Unexpected source audio format')
    start,end=starts
    if not 0<start<end<=len(chunks[b'data'])//align:raise ValueError('Invalid source loop')
    data=chunks[b'data'][:end*align];samples=array.array('f');samples.frombytes(data)
    peak=max(abs(v) for v in samples)
    rms=(sum(float(v)*v for v in samples)/len(samples))**.5
    if not .001<rms<100 or not .01<peak<1000:raise ValueError('Silent or invalid source music')
    gain=min(1,.92/peak)
    if gain<1:
        samples=array.array('f',(v*gain for v in samples));data=samples.tobytes()
    smpl=struct.pack('<9I',0,0,31250,60,0,0,0,1,0)+struct.pack('<6I',0,0,start,end-1,0,0)
    body=b'WAVE'
    for name,content in ((b'fmt ',fmt),(b'smpl',smpl),(b'data',data)):
        body+=struct.pack('<4sI',name,len(content))+content+(b'\0' if len(content)&1 else b'')
    return struct.pack('<4sI',b'RIFF',len(body))+body,dict(sample_rate=rate,frames=end,loop_start=start,loop_end=end,source_peak=peak,source_rms=rms,gain=gain)
def main():
    if (ROOT/'build/native-proof/.probe-running').exists():raise ValueError('Stop native sessions before preparing audio')
    renderer=prepare_tools();metadata=json.loads((CACHE/'source.json').read_text());audio=CACHE/'disc/AudioRes'
    needed=['data/nintendo.szs','AudioRes/Seqs/sequence.arc','AudioRes/Banks/w1stLoad_0.aw','AudioRes/Banks/w2ndLoad_0.aw']+[f'AudioRes/Banks/wScene_{i}.aw' for i in range(22)]
    if any(not (CACHE/'disc'/p).exists() for p in needed):
        extract(Path(metadata['source']),CACHE,list(dict.fromkeys([v['path'] for v in metadata['extracted']]+needed)))
    aaf=next((CACHE/'archives/nintendo').rglob('msound.aaf'));alias=audio/'msound.aaf'
    if not alias.exists():os.link(aaf,alias)
    if digest(alias)!=digest(aaf):raise ValueError('Audio bank metadata differs')
    output=CACHE/'delfino-render.wav';log=CACHE/'delfino-render.log'
    run([renderer,f'--audiores-directory={audio}','k_dolpic.com','--disable-track=15','--sample-rate=32000','--time-limit=180','--debug-flags=0',f'--output-filename={output}'],log)
    loops=[int(v) for v in re.findall(r'M3D BMS LOOP track=-1 target=\d+ sample=(\d+)',log.read_text())]
    if len(loops)<2:raise ValueError('A complete source loop was not observed')
    wav,report=loop_wav(output.read_bytes(),loops[:2]);target=CACHE/'delfino_plaza.wav';target.write_bytes(wav)
    report.update(sequence='k_dolpic.com',renderer_revisions=PINS,renderer_sha256=digest(renderer),
        fidelity='Source JAudio sequence and wave/instrument banks, software synthesis; not bit-exact DSP',
        files={str((CACHE/'disc'/p).relative_to(CACHE)):digest(CACHE/'disc'/p) for p in needed},
        wav_sha256=digest(target),script_sha256=digest(source_file('sunshine_music.py')))
    (CACHE/'music-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
