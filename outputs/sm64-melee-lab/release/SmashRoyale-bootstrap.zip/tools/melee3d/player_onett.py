"""Verified private Onett bank installation and native stage-selection wiring."""
import argparse,hashlib,json,os,shutil,sys,tempfile
from pathlib import Path
from player_paths import payload

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def verify_onett(art,overlay,purpose=None):
    art=Path(art).resolve();overlay=Path(overlay).resolve()
    report=json.loads((art/'report.json').read_text());identity=digest(art/'GrOt.dat')
    if report.get('output_sha256')!=identity:raise ValueError('Onett art archive differs from its build report')
    physics=json.loads((overlay/'overlay-report.json').read_text())
    if physics.get('render_only') and purpose!='render':raise ValueError('Render-only Onett bank cannot launch play')
    if physics.get('diagnostic_only') and purpose=='play':raise ValueError('Diagnostic Onett route subset cannot launch play')
    if physics.get('archive_sha256')!=identity:raise ValueError('Onett collision was built for a different art revision')
    region=physics.get('playable_region');traffic=physics.get('files',{}).get('onett.trf')
    if region and region.get('sha256')!=digest(art/'playable-region.json'):raise ValueError('Onett playable boundary differs from its art contract')
    if (overlay/'onett.trf').exists() and not traffic:raise ValueError('Onett traffic bank is missing its recorded identity')
    names=('onett.ovl','delfino.dln')+(('onett.reg',)if region else())+(('onett.trf',)if traffic else())
    for name in names:
        if physics.get('files',{}).get(name)!=digest(overlay/name):raise ValueError('Onett collision/navigation hash mismatch: '+name)
    if physics.get('replaced_original_surfaces',[])not in([], [25]):raise ValueError('Unsupported Onett source-ground replacement declaration')
    return dict(art=report,overlay=physics,archive_sha256=identity)

def find_bank(installation):
    registered=Path(installation).parent/'stages/onett'
    if registered.exists():return registered/'art',registered/'overlay'
    from player_install import DEFAULT
    if not getattr(sys,'frozen',False) and Path(installation).resolve()==DEFAULT.resolve():
        local=payload()/'build/map-lab/maps/onett'
        if (local/'art/report.json').is_file() and (local/'overlay/overlay-report.json').is_file():return local/'art',local/'overlay'
    return None

def configure(installation,metadata,profile,env):
    bank=find_bank(installation)
    if bank is None:return
    art,overlay=bank;source=verify_onett(art,overlay,'play')
    from player_stage_preview import native_menu_assets,preview
    native_menu_assets(installation,metadata)
    directory=Path(profile)/'stage-files';directory.mkdir(exist_ok=True)
    imported=Path(installation)/'akaneia/files'
    for source_file in imported.rglob('*'):
        if not source_file.is_file() or source_file.name in ('GrOt.dat','GrOt.usd'):continue
        target=directory/source_file.relative_to(imported);target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():
            if os.path.samefile(source_file,target):continue
            target.unlink()
        try:os.link(source_file,target)
        except OSError:shutil.copy2(source_file,target)
    for name in ('GrOt.dat','GrOt.usd'):
        target=directory/name
        if not target.is_file() or digest(target)!=source['archive_sha256']:
            target.unlink(missing_ok=True);shutil.copy2(art/'GrOt.dat',target)
    env.update(MELEE_FILES_DIR=str(directory),MELEE3D_NATIVE_ONETT_OVERLAY=str(overlay.resolve()),
               MELEE3D_NATIVE_ONETT_PREVIEW=str(preview(Path(installation).parent/'ui-cache',stage='onett')))
    if source['overlay'].get('replaced_original_surfaces')==[25]:env['MELEE3D_NATIVE_ONETT_REPLACE_GROUND']='1'

def install(installation,art,overlay):
    source=verify_onett(art,overlay,'play');target=Path(installation).parent/'stages/onett'
    if target.exists():
        current=verify_onett(target/'art',target/'overlay','play')
        if current['archive_sha256']==source['archive_sha256'] and current['overlay']['files']==source['overlay']['files']:return target
        raise ValueError('Preserve the installed Onett revision before installing another bank: '+str(target))
    target.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.onett-',dir=target.parent)as temporary:
        staged=Path(temporary)/'bank';staged.mkdir();shutil.copytree(art,staged/'art');shutil.copytree(overlay,staged/'overlay')
        verify_onett(staged/'art',staged/'overlay','play');staged.rename(target)
    return target

def main():
    from player_install import DEFAULT
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--installation',type=Path,default=DEFAULT)
    p.add_argument('--art',type=Path,required=True);p.add_argument('--overlay',type=Path,required=True);a=p.parse_args()
    print(install(a.installation,a.art,a.overlay))
if __name__=='__main__':main()
