#!/usr/bin/env python3
"""Prepare a fresh native Mac checkout from a verified local Melee ISO.

Downloads official mod patches and pinned open-source build dependencies.
Private patched images, extracted assets and generated banks stay in build/.
No historical Dolphin installation or transferred compiler caches are needed.
"""
import argparse
import hashlib
from pathlib import Path
import shutil
import subprocess
import tempfile
import urllib.request
import zipfile

from native_compatibility import ROOT, WORK, SOURCES, sha
from inspect_walz0 import REFERENCE_SHA256, PAYLOAD_OFFSET, PAYLOAD_SIZE, PAYLOAD_SHA256
from prepare_akaneia import BASE_MD5, prepare, verify
from player_install import extract_gamecube

REFERENCE_URL='https://github.com/walz0/Melee-3D/releases/download/v1.0/Melee3D.v1.0.zip'
AKANEIA_DOL_SHA256='f604e1399f2dc88e2fbbaa2b3441867ca34d00b99b82e16bee4e4ef108604805'


def prepare_reference(melee):
    directory=ROOT/'build/references';directory.mkdir(parents=True,exist_ok=True)
    image=directory/'walz0-v1.0.iso'
    if not image.exists():
        archive=directory/'Melee3D.v1.0.zip'
        if not archive.exists():
            with tempfile.TemporaryDirectory(prefix='.reference-download-',dir=directory) as temporary:
                downloaded=Path(temporary)/'release.zip'
                with urllib.request.urlopen(REFERENCE_URL,timeout=120) as source,downloaded.open('wb') as output:
                    shutil.copyfileobj(source,output)
                archive.hardlink_to(downloaded)
        with tempfile.TemporaryDirectory(prefix='.reference-patch-',dir=directory) as temporary:
            temporary=Path(temporary);patch=temporary/'patch.xdelta';patched=temporary/'patched.iso'
            with zipfile.ZipFile(archive) as release:
                member=release.getinfo('Melee3D-Slippi/patch.xdelta')
                if member.file_size>8*1024*1024:raise ValueError('Unexpected reference patch size')
                patch.write_bytes(release.read(member))
            subprocess.run(['xdelta3','-d','-s',str(melee),str(patch),str(patched)],check=True)
            if sha(patched)!=REFERENCE_SHA256:raise ValueError('Reference image checksum mismatch')
            image.hardlink_to(patched)
    if sha(image)!=REFERENCE_SHA256:raise ValueError('Existing reference image checksum mismatch; preserve and inspect it')
    with image.open('rb') as source:
        source.seek(PAYLOAD_OFFSET);payload=source.read(PAYLOAD_SIZE)
    if hashlib.sha256(payload).hexdigest()!=PAYLOAD_SHA256:raise ValueError('Reference payload checksum mismatch')
    destination=directory/'walz0-payload.bin'
    if destination.exists():
        if sha(destination)!=PAYLOAD_SHA256:raise ValueError('Existing payload changed; preserve and inspect it')
    else:
        with destination.open('xb') as output:output.write(payload)
    from native_reference import reference_source
    files,identities=reference_source()
    print('Verified reference assets:',files,len(identities),'stages',flush=True)


def prepare_sources():
    WORK.mkdir(parents=True,exist_ok=True)
    for name in ('melee-pc','gd-melee'):
        repository,_,revision=SOURCES[name];directory=WORK/name
        if not directory.exists():
            subprocess.run(['git','clone','--filter=blob:none','--no-checkout',f'https://github.com/{repository}.git',str(directory)],check=True)
            subprocess.run(['git','checkout','--detach',revision],cwd=directory,check=True)
        actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=directory,text=True).strip()
        if actual!=revision:raise ValueError('Existing dependency has a different revision; preserve it: '+str(directory))
        subprocess.run(['git','submodule','update','--init','--recursive','--jobs','8'],cwd=directory,check=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--melee',type=Path,required=True)
    parser.add_argument('--sources',action='store_true',help='Also fetch the two pinned native source checkouts')
    parser.add_argument('--music-tools',action='store_true',help='Also prepare the pinned Sunshine music converter')
    args=parser.parse_args();melee=args.melee.expanduser().resolve()
    verify(melee,BASE_MD5)
    patched=prepare(melee,ROOT/'build/akaneia')
    destination=ROOT/'build/akaneia/disc'
    if not destination.exists():
        with tempfile.TemporaryDirectory(prefix='.akaneia-extract-',dir=destination.parent) as temporary:
            staged=Path(temporary)/'disc';extract_gamecube(patched,staged)
            if sha(staged/'sys/main.dol')!=AKANEIA_DOL_SHA256:raise ValueError('Akaneia executable checksum mismatch')
            if destination.exists():raise ValueError('Extraction destination appeared; refusing to replace it')
            staged.rename(destination)
    if sha(destination/'sys/main.dol')!=AKANEIA_DOL_SHA256:raise ValueError('Existing Akaneia extraction changed')
    prepare_reference(melee)
    if args.sources:prepare_sources()
    if args.music_tools:
        from sunshine_music import prepare_tools
        print('Music converter:',prepare_tools(),flush=True)
    print('Native inputs ready. Build with python3.13 tools/melee3d/native_mac.py build',flush=True)


if __name__=='__main__':main()
