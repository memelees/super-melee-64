"""Content contracts for the supported owned-disc Sunshine conversions.

Hash data only: no donor assets or local paths. Exact native full rounds,
targeted routes/recovery and goop escape passed for these revisions.
Packaging must retain these contracts; changed output requires new acceptance.
"""
ACCEPTED_BANKS = {'bianco': {'files': {'delfino.dlv': '497163115d26c7c3acc21e9ac47a0e630ca712d3ecc8ca1953baac1b4c03f691',
                      'delfino.dlc': '764cdd5c8de8cf9f051e06595c2b005c39c59f19f7e396870709e63b9660d467',
                      'delfino.dls': '6eccdb3fe3eb37b6612d498f13138f8baa77676144384568e59a574e345d5444',
                      'delfino.dlg': 'c43bf03e5e76ea24c3b8294135c4513d98f8f386f865514e27ab66ffa0881d2d',
                      'delfino.dln': 'a080db383099dd1c481d18ebe94d570df289661df5d6299341d5f773dad35897'},
            'acceptance': {'full_round_32_cpus': True,
                           'routes': True,
                           'recovery': True,
                           'goop_escape': True}},
 'sirena': {'files': {'delfino.dlv': 'bc31f53d60ff0247e56050602863149a5b2b9a1ee332f3bf8f20a08236615acf',
                      'delfino.dlc': 'd0b9923decf551afaf0d42a05bcd866fe951711cd19a664bc29aa4bb34cd74c6',
                      'delfino.dls': '9840c71478e573dd068ad8dc5c0de9b55d991359ceeef8459aea4b479d02fccc',
                      'delfino.dlg': 'afd63d8ff2026cb8fdd11d6309c6158d79c607792449075632219b5161b0ce5b',
                      'delfino.dln': 'f2ec5e2426bc262c2db21f9bfa655c879a316ab9a23f375cdd7c59907ec78b36'},
            'acceptance': {'full_round_32_cpus': True,
                           'routes': True,
                           'recovery': True,
                           'goop_escape': True}},
 'pianta': {'files': {'delfino.dlv': '1332fd40d751b05750541992b82d58a1d1106ee3f1e18f85cc40b9d82f545129',
                      'delfino.dlc': '998d22c23a25500561bfcf29d22de60302af1bac43f835d76cc95d1a93982f04',
                      'delfino.dls': '2b5358251772d41cc14e7bd42ba27b03b516ad452db2d1328aa22aeef2fdceab',
                      'delfino.dlg': 'e3405bc374d55de7c4242cae38f6899fafb4e9302071e7ebe3aef06638c0fcaa',
                      'delfino.dln': 'bca2e250759bc64fae42996ffe0fdd74bf3b85f04040af9665d86f1bc8723ad6'},
            'acceptance': {'full_round_32_cpus': True,
                           'routes': True,
                           'recovery': True,
                           'goop_escape': True}}}
