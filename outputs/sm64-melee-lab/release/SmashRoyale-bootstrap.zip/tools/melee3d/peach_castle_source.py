"""Read rigid native HSD Castle geometry without exporting or replacing assets.

Flag cloth is deliberately excluded from physical geometry; its original HSD
skinning and animation remain in the donor archive. Positions, texture UVs and
vertex colours use the exact declarations/display lists in the local archive.
"""
import math
from sunshine_scene import Reader, matrix, multiply, transform
def normal(points):
    a,b,c=points;u=[b[k]-a[k]for k in range(3)];v=[c[k]-a[k]for k in range(3)]
    n=(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])
    length=math.sqrt(sum(q*q for q in n))
    return tuple(q/length for q in n)if length>1e-8 else None


def triangles(archive, groups=(3,4)):
    r=Reader(archive.payload);table=r.u32(archive.public['map_head']+8)
    scale=r.get('f',archive.public['grGroundParam'])[0]
    root=[[scale,0,0,0],[0,scale,0,0],[0,0,scale,0],[0,0,0,1]]
    result=[]
    def read_array(attr,cnt,ctype,shift,stride,start,index):
        if attr==9:count=2 if cnt==0 else 3
        elif attr in (13,14,15,16,17,18,19,20):count=1 if cnt==0 else 2
        elif attr==10:count=3 if cnt==0 else 9
        else:raise ValueError('Unsupported indexed Castle attribute '+str(attr))
        fmt={0:'B',1:'b',2:'H',3:'h',4:'f'}[ctype]
        values=r.get(str(count)+fmt,start+index*stride)
        return tuple(v/(1<<shift)if ctype!=4 else v for v in values)
    def colour(p,ctype):
        if ctype==3:
            word=r.u16(p);return tuple(((word>>s)&15)*17 for s in (12,8,4,0)),2
        if ctype==5:return tuple(r.data[p:p+4]),4
        if ctype==1:return tuple(r.data[p:p+3])+(255,),3
        if ctype==0:
            word=r.u16(p);return((word>>11)*255/31,((word>>5)&63)*255/63,(word&31)*255/31,255),2
        raise ValueError('Unsupported Castle vertex colour format '+str(ctype))
    for group in groups:
        def walk(o,parent):
            while o:
                mt=multiply(parent,matrix(r.get('3f',o+44),r.get('3f',o+20),r.get('3f',o+32)))
                dobj=r.u32(o+16)
                while dobj:
                    m=r.u32(dobj+8);t=r.u32(m+8);image=r.u32(t+76)if t else 0;ptr=r.u32(image)if image else None
                    symbols=[k for k,v in archive.public.items()if v==ptr];po=r.u32(dobj+12)
                    while po:
                        flags=r.u16(po+12)
                        if flags&0x3000 or r.u32(po+20):
                            if not symbols or not all('Flag' in s for s in symbols):raise ValueError('Unsupported structural Castle skinning')
                            po=r.u32(po+4);continue
                        decl=[];p=r.u32(po+8)
                        while r.u32(p)!=255:
                            decl.append((*r.get('4I',p),r.data[p+16],r.u16(p+18),r.u32(p+20)));p+=24
                        p=r.u32(po+16);end=p+r.u16(po+14)*32
                        while p<end:
                            op=r.data[p];p+=1
                            if not op:continue
                            primitive=op&0xf8
                            if primitive not in (0x80,0x90,0x98,0xa0):raise ValueError('Unsupported Castle GX primitive')
                            n=r.u16(p);p+=2;vertices=[]
                            for _ in range(n):
                                point=None;uv=(0.,0.);rgba=(255,255,255,255)
                                for attr,typ,cnt,ctype,shift,stride,start in decl:
                                    if typ==0:continue
                                    if typ==1 and attr<=8:p+=1
                                    elif typ==1 and attr in (11,12):rgba,size=colour(p,ctype);p+=size
                                    elif typ in (2,3):
                                        index=r.data[p]if typ==2 else r.u16(p);p+=typ-1
                                        values=read_array(attr,cnt,ctype,shift,stride,start,index)
                                        if attr==9:point=transform(mt,(*values,0)[:3])
                                        if attr==13:uv=(*values,0)[:2]
                                    else:raise ValueError('Unsupported Castle direct attribute')
                                if point is None:raise ValueError('Missing Castle position')
                                vertices.append([*point,*uv,*rgba])
                            if primitive==0x80:
                                if n%4:raise ValueError('Incomplete Castle GX quad')
                                ids=[v for i in range(0,n,4)for v in((i,i+1,i+2),(i,i+2,i+3))]
                            elif primitive==0x90:
                                if n%3:raise ValueError('Incomplete Castle GX triangle')
                                ids=[(i,i+1,i+2)for i in range(0,n,3)]
                            elif primitive==0x98:ids=[(i,i+1,i+2)if i%2==0 else(i+1,i,i+2)for i in range(n-2)]
                            else:ids=[(0,i,i+1)for i in range(1,n-1)]
                            for indices in ids:
                                vs=[vertices[i]for i in indices];ps=[v[:3]for v in vs];nrm=normal(ps)
                                if nrm:result.append(dict(group=group,joint=o,dobj=dobj,material=m,vertices=vs,points=ps,normal=nrm,symbols=symbols,pobj_flags=flags))
                        if p!=end:raise ValueError('Castle display list extent mismatch')
                        po=r.u32(po+4)
                    dobj=r.u32(dobj+4)
                if r.u32(o+8):walk(r.u32(o+8),mt)
                o=r.u32(o+12)
        walk(r.u32(table+group*52),root)
    return result
