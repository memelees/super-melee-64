"""Installer boundary: prepare private data, then publish the playable app."""
import json,os,shutil,subprocess,sys,tempfile,time,uuid
from pathlib import Path


def publish_app(template,target):
    template,target=Path(template).resolve(),Path(target).expanduser().absolute()
    if not template.is_dir() or target==template or template in target.parents:
        raise ValueError('Choose an application destination outside the installer.')
    if sys.platform=='darwin':
        commands=subprocess.check_output(['ps','-axo','comm'],text=True).splitlines()
        if any(c.startswith(str(target)+'/') for c in commands):
            raise ValueError('Close Smash Royale, then install the update.')
    target.parent.mkdir(parents=True,exist_ok=True)
    backup=None
    with tempfile.TemporaryDirectory(prefix='.big-melee-install-',dir=target.parent) as folder:
        staged=Path(folder)/target.name
        shutil.copytree(template,staged,symlinks=True)
        if sys.platform=='darwin':
            subprocess.run(['codesign','--verify','--deep','--strict',str(staged)],check=True,capture_output=True)
        else:
            # The downloaded installer and the installed game share a runtime,
            # but the installed entry point always starts the game directly.
            setup=staged/'Smash Royale Setup.exe'
            if setup.exists():setup.rename(staged/'Smash Royale.exe')
            (staged/'game-app.json').write_text('{"version":1}\n')
        if target.exists():
            if target.is_symlink() or not target.is_dir():raise ValueError('Application destination is not a folder.')
            backup=target.with_name('.'+target.name+'.previous-'+uuid.uuid4().hex[:8])
            target.rename(backup)
        try:staged.rename(target)
        except BaseException:
            if backup:backup.rename(target)
            raise
    return target


def install_game(job,progress):
    from player_install import ready_install,prepare_install
    from player_launcher import load_settings,save_settings
    from player_paths import user_directory
    from player_play import binary_path,environment
    from player_graphics import prepare_graphics
    from player_session import session_lock
    home=Path(job.get('home') or user_directory());home.mkdir(parents=True,exist_ok=True)
    config=home/'launcher.json';settings=load_settings(config)
    if job.get('reuse'):
        installation=Path(settings.get('installation') or home/'game-data')
        metadata=ready_install(installation,progress)
    else:
        installation=home/'installations'/('game-'+uuid.uuid4().hex[:12])
        prepare_install(Path(job['melee']),Path(job['sunshine']),installation,
                        patch=Path(job['patch']) if job.get('patch') else None,
                        progress=lambda v,m:progress(v*.75,m))
        metadata=ready_install(installation)
    profile=home/'profiles/offline';env=environment(installation,metadata,profile,32,'sonic','hill','medium')
    progress(76,'Preparing graphics…')
    with session_lock(profile):
        prepare_graphics(binary_path(),env,profile,lambda v,m:progress(76+v*.28,m))
    progress(97,'Creating your game app…')
    target=publish_app(job['template_app'],job['target_app'])
    settings['installation']=str(installation)
    save_settings(config,settings)
    if sys.platform=='win32':
        shortcuts(target)
    progress(100,'Ready to play')
    return str(target)


def shortcuts(target):
    """Per-user Windows shortcuts require neither admin rights nor a service."""
    exe=Path(target)/'Smash Royale.exe'
    # Paths are supplied as environment data, never interpolated into PowerShell.
    script='''$shell=New-Object -ComObject WScript.Shell
$places=@([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('StartMenu'))
foreach($folder in $places){
 $link=$shell.CreateShortcut((Join-Path $folder 'Smash Royale.lnk'))
 $link.TargetPath=$env:BIG_MELEE_GAME_EXE
 $link.WorkingDirectory=[IO.Path]::GetDirectoryName($env:BIG_MELEE_GAME_EXE)
 $link.Save()
}'''
    subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],
                   env=dict(os.environ,BIG_MELEE_GAME_EXE=str(exe)),check=True,capture_output=True)
