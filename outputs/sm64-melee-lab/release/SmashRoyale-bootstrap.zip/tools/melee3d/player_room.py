#!/usr/bin/env python3
"""Player-hosted, bounded input relay for the native multiplayer preview.

No game files or game-state snapshots cross this connection. TCP and a small
input delay are deliberately the first LAN/VPN proof, not rollback netcode.
The host is a player process, not a service maintained by the mod author.
"""
import argparse
import hashlib
import hmac
import json
import secrets
import selectors
import socket
import struct
import time
from pathlib import Path

MAGIC = b'M3DROOM1'
PAD_BYTES = 12
MAX_PLAYERS = 32
TAG_BYTES = 16


def tag(key, data, size=TAG_BYTES):
    return hashlib.blake2b(data, key=key, digest_size=size).digest()


def sealed(key, data):
    return data + tag(key, data)


def unseal(key, data):
    if len(data) < TAG_BYTES or not hmac.compare_digest(data[-TAG_BYTES:], tag(key, data[:-TAG_BYTES])):
        raise ValueError('Invalid room message authentication')
    return data[:-TAG_BYTES]


def read_exact(sock, size):
    result = bytearray()
    while len(result) < size:
        part = sock.recv(size - len(result))
        if not part:
            raise ConnectionError('Player disconnected')
        result.extend(part)
    return bytes(result)


def validate_pad(pad):
    buttons, x, y, cx, cy, left, right, yaw, reserved = struct.unpack('!HbbbbBBHH', pad)
    if buttons & ~0x1f7f or -128 in (x, y, cx, cy) or reserved > 1:
        raise ValueError('Invalid controller input')


class Timeline:
    """Exactly one immutable input per human per frame, with bounded lookahead."""
    def __init__(self, players, delay, seed):
        if not 2 <= players <= MAX_PLAYERS or not 1 <= delay <= 12 or not 0 <= seed <= 0xffffffff:
            raise ValueError('Requires 2–32 humans, 1–12 delay frames and a uint32 seed')
        self.players, self.delay, self.seed = players, delay, seed
        self.samples = [0] * players
        self.next_frame = 0
        self.inputs = {f: [bytes(PAD_BYTES)] * players for f in range(delay)}
        self.hashes = {}
        self.terminal = False

    def submit(self, seat, sample, checksum, pad):
        if not 0 <= seat < self.players or sample != self.samples[seat]:
            raise ValueError('Duplicate, skipped or out-of-order player input')
        if sample > self.next_frame + 64:
            raise ValueError('Player exceeded the input window')
        validate_pad(pad)
        hashes = self.hashes.setdefault(sample, {})
        hashes[seat] = checksum
        if len(hashes) == self.players:
            if len(set(hashes.values())) != 1:
                raise ValueError(f'Simulation diverged at frame {sample}: ' +
                                 ', '.join(f'{s}={h:08x}' for s, h in sorted(hashes.items())))
            del self.hashes[sample]
        self.inputs.setdefault(sample + self.delay, [None] * self.players)[seat] = pad
        self.samples[seat] += 1

    def ready(self):
        frames = []
        while not self.terminal and self.next_frame in self.inputs and all(p is not None for p in self.inputs[self.next_frame]):
            f = self.next_frame
            # The deterministic reseed keeps asynchronous audio/load completion
            # from changing the seed inherited by the next simulation tick.
            seed = (self.seed + f * 0x9e3779b9) & 0xffffffff
            pads=self.inputs.pop(f)
            ending=[struct.unpack('!H',p[10:12])[0] for p in pads]
            if any(ending) and not all(ending):raise ValueError(f'Players disagreed about round completion at frame {f}')
            self.terminal=all(ending)
            frames.append(struct.pack('!IIHH', f, seed, self.players, int(self.terminal)) + b''.join(pads))
            self.next_frame += 1
        return frames


class Room:
    def __init__(self, bind, players, key, compatibility, *, delay=4, seed=1,
                 join_timeout=180, tick_timeout=15, max_frames=0):
        if len(key) != 32 or len(compatibility) != 32:
            raise ValueError('Room key and compatibility identity must be 32 bytes')
        self.timeline = Timeline(players, delay, seed)
        self.key, self.compatibility = key, compatibility
        self.join_timeout, self.tick_timeout, self.max_frames = join_timeout, tick_timeout, max_frames
        self.listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.listener.bind(bind)
        self.listener.listen(MAX_PLAYERS)
        self.address = self.listener.getsockname()
        self.clients = {}
        self.session_keys = {}
        self.result = dict(passed=False, humans=players, frames=0, rejected=0,
                           scope='Authenticated input transport; not 32 rendered games or WAN acceptance')

    def run(self):
        started = time.monotonic()
        selector = selectors.DefaultSelector()
        try:
            # An unauthenticated connection gets at most one second. A global
            # deadline still bounds the lobby, including repeated bad clients.
            deadline = started + self.join_timeout
            while len(self.clients) < self.timeline.players:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError('Room timed out waiting for players')
                self.listener.settimeout(remaining)
                sock, _ = self.listener.accept()
                try:
                    sock.settimeout(min(1, remaining))
                    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                    challenge = MAGIC + secrets.token_bytes(32)
                    sock.sendall(challenge)
                    hello = read_exact(sock, 68)
                    seat, reserved = struct.unpack('!HH', hello[:4])
                    identity = hello[4:36]
                    if not hmac.compare_digest(hello[36:], tag(self.key, challenge + hello[:36], 32)):
                        raise ValueError('Room key did not match')
                    if reserved or seat >= self.timeline.players or seat in self.clients:
                        raise ValueError('Invalid or occupied player seat')
                    if identity != self.compatibility:
                        raise ValueError('Build, assets, lineup or rules did not match')
                    self.clients[seat] = sock
                    self.session_keys[seat] = tag(self.key, challenge, 32)
                    print(f'Room: player {seat + 1}/{self.timeline.players} connected', flush=True)
                except (OSError, ValueError, ConnectionError):
                    self.result['rejected'] += 1
                    sock.close()
            self.listener.close()
            start = MAGIC + struct.pack('!HHI', self.timeline.players, self.timeline.delay, self.timeline.seed)
            pending, incoming = {}, {}
            for seat, sock in self.clients.items():
                sock.setblocking(False)
                pending[seat] = bytearray(sealed(self.session_keys[seat], start))
                incoming[seat] = bytearray()
                selector.register(sock, selectors.EVENT_READ | selectors.EVENT_WRITE, seat)

            def broadcast(frames):
                for frame in frames:
                    for seat, output in pending.items():
                        packet = sealed(self.session_keys[seat], frame)
                        output.extend(packet)
                        if len(output) > 256 * 1024:
                            raise TimeoutError('A player stopped receiving frames')
                    self.result['frames'] += 1

            broadcast(self.timeline.ready())
            progress = time.monotonic()
            finished = set()
            while True:
                if time.monotonic() - progress > self.tick_timeout:
                    raise TimeoutError('Match stopped: a player stopped sending input')
                if (((self.timeline.terminal and min(self.timeline.samples)>=self.timeline.next_frame) or (self.max_frames and min(self.timeline.samples) >= self.max_frames
                        and self.result['frames'] >= self.max_frames)) and not any(pending.values())):
                    self.result['passed'] = True
                    self.result['reason']='round-complete' if self.timeline.terminal else 'frame-limit'
                    break
                for event, mask in selector.select(.05):
                    sock, seat = event.fileobj, event.data
                    if mask & selectors.EVENT_READ:
                        try:data = sock.recv(4096)
                        except BlockingIOError:continue
                        if not data and (self.timeline.terminal or (self.max_frames and self.timeline.samples[seat] >= self.max_frames)):
                            selector.unregister(sock)
                            finished.add(seat)
                            continue
                        if not data:
                            raise ConnectionError(f'Player {seat + 1} disconnected; match stopped')
                        incoming[seat].extend(data)
                        if len(incoming[seat]) > 8192:
                            raise ValueError('Player exceeded message buffer')
                        while len(incoming[seat]) >= 36:
                            message = unseal(self.session_keys[seat], bytes(incoming[seat][:36]))
                            del incoming[seat][:36]
                            sample, checksum = struct.unpack('!II', message[:8])
                            self.timeline.submit(seat, sample, checksum, message[8:])
                        frames = self.timeline.ready()
                        if self.max_frames:
                            frames = frames[:max(0, self.max_frames - self.result['frames'])]
                        if frames:
                            progress = time.monotonic()
                            broadcast(frames)
                    if mask & selectors.EVENT_WRITE and pending[seat]:
                        try:sent = sock.send(pending[seat])
                        except BlockingIOError:sent = 0
                        del pending[seat][:sent]
                    selector.modify(sock, selectors.EVENT_READ | (selectors.EVENT_WRITE if pending[seat] else 0), seat)
                # A broadcast may have queued data for a socket whose last
                # event disabled writes. Rearm it without a polling send loop.
                for seat, sock in self.clients.items():
                    if seat in finished:
                        continue
                    selector.modify(sock, selectors.EVENT_READ | (selectors.EVENT_WRITE if pending[seat] else 0), seat)
        except (OSError, ValueError, ConnectionError) as error:
            self.result['error'] = str(error)
        finally:
            self.result['seconds'] = round(time.monotonic() - started, 3)
            selector.close()
            self.listener.close()
            for sock in self.clients.values():
                sock.close()
        return self.result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bind', default='127.0.0.1', help='Choose a LAN interface explicitly for other computers')
    p.add_argument('--port', type=int, default=41032)
    p.add_argument('--humans', type=int, default=2)
    p.add_argument('--identity', required=True, help='Compatibility SHA-256 from the matching launch manifest')
    p.add_argument('--key-file', required=True, type=Path, help='Private file containing a 64-digit hex room key')
    p.add_argument('--delay', type=int, default=4)
    p.add_argument('--seed', type=int, default=1)
    p.add_argument('--report', type=Path)
    a = p.parse_args()
    room = Room((a.bind, a.port), a.humans, bytes.fromhex(a.key_file.read_text().strip()),
                bytes.fromhex(a.identity), delay=a.delay, seed=a.seed)
    print(f'Player-hosted room listening on {room.address[0]}:{room.address[1]}', flush=True)
    report = room.run()
    if a.report:
        a.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report['passed'] else 1)


if __name__ == '__main__':
    main()
