#!/usr/bin/env python3
"""Build the pinned GD module loader/interpreter with an explicit Mac memory adapter.

External code stays in build/native-proof; generated runtime files retain the
upstream GPL-2.0-or-later license. Adapters here are GPL-3.0-or-later. This is
the module-execution component, not yet a complete Akaneia fighter integration.
"""
import argparse
import platform
import re
from pathlib import Path
import shutil
import subprocess

from native_compatibility import ROOT, WORK, SOURCES, source_identity, sha, write_json, stage_module

CHARACTERS = ["PlWf.dat", "PlDd.dat", "PlLz.dat", "PlLc.dat", "PlSn.dat", "PlDe.dat", "PlTs.dat"]


def prepare_bridge(include_tests=False, destination=None):
    identity = source_identity("gd-melee")
    if identity["revision"] != SOURCES["gd-melee"][2] or identity["tracked_sources_changed"]:
        raise ValueError("Bridge requires the clean pinned GD source checkout")
    source = WORK / "gd-melee/pc/platform"
    out = Path(destination) if destination is not None else WORK / "mac-bridge"
    out.mkdir(parents=True, exist_ok=True)
    for name in ("gw_ppc.h", "gw_mex_bridge.h", "gw_mex_ftfunction.h", "gw_test.h", "gw_profiler.h"):
        stage_module(source / name, out / name)
    header = (source / "gw.h").read_text()
    seam = "/* ---- byte-swapped access to game memory"
    header = header.replace(seam, '#include "m3d_guest_memory.h"\n#undef memcpy\n#undef memset\n#undef memcmp\n#define memcpy m3d_guest_memcpy\n'
                            '#define memset m3d_guest_memset\n#define memcmp m3d_guest_memcmp\n\n' + seam)
    header = header.replace("return *(const uint8_t *)p;", "uint8_t v; memcpy(&v,p,1); return v;")
    header = header.replace("*(uint8_t *)p = v;", "memcpy(p,&v,1);")
    (out / "gw.h").write_text(header)
    vm = (source / "gw_ppc.c").read_text()
    # An upstream register hexdump may cross one of our deliberately sparse
    # object views and fail itself. Preserve the actual fault before dumping.
    fault='    gw_ppc_dump_state(m, ip);\n    gw_panic("ppc: guest access violation'
    if vm.count(fault)!=1:raise ValueError('Unexpected interpreter access-fault seam')
    vm=vm.replace(fault,'    gw_log("ppc: original access fault ip=0x%08X ea=0x%08X",ip,ea);\n'+fault)
    if not include_tests:
        vm = vm.split("/* ---- end-to-end test ")[0]
    else:
        cases=["ppc_fp_aform_decode","ppc_fcmpu_orderings","ppc_xoris_int_to_float",
               "ppc_fp_indexed","ppc_fctiwz_stfiwx","ppc_update_indexed_and_brx"]
        registry="void gw_ppc_tests_register(void) {\n" + "".join(
            f'    gw_test_register("{case}", test_{case});\n' for case in cases) + "}\n"
        vm=re.sub(r"void gw_ppc_tests_register\(void\) \{[\s\S]*?\n\}",registry,vm)
    before = "sp = gw_ppc_host_args_in(&hb, guest_fn, a, na, sp, (uint32_t) (uintptr_t) &saved);"
    if vm.count(before) != 1:
        raise ValueError("Unexpected interpreter host-stack seam")
    vm = vm.replace(before, "/* DELFINO: callers pass explicit guest handles, never native stack addresses. */\n"
                    "    memset(&hb, 0, sizeof hb);")
    # A few original command-grab helpers retain their body behind a spatial
    # adapter. Internal direct/conditional/indirect calls must honor the same
    # exact typed registry as callbacks arriving from the native engine.
    branch = "if (gw_ppc_in_blob(m, target)) {"
    if vm.count(branch) != 3:
        raise ValueError("Unexpected interpreter branch dispatch seams")
    vm = vm.replace(branch, "if (gw_ppc_in_blob(m, target) && !m3d_native_is_bound(target)) {")
    vm = vm.replace('#include "gw_ppc.h"', '#include "gw_ppc.h"\n#include "m3d_native_calls.h"')
    seam = "static void gw_ppc_bridge_call(gw_ppc_machine *m, uint32_t guest_addr) {"
    if vm.count(seam) != 1:
        raise ValueError("Unexpected interpreter native-call seam")
    vm = vm.replace(seam, seam + "\n    if (m3d_native_invoke(guest_addr, &m->cpu)) return; // DELFINO: typed host ABI")
    # x86 extended signatures pack doubles/aggregates into stack words. They
    # must receive typed adapters before being admitted on Apple Silicon.
    vm = vm.replace("if (sig.ext != NULL) {", 'if (sig.ext != NULL) {\n'
                    '        gw_panic("native Mac bridge requires a typed extended-signature adapter");')
    seam="    if (sig.ext != NULL) {"
    vm=vm.replace(seam,'    if (sig.ext || sig.float_args || sig.ret_float)\n'
                  '        gw_panic("Native floating/extended call must use the typed registry");\n'+seam)
    vm += "\nuint32_t m3d_ppc_pc(void) { return gw_ppc_m.cpu.pc ? gw_ppc_m.cpu.pc-4 : 0; }\n"
    (out / "gw_ppc.c").write_text(vm)
    loader = (source / "gw_mex_ftfunction.c").read_text().split("/* ---- tests")[0]
    # Keep the complete loader, remove only its executable test registry.
    if "void gw_ftfunction_tests_register" in loader:
        marker = loader.find("/* ----", loader.find("void gw_ftfunction_free"))
        if marker < 0:
            raise ValueError("Unexpected loader test boundary")
        loader = loader[:marker]
    (out / "gw_mex_ftfunction.c").write_text(loader)
    for name in ("m3d_guest_memory.h", "m3d_guest_memory.c", "m3d_native_calls.h", "m3d_native_calls.c", "m3d_bridge_probe.c", "m3d_vm.h", "m3d_vm.c", "m3d_article_probe.c", "m3d_scene_pool.h"):
        stage_module(ROOT / "native/mac" / name, out / name)
    shutil.copy2(WORK / "gd-melee/pc/LICENSE", out / "UPSTREAM-LICENSE")
    return out, identity


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["build", "run", "matrix", "isa", "articles"])
    parser.add_argument("--character", choices=CHARACTERS, default="PlSn.dat")
    args = parser.parse_args()
    out, source = prepare_bridge(args.command=="isa",destination=WORK/"mac-articles" if args.command=="articles" else None)
    executable="article-probe" if args.command=="articles" else "isa-probe" if args.command=="isa" else "bridge-probe"
    command = ["clang", "-arch", "arm64", "-mmacosx-version-min=15.0", "-std=c11", "-O2", "-g", "-ffunction-sections", "-fdata-sections",
               "-Wno-unused-function", "-Wno-incompatible-function-pointer-types",
               "gw_ppc.c", "gw_mex_ftfunction.c", "m3d_guest_memory.c", "m3d_native_calls.c", "m3d_bridge_probe.c",
               "-lffi", "-Wl,-dead_strip", "-o", executable]
    if args.command=="articles":
        command[command.index("m3d_bridge_probe.c"):command.index("m3d_bridge_probe.c")+1]=["m3d_article_probe.c","m3d_vm.c"]
    if args.command=="isa": command.insert(1,"-DM3D_VM_TESTS=1")
    subprocess.run(command, cwd=out, check=True)
    write_json(out / ("article-build.json" if args.command=="articles" else "isa-build.json" if args.command=="isa" else "build.json"), {"source": source, "architecture": platform.machine(),
               "executable_sha256": sha(out / executable),
               "adapter_files": {p.name: sha(p) for p in (ROOT / "native/mac").glob("m3d_guest_memory.*")},
               "call_adapter_files": {p.name: sha(p) for p in (ROOT / "native/mac").glob("m3d_native_calls.*")},
               "probe_sha256": sha(ROOT / "native/mac/m3d_bridge_probe.c"),
               "scope": "Native arm64 module execution; not a complete in-game character"})
    if args.command == "articles":
        import struct
        from native_roster import Archive
        files=ROOT/'build/akaneia/disc/files'
        result=subprocess.run([str(out/executable),str(files)],cwd=out,capture_output=True,text=True,timeout=20)
        (out/'articles.log').write_text(result.stdout+result.stderr)
        passed=result.returncode==0 and 'M3D ARTICLE LOADER PASS slots=24 modules=22 holes=2 recovered_sizes=3' in result.stdout
        a=Archive(files/'PlSn.dat'); top=a.public['itFunction']; f=a.word(top+4)
        cases=[('bad-count',top,17,'Invalid article count/extent'),
               ('bad-code',f,a.size,'Character archive pointer outside data section'),
               ('bad-slot',a.word(f+12),15,'Invalid article logic slot'),
               ('bad-target',a.word(f+12)+4,a.word(f+20),'Invalid article logic slot')]
        negatives=[]
        for name,offset,value,message in cases:
            directory=out/name; directory.mkdir(exist_ok=True)
            for filename in CHARACTERS+['MxDt.dat']:
                target=directory/filename
                if target.exists() or target.is_symlink():target.unlink()
                if filename=='PlSn.dat':
                    data=bytearray(a.data); struct.pack_into('>I',data,32+offset,value); target.write_bytes(data)
                else:target.symlink_to(files/filename)
            failure=subprocess.run([str(out/executable),str(directory)],cwd=out,capture_output=True,text=True,timeout=20)
            (out/(name+'.log')).write_text(failure.stdout+failure.stderr)
            negatives.append({'case':name,'passed':failure.returncode==2 and message in failure.stderr,'exit_code':failure.returncode})
        report={'passed':passed and all(n['passed'] for n in negatives),'slots':24,'modules':22,'holes':2,
                'recovered_sizes':3,'negative_controls':negatives,'executable_sha256':sha(out/executable),
                'production_loader_sha256':sha(ROOT/'native/mac/m3d_vm.c'),
                'scope':'Original article relocation/state-table bounds, not native move correctness'}
        write_json(out/'suite.json',report)
        print(result.stdout)
        print(report)
        if not report['passed']:raise SystemExit(1)
    elif args.command == "isa":
        result=subprocess.run([str(out / executable)],cwd=out,capture_output=True,text=True,timeout=20)
        (out / "isa.log").write_text(result.stdout+result.stderr)
        passed=result.returncode==0 and "M3D ISA TESTS pass=6 fail=0 total=6" in result.stdout
        write_json(out / "isa-suite.json",{"passed":passed,"exit_code":result.returncode,
                   "executable_sha256":sha(out / executable),"scope":"Six upstream pure instruction/memory tests on arm64"})
        print(result.stdout)
        if not passed: raise SystemExit(1)
    elif args.command == "run":
        disc_file = ROOT / "build/akaneia/disc/files" / args.character
        subprocess.run([str(out / "bridge-probe"), str(disc_file)], cwd=out, check=True, timeout=20)
    elif args.command == "matrix":
        results = []
        for name in CHARACTERS:
            disc_file = ROOT / "build/akaneia/disc/files" / name
            result = subprocess.run([str(out / "bridge-probe"), str(disc_file)], cwd=out,
                                    capture_output=True, text=True, timeout=20)
            (out / (name + ".log")).write_text(result.stdout + result.stderr)
            passed = (result.returncode == 0 and f"M3D BRIDGE PASS original_reset_attributes character={name} host_pointer_bytes=8 objects=16" in result.stdout
                      and "M3D BRIDGE ABI PASS float_double_integer_pointer_size_return_typed_object" in result.stdout
                      and "M3D BRIDGE ABI PASS signed_unsigned_byte_halfword" in result.stdout
                      and "M3D BRIDGE ABI PASS typed_callback_object_contract" in result.stdout
                      and "M3D BRIDGE ABI PASS ten_mixed_register_arguments" in result.stdout
                      and "M3D BRIDGE ABI PASS page_hints_preserve_alias_field_extent_retirement" in result.stdout
                      and "M3D BRIDGE ABI PASS exact_translation_cache_alias_extent_invalidation" in result.stdout
                      and "M3D BRIDGE ABI PASS full_eabi_context_adapter" in result.stdout
                      and "M3D BRIDGE ABI PASS recyclable_metadata_10000_fresh_generations" in result.stdout
                      and "M3D BRIDGE ABI PASS scene_pool_10000_fresh_generations" in result.stdout
                      and "M3D BRIDGE ABI PASS live_host_buffer_pointer_return" in result.stdout
                      and "M3D BRIDGE ABI PASS reused_host_buffer_new_view" in result.stdout)
            results.append({"character_archive": name, "archive_sha256": sha(disc_file), "passed": passed,
                            "exit_code": result.returncode, "host_views": 16})
            print(name, "PASS" if passed else "FAIL")
        negatives = []
        for flag, expected in [("--page-field-span", "unexported object field"), ("--page-cross-view", "unexported object field"), ("--page-field", "unexported object field"), ("--page-unmapped", "unregistered guest region"),
                               ("--translation-field", "unexported object field"), ("--translation-span", "unexported object field"), ("--translation-retired", "retired guest allocation"),
                               ("--page-retired", "retired guest allocation"), ("--bad-field", "unexported object field"), ("--bad-pointer", "unmapped guest address"),
                               ("--bad-span", "unexported object field"), ("--unknown-call", "unsupported native call"),
                               ("--unmapped-global", "unregistered guest region"),
                               ("--stale-object", "Stale native object handle"), ("--wrong-object", "Native object kind mismatch"),
                               ("--retired-memory", "retired guest allocation"),
                               ("--wrong-callback", "Native callback object kind mismatch"),
                               ("--wrong-callback-result", "Native callback signature mismatch"),
                               ("--too-many-gprs", "Native call exceeds guest register argument capacity"),
                               ("--too-many-fprs", "Native call exceeds guest register argument capacity"),
                               ("--wrong-callback-arity", "Native callback signature mismatch"),
                               ("--reused-object", "fresh generation"),
                               ("--mixed-context", "Full-EABI context adapter requires one context"),
                               ("--retired-generation", "retired guest allocation"),
                               ("--retired-object-generation", "Unregistered native object handle")]:
            result = subprocess.run([str(out / "bridge-probe"), str(ROOT / "build/akaneia/disc/files/PlSn.dat"), flag],
                                    cwd=out, capture_output=True, text=True, timeout=20)
            negatives.append({"case": flag, "passed": result.returncode == 2 and expected in result.stderr,
                              "exit_code": result.returncode})
        report = {"passed": all(r["passed"] for r in results + negatives), "characters": results, "negative_controls": negatives,
                  "architecture": platform.machine(), "executable_sha256": sha(out / "bridge-probe"),
                  "scope": "Original Akaneia reset callbacks in portable module runtime; sixteen independent ABI views per character",
                  "in_game_roster_integration": False, "combined_native_3d_16_ready": False}
        write_json(out / "suite.json", report)
        if not report["passed"]:
            raise SystemExit(1)


if __name__ == "__main__":
    main()
