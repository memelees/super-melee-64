#!/usr/bin/env python3
"""Assemble player-owned game material locally, outside the source/release tree.

Input disc images are never uploaded. The resulting installation is private
game data and must never be included in a downloadable mod package.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile

from native_compatibility import ROOT, sha
from prepare_akaneia import BASE_MD5, PATCHED_MD5, prepare, verify as verify_iso
from sunshine_extract import CACHE, disc_stream, exact, extract, filesystem, safe_path, u32
from player_paths import user_directory

MARKER='player-install.json'
RUNTIME_DISC='runtime/melee.iso'
CHECK_CACHE='.player-install-check.json'
DEFAULT=user_directory()/'game-data'


class MeleeSourceError(ValueError):
    """The imported data is usable, but its runtime disc needs locating."""
    recovery='locate-melee'


def external_destination(destination):
    destination=destination.expanduser().resolve()
    if destination==ROOT or ROOT in destination.parents:
        raise ValueError('Player game data must stay outside the project/release directory')
    if destination.exists():
        raise ValueError('Destination already exists; use verify or select a new directory')
    return destination


def extract_gamecube(source,destination):
    """Extract a previously verified raw GameCube disc without Dolphin."""
    destination=Path(destination)
    if destination.exists():raise ValueError('Extraction destination must be new')
    source=Path(source);size=source.stat().st_size
    with source.open('rb') as stream:
        header=exact(stream,0x440)
        if header[0x1c:0x20]!=bytes.fromhex('c2339f3d'):raise ValueError('Not a GameCube disc image')
        dol_offset,fst_offset,fst_size=struct.unpack_from('>III',header,0x420)
        if fst_size>8*1024*1024 or fst_offset+fst_size>size:raise ValueError('Invalid disc filesystem')
        stream.seek(fst_offset);fst=exact(stream,fst_size);files=filesystem(fst)
        for f in files:
            safe_path(f['path'])
            if f['offset']+f['size']>size or f['size']>256*1024*1024:raise ValueError('Invalid disc file range')
        stream.seek(dol_offset);dol_header=exact(stream,0x100)
        ends=[off+n for off,n in zip(struct.unpack_from('>18I',dol_header),struct.unpack_from('>18I',dol_header,0x90)) if n]
        dol_size=max(ends,default=0)
        if dol_size<0x100 or dol_size>64*1024*1024 or dol_offset+dol_size>size:raise ValueError('Invalid disc executable')
        (destination/'sys').mkdir(parents=True)
        (destination/'files').mkdir()
        (destination/'sys/boot.bin').write_bytes(header)
        (destination/'sys/fst.bin').write_bytes(fst)
        stream.seek(dol_offset);(destination/'sys/main.dol').write_bytes(exact(stream,dol_size))
        for f in sorted(files,key=lambda f:f['offset']):
            target=destination/'files'/f['path'];target.parent.mkdir(parents=True,exist_ok=True)
            stream.seek(f['offset']);target.write_bytes(exact(stream,f['size']))


def prepare_install(melee,sunshine,destination,*,patch=None,akaneia_iso=None,music=True,progress=None):
    report=progress or (lambda value,message:None)
    destination=external_destination(destination)
    melee=melee.expanduser().resolve();sunshine=sunshine.expanduser().resolve()
    # Check source identity before creating a populated installation.
    report(3,'Checking Melee disc image…')
    try:verify_iso(melee,BASE_MD5)
    except ValueError as error:
        raise ValueError('Melee requires the USA version 1.02 disc image (.iso or .gcm). This image does not match.') from error
    report(9,'Checking Sunshine disc image…')
    with disc_stream(sunshine) as (stream,_):
        header=exact(stream,0x440)
        if header[:6]!=b'GMSE01' or header[7]!=0:raise ValueError('Requires Sunshine USA revision 0')
    if akaneia_iso:
        akaneia_iso=akaneia_iso.expanduser().resolve();verify_iso(akaneia_iso,PATCHED_MD5)
    destination.parent.mkdir(parents=True,exist_ok=True)
    if shutil.disk_usage(destination.parent).free<6*1024**3:
        raise ValueError('Import needs at least 6 GB of free space. Free some space and try again.')
    with tempfile.TemporaryDirectory(prefix=f'.memelees-import-{os.getpid()}-',dir=destination.parent) as temporary:
        stage=Path(temporary)/'installation';stage.mkdir()
        report(12,'Downloading and applying Akaneia 1.0.1…' if patch is None and akaneia_iso is None else 'Applying Akaneia locally…')
        patched=akaneia_iso or prepare(melee,Path(temporary)/'patch',patch)
        report(21,'Saving Melee for future launches…')
        copy_runtime_disc(melee,stage/RUNTIME_DISC,sha(melee))
        report(25,'Importing characters and items…')
        extract_gamecube(patched,stage/'akaneia')
        # Runtime aliases only; all bytes still originate in the locally
        # patched user disc. No stock/HUD/archive data comes from our repo.
        files=stage/'akaneia/files'
        shutil.copy2(files/'IfAll.usd',files/'M3dHud.dat')
        from player_stage_preview import native_menu_assets
        native_menu_assets(stage,dict(melee_path=str(stage/RUNTIME_DISC)))
        cache=stage/'sunshine'
        wanted=['data/scene/dolpic1.szs','data/mario.szs','data/common.szs','data/particle.szs','data/scene/bianco6.szs','data/scenecmn.bin','data/scene/bianco0.szs','data/scene/sirena1.szs','data/scene/monte7.szs']
        if music:
            wanted+=['data/nintendo.szs','AudioRes/mSound.asn','AudioRes/Seqs/sequence.arc',
                     'AudioRes/Banks/w1stLoad_0.aw','AudioRes/Banks/w2ndLoad_0.aw']
            wanted += [f'AudioRes/Banks/wScene_{i}.aw' for i in range(22)]
        report(38,'Reading Delfino Plaza…')
        extract(sunshine,cache,wanted)
        from sunshine_compile import compile_scene
        report(55,'Preparing geometry, collision and NPC routes…')
        compile_scene(cache,melee_files=files)
        from player_sunshine import prepare_import_maps
        from sunshine_accepted import ACCEPTED_BANKS
        prepare_import_maps(stage,cache,ACCEPTED_BANKS,lambda value,message:report(60+value*.09,message))
        if music:
            # Existing synth entry point uses a module-level cache. Override
            # only in this installer process, never the developer's cache.
            import sunshine_music
            previous,prepare_tools=sunshine_music.CACHE,sunshine_music.prepare_tools
            renderer=ROOT/('bin/smssynth.exe' if os.name=='nt' else 'bin/smssynth')
            report(70,'Preparing the Plaza music…')
            try:
                sunshine_music.CACHE=cache
                if renderer.is_file():sunshine_music.prepare_tools=lambda:renderer
                sunshine_music.main()
            finally:sunshine_music.CACHE=previous;sunshine_music.prepare_tools=prepare_tools
        # Conversion reports contain staging paths; replace those references
        # before the atomic rename, then recalculate their file identities.
        report(90,'Verifying imported files…')
        for document in stage.rglob('*.json'):
            document.write_text(document.read_text().replace(str(stage),str(destination)))
        identities={p.relative_to(stage).as_posix():sha(p) for p in sorted(stage.rglob('*')) if p.is_file()}
        metadata=dict(version=2,private_game_data=True,runtime_disc=RUNTIME_DISC,melee_path=str(destination/RUNTIME_DISC),
                      source_melee_path=str(melee),melee_md5=BASE_MD5,
                      melee_sha256=sha(melee),sunshine_path=str(sunshine),akaneia_md5=PATCHED_MD5,
                      music=music,files=identities,
                      warning='Private locally generated game data. Do not redistribute this directory.')
        (stage/MARKER).write_text(json.dumps(metadata,indent=2)+'\n')
        if destination.exists():raise ValueError('Destination appeared during import; refusing to replace it')
        stage.rename(destination)
    report(100,'Ready to play')
    return destination


def read_install(directory):
    directory=Path(directory).expanduser().resolve()
    metadata=json.loads((directory/MARKER).read_text())
    if metadata.get('version') not in (1,2) or metadata.get('private_game_data') is not True:
        raise ValueError('Invalid local installation')
    if not isinstance(metadata.get('files'),dict) or not metadata['files']:
        raise ValueError('Invalid game file manifest')
    if metadata['version']==2:
        # Stored absolute paths are informational; an installation can move.
        if metadata.get('runtime_disc')!=RUNTIME_DISC or metadata['files'].get(RUNTIME_DISC)!=metadata.get('melee_sha256'):
            raise ValueError('Invalid installed Melee disc')
        metadata['melee_path']=str(directory/RUNTIME_DISC)
    return directory,metadata


def verify_install(directory,*,melee=None,full=True):
    directory,metadata=read_install(directory)
    # Full verification is explicit (import/repair/CLI verify). Ordinary launch
    # hashes changed files and stats the remainder, entirely within the import.
    cache={}
    if not full:
        try:cache=json.loads((directory/CHECK_CACHE).read_text())
        except (OSError,ValueError):pass
        if not isinstance(cache,dict):cache={}
    identity=sha(directory/MARKER)
    previous=cache.get('files',{}) if cache.get('manifest')==identity else {}
    if not isinstance(previous,dict):previous={}
    checked={}
    for name,value in metadata['files'].items():
        safe_path(name);path=directory/name
        if melee is not None and name==RUNTIME_DISC:continue
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(directory):
            if name==RUNTIME_DISC:raise MeleeSourceError('The installed Melee image is missing. Choose Repair Melee in Game files and select your original USA version 1.02 image.')
            raise ValueError('Missing or invalid installed game file: '+name)
        st=path.stat();stamp=[st.st_size,st.st_mtime_ns,st.st_ctime_ns]
        if full or previous.get(name)!=stamp:
            if sha(path)!=value:
                if name==RUNTIME_DISC:raise MeleeSourceError('The installed Melee image changed. Choose Repair Melee in Game files and select your original USA version 1.02 image.')
                raise ValueError('Imported game data changed: '+name)
        checked[name]=stamp
    if metadata['version']==1 or melee is not None:
        source=Path(melee or metadata['melee_path']).expanduser().resolve()
        if not source.is_file():
            raise MeleeSourceError('Select your original Melee USA v1.2 image once to finish installation. Future launches will use the installed copy.')
        if sha(source)!=metadata['melee_sha256']:
            raise MeleeSourceError('This is not the Melee image used for this import. Select the original Melee USA v1.2 image.')
    if metadata['version']==2:
        atomic_json(directory/CHECK_CACHE,dict(manifest=identity,files=checked))
    return metadata


def atomic_json(path,value):
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=path.parent,prefix='.'+path.stem+'-',suffix='.tmp',delete=False) as stream:
            temporary=Path(stream.name);stream.write(json.dumps(value,indent=2)+'\n')
        os.replace(temporary,path)
    finally:
        if temporary is not None:temporary.unlink(missing_ok=True)


def copy_runtime_disc(source,target,expected):
    """Publish a verified local disc atomically; never leave a partial ISO."""
    source,target=Path(source),Path(target)
    if target.is_symlink() or target.parent.is_symlink():raise ValueError('Installed disc must not be a symlink')
    if target.is_file() and sha(target)==expected:return
    target.parent.mkdir(parents=True,exist_ok=True)
    if shutil.disk_usage(target.parent).free<source.stat().st_size+256*1024**2:
        raise ValueError('Not enough space to save the installed Melee image. Free at least 2 GB and try again.')
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent,prefix='.melee-',suffix='.tmp',delete=False) as stream:
            temporary=Path(stream.name)
        shutil.copyfile(source,temporary)
        if sha(temporary)!=expected:raise ValueError('Melee changed while copying; choose the image again.')
        os.replace(temporary,target)
    finally:
        if temporary is not None:temporary.unlink(missing_ok=True)


def make_self_contained(directory,source=None,progress=None):
    """Upgrade a prior import once; preserve converted assets and preferences."""
    directory,metadata=read_install(directory)
    if metadata['version']==2 and source is None:return verify_install(directory,full=False)
    metadata=verify_install(directory,melee=source)
    source=Path(source or metadata['melee_path']).expanduser().resolve()
    if progress:progress(8,'Finishing your one-time game installation…')
    target=directory/RUNTIME_DISC
    copy_runtime_disc(source,target,metadata['melee_sha256'])
    from player_stage_preview import native_menu_assets
    native_menu_assets(directory,dict(melee_path=str(target)))
    metadata.update(version=2,runtime_disc=RUNTIME_DISC,source_melee_path=str(source),melee_path=str(target))
    metadata['files'][RUNTIME_DISC]=metadata['melee_sha256']
    for name in ('M3dTitle.usd','M3dStageSelect.usd'):
        metadata['files']['akaneia/files/'+name]=sha(directory/'akaneia/files'/name)
    atomic_json(directory/MARKER,metadata)
    return verify_install(directory,full=False)


def ready_install(directory,progress=None):
    """Every playable path uses the private installation, including old imports."""
    return make_self_contained(directory,progress=progress)


def locate_melee(directory,source):
    """Finish/repair an import with an identical disc, then forget that location."""
    return make_self_contained(directory,source)


def cleanup_cancelled_import(directory,pid):
    """Only remove staging folders belonging to the worker we just stopped."""
    if type(pid) is not int or pid<=0:raise ValueError('Invalid import worker')
    for path in Path(directory).parent.glob(f'.memelees-import-{pid}-*'):
        if not path.is_symlink() and path.is_dir():shutil.rmtree(path)


def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    a=sub.add_parser('prepare');a.add_argument('--melee',required=True,type=Path);a.add_argument('--sunshine',required=True,type=Path)
    a.add_argument('--destination',type=Path,default=DEFAULT)
    source=a.add_mutually_exclusive_group();source.add_argument('--akaneia-patch',type=Path);source.add_argument('--akaneia-iso',type=Path)
    a.add_argument('--no-music',action='store_true',help='Skip the local music conversion')
    v=sub.add_parser('verify');v.add_argument('directory',type=Path)
    v=sub.add_parser('finish-setup');v.add_argument('directory',type=Path,default=DEFAULT,nargs='?')
    v=sub.add_parser('locate-melee');v.add_argument('directory',type=Path);v.add_argument('image',type=Path)
    args=p.parse_args()
    if args.command=='prepare':
        result=prepare_install(args.melee,args.sunshine,args.destination,patch=args.akaneia_patch,
                               akaneia_iso=args.akaneia_iso,music=not args.no_music)
        print('Local game import complete:',result)
    elif args.command=='finish-setup':
        ready_install(args.directory);print('Installation complete; original images are no longer needed to play')
    elif args.command=='locate-melee':
        locate_melee(args.directory,args.image);print('Melee image location updated; imported game data preserved')
    else:
        result=verify_install(args.directory);print('Local game import verified:',len(result['files']),'files')


if __name__=='__main__':main()
