"""Extend only the native lake horizon and close the original sky backdrop."""
import collections,math
from peach_castle_source import normal


def extend(rows,shore):
    water=[t for t in rows if 'GrdCastleWater1na_RGB565_image'in t['symbols']]
    sky=next(t for t in rows if 'GrdCastleSky1n_CMPR_image'in t['symbols'])
    cap=next(t for t in rows if 'GrdCastleSky2_CMPR_image'in t['symbols'])
    additions=shore['additions'];contacts=[];counts=collections.Counter();center=(117.5,150,74.93)
    def face(template,ps,uv,label,inward=None):
        for ids in[(0,i,i+1)for i in range(1,len(ps)-1)]:
            vs=[[*ps[i],*uv[i],255,255,255,255]for i in ids];n=normal([v[:3]for v in vs])
            if n is None:continue
            target=inward or(0,1,0)
            if sum(n[k]*target[k]for k in range(3))>0:vs.reverse();n=tuple(-v for v in n)
            t=dict(vertices=vs,points=[v[:3]for v in vs],normal=n,group=4,joint=template['joint'],dobj=template['dobj'],material=template['material'],symbols=template['symbols'],feature=label,extension_solid=False)
            additions.setdefault(t['dobj'],[]).append(t);counts[label]+=1
            if label=='water-horizon':contacts.append(t)
    edges=collections.defaultdict(list)
    for t in water:
        for a,b in zip(t['vertices'],t['vertices'][1:]+t['vertices'][:1]):edges[tuple(sorted(tuple(round(v,4)for v in p[:3])for p in(a,b)))].append((a,b,t))
    boundary=[items[0]for items in edges.values()if len(items)==1]
    if len(boundary)!=46:raise ValueError('Unexpected original Castle lake boundary')
    def ring(v,index):
        if index==0:return tuple(v[:3])
        dx,dz=v[0]-center[0],v[2]-center[2];distance=math.hypot(dx,dz);radius=(0,2400,5000,8500)[index]
        return(center[0]+dx/distance*radius,7.25,center[2]+dz/distance*radius)
    for a,b,t in boundary:
        for i in range(3):
            ps=[ring(a,i),ring(b,i),ring(b,i+1),ring(a,i+1)];original=(a,b,b,a)
            uv=[(v[3]+(p[0]-v[0])/2400,v[4]-(p[2]-v[2])/800)for p,v in zip(ps,original)]
            face(t,ps,uv,'water-horizon')
    # The original8x128 sky strip is a vertical blue gradient; wrapping it
    # closes the old card edges. The native cloud cap has matching blue edges.
    radius=8000;latitudes=[-math.pi/2,-math.pi/3,-math.pi/6,0,math.pi/12,math.pi/6,math.pi/4,math.pi/3,5*math.pi/12,math.pi/2]
    def point(lat,theta):return(center[0]+radius*math.cos(lat)*math.cos(theta),center[1]+radius*math.sin(lat),center[2]+radius*math.cos(lat)*math.sin(theta))
    for lo,hi in zip(latitudes,latitudes[1:]):
        template=cap if lo>=math.pi/3-1e-6 else sky
        for i in range(64):
            a,b=i*math.tau/64,(i+1)*math.tau/64;ps=[point(lo,a),point(lo,b),point(hi,b),point(hi,a)]
            if template is cap:uv=[(.5+(p[0]-center[0])/8000,.5+(p[2]-center[2])/8000)for p in ps]
            else:uv=[(theta/math.tau,1-max(0,lat)/(math.pi/3))for lat,theta in((lo,a),(lo,b),(hi,b),(hi,a))]
            midpoint=[sum(p[k]for p in ps)/4 for k in range(3)];inside=tuple(center[k]-midpoint[k]for k in range(3))
            face(template,ps,uv,'closed-native-sky',inside)
    shore['water_contacts']=[*water,*contacts]
    shore['replace_sky_dobjs']={sky['dobj'],cap['dobj']}
    shore['report']['horizon']=dict(original_water_faces=len(water),appended_water_faces=len(contacts),boundary_edges=len(boundary),outer_water_radius=8500,sky_radius=8000,sky_center=center,counts=dict(counts),source_water_vertices_retained=True,overlap_policy='Only the annulus outside the exact native lake boundary; shared edges have identical world positions and source UVs',sky_materials=sky['symbols']+cap['symbols'],physics='Added water stays non-solid; sky is excluded from collision/navigation/zone bounds')
    return shore
