"""Local native-menu bridge: lobby messages carry choices, never game assets."""
from pathlib import Path
from native_lineup import BY_NAME

def write_state(path,state):
 players=state.get('players',[]);options=state.get('options',{});local=state.get('seat',0)
 cpu=options.get("cpu_character","random");cpu_id=-1 if cpu=="random" else BY_NAME[cpu][1]
 lines=[f"{local} {options.get('humans',1)} {int(bool(state.get('running')))} {cpu_id}"]
 for p in players:
  character=p["character"];character_id=-1 if character=="random" else BY_NAME[character][1]
  lines.append(f"{p['seat']} {character_id} {int(bool(p['ready']))} {p.get('x',0):.4f} {p.get('y',10):.4f} {p.get('costume',0)}")
 temporary=Path(str(path)+'.tmp');temporary.write_text('\n'.join(lines)+'\n');temporary.replace(path)

def read_choice(path):
 try:
  raw=path.read_text()
  if not raw.endswith('\n'):return None
  fields=raw.split()
  if len(fields) not in (4,7):return None
  c,x,y,ready=fields[:4];character=next(r[0] for r in BY_NAME.values() if r[1]==int(c));x,y=float(x),float(y)
  if not -36<=x<=36 or not -25<=y<=25 or ready not in ('0','1'):return None
  return character,x,y,bool(int(ready))
 except (OSError,ValueError,StopIteration):return None


def read_selection(path):
 """Read old four-field cursors and new choice/outfit/CPU extensions."""
 base=read_choice(path)
 if not base:return None
 character,x,y,ready=base
 try:
  fields=path.read_text().split();costume=0;cpu='random'
  if len(fields)==7:
   raw,costume,raw_cpu=map(int,fields[4:]);character='random' if raw==-1 else next(r[0]for r in BY_NAME.values()if r[1]==raw)
   cpu='random' if raw_cpu==-1 else next(r[0]for r in BY_NAME.values()if r[1]==raw_cpu)
  from player_rules import fighter_choice
  fighter_choice(character,costume);fighter_choice(cpu)
  return dict(character=character,x=x,y=y,ready=ready,costume=costume,cpu=cpu)
 except (OSError,ValueError,StopIteration):return None


def _options(fields):
 from player_rules import decode
 try:return decode(fields)
 except (ValueError,TypeError):return None


def read_options(path):
 """Validate native menu preferences before using them in worker jobs."""
 try:
  text=path.read_text()
  return _options(text.split()) if text.endswith('\n') else None
 except OSError:return None


def read_request(path):
 try:
  text=path.read_text()
  if not text.endswith('\n'):return None
  action,*fields=text.split()
  if action not in ('host','join','files','quit','theater','theater-next','theater-back','watch0','watch1','watch2'):return None
  options=_options(fields)
  return dict(action=action,**options) if options else None
 except (OSError,ValueError):return None
