#!/usr/bin/env python3
"""Generate only explicitly classifiable native-call contracts from real headers.

Struct buffers, variadic calls, callbacks and unknown typedefs remain unbound.
No function is guessed from its argument count or treated as a no-op.
"""
from pathlib import Path
import re
import struct

from audit_akaneia import original_functions
from native_compatibility import ROOT, WORK, write_json
from native_roster import Archive, inventory

SCALARS={"void":"VOID", "int":"I32", "unsigned":"U32", "unsigned int":"U32",
         "s32":"I32", "u32":"U32", "int32_t":"I32", "uint32_t":"U32",
         "enum_t":"I32", "float":"F32", "f32":"F32", "double":"F64", "f64":"F64",
         "bool":"U8", "_Bool":"U8", "u8":"U8", "s8":"I8", "char":"I8",
         "unsigned char":"U8", "signed char":"I8", "u16":"U16", "s16":"I16",
         "unsigned short":"U16", "short":"I16", "uint16_t":"U16", "int16_t":"I16",
         "size_t":"SIZE"}
OBJECTS={"Fighter_GObj":1,"HSD_GObj":1,"Item_GObj":1,"Ground_GObj":1,
         "Fighter":2,"HSD_JObj":3,"FigaTree":4,"CollData":8,"Item":9,"HSD_AObj":11,"HitCapsule":12,"HSD_DObj":14,"HSD_MObj":15,"HSD_Material":16,"HSD_CObj":17}


def classify(declaration, enums, aliases):
    declaration=re.sub(r'\b(const|volatile|register)\b','',declaration)
    declaration=' '.join(declaration.split())
    if any(c in declaration for c in '()[],.'):
        raise ValueError("aggregate/function/array/variadic contract")
    # Strip a parameter's optional name only after recognizing its type prefix.
    parts=declaration.rsplit(' ',1)
    if len(parts)==2 and re.fullmatch(r'[A-Za-z_]\w*',parts[1]) and parts[0] not in ('unsigned','signed','enum','struct'):
        if declaration not in SCALARS and declaration not in aliases and declaration not in enums:
            declaration=parts[0]
    if '*' in declaration:
        if declaration.count('*')!=1:raise ValueError("pointer-to-pointer contract")
        pointee=declaration.replace('*','').removeprefix('struct ').strip()
        if pointee not in OBJECTS:raise ValueError("unmapped pointer type "+pointee)
        return "OBJECT",OBJECTS[pointee]
    seen=set()
    while declaration in aliases and declaration not in seen:
        seen.add(declaration);declaration=aliases[declaration]
    if declaration.removeprefix('enum ') in enums:return "I32",0
    if declaration in SCALARS:return SCALARS[declaration],0
    raise ValueError("unmapped scalar type "+declaration)


def native_literals(words,symbols):
    """Exact engine addresses in data and nearby PPC lis/addi or lis/ori.

    This discovers references, never signatures: every admitted function still
    needs one unambiguous, fully typed native header contract.
    """
    found={word for word in words if word in symbols}
    for index,upper in enumerate(words):
        if upper>>26!=15 or (upper>>16)&31:continue
        register=(upper>>21)&31
        high=(upper&65535)<<16
        for lower in words[index+1:index+9]:
            opcode=lower>>26
            if opcode==14 and (lower>>16)&31==register:
                low=lower&65535; low=low-65536 if low&32768 else low
                value=(high+low)&0xffffffff
                if value in symbols:found.add(value)
                break
            if opcode==24 and (lower>>21)&31==register:
                value=high|(lower&65535)
                if value in symbols:found.add(value)
                break
            # Stay within a short basic block and stop at register writes.
            # The extended-opcode check is conservative: missing a reference
            # leaves an explicit adapter gap rather than inferring a value.
            if opcode in (16,18,19):break
            if opcode in (7,8,12,13,14,15,32,33,34,35,40,41,42,43) and (lower>>21)&31==register:break
            if opcode==46 and (lower>>21)&31<=register:break
            if opcode in range(20,30) and (lower>>16)&31==register:break
            if opcode==31 and register in ((lower>>21)&31,(lower>>16)&31):break
            if opcode in (37,39,45,49,51,53,55) and (lower>>16)&31==register:break
    return found


def generate():
    source=WORK/'melee-pc/src'
    aurora=WORK/'melee-pc/extern/aurora/include'
    headers={p:p.read_text(errors='replace') for p in source.rglob('*.h') if 'sdk_include' not in p.parts}
    headers.update({p:p.read_text(errors='replace') for p in aurora.rglob('*.h')})
    header_name=lambda p:p.relative_to(aurora if p.is_relative_to(aurora) else source).as_posix()
    enums=set();aliases={}
    for text in headers.values():
        enums.update(re.findall(r'\benum\s+(\w+)\s*\{',text))
        enums.update(re.findall(r'typedef\s+enum\b[^;]*?\}\s*(\w+)\s*;',text,re.S))
        for base,alias in re.findall(r'typedef\s+([\w ]+)\s+(\w+)\s*;',text):
            base=' '.join(base.split())
            if base in SCALARS or base in enums or base in aliases:aliases[alias]=base
    symbols={address:name for name,(address,size) in original_functions(ROOT/'config/GALE01/symbols.txt').items()}
    addresses=set()
    for c in inventory()['characters']:
        a=Archive(ROOT/'build/akaneia/disc/files'/c['file']);f=a.public['ftFunction']
        words=[word[0] for word in struct.iter_unpack('>I',a.payload[:len(a.payload)//4*4])]
        addresses.update(native_literals(words,symbols))
        functions=[f]
        items=a.public.get('itFunction')
        if items is not None:
            functions += [a.word(items+4+i*4) for i in range(a.word(items)) if a.word(items+4+i*4)]
        for f in functions:
            table,count=a.word(f+4),a.word(f+8)
            for n in range(count):
                instruction,address=a.word(table+n*8),a.word(table+n*8+4)
                if instruction>>24 in (1,4,6,10) and address in symbols:addresses.add(address)
    # Preserve inherited native logic slots as well as executable overrides.
    mex=Archive(ROOT/'build/akaneia/disc/files/MxDt.dat')
    mex_root=mex.public['mexData']; fighter=mex.word(mex_root+8)
    lookup=mex.word(fighter+0x4c); custom=mex.word(mex.word(mex_root+0x1c)+0x10)
    for owner in range(27,34):
        count,ids=mex.word(lookup+owner*8),mex.word(lookup+owner*8+4)
        for index in range(count):
            global_id=int.from_bytes(mex.payload[ids+index*2:ids+index*2+2],'big')
            if global_id<237:continue
            row=custom+(global_id-237)*0x3c
            for slot in range(1,15):
                address=mex.word(row+slot*4)
                if address in symbols:addresses.add(address)
    manual={0x800031f4,0x800761c8,0x80390228,0x80088510,0x80089824,0x802ac62c,0x8007e2f4,0x802ad1e4,0x800693ac}  # object destruction needs lifecycle invalidation
    contracts=[];unbound=[];includes=set()
    for address in sorted(addresses-manual):
        name=symbols[address]
        candidates=[]
        for path,text in headers.items():
            if name not in text:continue
            # A prototype ending in ;, with a plain scalar/object return type.
            pattern=r'(?:^|\n)[ \t]*(?:/\*[^\n]*?\*/[ \t]*)?((?:extern[ \t]+)?(?:const[ \t]+)?(?:struct[ \t]+|enum[ \t]+)?(?:unsigned[ \t]+)?\w+[ \t]*\**)[ \t]+'+re.escape(name)+r'\s*\(([^;{}]*)\)\s*;'
            for m in re.finditer(pattern,text):
                if m.group(1).strip()!='return':candidates.append((path,m.group(1).removeprefix('extern ').strip(),m.group(2).strip()))
        if len(candidates)!=1:
            unbound.append({"address":hex(address),"name":name,"reason":"missing/ambiguous header prototype"});continue
        path,result,args=candidates[0]
        try:
            if not args:raise ValueError("old-style unspecified argument list")
            result_type,result_kind=classify(result,enums,aliases)
            arguments=[] if args=='void' else [classify(a.strip(),enums,aliases) for a in args.split(',')]
            floats=sum(t in ('F32','F64') for t,k in arguments)
            if len(arguments)>16 or floats>8 or len(arguments)-floats>8:
                raise ValueError("stack/extended argument contract")
            if any(t=='VOID' for t,k in arguments):raise ValueError("void argument")
        except ValueError as error:
            unbound.append({"address":hex(address),"name":name,"reason":str(error)});continue
        includes.add(header_name(path))
        contracts.append({"address":address,"name":name,"header":header_name(path),
                          "return":result_type,"return_kind":result_kind,"arguments":arguments})
    lines=['/* Generated typed contracts, from native declarations and original module relocations. */',
           '#include "m3d_native_calls.h"', '#include <dolphin/gx.h>']
    lines += [f'#include <{p}>' for p in sorted(includes)]
    lines += ['void m3d_bind_engine(void)','{']
    for c in contracts:
        types=','.join('M3D_'+t for t,k in c['arguments']) or '0'
        kinds=','.join(str(k) for t,k in c['arguments']) or '0'
        lengths=','.join('-1' for a in c['arguments']) or '0'
        lines += [f'    /* {c["name"]}: checked against {c["header"]}. */',
                  f'    {{ const struct M3dNativeCall call={{0x{c["address"]:08x},(void(*)(void)){c["name"]},M3D_{c["return"]},{len(c["arguments"])},',
                  f'        {{{types}}},{{{lengths}}},{{{kinds}}},{c["return_kind"]}}}; m3d_native_register(&call); }}']
    lines += ['}']
    (source/'pc/m3d_engine_calls.c').write_text('\n'.join(lines)+'\n')
    write_json(WORK/'native-engine-contracts.json',{"bound":contracts,"unbound":unbound})
    print(f"Typed native contracts: {len(contracts)} bound; {len(unbound)} require explicit adapters")
    return contracts


if __name__=='__main__':generate()
