#!/usr/bin/env python3
"""Collision-derived Plaza routes; no authored map-specific waypoint shortcuts.

Nodes preserve separate stacked surfaces. Links require support and body
clearance, with conservative jump/drop arcs. These are geometric candidates;
actual native fighter traversal remains the acceptance test.
"""
from collections import Counter,defaultdict
from functools import lru_cache
import math,struct

VERSION=3


def height(points,n,x,z):
    if abs(n[1])<1e-6:return None
    sign=0
    for a,b in zip(points,points[1:]+points[:1]):
        q=(b[0]-a[0])*(z-a[2])-(b[2]-a[2])*(x-a[0])
        if abs(q)<1e-6:continue
        if sign*q<0:return None
        sign=q
    return points[0][1]-(n[0]*(x-points[0][0])+n[2]*(z-points[0][2]))/n[1]


def supporting_plane(points,n,x,z,y):
    """A walkable plane continuous with the feet, including adjacent triangles.

    Clearance rays one unit above a sloped floor can intersect that same
    floor uphill within the body's radius. Ignore only its supporting plane;
    elevated floors, ceiling undersides and vertical walls still obstruct.
    Boundary support is checked separately at the full body radius.
    """
    if n[1]<.65:return False
    plane_y=points[0][1]-(n[0]*(x-points[0][0])+n[2]*(z-points[0][2]))/n[1]
    return abs(plane_y-y)<.5


def leaves_takeoff_plane(points,n,a,previous,current,supports):
    """Ignore only initial body overlap exiting an actual supporting plane.

    Adjacent coplanar floor triangles share support, but destination roofs,
    ceilings and a later re-entry into this floor remain collision obstacles.
    """
    if not supporting_plane(points,n,*a[::2],a[1]):return False
    if not any(sum(n[k]*sn[k] for k in range(3))>.9999 and supporting_plane(sp,sn,*a[::2],a[1]) for sp,sn in supports):return False
    before=sum(n[k]*(previous[k]-points[0][k]) for k in range(3))
    after=sum(n[k]*(current[k]-points[0][k]) for k in range(3))
    return before<=.001 and after>before+.001


def segment_hit(a,b,points):
    def sub(a,b):return tuple(x-y for x,y in zip(a,b))
    def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
    def dot(a,b):return sum(x*y for x,y in zip(a,b))
    d=sub(b,a);u=sub(points[1],points[0]);v=sub(points[2],points[0]);p=cross(d,v);det=dot(u,p)
    if abs(det)<1e-7:return False
    s=sub(a,points[0]);x=dot(s,p)/det
    if x<0 or x>1:return False
    q=cross(s,u);y=dot(d,q)/det
    if y<0 or x+y>1:return False
    t=dot(v,q)/det
    return -1e-6<=t<=1+1e-6


def components(edges):
    """Strong components avoid placing bots on a one-way reachable roof."""
    reverse=[[] for _ in edges]
    for i,links in enumerate(edges):
        for j,_ in links:reverse[j].append(i)
    seen=set();order=[]
    for start in range(len(edges)):
        if start in seen:continue
        stack=[(start,False)]
        while stack:
            i,done=stack.pop()
            if done:order.append(i);continue
            if i in seen:continue
            seen.add(i);stack.append((i,True));stack.extend((j,False) for j,_ in edges[i] if j not in seen)
    result=[-1]*len(edges);component=0
    for start in reversed(order):
        if result[start]>=0:continue
        stack=[start];result[start]=component
        while stack:
            i=stack.pop()
            for j in reverse[i]:
                if result[j]<0:result[j]=component;stack.append(j)
        component+=1
    return result


def build(colliders,step=16.,radius=5.):
    grid=defaultdict(list);water_grid=defaultdict(list)
    for i,(ps,n,s,f) in enumerate(colliders):
        if f&2 or (f&1 and f&8):continue
        for x in range(math.floor(min(p[0] for p in ps)/64),math.floor(max(p[0] for p in ps)/64)+1):
            for z in range(math.floor(min(p[2] for p in ps)/64),math.floor(max(p[2] for p in ps)/64)+1):(water_grid if f&1 and not f&8 else grid)[x,z].append(i)
    @lru_cache(maxsize=262144)
    def levels(x,z,walk=False):
        result=[]
        for i in grid.get((math.floor(x/64),math.floor(z/64)),[]):
            ps,n,_,_=colliders[i]
            if walk and n[1]<.65:continue
            y=height(ps,n,x,z)
            if y is not None:result.append(y)
        return result
    profile_cache={}
    def floor_profile(a,b,match_end=True):
        """Exact projected interval coverage across connected walkable facets.

        A convex crease may change slope within the body radius. It does not
        require one extrapolated centre plane or a linear start/end grade.
        Every interval still needs an actual floor, with <=0.5u seam drift;
        no sampling step can skip a genuine gap or a vertical ledge.
        """
        key=(tuple(a),tuple(b),match_end)
        if key in profile_cache:return profile_cache[key]
        dx,dz=b[0]-a[0],b[2]-a[2];length=math.hypot(dx,dz);candidates=set()
        for gx in range(math.floor(min(a[0],b[0])/64),math.floor(max(a[0],b[0])/64)+1):
            for gz in range(math.floor(min(a[2],b[2])/64),math.floor(max(a[2],b[2])/64)+1):candidates.update(grid.get((gx,gz),[]))
        intervals=[];events={0.,1.}
        for i in candidates:
            ps,n,_,_=colliders[i]
            if n[1]<.65:continue
            lo,hi=0.,1.
            # Upward winding is clockwise in XZ: retain cross(edge,p)<=0.
            for p,q in zip(ps,ps[1:]+ps[:1]):
                ex,ez=q[0]-p[0],q[2]-p[2];v=ex*(a[2]-p[2])-ez*(a[0]-p[0]);dv=ex*dz-ez*dx
                if abs(dv)<1e-10:
                    if v>1e-6:hi=-1;break
                elif dv>0:hi=min(hi,-v/dv)
                else:lo=max(lo,-v/dv)
            if hi-lo>1e-9 and hi>=0 and lo<=1:
                lo,hi=max(0.,lo),min(1.,hi);intervals.append((lo,hi,i));events.update((lo,hi))
        last_y=a[1];points=[tuple(a)];supports=set();ordered=sorted(events);valid=True
        for lo,hi in zip(ordered,ordered[1:]):
            if hi-lo<1e-9:continue
            options=[]
            for start,end,i in intervals:
                if start>lo+1e-8 or end<hi-1e-8:continue
                ps,n,_,_=colliders[i];x,z=a[0]+dx*lo,a[2]+dz*lo
                y=ps[0][1]-(n[0]*(x-ps[0][0])+n[2]*(z-ps[0][2]))/n[1]
                if abs(y-last_y)<=.5:options.append((abs(y-last_y),i))
            if not options:valid=False;break
            _,i=min(options);ps,n,_,_=colliders[i];supports.add(i);count=max(1,math.ceil(length*(hi-lo)/4))
            for k in range(1,count+1):
                t=lo+(hi-lo)*k/count;x,z=a[0]+dx*t,a[2]+dz*t;y=ps[0][1]-(n[0]*(x-ps[0][0])+n[2]*(z-ps[0][2]))/n[1]
                # Headroom is measured above each actual offset floor, not
                # only the node centre. Thin/sloped overhangs remain real.
                if any(y+.5<h<y+19 for h in levels(x,z)):valid=False;break
                points.append((x,y,z))
            if not valid:break
            last_y=points[-1][1]
        if match_end and abs(last_y-b[1])>.5:valid=False
        answer=(points,supports) if valid and len(points)>1 else None;profile_cache[key]=answer
        return answer
    def body_clear(paths,supports,offset=(0,0)):
        for points in paths:
            for a,b in zip(points,points[1:]):
                candidates=set()
                for gx in range(math.floor((min(a[0],b[0])+offset[0])/64),math.floor((max(a[0],b[0])+offset[0])/64)+1):
                    for gz in range(math.floor((min(a[2],b[2])+offset[1])/64),math.floor((max(a[2],b[2])+offset[1])/64)+1):candidates.update(grid.get((gx,gz),[]))
                for h in (1,8,16):
                    p=(a[0]+offset[0],a[1]+h,a[2]+offset[1]);q=(b[0]+offset[0],b[1]+h,b[2]+offset[1]);lo,hi=sorted((p[1],q[1]))
                    for i in candidates-supports:
                        ps,n,_,_=colliders[i]
                        if min(v[1] for v in ps)<=hi and max(v[1] for v in ps)>=lo and segment_hit(p,q,ps):return False
        return True
    cells=set()
    for ps,n,s,f in colliders:
        if f&3 or n[1]<.65:continue
        for x in range(math.ceil(min(p[0] for p in ps)/step),math.floor(max(p[0] for p in ps)/step)+1):
            for z in range(math.ceil(min(p[2] for p in ps)/step),math.floor(max(p[2] for p in ps)/step)+1):cells.add((x,z))
    nodes=[];lookup=defaultdict(list)
    for x,z in sorted(cells):
        wx,wz=x*step,z*step;seen=[];all_y=levels(wx,wz)
        water=[h for i in water_grid.get((math.floor(wx/64),math.floor(wz/64)),[]) if (h:=height(colliders[i][0],colliders[i][1],wx,wz)) is not None]
        for y in sorted(levels(wx,wz,True)):
            if any(abs(y-v)<.5 for v in seen):continue
            seen.append(y)
            if any(y+.5<h<y+19 for h in all_y):continue
            # Water is an out-of-bounds volume, not a traversable seabed.
            # Preserve covered tunnels only when a solid roof separates them.
            if water and y<max(water)+1.5 and not any(y+16<=h<max(water)+.1 for h in all_y):continue
            profiles=[floor_profile((wx,y,wz),(wx+dx,y,wz+dz),False) for dx,dz in ((radius,0),(-radius,0),(0,radius),(0,-radius))]
            if any(p is None for p in profiles):continue
            supports=set().union(*(p[1] for p in profiles))
            if not body_clear([p[0] for p in profiles],supports):continue
            lookup[x,z].append(len(nodes));nodes.append((wx,y,wz))
    def clear(a,b,jump):
        dx,dz=b[0]-a[0],b[2]-a[2];length=math.hypot(dx,dz);rx,rz=-dz/length*radius,dx/length*radius
        if not jump:
            middle=floor_profile(a,b)
            if middle is None:return False
            profiles=[middle];supports=set(middle[1])
            for side in (-1,1):
                start=floor_profile(a,(a[0]+rx*side,a[1],a[2]+rz*side),False);end=floor_profile(b,(b[0]+rx*side,b[1],b[2]+rz*side),False)
                if start is None or end is None:return False
                edge=floor_profile(start[0][-1],end[0][-1])
                if edge is None:return False
                profiles.extend((start,end,edge));supports.update(start[1]|end[1]|edge[1])
            if not body_clear([p[0] for p in profiles],supports):return False
            return all(body_clear([middle[0]],supports,(rx*side,rz*side)) for side in (-1,0,1))
        candidates=set()
        for x in range(math.floor((min(a[0],b[0])-radius)/64),math.floor((max(a[0],b[0])+radius)/64)+1):
            for z in range(math.floor((min(a[2],b[2])-radius)/64),math.floor((max(a[2],b[2])+radius)/64)+1):candidates.update(grid.get((x,z),[]))
        takeoff=[]
        if jump:
            for i in grid.get((math.floor(a[0]/64),math.floor(a[2]/64)),[]):
                ps,n,_,_=colliders[i]
                y=height(ps,n,a[0],a[2]) if n[1]>=.65 else None
                if y is not None and abs(y-a[1])<.5:takeoff.append((ps,n))
        for side in (-1,0,1):
            for h in (1,8,16):
                previous=(a[0]+rx*side,a[1]+h,a[2]+rz*side)
                for t in (.25,.5,.75,1):
                    along=min(1,t*2) if jump==2 else max(0,(t-.25)/.75) if jump in (3,4) else t
                    y=(max(a[1],b[1])+(32 if jump==4 else 12) if t<1 else b[1]) if jump in (3,4) else a[1] if jump==2 and t<=.5 else a[1]+(b[1]-a[1])*((t-.5)*2 if jump==2 else t)
                    p=(a[0]+dx*along+rx*side,y+h+(24*4*t*(1-t) if jump==1 else 0),a[2]+dz*along+rz*side)
                    lo=min(previous[1],p[1]);hi=max(previous[1],p[1])
                    for i in candidates:
                        ps,n,_,_=colliders[i]
                        if not jump and supporting_plane(ps,n,previous[0]-rx*side,previous[2]-rz*side,previous[1]-h) and supporting_plane(ps,n,p[0]-rx*side,p[2]-rz*side,p[1]-h):continue
                        if jump and t==.25 and leaves_takeoff_plane(ps,n,a,previous,p,takeoff):continue
                        if min(v[1] for v in ps)>hi or max(v[1] for v in ps)<lo:continue
                        if segment_hit(previous,p,ps):return False
                    previous=p
        return True
    edges=[[] for _ in nodes]
    directions=[(x,z) for x in range(-2,3) for z in range(-2,3) if 0<x*x+z*z<=4]
    for (x,z),ids in lookup.items():
        for i in ids:
            a=nodes[i]
            for dx,dz in directions:
                for j in lookup.get((x+dx,z+dz),[]):
                    b=nodes[j];rise=b[1]-a[1]
                    if clear(a,b,False):edges[i].append((j,0))
                    elif rise>32 or rise< -256:continue
                    elif rise>=-20 and clear(a,b,1):edges[i].append((j,1))
                    elif rise< -20 and clear(a,b,2):edges[i].append((j,2))
    # Keep base components separate: native fighters have different original
    # jump budgets. Longer/higher links get a distinct, ability-gated kind.
    groups=components(edges)
    # Preserve every previously available short connection; the extra links
    # below supplement these alternatives, including for larger ECB bodies.
    short_extra=[(x,z) for x in range(-4,5) for z in range(-4,5) if 0<x*x+z*z<=16 and (not x or not z or abs(x)==abs(z))]
    for (x,z),ids in lookup.items():
        for i in ids:
            a=nodes[i];linked={j for j,_ in edges[i]}
            for dx,dz in short_extra:
                for j in lookup.get((x+dx,z+dz),[]):
                    b=nodes[j];rise=b[1]-a[1]
                    if j in linked or (groups[i]==groups[j] and rise<20) or rise< -20 or rise>80:continue
                    if clear(a,b,3):edges[i].append((j,3))
                    elif math.hypot(dx,dz)*step<=64 and clear(a,b,4):edges[i].append((j,4))
    # Offshore islands can be farther apart than a single grid jump. Keep
    # these as candidates: native attributes and actual pad traversal decide
    # which fighter can cross. Bound candidates per directed component pair
    # instead of flooding the city graph with long shortcuts.
    extra=[(x,z) for x in range(-12,13) for z in range(-12,13)
           if 0<x*x+z*z<=144]
    candidates=defaultdict(list)
    for (x,z),ids in lookup.items():
        for i in ids:
            a=nodes[i];linked={j for j,_ in edges[i]}
            for dx,dz in extra:
                for j in lookup.get((x+dx,z+dz),[]):
                    b=nodes[j];rise=b[1]-a[1]
                    if j in linked or groups[i]==groups[j] or rise< -80 or rise>80:continue
                    pair=(groups[i],groups[j]);cost=math.hypot(dx,dz)*step+max(0,rise)*.5
                    bucket=candidates[pair];bucket.append((cost,i,j))
                    if len(bucket)>64:bucket.sort();del bucket[32:]
    for pair,bucket in sorted(candidates.items()):
        added=0;used=set()
        for _,i,j in sorted(bucket):
            if i in used:continue
            if clear(nodes[i],nodes[j],3):
                edges[i].append((j,3));used.add(i);added+=1
                if added>=4:break
    counts=Counter(groups);largest=max(counts,key=counts.get) if counts else -1
    return nodes,edges,groups,dict(step=step,radius=radius,nodes=len(nodes),edges=sum(map(len,edges)),components=len(counts),
        largest_component=largest,largest_component_nodes=counts.get(largest,0),link_kinds=dict(Counter(k for e in edges for _,k in e)),
        scope='Layered walk/jump/drop candidates plus ability-gated extended jumps; native traversal validation required')


def encode(nodes,edges,groups,step):
    raw=bytearray(struct.pack('<4s3If',b'DLN1',3,len(nodes),sum(map(len,edges)),step));first=0
    for p,links,component in zip(nodes,edges,groups):raw+=struct.pack('<3f3I',*p,component,first,len(links));first+=len(links)
    for links in edges:
        for target,kind in links:raw+=struct.pack('<2I',target,kind)
    return bytes(raw)
