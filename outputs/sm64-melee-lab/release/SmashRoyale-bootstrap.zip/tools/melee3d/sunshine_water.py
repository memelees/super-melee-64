"""Keep donor ocean ring-outs and make inland water bodies safely shallow."""

def shallow_collision(colliders,depth=4):
    result=[];beds=[]
    for points,normal,surface,flags in colliders:
        # Sunshine's ocean uses surface 0x102; its inland pools and channels
        # use separate water surface types. Preserve each original footprint.
        inland=bool(flags&1 and surface&0x3fff!=0x102)
        result.append((points,normal,surface,flags|(8 if inland else 0)))
        if inland and normal[1]>.65:
            beds.append(([tuple(v-depth if k==1 else v for k,v in enumerate(p)) for p in points],normal,0,0))
    return result+beds
