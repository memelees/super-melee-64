#!/usr/bin/env python3
"""Measure one Sunshine conversion using both Mario models in their bind pose.

Uses referenced render vertices (including skin matrices), rather than stage
bounds, collision capsules, skeleton-only bounds or the current camera zoom.
"""
import hashlib
import json
import struct
from native_roster import Archive
from sunshine_extract import CACHE
from sunshine_scene import Reader,bounds,identity,matrix,multiply,static_model,transform
from native_compatibility import ROOT


def melee_bind_vertices(path):
    ar=Archive(path);r=Reader(ar.payload);root=ar.public['PlyMario5K_Share_joint']
    joints={};inverse={};dobjects=[]
    def walk(offset,parent,depth=0):
        if depth>100:raise ValueError('HSD joint depth')
        while offset:
            mt=multiply(parent,matrix(r.get('3f',offset+44),r.get('3f',offset+20),r.get('3f',offset+32)))
            joints[offset]=mt;bind=r.u32(offset+56)
            if bind:inverse[offset]=[list(r.get('4f',bind+k*16)) for k in range(3)]+[[0,0,0,1]]
            dobj=r.u32(offset+16)
            while dobj:
                dobjects.append((dobj,offset));dobj=r.u32(dobj+4)
            if r.u32(offset+8):walk(r.u32(offset+8),mt,depth+1)
            offset=r.u32(offset+12)
    walk(root,identity());points=[]
    for dobj,bone in dobjects:
        po=r.u32(dobj+12)
        while po:
            flags=r.u16(po+12);typ=flags&0x3000;palette=[];pointer=r.u32(po+20)
            if typ==0x2000:
                for i in range(64):
                    env=r.u32(pointer+i*4)
                    if not env:break
                    total=[[0.]*4 for _ in range(4)]
                    for j in range(64):
                        joint=r.u32(env+j*8)
                        if not joint:break
                        weight=r.get('f',env+j*8+4)[0]
                        m=multiply(joints[joint],inverse[joint])
                        for y in range(4):
                            for x in range(4):total[y][x]+=m[y][x]*weight
                    palette.append(total)
            elif typ==0:
                if pointer:raise ValueError('Shared rigid vertex matrices need explicit support')
                palette=[joints[bone]]
            else:raise ValueError('Unexpected Mario shape-animation model')
            decl=[];o=r.u32(po+8)
            while True:
                attr,atype,cnt,ctype=r.get('4I',o)
                if attr==255:break
                decl.append((attr,atype,cnt,ctype,r.data[o+16],r.u16(o+18),r.u32(o+20)));o+=24
            o=r.u32(po+16);end=o+r.u16(po+14)*32
            while o<end:
                op=r.data[o];o+=1
                if not op:continue
                if op&0xf8 not in (0x80,0x90,0x98,0xa0):raise ValueError('Unexpected HSD primitive')
                count=r.u16(o);o+=2
                for _ in range(count):
                    p=None;mt=0
                    for attr,atype,cnt,ctype,shift,stride,start in decl:
                        if atype==1 and attr<=8:
                            index=r.data[o];o+=1
                            if attr==0:mt=index//3
                        elif atype in (2,3):
                            index=r.data[o] if atype==2 else r.u16(o);o+=atype-1
                            if attr==9:
                                fmt={0:'B',1:'b',2:'H',3:'h',4:'f'}[ctype]
                                values=r.get(('2' if cnt==0 else '3')+fmt,start+index*stride)
                                p=tuple(v/(1<<shift) if ctype!=4 else v for v in values);p=(*p,0)[:3]
                        else:raise ValueError('Unexpected direct HSD vertex attribute')
                    if p is None or mt>=len(palette):raise ValueError('Invalid HSD position matrix')
                    points.append(transform(palette[mt],p))
            if o!=end:raise ValueError('HSD display-list extent')
            po=r.u32(po+4)
    return points


def measure(cache=CACHE,melee_files=None):
    sms=cache/'archives/mario/bmd/ma_mdl1.bmd'
    files=melee_files if melee_files is not None else ROOT/'build/akaneia/disc/files'
    melee=files/'PlMrNr.dat'
    attrs_file=files/'PlMr.dat'
    attr=Archive(attrs_file);data=attr.public['ftDataMario'];model_scale=struct.unpack_from('>f',attr.payload,attr.word(data)+0x8c)[0]
    sms_points=[v[0] for _,tri in static_model(sms.read_bytes(),bind_skin=True)['triangles'] for v in tri]
    melee_points=melee_bind_vertices(melee)
    sb=bounds(sms_points);mb=bounds(melee_points)
    sms_height=sb[1][1]-sb[0][1];melee_height=(mb[1][1]-mb[0][1])*model_scale
    return dict(method='Referenced render vertices in each original Mario bind pose; native ftCo_DatAttrs.model_scaling applied',
                sunshine_height=sms_height,melee_unscaled_bounds=mb,sunshine_bounds=sb,
                melee_model_scaling=model_scale,melee_height=melee_height,scale=melee_height/sms_height,
                files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (sms,melee,attrs_file)})


if __name__=='__main__':print(json.dumps(measure(),indent=2))
