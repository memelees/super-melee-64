"""Canonical host/solo rules and the bounded native preference wire format."""
import re

MODES=('hill','survival','coin','battle','time','stock','bonus')
ITEMS=('off','verylow','low','medium','high','veryhigh')
FIELDS=('mode','items','minutes','humans','stocks','handicap','damage_ratio','stage_selection',
        'stock_minutes','friendly_fire','pause','score_display','sd_penalty','cpu_level','gravity','move_speed','game_speed')
LOW=(0,0,0,2,1,0,5,0,0,0,0,0,0,1,25,50,50)
HIGH=(6,5,99,32,99,2,20,4,99,1,1,1,2,9,150,200,150)
DEFAULT=(1,3,5,2,3,0,10,0,0,0,1,0,1,9,100,100,100)
# Match type, item frequency, duration and human count remain outer job fields.
RULE_DEFAULTS=dict(stocks=3,handicap=0,damage_ratio=10,stage_selection=0,stock_minutes=0,
                   friendly_fire=0,pause=1,score_display=0,sd_penalty=1,cpu_level=9,
                   gravity=100,move_speed=100,game_speed=100,item_mask=0xffffffff,handicaps=[9]*32)

def validate(rules=None):
    if rules is not None and (not isinstance(rules,dict) or set(rules)-set(RULE_DEFAULTS)):
        raise ValueError('Unsupported custom rules')
    value={**RULE_DEFAULTS,**(rules or {})}
    for key in FIELDS[4:]:
        index=FIELDS.index(key);v=value[key]
        if type(v) is not int or not LOW[index]<=v<=HIGH[index]:raise ValueError('Invalid rule: '+key)
    if type(value['item_mask']) is not int or not 0<=value['item_mask']<=0xffffffff:raise ValueError('Invalid item switch')
    hs=value['handicaps']
    if not isinstance(hs,list) or len(hs)!=32 or any(type(n) is not int or not 1<=n<=9 for n in hs):raise ValueError('Invalid handicaps')
    value['handicaps']=list(hs)
    return value

def decode(fields):
    if len(fields)==4:
        a,b,c,d=map(int,fields)
        if not (0<=a<4 and 0<=b<4 and 0<=c<5 and 2<=d<=32):raise ValueError('Invalid old menu state')
        return dict(mode=MODES[a],items=('off','low','medium','high')[b],seconds=(2,3,5,10,15)[c]*60,humans=d)
    if not fields or fields[0]!='BMR2' or len(fields)!=1+len(FIELDS)+1+32:raise ValueError('Invalid menu state')
    nums=list(map(int,fields[1:]));v=nums[:len(FIELDS)]
    if any(not lo<=n<=hi for n,lo,hi in zip(v,LOW,HIGH)):raise ValueError('Invalid menu rule')
    rules=validate(dict(zip(FIELDS[4:],v[4:]),item_mask=nums[len(FIELDS)],handicaps=nums[len(FIELDS)+1:]))
    return dict(mode=MODES[v[0]],items=ITEMS[v[1]],seconds=v[2]*60,humans=v[3],rules=rules)

def encode(mode='survival',items='medium',seconds=300,humans=2,rules=None):
    r=validate(rules)
    if type(seconds) is not int or seconds%60 or not 0<=seconds<=5940 or type(humans) is not int or not 2<=humans<=32:raise ValueError('Invalid menu duration/capacity')
    nums=[MODES.index(mode),ITEMS.index(items),seconds//60,humans]+[r[k] for k in FIELDS[4:]]+[r['item_mask']]+r['handicaps']
    return 'BMR2 '+' '.join(map(str,nums))+'\n'

def environment(rules=None):
    r=validate(rules)
    keys={'stocks':'STOCKS','handicap':'HANDICAP','damage_ratio':'DAMAGE_RATIO','stage_selection':'STAGE_SELECTION',
          'stock_minutes':'STOCK_MINUTES','friendly_fire':'FRIENDLY_FIRE','pause':'PAUSE','score_display':'SCORE_DISPLAY',
          'sd_penalty':'SD_PENALTY','cpu_level':'CPU_LEVEL','item_mask':'ITEM_MASK'}
    env={'MELEE3D_NATIVE_'+v:str(r[k]) for k,v in keys.items()}
    for k in ('gravity','move_speed','game_speed'):env['MELEE3D_NATIVE_'+k.upper()]=str(r[k]/100)
    env['MELEE3D_NATIVE_HANDICAPS']=','.join(map(str,r['handicaps']))
    return env

def adjusted_handicaps(log,rules=None):
    """Carry native Auto Handicap adjustments into the next hosted lobby."""
    matches=re.findall(r'^M3D RULE AUTO levels=([0-9,]+)$',log,re.M)
    if not matches:return None
    return validate(dict(validate(rules),handicaps=list(map(int,matches[-1].split(',')))))


def fighter_choice(character,costume=0):
    """Bound untrusted selection data; native loaded tables clamp outfit IDs."""
    from native_lineup import BY_NAME
    if not isinstance(character,str) or character not in (*BY_NAME,'random'):
        raise ValueError('Unknown fighter choice')
    if type(costume) is not int or not 0<=costume<=31 or (character=='random' and costume):
        raise ValueError('Invalid fighter costume')
    return character,costume


def selection(value,humans):
    if not isinstance(value,dict) or set(value)!={'characters','costumes','cpu'}:
        raise ValueError('Invalid character selections')
    chars=value['characters'];costumes=value['costumes']
    if not isinstance(chars,(list,tuple)) or not isinstance(costumes,(list,tuple)) or len(chars)!=humans or len(costumes)!=humans:
        raise ValueError('Choose one fighter and outfit per human')
    for c,outfit in zip(chars,costumes):fighter_choice(c,outfit)
    fighter_choice(value['cpu'])
    return dict(characters=list(chars),costumes=list(costumes),cpu=value['cpu'])


def resolved_selection(value,humans,seed):
    import random
    from native_lineup import BY_NAME
    value=selection(value,humans);rng=random.Random(seed)
    return [rng.choice(tuple(BY_NAME)) if c=='random' else c for c in value['characters']]
