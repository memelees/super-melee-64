"""Small authenticated LAN/VPN lobby; the player's machine owns the room.

Only choices, content hashes and controller-room invitations cross the wire.
No discovery, rendezvous or author-operated server is used.
"""
import hashlib
import hmac
import ipaddress
import json
import queue
import secrets
import socket
import struct
import threading
from urllib.parse import urlsplit

from native_lineup import BY_NAME
from player_rules import fighter_choice
from player_room import Room, read_exact, tag

MAX_MESSAGE=1024*1024

def player_name(value):
    if not isinstance(value,str):raise ValueError('Player name must be text.')
    value=value.strip()
    if len(value)>16 or any(not(c.isascii() and (c.isalnum() or c in ' _-')) for c in value):
        raise ValueError('Use up to 16 letters, numbers, spaces, underscores or hyphens for your name.')
    return value


def identity_digest(identity):
    return hashlib.sha256(json.dumps(identity,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def parse_code(code):
    value=urlsplit(code.strip())
    if value.scheme!='memelees' or value.username or value.password or value.query or value.fragment:
        raise ValueError('Paste the complete memelees:// room code from the host.')
    try:
        host=str(ipaddress.IPv4Address(value.hostname));port=value.port
        key=bytes.fromhex(value.path.removeprefix('/'))
    except (ValueError,TypeError):raise ValueError('The room code is incomplete or invalid.') from None
    if not port or len(key)!=32:raise ValueError('The room code is incomplete or invalid.')
    return host,port,key


def local_address():
    # UDP connect selects a route without sending traffic to this address.
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sock:
        try:sock.connect(('192.0.2.1',9));return sock.getsockname()[0]
        except OSError:return '127.0.0.1'


def send(sock,key,sequence,value):
    body=json.dumps(dict(sequence=sequence,value=value),separators=(',',':')).encode()
    if len(body)>MAX_MESSAGE:raise ValueError('Lobby message is too large.')
    head=struct.pack('!I',len(body));sock.sendall(head+body+tag(key,head+body,32))


def receive(sock,key,sequence):
    head=read_exact(sock,4);size=struct.unpack('!I',head)[0]
    if size>MAX_MESSAGE or size<2:raise ValueError('Invalid lobby message size.')
    body=read_exact(sock,size);signature=read_exact(sock,32)
    if not hmac.compare_digest(signature,tag(key,head+body,32)):raise ValueError('The room code did not match.')
    packet=json.loads(body)
    if not isinstance(packet,dict) or packet.get('sequence')!=sequence or not isinstance(packet.get('value'),dict):
        raise ValueError('Invalid lobby message sequence.')
    return packet['value']


class Host:
    def __init__(self,identity,factory,character,options,bind='0.0.0.0',port=0,advertise=None,nickname=''):
        fighter_choice(character)
        self.identity=identity_digest(identity);self.factory=factory;self.options=dict(options)
        self.options.setdefault('cpu_character','random');fighter_choice(self.options['cpu_character'])
        if not 2<=options['humans']<=options['fighters']<=32:raise ValueError('Choose 2–32 human players within the fighter total.')
        self.key=secrets.token_bytes(32);self.lock=threading.RLock();self.closed=threading.Event()
        self.players={0:dict(seat=0,character=character,costume=0,ready=True,name=player_name(nickname))}
        self.room=None;self.invite=None;self.error=None;self.connections=set()
        self.listener=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        self.listener.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        self.listener.bind((bind,port));self.listener.listen(32);self.listener.settimeout(.3)
        self.address=advertise or local_address()
        self.code=f'memelees://{self.address}:{self.listener.getsockname()[1]}/{self.key.hex()}'
        self.thread=threading.Thread(target=self._accept,daemon=True);self.thread.start()

    def snapshot(self,seat=0):
        with self.lock:
            state=dict(players=[dict(self.players[i]) for i in sorted(self.players)],options=self.options,seat=seat,
                       running=self.invite is not None,closed=self.closed.is_set())
            if self.invite is not None:state.update(invite=self.invite,host=self.address,port=self.room.address[1])
            if self.error:state['error']=self.error
            return state

    def choose(self,character,x,y,seat=0,costume=0,cpu=None):
        import math
        fighter_choice(character,costume)
        if cpu is not None:
            fighter_choice(cpu)
            if seat!=0:raise ValueError('Only the host chooses the CPU roster.')
        if not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in (x,y)) or not -36<=x<=36 or not -25<=y<=25:
            raise ValueError('Invalid character cursor.')
        with self.lock:
            if self.invite is not None:return
            self.players[seat].update(character=character,costume=costume,x=float(x),y=float(y),ready=False)
            if cpu is not None:self.options["cpu_character"]=cpu

    def set_ready(self,ready,character=None,seat=0,costume=None,cpu=None):
        with self.lock:
            if self.invite is not None:raise ValueError('The match has already started.')
            if character is not None:
                fighter_choice(character,costume if costume is not None else 0)
                if character!=self.players[seat]['character']:self.players[seat]['costume']=0
                self.players[seat]['character']=character
            if costume is not None:
                fighter_choice(self.players[seat]['character'],costume);self.players[seat]['costume']=costume
            if cpu is not None:
                fighter_choice(cpu)
                if seat!=0:raise ValueError('Only the host chooses the CPU roster.')
                self.options['cpu_character']=cpu
            self.players[seat]['ready']=bool(ready)

    def start(self):
        with self.lock:
            if self.invite is not None:return
            if len(self.players)!=self.options['humans'] or not all(p['ready'] for p in self.players.values()):
                raise ValueError('Wait for every player to join and choose Ready.')
            characters=[self.players[i]['character'] for i in sorted(self.players)]
            settings=dict(self.options,names=[self.players[i]['name'] or f'P{i+1}' for i in sorted(self.players)])
            settings['selection']=dict(characters=characters,costumes=[self.players[i].get('costume',0)for i in sorted(self.players)],cpu=self.options.get('cpu_character','random'))
            invite=self.factory(characters,settings)
            room=Room(('0.0.0.0',0),len(characters),bytes.fromhex(invite['key']),bytes.fromhex(invite['compatibility']),
                      delay=invite['delay'],seed=invite['seed'],max_frames=invite['frames'])
            self.invite=invite;self.room=room
            threading.Thread(target=room.run,daemon=True).start()

    def _accept(self):
        while not self.closed.is_set():
            try:sock,_=self.listener.accept()
            except socket.timeout:continue
            except OSError:break
            with self.lock:
                if len(self.connections)>=40:sock.close();continue
                self.connections.add(sock)
            threading.Thread(target=self._peer,args=(sock,),daemon=True).start()

    def _peer(self,sock):
        seat=None
        try:
            sock.settimeout(5);nonce=secrets.token_bytes(32);sock.sendall(nonce);key=tag(self.key,nonce,32)
            request=receive(sock,key,0)
            with self.lock:
                if request.get('identity')!=self.identity:raise ValueError('Different build or game files. Everyone needs the same platform build and imports.')
                fighter_choice(request.get('character'),request.get('costume',0))
                if self.invite is not None:raise ValueError('This match has already started.')
                seat=next((i for i in range(1,self.options['humans']) if i not in self.players),None)
                if seat is None:raise ValueError('This lobby is full.')
                self.players[seat]=dict(seat=seat,character=request['character'],costume=request.get('costume',0),ready=False,name=player_name(request.get('name','')))
            sequence=0
            while not self.closed.is_set():
                send(sock,key,sequence,self.snapshot(seat))
                if self.invite is not None:break
                sequence+=1;request=receive(sock,key,sequence)
                command=request.get('command','poll')
                if command=='select':self.choose(request.get('character'),request.get('x'),request.get('y'),seat,costume=request.get('costume',0))
                elif command=='ready':self.set_ready(request.get('ready',False),request.get('character'),seat,costume=request.get('costume'))
                elif command=='leave':break
                elif command!='poll':raise ValueError('Unknown lobby command.')
        except (OSError,ValueError,ConnectionError,KeyError) as error:
            try:send(sock,key,locals().get('sequence',0),dict(error=str(error)))
            except (OSError,UnboundLocalError):pass
        finally:
            with self.lock:
                self.connections.discard(sock)
                if seat is not None and self.invite is None:self.players.pop(seat,None)
            sock.close()

    def close(self):
        self.closed.set();self.listener.close()
        with self.lock:
            for sock in list(self.connections):
                try:sock.shutdown(socket.SHUT_RDWR)
                except OSError:pass
            if self.room:
                self.room.listener.close()
                for sock in list(self.room.clients.values()):
                    try:sock.shutdown(socket.SHUT_RDWR)
                    except OSError:pass


class Client:
    def __init__(self,code,identity,character,nickname=''):
        self.address,self.port,self.key=parse_code(code)
        fighter_choice(character)
        self.identity=identity_digest(identity);self.character=character;self.costume=0;self.name=player_name(nickname)
        self.events=queue.Queue();self.commands=queue.Queue();self.choice_lock=threading.Lock();self.pending_choice=None;self.closed=threading.Event();self.sock=None
        self.thread=threading.Thread(target=self._run,daemon=True);self.thread.start()

    def choose(self,character,x,y,costume=0):
        fighter_choice(character,costume)
        self.character=character;self.costume=costume
        with self.choice_lock:self.pending_choice=dict(command='select',character=character,costume=costume,x=x,y=y)

    def ready(self,value,character=None,costume=None):
        with self.choice_lock:self.pending_choice=None
        if character is not None:
            if character!=self.character and costume is None:self.costume=0
            fighter_choice(character,costume if costume is not None else self.costume);self.character=character
        if costume is not None:self.costume=costume
        self.commands.put(dict(command='ready',ready=bool(value),character=character or self.character,costume=self.costume))

    def _run(self):
        try:
            with socket.create_connection((self.address,self.port),timeout=5) as sock:
                self.sock=sock;sock.settimeout(6);key=tag(self.key,read_exact(sock,32),32)
                send(sock,key,0,dict(identity=self.identity,character=self.character,costume=self.costume,name=self.name));sequence=0
                while not self.closed.is_set():
                    state=receive(sock,key,sequence);self.events.put(state)
                    if state.get('error') or state.get('running'):return
                    try:command=self.commands.get(timeout=.05)
                    except queue.Empty:
                        with self.choice_lock:command=self.pending_choice or dict(command='poll');self.pending_choice=None
                    sequence+=1;send(sock,key,sequence,command)
        except (OSError,ValueError,ConnectionError) as error:
            if not self.closed.is_set():self.events.put(dict(error=f'Could not connect to the host: {error}'))
        finally:self.sock=None

    def close(self):
        self.closed.set()
        if self.sock:
            try:self.sock.shutdown(socket.SHUT_RDWR)
            except OSError:pass
