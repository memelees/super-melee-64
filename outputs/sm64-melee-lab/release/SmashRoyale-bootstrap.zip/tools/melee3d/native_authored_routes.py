"""Source-validated authored walking lanes for narrow native map corridors.

These add route samples only. Real solid triangles retain authority over floor
coverage, walls and headroom; no physical collision or movement changes occur.
"""
from collections import defaultdict
import math,struct
from sunshine_navigation import height,segment_hit,supporting_plane,components


def floor_coverage(rows,a,b):
    """Exact projected union along a linear source floor path, including gaps."""
    dx,dz=b[0]-a[0],b[2]-a[2]
    if abs(dx)+abs(dz)<1e-9:
        return any(n[1]>=.65 and (y:=height(ps,n,a[0],a[2])) is not None and abs(y-a[1])<=.5 for ps,n,*_ in rows)
    intervals=[];events={0.,1.}
    for ps,n,*_ in rows:
        if n[1]<.65:continue
        lo,hi=0.,1.
        for p,q in zip(ps,ps[1:]+ps[:1]):
            ex,ez=q[0]-p[0],q[2]-p[2];v=ex*(a[2]-p[2])-ez*(a[0]-p[0]);dv=ex*dz-ez*dx
            if abs(dv)<1e-10:
                if v>1e-6:hi=-1;break
            elif dv>0:hi=min(hi,-v/dv)
            else:lo=max(lo,-v/dv)
        lo,hi=max(0,lo),min(1,hi)
        if hi-lo<=1e-9:continue
        matches=True
        for t in (lo,hi):
            x,z=a[0]+dx*t,a[2]+dz*t;y=ps[0][1]-(n[0]*(x-ps[0][0])+n[2]*(z-ps[0][2]))/n[1]
            if abs(y-(a[1]+(b[1]-a[1])*t))>.5:matches=False;break
        if matches:intervals.append((lo,hi,ps,n));events.update((lo,hi))
    previous=a[1];ordered=sorted(events)
    for lo,hi in zip(ordered,ordered[1:]):
        if hi-lo<1e-9:continue
        options=[]
        for start,end,ps,n in intervals:
            if start>lo+1e-8 or end<hi-1e-8:continue
            x,z=a[0]+dx*lo,a[2]+dz*lo;y=ps[0][1]-(n[0]*(x-ps[0][0])+n[2]*(z-ps[0][2]))/n[1]
            if abs(y-previous)<=.5:options.append((abs(y-previous),ps,n))
        if not options:return False
        _,ps,n=min(options,key=lambda item:item[0]);x,z=a[0]+dx*hi,a[2]+dz*hi
        previous=ps[0][1]-(n[0]*(x-ps[0][0])+n[2]*(z-ps[0][2]))/n[1]
    return abs(previous-b[1])<=.5


def append_walk_routes(nodes,edges,groups,colliders,payload):
    routes=payload.get('walk_routes',[])if payload else[]
    if not routes:return dict(added_nodes=0,added_edges=0,routes=[])
    # Validate against the exact float32 coordinates the OVL loader receives.
    # Source scale products can lie a few microunits outside an authored join
    # before serialization, while their actual native vertices coincide.
    def f32(v):return struct.unpack('<f',struct.pack('<f',v))[0]
    colliders=[([[f32(v)for v in p]for p in ps],[f32(v)for v in n],surface,flags)for ps,n,surface,flags in colliders]
    grid=defaultdict(list)
    for row in colliders:
        ps,n,_,flags=row
        if flags&3:continue
        for x in range(math.floor(min(p[0]for p in ps)/64),math.floor(max(p[0]for p in ps)/64)+1):
            for z in range(math.floor(min(p[2]for p in ps)/64),math.floor(max(p[2]for p in ps)/64)+1):grid[x,z].append(row)
    def nearby(a,b,pad=16):
        found={}
        for x in range(math.floor((min(a[0],b[0])-pad)/64),math.floor((max(a[0],b[0])+pad)/64)+1):
            for z in range(math.floor((min(a[2],b[2])-pad)/64),math.floor((max(a[2],b[2])+pad)/64)+1):
                for row in grid.get((x,z),[]):found[id(row)]=row
        return list(found.values())
    def clear(a,b):
        rows=nearby(a,b);dx,dz=b[0]-a[0],b[2]-a[2];length=math.hypot(dx,dz)
        rx,rz=(-dz/length,dx/length)if length>1e-7 else(1.,0.)
        # Real five-unit feet, measured maximum torso radius16 and height22
        # from the current32-fighter native probe. Exact side floor coverage
        # rejects even narrow holes between the old discrete body samples.
        for side in (-1,0,1):
            p=(a[0]+rx*5*side,a[1],a[2]+rz*5*side);q=(b[0]+rx*5*side,b[1],b[2]+rz*5*side)
            if not floor_coverage(rows,p,q):return False
        for center in (a,b):
            for dx,dz in ((0,0),(5,0),(-5,0),(0,5),(0,-5)):
                if not floor_coverage(rows,center,(center[0]+dx,center[1],center[2]+dz)):return False
                foot=(center[0]+dx,center[1]+.1,center[2]+dz);head=(foot[0],center[1]+22,foot[2])
                if any(segment_hit(foot,head,ps)for ps,n,*_ in rows):return False
        for h,radius in ((1,5),(11,16),(22,5)):
            for side in (-1,0,1):
                p=(a[0]+rx*radius*side,a[1]+h,a[2]+rz*radius*side);q=(b[0]+rx*radius*side,b[1]+h,b[2]+rz*radius*side)
                for ps,n,*_ in rows:
                    if supporting_plane(ps,n,a[0],a[2],a[1])and supporting_plane(ps,n,b[0],b[2],b[1]):continue
                    if segment_hit(p,q,ps):return False
        return True
    original=len(nodes);added_edges=0;records=[];authored=[]
    for route in routes:
        name=route['name'];points=[tuple(float(v)for v in p)for p in route['points']]
        if len(points)<2 or any(len(p)!=3 or not all(map(math.isfinite,p))for p in points):raise ValueError('Invalid authored walk route '+name)
        samples=[points[0]]
        for a,b in zip(points,points[1:]):
            count=max(1,math.ceil(math.dist(a,b)/8))
            samples.extend(tuple(a[k]+(b[k]-a[k])*j/count for k in range(3))for j in range(1,count+1))
        for p in samples:
            if not clear(p,p):raise ValueError('Authored walk node lacks real floor/body/headroom: '+name+' '+str(p))
        indices=[]
        for p in samples:
            i=next((i for i,q in enumerate(nodes)if math.dist(p,q)<.05),None)
            if i is None:i=len(nodes);nodes.append(p);edges.append([]);groups.append(-1)
            indices.append(i)
        for i,j in zip(indices,indices[1:]):
            if not clear(nodes[i],nodes[j]):raise ValueError('Authored walk segment crosses real gap/step/body obstruction: '+name)
            for u,v in ((i,j),(j,i)):
                if not any(target==v for target,_ in edges[u]):edges[u].append((v,0));added_edges+=1
        authored.extend(indices);records.append(dict(name=name,node_indices=indices,samples=len(indices)))
    # Join actual route samples to nearby existing graph nodes through the same
    # geometry/body checks. No invented jump edge or component exemption.
    for i in sorted(set(authored)):
        a=nodes[i];near=sorted((math.dist(a,b),j)for j,b in enumerate(nodes)if j!=i and math.hypot(a[0]-b[0],a[2]-b[2])<=24 and abs(a[1]-b[1])<=8)
        for _,j in near[:24]:
            if any(target==j for target,_ in edges[i])or not clear(a,nodes[j]):continue
            edges[i].append((j,0));edges[j].append((i,0));added_edges+=2
    groups[:]=components([[(j,k)for j,k in row if k!=3]for row in edges])
    return dict(added_nodes=len(nodes)-original,added_edges=added_edges,routes=records,foot_radius=5,torso_radius=16,body_height=22,maximum_sample_gap=8,coordinate_precision='Serialized native float32',method='Authored source floor lanes; exact continuous linear floor coverage, real walls/ceilings and measured32-roster body envelope; all new links WALK')


def routes_from_report(report):
    """Measured centerlines emitted by the actual Onett art compiler."""
    features=report.get('field_southern_hills',{}).get('architecture',{}).get('features',[]);routes=[]
    for feature in features:
        kind=feature.get('type')
        if kind not in ('arched-road-tunnel','connecting-underhill-road'):continue
        points=feature.get('centerline')
        if not points:raise ValueError('Authored tunnel lacks measured centerline')
        name=feature.get('name','crossroad')
        routes.append(dict(name='ballfield-southern-hills/'+name+'-centerline',points=points,source_feature_type=kind))
    return routes
