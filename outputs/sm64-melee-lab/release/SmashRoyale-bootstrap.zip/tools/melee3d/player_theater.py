"""Local input replays, backed by the engine's recorder and native menu scenes."""
import datetime
import math
import os
import json
import platform
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import uuid

from native_compatibility import sha
from player_paths import user_directory,game_command


def library():return user_directory()/'Replays'


def begin_recording(env,binary,launch,destination=None):
    """Record from boot so menu choices, loads and RNG follow the same timeline."""
    root=destination or library();root.mkdir(parents=True,exist_ok=True)
    directory=root/(datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:6]);directory.mkdir()
    allowed=('fighters','character','mode','items','seed','seconds','name','rules','menus','cpu_only')
    data=dict(version=1,created=datetime.datetime.now().isoformat(timespec='seconds'),engine_sha256=sha(binary),
              platform=sys.platform,machine=platform.machine(),launch={k:launch[k] for k in allowed if k in launch})
    from player_sunshine import recording_identity
    data['maps']=recording_identity(env)
    state=env.get('MELEE3D_NATIVE_MENU_SETTINGS')
    data['menu_state']=Path(state).read_text() if state and Path(state).is_file() else ''
    fighters=Path(str(state)+'.fighters') if state else None
    data['menu_fighters_state']=fighters.read_text() if fighters and fighters.is_file() else ''
    (directory/'pending.json').write_text(json.dumps(data,indent=2)+'\n')
    env.update(MELEE_NET_RECORD=str(directory/'inputs.mrc'),MELEE3D_THEATER_RECORD=str(directory/'world.bmt'))
    return directory


def finish_recording(directory,log):
    data=json.loads((directory/'pending.json').read_text());inputs=directory/'inputs.mrc';world=directory/'world.bmt'
    data['matches']=log.count('M3D PARTY START')
    data['match_starts']=[int(t) for t in re.findall(r'M3D THEATER MATCH tick=(\d+)',log)]
    data['ticks']=max(0,(world.stat().st_size-4)//12) if world.is_file() else 0
    if not data['matches'] or not data['ticks']:
        shutil.rmtree(directory);return
    data['files']={p.name:sha(p) for p in (inputs,world)}
    choices=re.findall(r'M3D MENU CHOICE character=\d+ name=(\w+)',log)
    data['character']=choices[-1] if choices else data['launch'].get('character','sonic')
    temporary=directory/'replay.tmp';temporary.write_text(json.dumps(data,indent=2)+'\n');temporary.replace(directory/'replay.json')
    (directory/'pending.json').unlink(missing_ok=True)


def recordings(root=None):
    found=[]
    for path in sorted((root or library()).glob('*/replay.json'),reverse=True):
        try:
            data=json.loads(path.read_text())
            if data.get('version')==1 and data.get('matches',0)>0 and data.get('ticks',0)>0:found.append((path,data))
        except (OSError,ValueError,TypeError):continue
    return found


def recording_issue(data,engine_sha,current_maps=None):
    """Explain known compatibility gates before offering native playback."""
    if data.get('version')!=1 or data.get('engine_sha256')!=engine_sha:
        return 'This replay needs the exact game build that recorded it.'
    if data.get('platform')!=sys.platform or data.get('machine')!=platform.machine():
        return 'This replay was recorded on a different platform.'
    if current_maps is not None and 'maps'in data and data['maps']!=current_maps:
        return 'This replay needs the same maps and goop data that recorded it. A map was added, removed or changed.'
    return None


def replay_environment(path,binary,installation,metadata,profile):
    """Only accept current-build recordings; never execute paths/settings in a replay."""
    from player_play import environment
    path=Path(path).resolve();data=json.loads(path.read_text())
    engine_sha=sha(binary);issue=recording_issue(data,engine_sha)
    if issue:raise ValueError(issue)
    for name,magic in (('inputs.mrc',b'MRC5'),('world.bmt',b'BMT1')):
        p=path.parent/name
        if p.is_symlink() or data.get('files',{}).get(name)!=sha(p):raise ValueError('Replay data is incomplete or changed.')
        with p.open('rb') as f:
            if f.read(4)!=magic:raise ValueError('Unsupported replay format.')
    launch=data['launch'];env=environment(installation,metadata,profile,launch.get('fighters',32),launch.get('character','sonic'),launch.get('mode','hill'),launch.get('items','medium'),launch.get('seed',1),launch.get('cpu_only',False),launch.get('seconds',300),name=launch.get('name',''),rules=launch.get('rules'))
    if 'maps' in data:
        from player_sunshine import recording_identity
        issue=recording_issue(data,engine_sha,recording_identity(env))
        if issue:raise ValueError(issue)
    if launch.get('menus'):
        from player_stage_preview import preview,native_menu_assets
        native_menu_assets(installation,metadata)
        state=profile/'replay-menu.state';state.write_text(data.get('menu_state',''))
        Path(str(state)+'.fighters').write_text(data.get('menu_fighters_state',''))
        env.update(MELEE3D_NATIVE_MENUS='1',MELEE_BOOT_SCENE='title',MELEE_NO_ATTRACT='1',MELEE3D_NATIVE_MENU_SETTINGS=str(state),MELEE3D_NATIVE_STAGE_PREVIEW=str(preview(installation.parent/'ui-cache')))
    env.update(MELEE_NET_REPLAY=str(path.parent/'inputs.mrc'),MELEE3D_THEATER_PLAY=str(path.parent/'world.bmt'),MELEE_WINDOW_TITLE='Smash Royale — Theater')
    return env


def browse(installation,binary,profile,progress,root=None):
    """The library uses Melee's original five-entry menu, three replays per page."""
    from player_install import ready_install as verify_install
    from player_play import environment
    from player_menu import read_request
    from player_session import session_lock
    meta=verify_install(installation);page=0;unavailable={};engine_sha=sha(binary)
    cache=installation.parent/'profiles/offline/cache'
    if cache.is_dir() and not (profile/'cache').exists():shutil.copytree(cache,profile/'cache')
    while True:
        all_replays=recordings(root);entries=all_replays[page*3:page*3+3]
        lines=[];issues=[]
        for i in range(3):
            if i<len(entries):
                path,data=entries[i];label=f'{page*3+i+1:02d}  '+data.get('character','sonic').upper()[:10]
                seconds=data['ticks']//60;help=f"{data['created'][5:16].replace('T',' ')} / {seconds//60}:{seconds%60:02d} / Start to watch"
                issue=unavailable.get(path)or recording_issue(data,engine_sha)
                if issue:
                    label+=' (OLD)'if data.get('engine_sha256')!=engine_sha else' (UNAVAILABLE)'
                    help='Older game build. Play a new solo match for this version.' if data.get('engine_sha256')!=engine_sha else issue
                issues.append(issue)
            else:label='NO REPLAY' if i==0 else '-';help='Solo sessions save when you close the game.';issues.append(None)
            lines.append(label+'\t'+help)
        lines+=['NEXT PAGE\tBrowse more recordings.','BACK\tReturn to the main menu.']
        index=profile/'theater.index';index.parent.mkdir(parents=True,exist_ok=True);index.write_text('\n'.join(lines)+'\n')
        request=profile/'theater-request.txt';request.unlink(missing_ok=True)
        env=environment(installation,meta,profile,32,'sonic','hill','off')
        env.update(MELEE3D_NATIVE_MENUS='1',MELEE_BOOT_SCENE='main',MELEE_NO_ATTRACT='1',MELEE3D_THEATER_BROWSER=str(index),MELEE_WINDOW_TITLE='Smash Royale — Theater',MELEE3D_NATIVE_MENU_REQUEST=str(request),MELEE3D_NATIVE_MENU_SETTINGS=str(profile/'browser.state'))
        progress(100,'Theater — choose a recording in game')
        with session_lock(profile):
            with (profile/'stdout.txt').open('w') as log:result=subprocess.run(game_command(binary,meta['melee_path']),cwd=profile,env=env,stdout=log,stderr=subprocess.STDOUT)
        if result.returncode:raise RuntimeError('The theater menu stopped unexpectedly. See Logs.')
        choice=read_request(request)
        if not choice or choice['action']=='theater-back':return
        if choice['action']=='theater-next':page=(page+1)%max(1,(len(all_replays)+2)//3);continue
        if choice['action'].startswith('watch'):
            slot=int(choice['action'][-1])
            if slot>=len(entries)or issues[slot]:continue
            try:watch_session(entries[slot][0],binary,installation,meta,profile,progress)
            except (ValueError,OSError) as error:
                unavailable[entries[slot][0]]=str(error)
                progress(100,'Theater - '+str(error))


SPEEDS=(.25,.5,1.)
VIDEO_FPS=30
VIDEO_WIDTH,VIDEO_HEIGHT=1920,1080


def encoder_path():
    """The release ships its encoder; source runs may use an installed ffmpeg."""
    from player_paths import payload
    bundled=payload()/'bin'/('ffmpeg.exe' if sys.platform=='win32' else 'ffmpeg')
    executable=bundled if bundled.is_file() else shutil.which('ffmpeg')
    if not executable:raise RuntimeError('The video encoder is missing. Reinstall the complete app to save Theater clips.')
    return Path(executable).resolve()


def clip_frames(start,end,speed):
    if isinstance(start,bool) or isinstance(end,bool) or not isinstance(start,int) or not isinstance(end,int):
        raise ValueError('Clip points must be recording ticks.')
    if start<0 or end<=start:raise ValueError('Set the clip end after its start.')
    if speed not in SPEEDS:raise ValueError('Choose 1x, 1/2x or 1/4x playback.')
    return math.ceil((end-start)/(60*speed/VIDEO_FPS))


def read_control(path,ticks):
    """Small data-only request from our child; never execute a replay command."""
    path=Path(path)
    if not path.is_file() or path.stat().st_size>4096:return None
    try:
        fields=dict(line.split(' ',1) for line in path.read_text().splitlines())
        if fields.get('action') not in ('seek','export'):return None
        result={'action':fields['action']}
        for key in ('tick','in','out'):
            result[key]=int(fields[key])
            if not 0<=result[key]<=ticks:return None
        result['speed']=float(fields['speed'])
        if result['speed'] not in SPEEDS:return None
        result['paused']=int(fields['paused'])
        if result['paused'] not in (0,1):return None
        camera=[float(n) for n in fields.get('camera','').split()]
        if len(camera)!=7 or any(not math.isfinite(v) or abs(v)>1000000 for v in camera):return None
        if not 5<=camera[6]<=140:return None
        result['camera']=' '.join(format(n,'.9g') for n in camera)
        if result['action']=='export':clip_frames(result['in'],result['out'],result['speed'])
        return result
    except (OSError,ValueError,KeyError,TypeError):return None


def _viewer_options(env,state,total):
    env.update(MELEE3D_THEATER_SEEK=str(state['tick']),MELEE3D_THEATER_TOTAL=str(total),
               MELEE3D_THEATER_SPEED=str(state['speed']),MELEE3D_THEATER_PAUSED=str(state['paused']),
               MELEE3D_THEATER_CLIP_IN=str(state['in']),MELEE3D_THEATER_CLIP_OUT=str(state['out']))
    if state.get('camera'):env['MELEE3D_THEATER_CAMERA']=state['camera']


def export_clip(replay,binary,installation,metadata,profile,output,start,end,speed=1.,camera=None,progress=lambda *_:None,timeout=None):
    """Re-simulate exact saved pads and stream native frames straight to H.264.

    The renderer cannot advance while a frame is in flight. At 30 fps a 1x
    export advances two simulation ticks, 1/2x one tick, and 1/4x alternates
    zero/one tick. No action, hit or RNG step is dropped at any playback speed.
    ffmpeg receives a private inherited pipe, not a shell command or screen.
    """
    from player_session import session_lock
    replay=Path(replay);profile=Path(profile);profile.mkdir(parents=True,exist_ok=True)
    output=Path(output).expanduser().resolve()
    if output.suffix.lower()!='.mp4':raise ValueError('Save the clip as an .mp4 video.')
    data=json.loads(replay.read_text());frames=clip_frames(start,end,speed)
    if end>data['ticks']:raise ValueError('The clip extends beyond this recording.')
    output.parent.mkdir(parents=True,exist_ok=True)
    # The final destination appears only after the encoder has finalized it.
    part=output.with_name('.'+output.stem+'-'+uuid.uuid4().hex[:8]+'.mp4')
    env=replay_environment(replay,binary,installation,metadata,profile)
    state={'tick':start,'in':start,'out':end,'speed':speed,'paused':0,'camera':camera}
    _viewer_options(env,state,data['ticks'])
    env.update(MELEE3D_THEATER_EXPORT='1',MELEE_WINDOW_TITLE='Smash Royale — Saving clip')
    command=[str(encoder_path()),'-hide_banner','-loglevel','error','-y','-f','rawvideo',
             '-pixel_format','rgb24','-video_size',f'{VIDEO_WIDTH}x{VIDEO_HEIGHT}',
             '-framerate',str(VIDEO_FPS),'-i','pipe:0','-an','-c:v','libx264',
             '-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(part)]
    progress(100,f'Saving clip — {speed:g}x speed')
    try:
        with tempfile.TemporaryFile() as errors,session_lock(profile):
            encoder=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=errors)
            options={}
            try:
                fd=encoder.stdin.fileno()
                if sys.platform=='win32':
                    import msvcrt
                    handle=msvcrt.get_osfhandle(fd);os.set_handle_inheritable(handle,True)
                    startup=subprocess.STARTUPINFO();startup.lpAttributeList={'handle_list':[handle]}
                    env['MELEE3D_THEATER_VIDEO_HANDLE']=str(handle);options['startupinfo']=startup
                else:
                    env['MELEE3D_THEATER_VIDEO_FD']=str(fd);options['pass_fds']=(fd,)
                with (profile/'export-stdout.txt').open('w') as log:
                    completed=subprocess.run(game_command(binary,metadata['melee_path']),cwd=profile,
                                             env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout,**options)
                encoder.stdin.close()
                code=encoder.wait(timeout=60)
            finally:
                if sys.platform=='win32' and 'handle' in locals():os.set_handle_inheritable(handle,False)
                if encoder.stdin and not encoder.stdin.closed:encoder.stdin.close()
                if encoder.poll() is None:
                    encoder.terminate()
                    try:encoder.wait(timeout=5)
                    except subprocess.TimeoutExpired:encoder.kill();encoder.wait()
            log=(profile/'export-stdout.txt').read_text(errors='replace')
            if 'M3D THEATER EXPORT CANCELLED' in log:
                progress(100,'Clip cancelled — returning to Theater');return None
            matched=re.search(r'M3D THEATER EXPORT DONE frames=(\d+)',log)
            if completed.returncode or code or not matched or int(matched[1])!=frames or not part.is_file() or part.stat().st_size<128:
                errors.seek(0);detail=errors.read(4000).decode(errors='replace')
                raise RuntimeError('The clip could not be completed. The original replay is safe. '+detail[-1000:])
        part.replace(output)
        report={'version':1,'replay':replay.parent.name,'engine_sha256':data['engine_sha256'],
                'start_tick':start,'end_tick':end,'speed':speed,'fps':VIDEO_FPS,'frames':frames,
                'duration_seconds':frames/VIDEO_FPS,'width':VIDEO_WIDTH,'height':VIDEO_HEIGHT,
                'audio':False,'sha256':sha(output)}
        output.with_suffix('.clip.json').write_text(json.dumps(report,indent=2)+'\n')
        progress(100,'Clip saved — returning to Theater')
        return report
    finally:part.unlink(missing_ok=True)


def mac_clip_dialog():
    """Use the bundled native picker; source runs cache a locally built helper."""
    from player_paths import payload
    helper=payload()/'bin/theater-save-dialog'
    if helper.is_file():return helper
    if getattr(sys,'frozen',False):raise RuntimeError('The Theater save dialog is missing. Reinstall Smash Royale.')
    source=Path(__file__).with_name('player_theater_dialog.swift')
    helper=user_directory()/'tools'/('theater-save-dialog-'+sha(source)[:16])
    if not helper.is_file():
        helper.parent.mkdir(parents=True,exist_ok=True)
        temporary=helper.with_name(helper.name+'-'+uuid.uuid4().hex[:8])
        try:
            subprocess.run(['/usr/bin/xcrun','swiftc','-parse-as-library','-O',str(source),'-o',str(temporary)],check=True,capture_output=True)
            temporary.replace(helper)
        finally:temporary.unlink(missing_ok=True)
    return helper


def choose_clip_path():
    """Use the platform's Save dialog, with a useful default collection folder."""
    folder=Path.home()/'Movies'/'Smash Royale'/'Clips' if sys.platform=='darwin' else Path.home()/'Videos'/'Smash Royale'/'Clips'
    folder.mkdir(parents=True,exist_ok=True)
    if sys.platform=='darwin':
        completed=subprocess.run([str(mac_clip_dialog()),str(folder),datetime.datetime.now().strftime('Smash-Royale-%Y%m%d-%H%M%S.mp4')],capture_output=True,text=True,check=True)
        chosen=json.loads(completed.stdout)
        if chosen is None:return None
        if not isinstance(chosen,str) or not Path(chosen).is_absolute() or Path(chosen).suffix.lower()!='.mp4':raise RuntimeError('The clip destination was invalid.')
        return Path(chosen)
    import tkinter as tk
    from tkinter import filedialog
    root=tk.Tk();root.withdraw()
    try:
        chosen=filedialog.asksaveasfilename(parent=root,title='Save Theater clip',initialdir=str(folder),
                initialfile=datetime.datetime.now().strftime('Smash-Royale-%Y%m%d-%H%M%S.mp4'),
                defaultextension='.mp4',filetypes=[('MP4 video','*.mp4')])
        return Path(chosen) if chosen else None
    finally:root.destroy()


def watch_session(replay,binary,installation,metadata,profile,progress):
    """A clean restart is a deterministic seek, including across native scenes."""
    from player_session import session_lock
    replay=Path(replay);profile=Path(profile);data=json.loads(replay.read_text());total=data['ticks']
    first=(data.get('match_starts') or [0])[0]
    state={'tick':first,'in':first,'out':min(total,first+600),'speed':1.,'paused':1}
    request=profile/'theater-control.txt'
    while True:
        request.unlink(missing_ok=True)
        env=replay_environment(replay,binary,installation,metadata,profile)
        _viewer_options(env,state,total);env['MELEE3D_THEATER_CONTROL']=str(request)
        progress(100,'Theater — A: clip options · Start: pause · B: recordings')
        with session_lock(profile):
            with (profile/'stdout.txt').open('w') as log:
                completed=subprocess.run(game_command(binary,metadata['melee_path']),cwd=profile,env=env,stdout=log,stderr=subprocess.STDOUT)
        if completed.returncode==0:return
        control=read_control(request,total) if completed.returncode==75 else None
        if not control:raise RuntimeError('Replay stopped because its gameplay state did not match the recording. See Logs.')
        state=control
        if state.pop('action')=='export':
            output=choose_clip_path()
            if output is not None:
                export_clip(replay,binary,installation,metadata,profile,output,state['in'],state['out'],state['speed'],state['camera'],progress)
            state['paused']=1
