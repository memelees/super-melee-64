#!/usr/bin/env python3
"""Single-player desktop launcher; also the frozen app's isolated import worker."""
import argparse
import json
import os
from pathlib import Path
import re
import secrets
import signal
import subprocess
import sys
import time
import traceback
import uuid

from player_paths import payload, user_directory, tool_environment, game_command

NAMES={'dk':'Donkey Kong','falcon':'Captain Falcon','iceclimbers':'Ice Climbers',
       'drmario':'Dr. Mario','younglink':'Young Link','gamewatch':'Mr. Game & Watch',
       'dedede':'King Dedede','diddy':'Diddy Kong','jigglypuff':'Jigglypuff'}
MODES={'Battle Royale':'survival','Plaza Party':'hill','Coin Battle':'coin','Free Battle':'battle','Time':'time','Stock':'stock','Bonus':'bonus'}
MODE_HINTS={'Plaza Party':'Fight for control of moving hills.','Battle Royale':'One life. Last fighter standing wins; no time limit.','Coin Battle':'Hit for coins. Collect the most before time runs out.','Free Battle':'Explore and fight freely, with no time limit.'}
ITEMS={'Off':'off','Very Low':'verylow','Low':'low','Medium':'medium','High':'high','Very High':'veryhigh'}


def load_settings(path):
    try:
        value=json.loads(path.read_text())
        if not isinstance(value,dict):return {}
        return value
    except (OSError,ValueError):return {}


def save_settings(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(value,indent=2)+'\n')
    temporary.replace(path)
    if os.name!='nt':path.chmod(0o600)


def migrate_brand(home,settings):
    """One-time default change; preserve imported data, controls and other rules."""
    if settings.get('game_title')=='Smash Royale':return
    from player_menu import read_options
    from player_rules import encode
    for path in (home/'native-menu.state',home/'profiles/offline/native-menu.state'):
        options=read_options(path)
        if options:
            options['mode']='survival'
            temporary=path.with_suffix('.tmp');temporary.write_text(encode(**options));temporary.replace(path)
    settings.update(game_title='Smash Royale',mode='Battle Royale')
    save_settings(home/'launcher.json',settings)


def worker(job_path):
    """Heavy work stays outside the UI process; failures preserve the previous install."""
    job=json.loads(job_path.read_text())
    if job['task']=='install-game' and os.name!='nt':
        if os.getpgrp()!=os.getpid():os.setsid()
        def cancel(signum,frame):
            signal.signal(signal.SIGTERM,signal.SIG_IGN)
            os.killpg(os.getpgrp(),signal.SIGTERM)
            raise InterruptedError('Installation cancelled.')
        signal.signal(signal.SIGTERM,cancel)
    log=Path(job['log']);log.parent.mkdir(parents=True,exist_ok=True)
    with log.open('w',encoding='utf-8',buffering=1) as stream:
        sys.stdout=sys.stderr=stream
        tool_environment()
        result={'ok':False}
        try:
            from player_install import prepare_install, verify_install, ready_install, locate_melee
            def progress(value,message):
                print('MEMELEES_PROGRESS '+json.dumps({'value':value,'message':message}),flush=True)
            installation=Path(job.get('installation') or user_directory()/'game-data')
            installed_app=None
            if job['task']=='install-game':
                from player_deploy import install_game
                installed_app=install_game(job,progress)
                installation=Path(load_settings(Path(job.get('home') or user_directory())/'launcher.json')['installation'])
            elif job['task']=='import':
                prepare_install(Path(job['melee']),Path(job['sunshine']),installation,
                                patch=Path(job['patch']) if job.get('patch') else None,progress=progress)
                verify_install(installation)
            elif job['task']=='locate-melee':
                progress(5,'Checking the Melee image…')
                locate_melee(installation,Path(job['melee']))
                progress(100,'Melee image located — ready to play')
            elif job['task']=='room':
                from player_multiplayer import configure_installation,run
                progress(5,'Checking game files…')
                configure_installation(installation,Path(job['binary']) if job.get('binary') else None)
                progress(100,'Connecting to the match…')
                room_report={}
                if not run(job['invite'],job['host'],job['port'],job['seat'],script=job.get('script',False),report_callback=room_report.update):
                    raise RuntimeError('The match stopped. Check the connection and use Logs for details.')
            elif job['task']=='theater':
                from player_theater import browse
                from player_play import binary_path
                browse(installation,binary_path(),Path(job['profile']),progress)
            elif job['task'] in ('play','verify','choose'):
                progress(5,'Checking game files…')
                metadata=ready_install(installation,progress) if job['task']!='verify' else verify_install(installation)
                if job['task'] in ('play','choose'):
                    from player_play import environment, binary_path
                    from player_session import session_lock
                    binary=binary_path(Path(job['binary']) if job.get('binary') else None)
                    profile=Path(job['profile']);profile.mkdir(parents=True,exist_ok=True)
                    env=environment(installation,metadata,profile,int(job['fighters']),job['character'],job['mode'],job['items'],seed=job.get('seed',1),seconds=job.get('seconds',300),name=job.get('name',''),rules=job.get('rules'))
                    if job.get('show_controls'):env['MELEE3D_OPEN_CONTROLS']='1'
                    if job.get('backend') in ('vulkan','d3d12'):env['MELEE_BACKEND']=job['backend']
                    from player_graphics import prepare_graphics
                    with session_lock(profile):prepare_graphics(binary,env,profile,progress)
                    if job.get('menus',False) or job['task']=='choose':
                        from player_stage_preview import preview,native_menu_assets
                        native_menu_assets(installation,metadata)
                        env.update(MELEE_WINDOW_TITLE='Smash Royale',MELEE3D_NATIVE_MENUS='1',MELEE_BOOT_SCENE='title' if job['task']=='play' else 'melee',MELEE_NO_ATTRACT='1',
                                   MELEE3D_NATIVE_STAGE_PREVIEW=str(preview(installation.parent/'ui-cache')))
                        if job['task']=='choose':
                            env['MELEE3D_NATIVE_PICK_FILE']=str(profile/'choice.json')
                            if job.get('menu_state'):env.update(MELEE3D_NATIVE_MENU_STATE=job['menu_state'],MELEE3D_NATIVE_MENU_OUTPUT=job['menu_output'])
                    if job.get('menus',False):
                        request=profile/'menu-request.txt';request.unlink(missing_ok=True)
                        env.update(MELEE3D_NATIVE_MENU_SETTINGS=job.get('menu_settings',str(profile/'native-menu.state')),
                                   MELEE3D_NATIVE_MENU_REQUEST=str(request))
                    if job.get('frontend_check'):env['MELEE3D_NATIVE_FRONTEND_CHECK']=job['frontend_check'];env['MELEE3D_NATIVE_MENU_CHECK']='roster'
                    if job.get('frames'):env['MELEE_EXIT_AFTER_FRAMES']=str(job['frames'])
                    progress(100,'Playing — close the game window to return here')
                    recording=None
                    if job['task']=='play' and not job.get('frontend_check') and not job.get('frames'):
                        from player_theater import begin_recording
                        recording=begin_recording(env,binary,job)
                    with session_lock(profile):
                        with (profile/'stdout.txt').open('w',encoding='utf-8') as game_log:
                            completed=subprocess.run(game_command(binary,metadata['melee_path']),cwd=profile,
                                env=env,stdout=game_log,stderr=subprocess.STDOUT)
                    if recording:
                        from player_theater import finish_recording
                        finish_recording(recording,(profile/'stdout.txt').read_text(errors='replace'))
                    controls_shown='M3D CONTROLS READY' in (profile/'stdout.txt').read_text(errors='replace')
                    if completed.returncode:
                        raise RuntimeError(f'The game closed unexpectedly (code {completed.returncode}). Logs: {profile}')
                else:progress(100,'Game files verified')
            else:raise ValueError('Unknown launcher task')
            result={'ok':True,'installation':str(installation)}
            if installed_app:result['app']=installed_app
            if job['task']=='room' and room_report.get('options'):result['options']=room_report['options']
            if job['task']=='room' and room_report.get('round'):
                result['round']=room_report['round'];name=result['round']['winner'];result['round']['winner']=NAMES.get(name,name.title())
            if job['task']=='choose':
                result['choice']=load_settings(profile/'choice.json')
            if job['task']=='play':
                result['controls_shown']=controls_shown
                if job.get('menus'):
                    from player_menu import read_request,read_options
                    result['request']=read_request(profile/'menu-request.txt')
                    result['options']=read_options(Path(env['MELEE3D_NATIVE_MENU_SETTINGS']))
                logtext=(profile/'stdout.txt').read_text(errors='replace')
                choices=re.findall(r'M3D MENU CHOICE character=\d+ name=(\w+)',logtext)
                if choices:result['choice']={'character':choices[-1]}
                match=re.search(r'M3D PARTY END tick=(\d+) winner=(-?\d+)',logtext)
                if match:
                    from native_lineup import PLAYERS
                    labels={kind:NAMES.get(name,name.title()) for name,kind,_ in PLAYERS}
                    slot=int(match[2]);lineup=list(map(int,env['MELEE3D_NATIVE_LINEUP'].split(',')))
                    for seat,character in re.findall(r'M3D ROSTER SLOT slot=(\d+) character=(\d+)',logtext):lineup[int(seat)]=int(character)
                    result['round']=dict(winner='Draw' if slot<0 else labels.get(lineup[slot],'Winner'),
                                         you_won=slot==0,seconds=int(match[1])//60)

        except Exception as error:
            traceback.print_exc()
            message=str(error)
            if isinstance(error,subprocess.CalledProcessError):
                message=f'The import tool {Path(error.cmd[0]).name} stopped (code {error.returncode}). See the log for details.'
            result={'ok':False,'error':message,'log':str(log)}
            if getattr(error,'recovery',None)=='locate-melee':result['recovery']='locate-melee'
        finally:save_settings(Path(job['result']),result)
    return 0 if result['ok'] else 1


class Launcher:
    def __init__(self,root,home=None,autoplay=True,game_only=False):
        import tkinter as tk
        from tkinter import ttk
        from native_lineup import PLAYERS
        self.tk=tk;self.ttk=ttk;self.root=root;self.home=home or user_directory();self.autoplay=autoplay;self.game_only=game_only
        self.config=self.home/'launcher.json';self.settings=load_settings(self.config)
        self.process=None;self.job=None;self.log_offset=0;self.busy=False;self.traces=[]
        self.characters={NAMES.get(name,name.title()):name for name,_,_ in PLAYERS}
        self.character=tk.StringVar(value=self.settings.get('character','Sonic'))
        if self.character.get() not in self.characters:self.character.set('Sonic')
        migrate_brand(self.home,self.settings)
        self.mode=tk.StringVar(value=self.settings.get('mode','Battle Royale'))
        if self.mode.get() not in MODES:self.mode.set('Battle Royale')
        self.fighters=tk.StringVar(value='32')
        if self.fighters.get() not in ('2','16','24','32'):self.fighters.set('32')
        self.items=tk.StringVar(value=self.settings.get('items','Medium'))
        if self.items.get() not in ITEMS:self.items.set('Medium')
        self.renderer=tk.StringVar(value=self.settings.get('renderer','Automatic'))
        if self.renderer.get() not in ('Automatic','Vulkan','Direct3D 12'):self.renderer.set('Automatic')
        saved_path=self.settings.get('installation');self.installation=Path(saved_path if isinstance(saved_path,str) and saved_path else self.home/'game-data')
        self.lobby_host=None;self.lobby_client=None;self.lobby_state=None;self.room_launched=False
        minutes=str(self.settings.get('minutes',5));self.seconds=tk.StringVar(value=minutes if minutes.isdigit() and 0<=int(minutes)<=99 else '5')
        self.humans=tk.StringVar(value='2');self.code=tk.StringVar();self.address=tk.StringVar()
        self.nickname=tk.StringVar(value=self.settings.get('nickname',''))
        root.title('Smash Royale');root.geometry('480x230');root.minsize(440,220)
        root.protocol('WM_DELETE_WINDOW',self.close)
        style=ttk.Style()
        # Installer/recovery only. Normal play uses Melee's native menu scenes.
        themes=style.theme_names()
        preferred='aqua' if sys.platform=='darwin' else 'vista'
        if preferred in themes:style.theme_use(preferred)
        style.configure('Title.TLabel',font=('TkDefaultFont',18,'bold'))
        style.configure('Section.TLabel',font=('TkDefaultFont',14,'bold'))
        style.configure('Muted.TLabel',font=('TkDefaultFont',11))
        self.frame=ttk.Frame(root,padding=(20,16));self.frame.pack(fill='both',expand=True)
        self.heading=ttk.Label(self.frame,text='Preparing to play',style='Section.TLabel')
        self.heading.pack(anchor='w',pady=(0,8))
        self.body_area=ttk.Frame(self.frame)
        self.body_canvas=tk.Canvas(self.body_area,background=root.cget('background'),borderwidth=0,highlightthickness=0)
        self.body_scroll=ttk.Scrollbar(self.body_area,orient='vertical',command=self.body_canvas.yview)
        self.body_canvas.configure(yscrollcommand=self.body_scroll.set)
        self.body_canvas.pack(side='left',fill='both',expand=True)
        self.body=ttk.Frame(self.body_canvas)
        self.body_window=self.body_canvas.create_window((0,0),window=self.body,anchor='nw')
        def fit_body(event=None):
            self.body_canvas.itemconfigure(self.body_window,width=self.body_canvas.winfo_width())
            self.body_canvas.configure(scrollregion=self.body_canvas.bbox('all'))
            if self.body.winfo_reqheight()>self.body_canvas.winfo_height()+2:self.body_scroll.pack(side='right',fill='y')
            else:self.body_scroll.pack_forget()
        self.body.bind('<Configure>',fit_body);self.body_canvas.bind('<Configure>',fit_body)
        def scroll_body(event):
            if self.body_scroll.winfo_ismapped() and not isinstance(event.widget,ttk.Combobox):
                amount=int(-event.delta/120) if abs(event.delta)>=120 else (-1 if event.delta>0 else 1)
                self.body_canvas.yview_scroll(amount,'units')
        root.bind('<MouseWheel>',scroll_body)
        self.status=tk.StringVar(value='')
        self.progress=ttk.Progressbar(self.frame,maximum=100)
        self.footer=ttk.Frame(self.frame);self.footer.pack(side='bottom',fill='x',pady=(12,0))
        self.progress.pack(side='bottom',fill='x',pady=(8,0))
        status_label=ttk.Label(self.frame,textvariable=self.status,wraplength=400)
        status_label.pack(side='bottom',anchor='w',pady=(8,4))
        self.frame.bind('<Configure>',lambda event:status_label.configure(wraplength=max(260,event.width-40)))
        self.body_area.pack(fill='both',expand=True)
        ttk.Button(self.footer,text='Logs',command=lambda:self.open_path(self.home/'logs')).pack(side='right')
        ttk.Button(self.footer,text='Controls',command=self.controls).pack(side='right',padx=8)
        ttk.Button(self.footer,text='Game files',command=self.setup).pack(side='left')
        if (self.installation/'player-install.json').is_file():self.play_screen()
        else:self.setup()

    def trace(self,var,callback):
        self.traces.append((var,var.trace_add('write',callback)))

    def clear(self):
        for var,token in self.traces:var.trace_remove('write',token)
        self.traces=[]
        self.body_canvas.yview_moveto(0)
        for widget in self.body.winfo_children():widget.destroy()

    def play_screen(self):
        if self.busy:return
        self.clear()
        self.root.title('Smash Royale');self.root.geometry('480x230');self.root.minsize(440,220)
        if hasattr(self,'heading'):self.heading.configure(text='Preparing to play')
        if self.autoplay:self.root.after(0,self.play)

    def choose_fighter(self,live=False):
        if self.busy:return
        if live and not (self.lobby_host or self.lobby_client):return
        profile=self.home/'profiles'/('lobby-menu' if live else 'fighter-menu')
        profile.mkdir(parents=True,exist_ok=True)
        (profile/'choice.json').unlink(missing_ok=True)
        job=dict(task='choose',installation=str(self.installation),profile=str(profile),fighters=32,
                 character=self.characters[self.character.get()],mode=MODES[self.mode.get()],items=ITEMS[self.items.get()],seed=secrets.randbits(32))
        if live:
            self.native_lobby_started=True
            if self.lobby_host:self.lobby_host.set_ready(False)
            else:self.lobby_client.ready(False)
            self.menu_state_path=profile/'lobby.state';self.menu_output_path=profile/'cursor.state';self.last_menu_choice=None
            self.menu_output_path.unlink(missing_ok=True)
            from player_menu import write_state
            write_state(self.menu_state_path,self.lobby_state)
            job.update(menu_state=str(self.menu_state_path),menu_output=str(self.menu_output_path))
        self.start(job)

    def room_identity(self):
        from player_play import binary_path
        from native_compatibility import sha
        metadata=load_settings(self.installation/'player-install.json')
        if not metadata:raise ValueError('Import your game files first.')
        return dict(executable=sha(binary_path()),melee=metadata['melee_sha256'],
                    game_files={k:v for k,v in metadata['files'].items() if not k.endswith(('.json','.log','.wav'))})

    def host_lobby(self):
        try:
            from player_lobby import Host
            from player_multiplayer import create
            identity=self.room_identity()
            options=dict(humans=int(self.humans.get()),fighters=int(self.fighters.get()),mode=MODES[self.mode.get()],
                         items=ITEMS[self.items.get()],seconds=int(self.seconds.get())*60,rules=self.settings.get('rules'))
            def factory(characters,settings):
                return create(settings['humans'],settings['fighters'],characters,settings['mode'],settings['items'],
                              seed=secrets.randbits(32),frames=0,identity=identity,seconds=settings['seconds'],names=settings['names'],rules=settings.get('rules'),selection=settings.get('selection'))
            self.lobby_host=Host(identity,factory,self.characters[self.character.get()],options,nickname=self.nickname.get())
            self.code.set(self.lobby_host.code);self.address.set(self.lobby_host.address)
            self.lobby_screen(True)
        except (ValueError,OSError) as error:
            self.error(str(error));self.play_screen()

    def join_lobby(self):
        try:
            from player_lobby import Client
            self.lobby_client=Client(self.code.get(),self.room_identity(),self.characters[self.character.get()],nickname=self.nickname.get())
            self.lobby_screen(False)
        except (ValueError,OSError) as error:
            self.error(str(error));self.play_screen()

    def lobby_screen(self,hosting):
        self.room_launched=False;self.native_lobby_started=False;self.pending_room_state=None
        if self.lobby_host:
            self.lobby_host.set_ready(False)
            self.root.clipboard_clear();self.root.clipboard_append(self.lobby_host.code)
            from tkinter import messagebox
            messagebox.showinfo('Room code copied',
                'Share this code with friends on your LAN or VPN:\n\n'+self.lobby_host.code+
                '\n\nChoose your fighter and press START when ready.',parent=self.root)
        self.root.withdraw()
        self.root.after(150,self.poll_lobby)

    def update_address(self):
        import ipaddress
        try:
            address=str(ipaddress.IPv4Address(self.address.get().strip()));self.lobby_host.address=address
            self.code.set(f'memelees://{address}:{self.lobby_host.listener.getsockname()[1]}/{self.lobby_host.key.hex()}')
        except ValueError:self.error('Enter your LAN or VPN IPv4 address.')

    def start_room(self):
        try:self.lobby_host.start()
        except (ValueError,OSError) as error:
            self.error(str(error));self.play_screen()

    def poll_lobby(self):
        if not self.lobby_host and not self.lobby_client:return
        state=self.lobby_host.snapshot() if self.lobby_host else self.lobby_state
        if self.lobby_client:
            while not self.lobby_client.events.empty():state=self.lobby_client.events.get()
        if state:
            self.lobby_state=state
            if state.get('error'):
                self.leave_lobby();self.error(state['error']);self.play_screen();return
            if not getattr(self,'native_lobby_started',False) and not self.busy and not state.get('running'):
                self.native_lobby_started=True;self.choose_fighter(live=True)
            if getattr(self,'native_lobby_started',False) and getattr(self,'menu_state_path',None):
                from player_menu import write_state,read_selection
                write_state(self.menu_state_path,state)
                choice=read_selection(self.menu_output_path)
                if choice and choice!=self.last_menu_choice and not state.get('running'):
                    self.last_menu_choice=choice;character=choice['character'];x,y,ready=choice['x'],choice['y'],choice['ready']
                    label=next((k for k,v in self.characters.items() if v==character),None)
                    if label and self.character.get()!=label:self.character.set(label);self.settings['character']=label;save_settings(self.config,self.settings)
                    if self.lobby_host:
                        if ready:self.lobby_host.set_ready(True,character,costume=choice["costume"],cpu=choice["cpu"])
                        else:self.lobby_host.choose(character,x,y,costume=choice["costume"],cpu=choice["cpu"])
                    else:
                        if ready:self.lobby_client.ready(True,character,costume=choice["costume"])
                        else:self.lobby_client.choose(character,x,y,costume=choice["costume"])
                if self.lobby_host and not state.get('running') and len(state.get('players',[]))==state['options']['humans'] and all(p['ready'] for p in state['players']):
                    self.lobby_host.start()
            if state.get('running') and self.busy and self.job.get('task')=='choose':self.pending_room_state=state
            if state.get('running') and not self.room_launched and not self.busy:
                self.room_launched=True
                self.start(dict(task='room',installation=str(self.installation),invite=state['invite'],host='127.0.0.1' if self.lobby_host else self.lobby_client.address,
                                port=state['port'],seat=state['seat']))
        if not self.room_launched:self.root.after(100,self.poll_lobby)

    def leave_lobby(self):
        if self.lobby_client:self.lobby_client.close()
        if self.lobby_host:self.lobby_host.close()
        self.lobby_client=self.lobby_host=self.lobby_state=None;self.room_launched=False

    def finish_fighter_menu(self):
        """Closing a selector withdraws readiness unless the room has started.

        Covers B, the window close button and Stop, including a close after
        pressing Ready. The last native output must not re-ready the player
        on the next lobby poll.
        """
        state=self.lobby_host.snapshot() if self.lobby_host else self.lobby_state
        if state and state.get('running'):return
        self.menu_output_path.unlink(missing_ok=True)
        self.last_menu_choice=None
        if self.lobby_host:self.lobby_host.set_ready(False)
        elif self.lobby_client:self.lobby_client.ready(False)

    def error(self,message):
        from tkinter import messagebox
        self.status.set(message);messagebox.showerror('Smash Royale',message,parent=self.root)

    def setup(self):
        if self.busy:return
        if getattr(self,'game_only',False):
            from tkinter import messagebox
            messagebox.showinfo('Game files','Open Smash Royale Setup to import or repair your game files.',parent=self.root)
            self.root.destroy();return
        from tkinter import filedialog
        self.root.deiconify();self.clear();ttk=self.ttk
        self.root.title('Smash Royale — Setup');self.root.geometry('600x540');self.root.minsize(560,520)
        self.heading.configure(text='Install your game files')
        self.progress.pack_forget()
        ttk.Label(self.body,text='Choose your two game images. Import once, then just play.',
                  style='Muted.TLabel',wraplength=520).pack(anchor='w',pady=(0,16))
        self.paths={}
        for key,label,hint,types in (
            ('melee','Super Smash Bros. Melee','USA · version 1.02',[('GameCube image','*.iso *.gcm'),('All files','*')]),
            ('sunshine','Super Mario Sunshine','USA · revision 0',[('Disc image','*.iso *.gcm *.7z *.zip'),('All files','*')])):
            card=ttk.LabelFrame(self.body,text=label,padding=12);card.pack(fill='x',pady=(0,12))
            ttk.Label(card,text=hint,style='Muted.TLabel').pack(anchor='w')
            line=ttk.Frame(card);line.pack(fill='x',pady=(6,0));line.columnconfigure(0,weight=1)
            var=self.tk.StringVar(value=self.settings.get(key,''));self.paths[key]=var
            ttk.Entry(line,textvariable=var).grid(row=0,column=0,sticky='ew',padx=(0,8))
            def browse(v=var,t=types,title=label):
                path=filedialog.askopenfilename(parent=self.root,title='Choose '+title,filetypes=t)
                if path:v.set(path)
            ttk.Button(line,text='Choose…',command=browse).grid(row=0,column=1)
        self.paths['patch']=self.tk.StringVar(value='')
        offline=ttk.Frame(self.body);offline.pack(fill='x',pady=(0,10))
        ttk.Label(offline,text='Akaneia 1.0.1 downloads automatically.',style='Muted.TLabel').pack(side='left')
        def choose_patch():
            path=filedialog.askopenfilename(parent=self.root,title='Choose the official Akaneia 1.0.1 builder',
                                           filetypes=[('7-Zip archive','*.7z'),('All files','*')])
            if path:self.paths['patch'].set(path);self.status.set('Offline Akaneia patch selected: '+Path(path).name)
        ttk.Button(offline,text='Use offline patch…',command=choose_patch).pack(side='right')
        buttons=ttk.Frame(self.body);buttons.pack(fill='x',pady=(4,0))
        ttk.Button(buttons,text='Install and play',command=self.import_files).pack(side='left')
        if (self.installation/'player-install.json').is_file():
            ttk.Button(buttons,text='Repair Melee…',command=self.locate_melee).pack(side='left',padx=12)
            ttk.Button(buttons,text='Back to game',command=self.play_screen).pack(side='right')
        self.status.set('6 GB free required. Everything is prepared locally; no game files are uploaded.')

    def locate_melee(self):
        if self.busy:return
        from tkinter import filedialog
        path=filedialog.askopenfilename(parent=self.root,title='Locate your original Melee USA v1.2 image',
                                       filetypes=[('GameCube image','*.iso *.gcm'),('All files','*')])
        if path:self.start(dict(task='locate-melee',installation=str(self.installation),melee=path))

    def import_files(self):
        from tkinter import messagebox
        values={k:v.get().strip() for k,v in self.paths.items()}
        if not all(Path(v).is_file() for v in values.values() if v) or not values.get('melee') or not values.get('sunshine'):
            messagebox.showerror('Choose game files','Choose your Melee and Sunshine images before installing.',parent=self.root);return
        self.settings.update(values)
        # A successful import selects the new directory. Failed imports leave the old one usable.
        target=self.home/'installations'/(time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:6])
        self.start(dict(task='import',installation=str(target),**values))

    def play(self,show_controls=False):
        from player_lobby import player_name
        try:name=player_name(self.nickname.get())
        except ValueError as error:self.error(str(error));return
        self.settings['nickname']=name
        self.settings.update(character=self.character.get(),mode=self.mode.get(),fighters=int(self.fighters.get()),items=self.items.get(),renderer=self.renderer.get(),minutes=int(self.seconds.get()))
        save_settings(self.config,self.settings)
        self.start(dict(task='play',menus=True,show_controls=show_controls,menu_settings=str(self.home/'native-menu.state'),installation=str(self.installation),character=self.characters[self.character.get()],
                        mode=MODES[self.mode.get()],fighters=int(self.fighters.get()),items=ITEMS[self.items.get()],
                        backend={'Vulkan':'vulkan','Direct3D 12':'d3d12'}.get(self.renderer.get()),
                        profile=str(self.home/'profiles/offline'),seconds=int(self.seconds.get())*60,seed=secrets.randbits(32),name=name,rules=self.settings.get('rules')))

    def controls(self):
        # Reuse the real controller/remapping screen, with the attached pad's
        # SDL button names and saved bindings, rather than a generic diagram.
        if not self.busy and (self.installation/'player-install.json').is_file():
            self.play(show_controls=True);return
        from tkinter import messagebox
        messagebox.showinfo('Controls',
            'Connect a controller by USB or Bluetooth before playing.\n\n'
            'The game shows your controller’s buttons and lets you remap them. '
            'Press F1 from the game menus to reopen Controls.\n\n'
            'Left stick: move / aim · Right stick: turn camera\n'
            'L1 / LB: aim up · L2 / LT: aim down\n'
            'R1 / RB: grab · R2 / RT: shield',parent=self.root)

    def start(self,job):
        if self.busy:return
        if job['task'] in ('play','import','locate-melee') and not getattr(self,'game_only',False):
            self.root.deiconify();self.clear();self.root.title('Smash Royale');self.root.geometry('480x230');self.root.minsize(440,220)
            self.heading.configure(text='Installing game files' if job['task']=='import' else 'Starting game')
        self.cancelled=False
        self.progress.pack(side='bottom',fill='x',pady=(8,0),before=self.body_area)
        self.home.mkdir(parents=True,exist_ok=True)
        identifier=time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:6]
        base=self.home/'logs'/identifier;base.parent.mkdir(parents=True,exist_ok=True)
        self.job_path=base.with_suffix('.job.json')
        job.update(log=str(base.with_suffix('.log')),result=str(base.with_suffix('.result.json')))
        save_settings(self.job_path,job);self.job=job;self.log_offset=0
        command=[sys.executable]
        if not getattr(sys,'frozen',False):command+=[str(Path(__file__).resolve())]
        command+=['--worker',str(self.job_path)]
        try:self.process=subprocess.Popen(command,stdin=subprocess.DEVNULL,start_new_session=(os.name!='nt'))
        except OSError as error:
            from tkinter import messagebox
            messagebox.showerror('Could not start',str(error),parent=self.root);return
        self.busy=True;self.set_enabled(False);self.stop_button=self.ttk.Button(self.footer,text='Stop',command=self.stop);self.stop_button.pack(side='right',padx=8);self.progress['value']=0
        self.status.set('Starting…');self.root.after(100,self.poll)

    def set_enabled(self,enabled):
        def walk(parent):
            for widget in parent.winfo_children():
                if isinstance(widget,(self.ttk.Button,self.ttk.Entry,self.ttk.Combobox,self.ttk.Checkbutton)):
                    widget.state(['!disabled'] if enabled else ['disabled'])
                walk(widget)
        walk(self.body)

    def poll(self):
        log=Path(self.job['log'])
        if log.exists():
            with log.open(encoding='utf-8',errors='replace') as f:
                f.seek(self.log_offset);lines=f.readlines();self.log_offset=f.tell()
            for line in lines:
                if line.startswith('MEMELEES_PROGRESS '):
                    try:
                        info=json.loads(line.split(' ',1)[1]);self.status.set(info['message']);self.progress['value']=info['value']
                        if info['value']>=100 and self.job['task'] in ('play','choose','room','theater'):self.root.withdraw()
                    except ValueError:pass
        if self.process.poll() is None:self.root.after(150,self.poll);return
        # A completed job may immediately start another one (play -> Theater
        # or Theater -> play). Cleanup must refer to the finished task, not
        # self.job_path after that handoff has installed a fresh worker.
        finished_job_path=self.job_path
        self.busy=False;self.stop_button.destroy();self.set_enabled(True)
        if self.job['task']=='import':
            from player_install import cleanup_cancelled_import
            cleanup_cancelled_import(Path(self.job['installation']),self.process.pid)
        result=load_settings(Path(self.job['result']))
        if self.job['task']=='choose' and self.job.get('menu_state'):
            self.finish_fighter_menu()
        if result.get('ok'):
            if self.job['task']=='import':
                self.settings['controls_seen']=False
                self.installation=Path(result['installation']);self.settings['installation']=str(self.installation)
                save_settings(self.config,self.settings);self.play_screen()
            elif self.job['task']=='locate-melee':
                self.settings['melee']=self.job['melee'];save_settings(self.config,self.settings);self.play_screen()
                self.status.set('Melee image located — ready to play')
            elif self.job['task']=='choose':
                chosen=result.get('choice',{}).get('character')
                if chosen in self.characters.values():
                    self.character.set(next(k for k,v in self.characters.items() if v==chosen));self.settings['character']=self.character.get();save_settings(self.config,self.settings)
                if not self.job.get('menu_state'):self.play_screen()
                elif not (self.lobby_host.snapshot() if self.lobby_host else self.lobby_state or {}).get('running'):
                    self.leave_lobby();self.play_screen()
            elif self.job['task'] in ('play','room'):
                if result.get('controls_shown'):self.settings['controls_seen']=True;save_settings(self.config,self.settings)
                chosen=result.get('choice',{}).get('character')
                if chosen in self.characters.values():
                    self.character.set(next(k for k,v in self.characters.items() if v==chosen));self.settings['character']=self.character.get()
                self.apply_native_options(result.get('options'))
                self.leave_lobby()
                request=result.get('request')
                if request:self.native_request(request)
                elif result.get('round'):self.play_screen()
                else:finished_job_path.unlink(missing_ok=True);self.root.destroy();return
            elif self.job['task']=='theater':self.play()
            else:self.status.set('Game files verified')
        else:
            from tkinter import messagebox
            self.root.deiconify()
            if self.job['task']=='room':self.leave_lobby()
            self.status.set('Stopped' if getattr(self,'cancelled',False) else 'Could not finish. See the log for details.')
            if not getattr(self,'cancelled',False):messagebox.showerror('Smash Royale',result.get('error','The task stopped unexpectedly.')+'\n\nLog: '+str(log),parent=self.root)
            self.clear()
            self.ttk.Button(self.body,text='Try again',command=self.setup if self.job['task']=='import' else self.play_screen).pack(anchor='w',pady=12)
            if result.get('recovery')=='locate-melee' and not getattr(self,'cancelled',False):self.setup()
        finished_job_path.unlink(missing_ok=True)

    def open_path(self,path):
        path.mkdir(parents=True,exist_ok=True)
        if sys.platform=='win32':os.startfile(path)
        else:subprocess.Popen(['open' if sys.platform=='darwin' else 'xdg-open',str(path)])

    def apply_native_options(self,options):
        if not options:return
        self.mode.set(next(label for label,value in MODES.items() if value==options['mode']))
        self.items.set(next(label for label,value in ITEMS.items() if value==options['items']))
        self.seconds.set(str(options['seconds']//60));self.humans.set(str(options['humans']))
        self.settings.update(mode=self.mode.get(),items=self.items.get(),minutes=int(self.seconds.get()))
        if 'rules' in options:
            from player_rules import validate
            self.settings['rules']=validate(options['rules'])
        save_settings(self.config,self.settings)

    def native_request(self,request):
        self.apply_native_options(request)
        action=request['action']
        if action=='files':self.setup()
        elif action=='theater':self.start(dict(task='theater',installation=str(self.installation),profile=str(self.home/'profiles/theater')))
        elif action=='host':self.host_lobby()
        elif action=='join':
            from tkinter import simpledialog
            code=simpledialog.askstring('Join match','Room code from your friend:',parent=self.root)
            if code:self.code.set(code);self.join_lobby()
            else:self.play_screen()
        else:self.root.destroy()

    def stop(self):
        if not self.process or self.process.poll() is not None:return
        self.cancelled=True
        if os.name=='nt':subprocess.run(['taskkill','/PID',str(self.process.pid),'/T','/F'],capture_output=True)
        else:
            try:os.killpg(self.process.pid,signal.SIGTERM)
            except ProcessLookupError:pass
        self.status.set('Stopping…')

    def close(self):
        if self.busy:
            from tkinter import messagebox
            if not messagebox.askyesno('Quit Smash Royale','Stop the current game or import and quit?',parent=self.root):return
            self.stop()
        if self.lobby_client:self.lobby_client.close()
        if self.lobby_host:self.lobby_host.close()
        self.root.destroy()


def continue_desktop(installation,request,character='sonic'):
    """Continue native menu actions when the game was started from the CLI."""
    import tkinter as tk
    root=tk.Tk();root.withdraw();app=Launcher(root,autoplay=False);root.withdraw()
    app.installation=Path(installation);app.autoplay=True
    if character in app.characters.values():app.character.set(next(k for k,v in app.characters.items() if v==character))
    app.native_request(request);root.mainloop()


def main():
    p=argparse.ArgumentParser();p.add_argument('--worker',type=Path);p.add_argument('--home',type=Path)
    p.add_argument('--game',action='store_true');p.add_argument('--setup',action='store_true')
    p.add_argument('--smoke',type=Path,help=argparse.SUPPRESS);a=p.parse_args()
    if a.worker:return worker(a.worker)
    game_marker=(Path(sys.executable).parent/'game-app.json').exists() or (Path(sys.executable).parent.parent/'Resources/game-app.json').exists()
    if a.setup or (getattr(sys,'frozen',False) and not game_marker and not a.game and not a.smoke):
        from player_setup import main as setup_main
        return setup_main(a.home,a.smoke)
    import tkinter as tk
    root=tk.Tk()
    game_only=(a.game or game_marker) and not a.smoke
    if game_only:root.withdraw()
    app=Launcher(root,a.home,autoplay=not bool(a.smoke),game_only=game_only)
    if a.smoke:
        def done():
            save_settings(a.smoke,dict(ok=True,screen='play' if (app.installation/'player-install.json').is_file() else 'setup',
                frozen=bool(getattr(sys,'frozen',False)),payload=str(payload()),characters=len(app.characters),
                fighters=int(app.fighters.get()),python=sys.version.split()[0],platform=sys.platform))
            root.destroy()
        root.after(1500,done)
    root.mainloop();return 0


if __name__=='__main__':raise SystemExit(main())
