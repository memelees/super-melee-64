"""Bianco Hills candidate: authored art plus an explicit connected spawn area.

No invented bridge joins the disconnected hills. The ordinary village SCC is
the spawn/clean-goal region; extended character abilities can reach farther.
The separate native acceptance gate decides whether to expose this bank.
"""
from collections import Counter
import hashlib,json,struct,time
from pathlib import Path
from player_paths import payload,source_file
from sunshine_survey_brg import collect,write_banks
from sunshine_navigation import components,encode
from sunshine_sirena_prototype import Queries,read_collision,filter_graph,select_spawns

VERSION=1

class BiancoQueries(Queries):
    def dry(self,p):return not any(p[1]<h+.5 for h in self.levels(p[0],p[2],True))

def read_navigation(path):
    raw=Path(path).read_bytes();magic,version,count,links,step=struct.unpack_from('<4s3If',raw)
    if magic!=b'DLN1' or version!=3 or len(raw)!=20+count*24+links*8:raise ValueError('Invalid Bianco route bank')
    records=[struct.unpack_from('<3f3I',raw,20+i*24) for i in range(count)]
    nodes=[r[:3] for r in records];edges=[]
    for x,y,z,group,first,n in records:
        if first+n>links:raise ValueError('Invalid Bianco route range')
        edges.append([struct.unpack_from('<2I',raw,20+count*24+(first+j)*8)for j in range(n)])
    return nodes,edges,[r[3]for r in records],step

def curate(source,target):
    """Update only routes/settings in a separately copied material revision."""
    import shutil
    source=Path(source);target=Path(target).resolve()
    repo=payload().resolve()
    if target==repo or repo in target.parents:raise ValueError('Private Sunshine bank must stay outside the repository')
    if target.exists():raise ValueError('Use a fresh private Bianco candidate directory')
    target.mkdir(parents=True)
    for name in ('delfino.dlv','delfino.dlc','delfino.dlg','delfino.dls'):shutil.copy2(source/name,target/name)
    triangles=read_collision(source/'delfino.dlc');nodes,edges,groups,step=read_navigation(source/'delfino.dln')
    query=BiancoQueries(triangles);nodes,edges,groups,removed=filter_graph(nodes,edges,query)
    center,spawns=select_spawns(nodes,edges,groups,query);point=nodes[center]
    (target/'delfino.dln').write_bytes(encode(nodes,edges,groups,step))
    raw=(target/'delfino.dls').read_bytes();(target/'delfino.dls').write_bytes(raw[:12]+struct.pack('<3f',*point)+raw[24:])
    report=dict(version=VERSION,scene='bianco0',name='Bianco Hills',spawn_center=point,spawn_candidates=spawns,
        navigation=dict(nodes=len(nodes),edges=sum(map(len,edges)),ordinary_scc=True,largest_component_nodes=Counter(groups).most_common(1)[0][1],wet_nodes_removed=removed,step=step),
        limitations=['Spawn and clean-goal region is the ordinary connected village. Distant disconnected hills are not claimed reachable by every fighter.',
                      'Windmills and platforms retain authored static poses; no Sunshine actor simulation.'],
        files={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in target.glob('delfino.*')})
    (target/'prototype-report.json').write_text(json.dumps(report,indent=2)+'\n')
    return report

def convert(directory,target,scale,navigation=True):
    """Derive a fresh bank from already extracted owned-disc Bianco0 files."""
    import tempfile
    target=Path(target);target.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.bianco-',dir=target.parent)as td:
        raw=Path(td)/'raw';geometry,colliders,textures,draws,report=collect(Path(directory),scale)
        if report['failed_models']:raise ValueError('Bianco contains unsupported original props')
        write_banks(raw,geometry,colliders,textures,draws,scale,32)
        result=curate(raw,target)
    result['source_sha256']={name:hashlib.sha256((Path(directory)/name).read_bytes()).hexdigest()for name in ('map/scene.bin','map/map.col','map/map/map.bmd')}
    result['converter_sha256']=hashlib.sha256(source_file('sunshine_bianco_playable.py').read_bytes()).hexdigest()
    (target/'prototype-report.json').write_text(json.dumps(result,indent=2)+'\n');return result
