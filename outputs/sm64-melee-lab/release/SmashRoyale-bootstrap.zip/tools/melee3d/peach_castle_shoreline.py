"""Measured Castle garden edge repair using the original grass/rock materials.

A rounded, gently sloping bank meets the existing lake. No water, skyline,
waterfall, sea or cloud geometry is added. Rendered bank faces and physical
bank faces are the same geometry; submerged tops are clipped by the compiler.
"""
import collections,math
from peach_castle_source import normal


def scenery(rows):
    rock=next(t for t in rows if t['group']==4 and 'GrdCastleMt3_CMPR_image'in t['symbols'])
    grass=[t for t in rows if t['group']==3 and t['normal'][1]<-.64 and any('Gdngrs'in s for s in t['symbols'])]
    edges=collections.defaultdict(list)
    for t in grass:
        vs=t['vertices']
        for a,b in zip(vs,vs[1:]+vs[:1]):edges[tuple(sorted(tuple(round(x,4)for x in v[:3])for v in(a,b)))].append((a,b,t))
    additions=collections.defaultdict(list);land=[];counts=collections.Counter();joins=[]
    def face(template,ps,uv,color,feature,outward,physical=True):
        for ids in((0,1,2),(0,2,3)):
            vs=[[*ps[i],*uv[i],*color[i]]for i in ids];n=normal([v[:3]for v in vs])
            if n is None:continue
            if sum(n[k]*outward[k]for k in range(3))>0:vs.reverse();n=tuple(-v for v in n)
            t=dict(vertices=vs,points=[v[:3]for v in vs],normal=n,group=template['group'],joint=template['joint'],dobj=template['dobj'],material=template['material'],symbols=template['symbols'],feature=feature,extension_solid=physical)
            additions[t['dobj']].append(t);counts[feature]+=1
            if physical:land.append(t)
    def outward(v):
        x,_,z=v[:3]
        if z>370.49:
            nx=math.copysign(max(0,(abs(x)-350)/75),x);nz=1.
        else:nx=math.copysign(1.,x);nz=max(0,(z-295.5)/75)
        length=math.hypot(nx,nz);return nx/length,nz/length
    def point(v,f):
        x,y,z=v[:3];nx,nz=outward(v);width=60+5*math.sin(x*.017)+4*math.cos(z*.029)
        smooth=f*f*(3-2*f)
        return(x+nx*width*f,y+(6.2-y)*smooth,z+nz*width*f)
    selected=[]
    for records in edges.values():
        if len(records)!=1:continue
        a,b,t=records[0]
        if not(all(abs(v[0])>424.99 for v in(a,b))or all(v[2]>370.49 for v in(a,b))):continue
        # Retain the shallow native shore at the path's eastern low point;
        # never add a high barrier to a source edge already below the water.
        if max(a[1],b[1])<7.31:continue
        selected.append((a,b,t));joins.append([a[:3],b[:3]])
        for f0,f1 in((0,.32),(.32,.65),(.65,1.)):
            ps=[point(a,f0),point(b,f0),point(b,f1),point(a,f1)];source=(a,b,b,a)
            if f1<=.65:
                uv=[(v[3]+(p[0]-v[0])/850,v[4]+(p[2]-v[2])/276)for p,v in zip(ps,source)]
                colors=[tuple(v[5:9])for v in source];template=t;label='rounded-grass-bank'
            else:
                uv=[(p[0]/70+p[2]/95,-p[1]/40)for p in ps];colors=[(160,170,147,255),(151,164,141,255),(103,127,125,255),(112,133,129,255)];template=rock;label='sloping-rock-shore'
            face(template,ps,uv,colors,label,(0,1,0))
        p,q=point(a,1),point(b,1);ps=[p,q,(q[0],-12,q[2]),(p[0],-12,p[2])]
        nx,nz=outward(a);uv=[(v[0]/70+v[2]/95,-v[1]/40)for v in ps]
        face(rock,ps,uv,[(103,127,125,255)]*4,'submerged-shore-base',(nx,0,nz))
    if len(selected)<30:raise ValueError('Insufficient measured Castle shoreline edges')
    report=dict(version=1,scope='Local garden perimeter repair only; original water and scenery retained',boundary_edges=len(selected),counts=dict(counts),source_joins=joins,bank_width=[51,69],outer_bank_y=6.2,rock_base_y=-12,rounded_corner_start=dict(front_x=350,side_z=295.5),original_water_preserved=True,added_water_faces=0,added_scenic_sea=False,added_waterfall=False,added_clouds=False,central_path='Original dirt path boundary is included in the same continuous shoreline band; no separate notch or water floor',inspection_camera=dict(eye=[440,150,660],target=[80,12,390]))
    return dict(additions=dict(additions),land=land,report=report)
