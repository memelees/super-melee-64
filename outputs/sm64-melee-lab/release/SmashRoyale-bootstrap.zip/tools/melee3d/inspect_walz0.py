#!/usr/bin/env python3
"""Read-only research of walz0's pinned Melee-3D v1.0 distribution.

Requires a locally patched reference ISO and the user's original Melee ISO.
Does not install, execute or import the reference into either playable build.
The payload locations and record layout were identified from its PPC loader
and accessors, and are specific to the SHA-256 pinned below.
"""

import argparse
import hashlib
import json
import math
from pathlib import Path
import struct

from audit_akaneia import dol_read, dol_sections, original_functions
from prepare_akaneia import ROOT, BASE_MD5, digest


REFERENCE_SHA256 = "a11c8862b88dd0858ae1a8a980a3bd36e9ab9883372439cd5e8c2d08934b3839"
PAYLOAD_SHA256 = "ee4023f05f71e7efabafa99092d16178351ffe620abfbd1302e00eaac0922a3b"
PAYLOAD_BASE = 0x80586C00
PAYLOAD_OFFSET = 0x57700000
PAYLOAD_SIZE = 0x8D9E0
# Explicit StKind dispatch in the payload accessor at 0x805EADDC.
# Presence here is NOT a claim of officially supported/playtested stages.
SURFACE_TABLES = [
    (32, "Final Destination", 0x806004DC, 1),
    (3, "Pokemon Stadium", 0x806005E8, 12),
    (84, "Special stage 84", 0x80600A08, 2),
    (10, "Mute City", 0x80600F18, 13),
    (22, "Venom", 0x80602090, 31),
    (7, "Corneria", 0x80604800, 36),
    (2, "Fountain of Dreams", 0x80605574, 7),
    (28, "Dream Land", 0x806057DC, 5),
    (9, "Onett", 0x80605A28, 26),
    (8, "Yoshi's Story", 0x80606318, 5),
    (16, "Yoshi's Island", 0x8060651C, 18),
    (17, "Green Greens", 0x80606B4C, 96),
]


def read_at(stream, offset, length):
    stream.seek(offset)
    data = stream.read(length)
    if len(data) != length:
        raise ValueError("Reference extent outside ISO")
    return data


def filesystem(stream):
    offset, size = struct.unpack(">II", read_at(stream, 0x424, 8))
    data = read_at(stream, offset, size)
    count = struct.unpack_from(">I", data, 8)[0]
    if not 0 < count * 12 <= size:
        raise ValueError("Invalid disc filesystem")
    names = data[count * 12:]
    stack, result = [("", count)], {}
    for index in range(1, count):
        while stack and index >= stack[-1][1]:
            stack.pop()
        kind_name, address, length = struct.unpack_from(">III", data, index * 12)
        start = kind_name & 0xFFFFFF
        name = names[start:names.index(0, start)].decode("ascii")
        path = "/".join(filter(None, (stack[-1][0], name)))
        if kind_name >> 24:
            stack.append((path, length))
        else:
            result[path] = address, length
    return result


def executable(stream):
    offset = struct.unpack(">I", read_at(stream, 0x420, 4))[0]
    header = read_at(stream, offset, 0x100)
    length = max(struct.unpack_from(">I", header, index * 4)[0] +
                 struct.unpack_from(">I", header, 0x90 + index * 4)[0]
                 for index in range(18))
    return read_at(stream, offset, length)


def surface_records(payload):
    stages = []
    for stage_id, name, address, count in SURFACE_TABLES:
        surfaces = []
        for index in range(count):
            offset = address - PAYLOAD_BASE + index * 0x58
            pointer, vertices, height = struct.unpack_from(">IIf", payload, offset)
            begin = pointer - PAYLOAD_BASE
            if not 3 <= vertices <= 256 or not 0 <= begin <= len(payload) - vertices * 8:
                raise ValueError("Unexpected surface layout in pinned release")
            points = [struct.unpack_from(">2f", payload, begin + index * 8)
                      for index in range(vertices)]
            if not all(math.isfinite(value) for point in points for value in point):
                raise ValueError("Non-finite footprint")
            surfaces.append({"address": hex(address + index * 0x58),
                             "height": height, "footprint_xz": points,
                             "raw_flags": hex(struct.unpack_from(">I", payload, offset + 0x24)[0])})
        stages.append({"stage_id": stage_id, "name": name, "surfaces": surfaces})
    return stages


def inspect(base, reference):
    if digest(base) != BASE_MD5 or digest(reference, "sha256") != REFERENCE_SHA256:
        raise ValueError("Expected native NTSC 1.02 and the pinned walz0 v1.0 ISO")
    with base.open("rb") as before, reference.open("rb") as after:
        old_files, new_files = filesystem(before), filesystem(after)
        changes = []
        for name, (address, size) in sorted(new_files.items()):
            data = read_at(after, address, size)
            old = read_at(before, *old_files[name]) if name in old_files else None
            if old != data:
                changes.append({"name": name, "before": len(old) if old is not None else None,
                                "after": size, "sha256": hashlib.sha256(data).hexdigest()})
        old_dol, new_dol = executable(before), executable(after)
        payload = read_at(after, PAYLOAD_OFFSET, PAYLOAD_SIZE)
    if hashlib.sha256(payload).hexdigest() != PAYLOAD_SHA256:
        raise ValueError("Reference code payload does not match the inspected release")
    old_sections, new_sections = dol_sections(old_dol), dol_sections(new_dol)
    functions = []
    for name, (address, size) in original_functions(ROOT / "config/GALE01/symbols.txt").items():
        old = dol_read(old_dol, old_sections, address, size)
        new = dol_read(new_dol, new_sections, address, size)
        if old == new:
            continue
        word = int.from_bytes(new[:4], "big")
        target = None
        if word >> 26 == 18 and not word & 2:
            displacement = word & 0x3FFFFFC
            if displacement & 0x2000000:
                displacement -= 0x4000000
            target = hex(address + displacement)
        functions.append({"name": name, "address": hex(address), "entry_branch": target,
                          "changed_words": sum(old[index:index + 4] != new[index:index + 4]
                                               for index in range(0, size, 4))})
    return {"project": "https://github.com/walz0/Melee-3D",
            "release": "https://github.com/walz0/Melee-3D/releases/tag/v1.0",
            "reference_sha256": REFERENCE_SHA256,
            "scope": "Static binary inspection, not runtime validation or recovered source. Surface names/layout semantics are inferred from accessor/disassembly; raw flag meanings remain incomplete.",
            "payload": {"address": hex(PAYLOAD_BASE), "iso_offset": hex(PAYLOAD_OFFSET),
                        "bytes": PAYLOAD_SIZE, "sha256": PAYLOAD_SHA256},
            "changed_files": changes, "removed_files": sorted(set(old_files) - set(new_files)),
            "changed_functions": functions, "surface_tables": surface_records(payload)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-iso", required=True, type=Path)
    parser.add_argument("--reference-iso", required=True, type=Path)
    parser.add_argument("--output", type=Path, default=ROOT / "build/references/walz0-audit.json")
    args = parser.parse_args()
    report = inspect(args.base_iso, args.reference_iso)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(f"Inspected {len(report['changed_functions'])} changed functions, "
          f"{len(report['changed_files'])} changed files and {len(report['surface_tables'])} surface tables")
    print(args.output)
