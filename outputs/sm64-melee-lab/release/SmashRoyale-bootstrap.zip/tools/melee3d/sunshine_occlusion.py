"""Geometry groups for camera cutaways; no level-specific building rules."""

def groups(triangles, whole=False, span=(192,256,192)):
    """Keep a prop together; split a town mesh into bounded welded components.

    An edge must be shared, rather than just a point. Bounds stop streets and
    connected architecture from turning the whole town into one cutaway.
    Material and UV seams do not split an otherwise connected component.
    """
    if not triangles:return []
    if whole:return [0]*len(triangles)
    parent=list(range(len(triangles)));sizes=[1]*len(parent)
    lo=[[min(v[0][k] for v in t) for k in range(3)] for t in triangles]
    hi=[[max(v[0][k] for v in t) for k in range(3)] for t in triangles]
    def root(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
        return i
    def join(a,b):
        a,b=root(a),root(b)
        if a==b or sizes[a]+sizes[b]>4096:return
        low=[min(lo[a][k],lo[b][k]) for k in range(3)];high=[max(hi[a][k],hi[b][k]) for k in range(3)]
        if any(high[k]-low[k]>span[k] for k in range(3)):return
        if sizes[a]<sizes[b]:a,b=b,a
        parent[b]=a;sizes[a]+=sizes[b];lo[a]=low;hi[a]=high
    edges={}
    for i,t in enumerate(triangles):
        ps=[tuple(round(c*1000) for c in v[0]) for v in t]
        for a,b in zip(ps,ps[1:]+ps[:1]):
            if a==b:continue
            key=tuple(sorted((a,b)))
            if key in edges:join(i,edges[key])
            else:edges[key]=i
    ids={};result=[]
    for i in range(len(parent)):
        r=root(i)
        if r not in ids:ids[r]=len(ids)
        result.append(ids[r])
    return result
