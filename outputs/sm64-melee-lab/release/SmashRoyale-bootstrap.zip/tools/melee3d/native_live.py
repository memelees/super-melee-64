#!/usr/bin/env python3
"""Bounded live Akaneia integration diagnostics, separate from the retail lab.

Failure on an unbound callback is expected while implementing the bridge; it
must never be reported as a playable character or a completed capacity pass.
"""
import argparse
import json
import os
import re

from native_compatibility import ROOT, WORK, DISC, bounded, sha, write_json
from native_mac import bundle, judge, verify_build
from native_roster import inventory, asset_identity
from native_lineup import allowed_kinds


def judge_live(code,log,roster,mode,frames,humans=0,character="fox",fighters=16,expected_lineup=None):
    """A spawn diagnostic cannot certify combat or silently omit a slot."""
    slots={int(s) for s in re.findall(r"M3D LIVE ONLOAD PASS slot=(\d+)",log)}
    outputs={int(s) for s in re.findall(r'M3D LIVE OUTPUT PASS slot=(\d+)',log)}
    evidence=judge(code,log,fighters,frames,False,"fox")
    expected={(s,(33+CHARACTERS.index(character)) if s==0 and character!='fox' else 1 if s<4 else 33 if roster=='wolf' else 33+(s-4)%7) for s in range(fighters)}
    added=set(range(4,fighters))|({0} if character!='fox' else set())
    identities=set(map(tuple,evidence['observed_identities']))
    identity_ok=identities==expected
    if expected_lineup is not None:
        expected={(s,r[2]) for s,r in enumerate(expected_lineup)}
        added={s for s,k in expected if k>=33}
        loaded=set(tuple(map(int,v)) for v in re.findall(r'M3D ROSTER LOADED slot=(\d+) kind=(\d+)',log))
        identity_ok=(len(expected_lineup)==fighters and loaded==expected and
                     {s for s,k in identities}==set(range(fighters)) and
                     all(k in allowed_kinds(expected_lineup[s][2]) for s,k in identities if 0<=s<fighters))
    summaries=evidence['summaries']
    pairs=evidence['observed_pairs']
    contacts=sorted({s for pair in pairs for s in pair})
    valid_pairs=all(0<=a<fighters and 0<=b<fighters and a!=b for a,b in pairs)
    failures=[line for line in log.splitlines() if any(x in line for x in
              ('M3D LIVE FAIL','M3D BRIDGE FAIL','M3D LAB FAIL','PANIC','FATAL','texture no exist!', 'assertion "'))]
    if code<0:failures.append(f'Native process crashed with signal {-code}')
    elif code==124:failures.append('Native process exceeded its bounded timeout')
    missing=[{'kind' :int(k),'slot':int(s)} for k,s in re.findall(r'M3D LIVE MISSING HOOK kind=(\d+) slot=(\d+)',log)]
    complete=(code==0 and f'MELEE_EXIT_AFTER_FRAMES: reached frame {frames}, exiting' in log
              and slots==added and outputs==slots and identity_ok and bool(summaries)
              and summaries[-1][0]>=600 and all(s[1]==fighters for s in summaries) and valid_pairs and not failures)
    combat=complete and mode=='combat' and summaries[-1][2]>=fighters-humans and summaries[-1][3]>=fighters//2 and len(contacts)>=fighters//2 and not missing
    return {'passed':complete if mode=='spawn' else combat,'mode':mode,'onload_slots':sorted(slots),
            'numeric_output_slots':sorted(outputs),
            'observed_identities':sorted(identities),'summaries':summaries,'missing_hooks':missing,
            'entered_events':sorted({tuple(map(int,row)) for row in re.findall(r'M3D LIVE EVENT slot=(\d+) kind=(\d+) event=(\d+)',log)}),
            'observed_pairs':pairs,'contact_slots':contacts,'failures':failures,'combat_smoke_pass':combat,
            'full_combat_pass':False,'all_moves_verified':False}


CHARACTERS=['wolf','diddy','charizard','lucas','sonic','dedede','tails']
DIRECTIONS=['neutral','side','up','down']


def judge_special(code,log,special,frames,evidence=None):
    character,direction,air=special.split(':')
    index=CHARACTERS.index(character)
    move=DIRECTIONS.index(direction)*2+(air=='air')
    evidence=evidence or judge_live(code,log,'akaneia','spawn',frames)
    entered=f'M3D LIVE SPECIAL ENTER kind={33+index} move={move}' in log
    observed=f'M3D LIVE SPECIAL OBSERVED kind={33+index} move={move}' in log
    expected=sorted((s,1 if s<4 else 33+(s-4)%7) for s in range(16))
    complete=(code==0 and f'MELEE_EXIT_AFTER_FRAMES: reached frame {frames}, exiting' in log
              and entered and observed and not evidence['failures'] and not evidence['missing_hooks']
              and evidence['onload_slots']==list(range(4,16)) and evidence['numeric_output_slots']==list(range(4,16))
              and sorted(map(tuple,evidence['observed_identities']))==expected
              and bool(evidence['summaries']) and all(row[1]==16 for row in evidence['summaries']))
    return {'passed':complete,'special_case':special,'special_entered':entered,'special_observed':observed,
            'combat_smoke_pass':False,'all_moves_verified':False,'full_combat_pass':False}


def stage_assets(metadata,world=False):
    files=ROOT/"build/akaneia/disc/files"
    destination=WORK/("akaneia-world-files" if world else "akaneia-native-files")
    destination.mkdir(parents=True,exist_ok=True)
    names={"PlCo.dat"}
    for c in metadata["characters"]:
        names.update([c["file"],c["animation_file"]])
        names.add(c["effect_file"])
        names.update(costume[0] for costume in c["costumes"])
    for name in names:
        target=destination/name
        if not target.exists():os.link(files/name,target)
        if sha(files/name)!=sha(target):raise ValueError("Local asset changed: "+name)
    # The native synth mounts imported SEM/SSM banks through this same root.
    # Include nested audio, not only DAT aliases and the menu stream.
    audio=files/'audio'
    for source in audio.rglob('*'):
        if not source.is_file():continue
        target=destination/source.relative_to(files);target.parent.mkdir(parents=True,exist_ok=True)
        if not target.exists():os.link(source,target)
        if sha(source)!=sha(target):raise ValueError('Local audio asset changed: '+str(source))
    # Results screen: Akaneia's GmRst keeps retail frames and adds its fighters'
    # names/emblem; GmRstM<xx> are the added fighters' results animations.
    for name in ['GmRst.usd']+['GmRstM%s.dat'%c for c in ('Wf','Dd','Lz','Lc','Sn','De','Ts')]+['audio/ff_sonic.hps']:
        target=destination/name;target.parent.mkdir(parents=True,exist_ok=True)
        if not target.exists():os.link(files/name,target)
        if sha(files/name)!=sha(target):raise ValueError("Local asset changed: "+name)
    hud=destination/'M3dHud.dat';source=files/'IfAll.usd'
    if not hud.exists():os.link(source,hud)
    if sha(hud)!=metadata['hud_archive_sha256']:raise ValueError('Akaneia HUD archive changed')
    if world:
        from native_reference import reference_source
        reference,stage_names=reference_source()
        for name in stage_names:
            source=reference/name;target=destination/name
            if not target.exists():os.link(source,target)
            if sha(source)!=sha(target):raise ValueError('Native 3D stage differs from canonical archive: '+name)
            # The USA disc requests .usd for localized stages (e.g. Stadium).
            # Both names must resolve to the authored 3D archive, otherwise the
            # loader silently falls back to the retail 2D stage in the ISO.
            localized=destination/(name[:-4]+'.usd')
            if not localized.exists():os.link(source,localized)
            if sha(source)!=sha(localized):raise ValueError('Localized 3D stage differs from canonical archive: '+name)
    return destination


def run(args):
    build=verify_build()
    metadata=inventory()
    if asset_identity(metadata)!=build.get('akaneia_asset_sources'):
        raise ValueError('Local Akaneia assets differ from the native build; rebuild first')
    world=getattr(args,'world',False)
    files=stage_assets(metadata,world)
    game=bundle()
    binary=sha(game/"melee")
    special=getattr(args,'special',None)
    selected_stage=getattr(args,'stage',32)
    suffix=(('-world-'+getattr(args,'camera','orbit')) if world else '')+('-human-'+getattr(args,'character','fox') if getattr(args,'human',False) else '')+(f"-special-{special.replace(':','-')}" if special else '')
    if selected_stage!=32:suffix+='-stage-'+str(selected_stage)
    case=WORK/"runs"/f"mac-live-{args.roster}-{args.mode}-{args.frames}{suffix}-{binary[:10]}"
    env=dict(os.environ,MELEE_BOOT_SCENE="vs",MELEE_DEBUG_VS_STAGE=str(selected_stage),MELEE3D_NATIVE_LAB="16",
             MELEE3D_NATIVE_ROSTER=args.roster,MELEE_EXIT_AFTER_FRAMES=str(args.frames),MELEE_SEED="1",
             MELEE_BACKEND="metal",MELEE_LOG_FILE=str(case/"game.log"),MELEE_FILES_DIR=str(files),
             MELEE3D_NATIVE_OUTPUT_FIXTURE='1',
             MELEE3D_NATIVE_AKANEIA="1",MELEE3D_AKANEIA_FILES=str(ROOT/"build/akaneia/disc/files"))
    for name in ("MELEE3D_NATIVE_HUMAN","MELEE3D_NATIVE_KIRBY_COPY","MELEE3D_NATIVE_KO_TEST"):
        env.pop(name,None)
    env.pop("MELEE3D_NATIVE_SPAWN_ONLY",None)
    env.pop("MELEE3D_NATIVE_SPECIAL",None)
    env["MELEE3D_NATIVE_INPUTS"]=getattr(args,"inputs","spatial")
    env.pop("MELEE3D_NATIVE_SEQUENCE",None)
    env.pop("MELEE3D_NATIVE_SEQUENCE_PROFILE",None)
    env.pop("MELEE3D_NATIVE_3D",None)
    env.pop("MELEE3D_NATIVE_CHARACTER",None)
    env.pop('MELEE3D_NATIVE_CONTROLS',None)
    if world:
        env['MELEE3D_NATIVE_3D']='1'
        env['MELEE3D_NATIVE_CAMERA']=getattr(args,'camera','orbit')
    if getattr(args,'human',False):
        env['MELEE3D_NATIVE_HUMAN']='1'
        env['MELEE3D_NATIVE_CHARACTER']=getattr(args,'character','fox')
    if special:
        character,direction,air=special.split(':')
        index=CHARACTERS.index(character)
        move=DIRECTIONS.index(direction)*2+(air=='air')
        env['MELEE3D_NATIVE_SPECIAL']=f'{index}:{move}'
    if args.mode=="spawn":env["MELEE3D_NATIVE_SPAWN_ONLY"]="1"
    # The interpreted compatibility lane is not yet a performance pass. Give
    # functional diagnostics a finite, slower budget without certifying 60 Hz.
    code,log,seconds=bounded([str(game/"melee"),"--no-card",str(DISC)],game,env,case,timeout=args.frames/10+40)
    result={"passed":False,"exit_code":code,"seconds":seconds,"frames":args.frames,
            "executable_sha256":binary,
            "original_module_dispatch":True,"roster":args.roster,
            "scope":"Live native added-fighter integration diagnostic; does not certify all moves or 3D",
            "all_moves_verified":False,
            "combined_native_3d_16_ready":False}
    result["build"]=build
    result['native_world_requested']=world
    result['human_character']=getattr(args,'character','fox') if getattr(args,'human',False) else None
    result['camera']=getattr(args,'camera','orbit') if world else None
    result['humans']=int(getattr(args,'human',False))
    result.update(judge_live(code,log,args.roster,args.mode,args.frames,result['humans'],getattr(args,'character','fox')))
    if world:
        result['world_frames']=len(re.findall(r'M3D WORLD FRAME ',log))
        from native_reference import STAGES
        result['selected_stage']=selected_stage
        result['world_stage_sha256']=sha(files/STAGES[selected_stage][1])
        result['world_cpu_slots']=sorted({int(s) for s,n in re.findall(r'M3D WORLD FRAME tick=\d+ slot=(\d+) [^\n]* cpu_frames=(\d+)',log) if int(n)>0})
        expected_cpus=list(range(1 if result['humans'] else 0,16)) if args.mode=='combat' else None
        if expected_cpus is not None:result['passed']=result['passed'] and result['world_cpu_slots']==expected_cpus
        result['passed']=result['passed'] and f"M3D WORLD ENABLED capacity={build['player_capacity']}" in log and result['world_frames']>0
    if special:
        result.update(judge_special(code,log,special,args.frames,result))
    result['article_modules']=[list(map(int,row)) for row in re.findall(r'M3D LIVE ARTICLE MODULE owner=(\d+) article=(\d+)',log)]
    result['items_created']=[int(kind) for kind in re.findall(r'M3D LIVE ITEM CREATE kind=(\d+)',log)]
    result['items_removed']=[int(kind) for kind in re.findall(r'M3D LIVE ITEM REMOVE kind=(\d+)',log)]
    write_json(case/"result.json",result)
    print(json.dumps({k:v for k,v in result.items() if k!='build'},indent=2))
    print(case/"stdout.txt")
    return result["passed"]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--roster",choices=["wolf","akaneia"],default="wolf")
    parser.add_argument("--mode",choices=["spawn","combat"],default="combat")
    parser.add_argument("--frames",type=int,default=900)
    parser.add_argument('--special',help='Isolated move smoke case: sonic:up:air (requires akaneia roster)')
    parser.add_argument('--stage',type=int,choices=[32,3,8,2,28,17,16,10,9],default=32)
    parser.add_argument('--world',action='store_true',help='Native 3D FD source port')
    parser.add_argument('--inputs',choices=['classic','spatial'],default='spatial')
    parser.add_argument('--camera',choices=['combat','orbit','smash'],default='orbit',help='3D camera; D-pad left toggles in game')
    parser.add_argument('--human',action='store_true',help='Human on port one; remaining fighters are CPUs')
    parser.add_argument('--character',choices=['fox']+CHARACTERS,default='fox',help='Human character in the native prototype')
    args=parser.parse_args()
    if args.character!='fox' and not args.human:parser.error('--character requires --human')
    if args.special:
        parts=args.special.split(':')
        if len(parts)!=3 or parts[0] not in ['wolf','diddy','charizard','lucas','sonic','dedede','tails'] or parts[1] not in ['neutral','side','up','down'] or parts[2] not in ['ground','air'] or args.roster!='akaneia':
            parser.error('Special case must be character:neutral|side|up|down:ground|air with --roster akaneia')
    if not (360 if args.special else 900)<=args.frames<=36000:parser.error("Frames must be 360+ for isolated specials, 900+ otherwise")
    lock=WORK/".probe-running"
    with lock.open("x") as owner:owner.write(str(os.getpid()))
    try:
        if not run(args):raise SystemExit(1)
    finally:lock.unlink()


if __name__=="__main__":main()
