"""Standalone Windows installer. The installed entry point opens the game."""
import ctypes,json,os,subprocess,sys,time,uuid
from pathlib import Path
from player_paths import user_directory
from player_launcher import load_settings,save_settings


def classify(path):
    path=Path(path)
    if path.suffix.lower() in ('.zip','.7z'):return 'sunshine'
    with path.open('rb') as stream:header=stream.read(6)
    if header==b'GALE01':return 'melee'
    if header==b'GMSE01':return 'sunshine'
    raise ValueError('Choose a Melee USA or Sunshine USA game image.')


def windows_drop(root,receive):
    """Explorer file drops using Windows' native HDROP, no extra GUI runtime."""
    from ctypes import wintypes
    root.update_idletasks();user=ctypes.windll.user32;shell=ctypes.windll.shell32
    user.GetAncestor.argtypes=[wintypes.HWND,wintypes.UINT];user.GetAncestor.restype=wintypes.HWND
    window=user.GetAncestor(root.winfo_id(),2)
    proto=ctypes.WINFUNCTYPE(ctypes.c_ssize_t,wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM)
    setter=user.SetWindowLongPtrW;setter.argtypes=[wintypes.HWND,ctypes.c_int,ctypes.c_void_p];setter.restype=ctypes.c_void_p
    user.CallWindowProcW.argtypes=[ctypes.c_void_p,wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM];user.CallWindowProcW.restype=ctypes.c_ssize_t
    shell.DragAcceptFiles.argtypes=[wintypes.HWND,wintypes.BOOL]
    shell.DragQueryFileW.argtypes=[wintypes.HANDLE,wintypes.UINT,wintypes.LPWSTR,wintypes.UINT]
    shell.DragFinish.argtypes=[wintypes.HANDLE]
    previous=None
    def callback(hwnd,message,wparam,lparam):
        if message==0x233:
            try:
                paths=[]
                for index in range(shell.DragQueryFileW(wparam,0xffffffff,None,0)):
                    buffer=ctypes.create_unicode_buffer(shell.DragQueryFileW(wparam,index,None,0)+1)
                    shell.DragQueryFileW(wparam,index,buffer,len(buffer));paths.append(buffer.value)
                root.after(0,lambda:receive(paths))
            finally:shell.DragFinish(wparam)
            return 0
        return user.CallWindowProcW(previous,hwnd,message,wparam,lparam)
    handler=proto(callback);previous=setter(window,-4,ctypes.cast(handler,ctypes.c_void_p))
    if not previous:raise OSError('Could not enable Explorer file dropping')
    shell.DragAcceptFiles(window,True)
    # Keep the callback alive as long as the native window exists.
    root._drop_handler=(handler,previous,window)


class Setup:
    def __init__(self,root,home):
        import tkinter as tk
        from tkinter import ttk,filedialog,messagebox
        self.root=root;self.home=home;self.ttk=ttk;self.dialog=filedialog;self.alert=messagebox
        self.process=None;self.job=None;self.log_offset=0;self.app=None
        root.title('Install Smash Royale');root.geometry('570x440');root.resizable(False,False)
        style=ttk.Style()
        if 'vista' in style.theme_names():style.theme_use('vista')
        area=ttk.Frame(root,padding=24);area.pack(fill='both',expand=True)
        ttk.Label(area,text='Create your game app',font=('Segoe UI',19,'bold')).pack(anchor='w')
        ttk.Label(area,text='Drop your two game images below. They stay on your computer.').pack(anchor='w',pady=(6,18))
        self.paths={}
        for key,label in (('melee','Melee · USA 1.02'),('sunshine','Sunshine · USA revision 0')):
            box=ttk.LabelFrame(area,text=label,padding=12);box.pack(fill='x',pady=(0,12))
            var=tk.StringVar(value='Drop game image here');self.paths[key]=var
            ttk.Label(box,textvariable=var,width=46).pack(side='left')
            ttk.Button(box,text='Choose…',command=lambda k=key:self.choose(k)).pack(side='right')
        self.message=tk.StringVar(value='Akaneia downloads automatically. Requires 6 GB free.')
        ttk.Label(area,textvariable=self.message,wraplength=510).pack(anchor='w',pady=8)
        self.progress=ttk.Progressbar(area,maximum=100);self.progress.pack(fill='x',pady=8)
        buttons=ttk.Frame(area);buttons.pack(fill='x',pady=(10,0))
        self.action=ttk.Button(buttons,text='Create game app',command=self.start);self.action.pack(side='right')
        self.cancel=ttk.Button(buttons,text='Close',command=self.close);self.cancel.pack(side='left')
        settings=load_settings(home/'launcher.json');self.existing=Path(settings.get('installation') or home/'game-data')
        self.reuse=(self.existing/'player-install.json').is_file()
        if self.reuse:self.action.configure(text='Install update')
        root.protocol('WM_DELETE_WINDOW',self.close)
        if sys.platform=='win32':windows_drop(root,self.drop)

    def choose(self,key):
        if self.process:return
        path=self.dialog.askopenfilename(parent=self.root,title='Choose '+key.title(),filetypes=[('Game images','*.iso *.gcm *.zip *.7z'),('All files','*')])
        if path:self.paths[key].set(path);self.reuse=False;self.action.configure(text='Create game app')

    def drop(self,paths):
        if self.process:return
        try:
            for value in paths:self.paths[classify(value)].set(value)
            self.reuse=False;self.action.configure(text='Create game app')
        except (OSError,ValueError) as error:self.message.set(str(error))

    def start(self):
        if self.app:os.startfile(self.app/'Smash Royale.exe');self.root.destroy();return
        if self.process:return
        values={k:v.get() for k,v in self.paths.items()}
        if not self.reuse and not all(Path(v).is_file() for v in values.values()):self.message.set('Drop or choose both game images.');return
        self.home.mkdir(parents=True,exist_ok=True);logs=self.home/'logs';logs.mkdir(exist_ok=True)
        base=logs/('setup-'+uuid.uuid4().hex[:10]);target=self.home.parent/'Programs/Smash Royale'
        self.job=dict(task='install-game',home=str(self.home),installation=str(self.existing),reuse=self.reuse,
                      template_app=str(Path(sys.executable).parent),target_app=str(target),
                      log=str(base.with_suffix('.log')),result=str(base.with_suffix('.result.json')),**values)
        jobfile=base.with_suffix('.job.json');save_settings(jobfile,self.job)
        self.process=subprocess.Popen([sys.executable,'--worker',str(jobfile)],creationflags=subprocess.CREATE_NO_WINDOW)
        self.action.state(['disabled']);self.cancel.configure(text='Cancel');self.message.set('Preparing your game…');self.root.after(100,self.poll)

    def poll(self):
        path=Path(self.job['log'])
        if path.exists():
            with path.open(errors='replace') as stream:
                stream.seek(self.log_offset);lines=stream.readlines();self.log_offset=stream.tell()
            for line in lines:
                if line.startswith('MEMELEES_PROGRESS '):
                    row=json.loads(line.split(' ',1)[1]);self.message.set(row['message']);self.progress['value']=row['value']
        if self.process.poll() is None:self.root.after(150,self.poll);return
        result=load_settings(Path(self.job['result']));self.process=None;self.action.state(['!disabled']);self.cancel.configure(text='Close')
        if result.get('ok'):
            self.app=Path(result['app']);self.action.configure(text='Play');self.message.set('Installed. Open Smash Royale from your desktop or Start menu.')
        else:self.message.set(result.get('error','Installation stopped. Try again.'))

    def close(self):
        if self.process:
            subprocess.run(['taskkill','/PID',str(self.process.pid),'/T','/F'],capture_output=True)
            from player_install import cleanup_cancelled_import
            cleanup_cancelled_import(self.home/'installations/new',self.process.pid)
        self.root.destroy()


def main(home=None,smoke=None):
    import tkinter as tk
    root=tk.Tk();Setup(root,home or user_directory())
    if smoke:
        def finish():
            save_settings(smoke,dict(ok=True,screen='standalone-setup',native_file_drop=hasattr(root,'_drop_handler')));root.destroy()
        root.after(1500,finish)
    root.mainloop();return 0
