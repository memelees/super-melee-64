#!/usr/bin/env python3
"""Play using an imported installation; game material stays in the user cache."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time
import shutil
import sys
import secrets

from native_compatibility import ROOT
from native_lineup import BY_NAME, lineup
from player_install import DEFAULT, ready_install as verify_install
from player_paths import game_command
from player_session import session_lock


def binary_path(override=None):
    path=override or ROOT/('bin/melee.exe' if sys.platform=='win32' else 'bin/melee')
    if not path.is_file():
        if override:raise ValueError('Native executable was not found')
        from native_mac import verify_build, SOURCE
        verify_build();path=SOURCE/'build/macos-proof/melee'
    return path.resolve()


def environment(installation,metadata,profile,fighters=32,character='sonic',mode='survival',items='medium',seed=1,cpu_only=False,seconds=300,name='',rules=None):
    from player_lobby import player_name
    from player_stage import visual_bank
    name=player_name(name)
    from player_rules import MODES, environment as rule_environment
    if mode=='battle-royale':mode='survival'  # Keep recordings and room invitations compatible.
    if mode not in MODES:raise ValueError('Unknown game mode')
    if type(seconds) is not int or not 0<=seconds<=5940:raise ValueError('Round duration must be 0–5940 seconds (0 = unlimited)')
    profile.mkdir(parents=True,exist_ok=True)
    (profile/'cache').mkdir(exist_ok=True)
    music=profile/'music';music.mkdir(exist_ok=True)
    if metadata['music'] and not (music/'delfino_plaza.wav').exists():
        shutil.copy2(installation/'sunshine/delfino_plaza.wav',music/'delfino_plaza.wav')
    env={k:v for k,v in os.environ.items() if not k.startswith(('MELEE_','MELEE3D_'))}
    env.update(MELEE_BOOT_SCENE='vs',MELEE_DEBUG_VS_STAGE='32',MELEE3D_NATIVE_LAB=str(fighters),
               MELEE3D_NATIVE_ROSTER='akaneia',MELEE3D_NATIVE_CHARACTER=character,MELEE_SEED=str(seed),
               MELEE3D_NATIVE_LINEUP=','.join(str(r[1]) for r in lineup(fighters,character,seed,0 if cpu_only else 1)),
               MELEE3D_NATIVE_3D='1',MELEE3D_NATIVE_CAMERA='combat',MELEE3D_NATIVE_CAMERA_TURN='snap',
               MELEE3D_NATIVE_INPUTS='spatial',MELEE3D_NATIVE_AKANEIA='1',
               MELEE3D_NATIVE_DELFINO=str(visual_bank(installation,metadata)),
               MELEE3D_AKANEIA_FILES=str(installation/'akaneia/files'),MELEE_FILES_DIR=str(installation/'akaneia/files'),
               MELEE_LOG_FILE=str(profile/'game.log'),MELEE_CACHE_DIR=str(profile/'cache'),
               MELEE_WINDOW_TITLE='Smash Royale — '+{'hill':'Plaza Party','survival':'Battle Royale','coin':'Coin Battle','battle':'Free Battle','time':'Time','stock':'Stock','bonus':'Bonus'}[mode],MELEE_FPS='1',MELEE3D_NATIVE_PARTY=mode,
               MELEE3D_NATIVE_ITEMS=items,MELEE3D_NATIVE_ROUND_SECONDS=str(seconds),MELEE3D_NATIVE_RESULTS='on',MELEE3D_NATIVE_ASSIST='startup',
               MELEE3D_NATIVE_PROJECTILES='distance',MELEE3D_NATIVE_DI='fixed',MELEE3D_NATIVE_ZONE='adaptive',
               MELEE3D_NATIVE_HILL_RULE='brawl',MELEE3D_NATIVE_RESPAWN='action' if mode=='hill' else 'spread',
               MELEE3D_NATIVE_SURGE='on' if mode=='hill' else 'off')
    env.update(rule_environment(rules))
    if not cpu_only:env.update(MELEE3D_NATIVE_HUMAN='1',MELEE3D_NATIVE_PLAYER_NAMES=name or 'P1')
    if sys.platform=='darwin':env['MELEE_BACKEND']='metal'
    from player_goop import configure
    configure(installation,env)
    # Optional verified city banks share the native character/stage menu.
    # Keep these overlays private and mount them without replacing the import.
    from player_onett import configure as configure_onett
    configure_onett(installation,metadata,profile,env)
    from player_castle import configure as configure_castle
    configure_castle(installation,metadata,profile,env)
    from player_sunshine import configure as configure_sunshine
    configure_sunshine(installation,metadata,profile,env)
    return env


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--installation',type=Path,default=DEFAULT)
    p.add_argument('--binary',type=Path);p.add_argument('--profile',type=Path)
    p.add_argument('--character',choices=tuple(BY_NAME),default='sonic')
    p.add_argument('--fighters',type=int,choices=(2,16,24,32),default=32)
    p.add_argument('--mode',choices=('battle-royale','battle','hill','survival','coin','time','stock','bonus'),default='battle-royale')
    p.add_argument('--items',choices=('off','verylow','low','medium','high','veryhigh'),default='medium')
    p.add_argument('--seconds',type=int,default=300,help='Round seconds; 0 disables the time limit')
    p.add_argument('--stocks',type=int,default=3);p.add_argument('--stock-minutes',type=int,default=0)
    p.add_argument('--cpu-level',type=int,default=9)
    p.add_argument('--gravity',type=int,default=100,help='Gravity percent (25–150)')
    p.add_argument('--move-speed',type=int,default=100,help='Movement speed percent (50–200)')
    p.add_argument('--game-speed',type=int,default=100,help='Whole-game speed percent (50–150)')
    p.add_argument('--name',default='',help='Short overhead name (humans only, up to 16 characters)')
    p.add_argument('--quickstart',action='store_true',help='Skip the native opening and selection screens')
    p.add_argument('--frames',type=int,default=0);p.add_argument('--seed',type=int,default=None,help='Repeatable match seed; otherwise chooses a fresh seed');p.add_argument('--cpu-only',action='store_true')
    a=p.parse_args()
    if a.mode=='battle-royale':a.mode='survival'
    if not a.quickstart and not a.cpu_only and not a.frames and a.fighters!=32:
        p.error('The game menus support 32-fighter matches; use --quickstart for diagnostics')
    installation=a.installation.expanduser().resolve();metadata=verify_install(installation)
    binary=binary_path(a.binary);profile=(a.profile or installation.parent/'profiles/offline').expanduser().resolve()
    env=environment(installation,metadata,profile,a.fighters,a.character,a.mode,a.items,a.seed if a.seed is not None else secrets.randbits(32),a.cpu_only,a.seconds,name=a.name,rules=dict(stocks=a.stocks,stock_minutes=a.stock_minutes,cpu_level=a.cpu_level,gravity=a.gravity,move_speed=a.move_speed,game_speed=a.game_speed))
    if a.frames:
        if not 120<=a.frames<=216000:p.error('Diagnostic frame limit must be 120–216000')
        env['MELEE_EXIT_AFTER_FRAMES']=str(a.frames)
    with session_lock(profile):
        if not a.cpu_only and not a.frames:
            from player_graphics import prepare_graphics
            last_report=[-10]
            def progress(value,message):
                if value>=last_report[0]+10 or value==70:
                    print(f'{message} ({value:.0f}%)',flush=True);last_report[0]=value
            prepare_graphics(binary,env,profile,progress)
        if not a.quickstart and not a.cpu_only and not a.frames:
            from player_stage_preview import preview,native_menu_assets
            native_menu_assets(installation,metadata)
            request=profile/'menu-request.txt';request.unlink(missing_ok=True)
            env['MELEE3D_NATIVE_MENU_REQUEST']=str(request)
            env.update(MELEE_WINDOW_TITLE='Smash Royale',MELEE3D_NATIVE_MENUS='1',MELEE_BOOT_SCENE='title',MELEE_NO_ATTRACT='1',MELEE3D_NATIVE_MENU_SETTINGS=str(profile/'native-menu.state'),MELEE3D_NATIVE_STAGE_PREVIEW=str(preview(installation.parent/'ui-cache')))
        with (profile/'stdout.txt').open('w') as log:
            recording=None
            if not a.frames:
                from player_theater import begin_recording
                recording=begin_recording(env,binary,dict(fighters=a.fighters,character=a.character,mode=a.mode,items=a.items,seed=int(env['MELEE_SEED']),seconds=a.seconds,name=a.name,cpu_only=a.cpu_only,rules=dict(stocks=a.stocks,stock_minutes=a.stock_minutes,cpu_level=a.cpu_level,gravity=a.gravity,move_speed=a.move_speed,game_speed=a.game_speed),menus=bool(env.get('MELEE3D_NATIVE_MENUS'))))
            result=subprocess.run(game_command(binary,metadata['melee_path']),cwd=profile,env=env,stdout=log,stderr=subprocess.STDOUT,
                                  timeout=a.frames/15+120 if a.frames else None)
        if recording:
            from player_theater import finish_recording
            finish_recording(recording,(profile/'stdout.txt').read_text(errors='replace'))
    print('Game log:',profile/'stdout.txt')
    if not result.returncode and env.get('MELEE3D_NATIVE_MENU_REQUEST'):
        from player_menu import read_request
        request=read_request(Path(env['MELEE3D_NATIVE_MENU_REQUEST']))
        if request and request['action']!='quit':
            from player_launcher import continue_desktop
            continue_desktop(installation,request,a.character)
    raise SystemExit(result.returncode)


if __name__=='__main__':main()
