#!/usr/bin/env python3
"""Private static port experiments for Bianco, Ricco and Gelato.

This deliberately does not register maps with the launcher. It writes original
donor pixels and derived banks only to an external user cache. Frozen dynamic
props are an inspection aid, not evidence of gameplay-complete ports.
"""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
from player_paths import payload,source_file
import re
import shutil
import struct
import time

from sunshine_scene import Reader, bounds, collision, flatten, identity, matrix, scene, static_model, strings, transform
from sunshine_compile import MATERIAL_STATE, PASS_THROUGH, WATER, cross, ledges, material_chunks, materials, prop_model_candidates, unique_collision

DEFAULT = Path.home() / 'Library/Application Support/Memelees/map-survey/bianco-ricco-gelato'
TYPES = {0:'sink',1:'fire',2:'slip',3:'glass_wall',4:'electric',5:'lethal',6:'safe',7:'unknown7',8:'unknown8',10:'unknown10'}
PROPS = {'MapStaticObj','MapObjBase','MapObjGeneral','Palm','BananaTree','MapObjTreeScale',
         'BigWindmill','MiniWindmill','WindmillRoof','BiaBell','BiaWatermill',
         'BiaWatermillVertical','BiaTurnBridge','RiccoLog','Manhole','Container',
         'Crane','CraneCargo','RiccoSwitch','WoodBox','SandCastle','SandEgg',
         'LeanMirror','MammaYacht','SwingBoard','SandBombBase'}

# MapObjInit.cpp::TMapObjBase::initUnique, ACTOR_TYPE_* cases that explicitly
# call getBiancoMatTable(). Match the authored actor/model pair, not every prop
# with a placeholder-looking name. MapObjManager loads this table only stage2.
BIANCO_SHARED = {
    ('MapObjBase','bigwindmillblock'), ('BigWindmill','bigwindmill'),
    ('BiaWatermill','biawatermill01'), ('BiaTurnBridge','biaturnbridge'),
    ('BiaBell','biabell'), ('BiaWatermill','biawatermill00'),
    ('BiaWatermillVertical','biawatermillvertical'),
    ('MapObjGeneral','lampbianco'), ('MapObjBase','biadoor'),
    ('MiniWindmill','miniwindmilll'),
}
ARROW_SHARED = {('MapObjBase',name) for name in ('arrowboardlr','arrowboardup','arrowboarddown')}
SAND_SHARED = {('SandBombBase',name) for name in ('sandbombbase00','sandbombbasemushroom',
    'sandbombbasepyramid','sandbombbaseshit','sandbombbasestar','sandbombbaseturtle',
    'sandbombbasefoot','sandbombbasehand','sandbombbasestairs')}
SAND_SHARED.add(('SandLeafBase','sandleafbase00'))
MIRROR_SHARED = {('LeanMirror',name) for name in ('mirrors','mirrorm','mirrorl')}


def bounded_texture_table(data,names,width,height):
    """Validate the donor's texture-only BMT, including its known count quirk.

    US rev0 bianco.bmt declares two chunks but has one bounded TEX1 ending at
    EOF. This exception is local to this exact table contract; the general J3D
    reader remains strict. No malformed/trailing chunk bytes are tolerated.
    """
    if len(data)<40 or data[:8]!=b'J3D2bmt3' or struct.unpack_from('>I',data,8)[0]!=len(data):
        raise ValueError('Invalid Bianco shared BMT header')
    if struct.unpack_from('>I',data,12)[0] not in (1,2):
        raise ValueError('Unexpected Bianco shared BMT chunk count')
    tag,size=struct.unpack_from('>4sI',data,32)
    if tag!=b'TEX1' or size<32 or 32+size!=len(data):
        raise ValueError('Bianco shared BMT must contain exactly one complete TEX1')
    tex=data[32:];r=Reader(tex);base=r.u32(12)
    if r.u16(8)!=len(names) or base<32 or base+32*len(names)>len(tex) or strings(tex,r.u32(16))!=names:
        raise ValueError('Unexpected shared texture table')
    for i in range(len(names)):
        o=base+i*32;fmt,alpha,w,h,ws,wt=r.get('2B2H2B',o);offset=r.u32(o+28)
        if (fmt,w,h)!=(14,width,height) or ws>2 or wt>2 or offset<32 or o+offset+((w+7)//8)*((h+7)//8)*32>len(tex):
            raise ValueError('Invalid shared texture extent')
    return tex


def bianco_texture_table(data):
    return bounded_texture_table(data,['J_bianco_obj']*2,256,256)


def survey_material_chunks(directory,path,base,klass=None,actor_model=None):
    cs,companion=material_chunks(path,base)
    binding=(klass,(actor_model or '').lower())
    if re.fullmatch(r'bianco[0-7]',directory.name) and binding in BIANCO_SHARED:
        shared=directory/'mapobj/bianco.bmt'
        tex=bianco_texture_table(shared.read_bytes())
        # The shared file has TEX1 only: retain this mesh's original MAT3.
        cs=dict(cs,TEX1=tex);companion=shared
        materials(cs)  # Validate original MAT3 references against replacement.
    elif binding in ARROW_SHARED:
        # All three donor ArrowBoard records use ACTOR_TYPE_ARROW_BOARD_LR.
        # Its initUnique() applies ArrowBoard.bmt, which has MAT3 and TEX1.
        shared=directory/'mapobj/arrowboard.bmt'
        if shared.is_file():
            cs,companion=material_chunks(path,base,override=shared)
            bound=materials(cs)
            if len(bound)!=1 or bound[0]['texture']['name']!='K_yajirushiBoard' or (bound[0]['texture']['format'],bound[0]['texture']['width'],bound[0]['texture']['height'])!=(14,64,32):
                raise ValueError('Unexpected original ArrowBoard table')
    elif re.fullmatch(r'mamma[0-7]',directory.name) and binding in SAND_SHARED|MIRROR_SHARED:
        # Source-listed ACTOR_TYPE_SAND_BOMB_BASE00/FOOT, SAND_LEAF_BASE00,
        # and MIRROR_L cases. These shared tables, like Bianco's, are TEX1 only.
        mirror=binding in MIRROR_SHARED;shared=directory/'mapobj'/('mirror.bmt' if mirror else 'sandbombbase.bmt')
        names,width,height=(['J_MirrorSide'],64,128) if mirror else (['suna'],256,256)
        cs=dict(cs,TEX1=bounded_texture_table(shared.read_bytes(),names,width,height));companion=shared
        materials(cs)
    return cs,companion


def source_shadow_policy(cs,mats):
    """Adapt an exact donor alpha-mask shadow pass to the flat DLV renderer.

    Sunshine's opaque/XLU buffers separate this pass from its receiver. The
    survey bank is one draw list: mark the known single-stage constant-colour,
    I4-alpha shadow profile for late drawing without depth writes. Preserve
    original pixels/UVs/geometry/colour; never infer shadows from palm names.
    """
    m=Reader(cs['MAT3']);base=m.u32(12);remap=m.u32(16);matched=[]
    for i,mat in enumerate(mats):
        if mat['texture']['format']!=0 or mat['state']['blend_mode']!=1 or (mat['state']['blend_src'],mat['state']['blend_dst'])!=(4,5):continue
        o=base+m.u16(remap+i*2)*0x14c
        if m.data[m.u32(0x58)+m.data[o+4]]!=1:continue
        index=m.u16(o+0xe4)
        if index==65535:continue
        stage=m.data[m.u32(0x5c)+index*20:m.u32(0x5c)+index*20+20]
        if len(stage)!=20:raise ValueError('Truncated donor shadow TEV stage')
        # Colour = C0, alpha = A0 * TEXA; ADD/zero bias/unit scale/clamp/prev.
        if stage[1:19]!=bytes((15,15,15,2,0,0,0,1,0,7,1,4,7,0,0,0,1,0)):continue
        reg=m.u16(o+0xdc)
        if reg==65535:raise ValueError('Missing donor shadow C0/A0 register')
        colour=m.get('4h',m.u32(0x50)+reg*8)
        # TEV A/B/C inputs overflow to unsigned eight bits before arithmetic;
        # the donor's S10 A0=428 therefore means172, not opaque255.
        mat['shadow_rgba']=tuple(max(0,min(255,v)) for v in colour[:3])+(colour[3]&255,)
        original=mat['texture'];w,h=original['width'],original['height'];source=original['data']
        if w%8 or h%8 or len(source)!=w*h//2:raise ValueError('Unexpected donor shadow I4 extent')
        mask=[0]*(w*h);cursor=0
        for by in range(0,h,8):
            for bx in range(0,w,8):
                for y in range(8):
                    for x in range(0,8,2):
                        v=source[cursor];cursor+=1
                        mask[(by+y)*w+bx+x]=(v>>4)*17;mask[(by+y)*w+bx+x+1]=(v&15)*17
        # IA8 has constant white intensity and the ORIGINAL I4 mask in alpha.
        # Native MODULATE then evaluates C0 and A0*TEXA exactly for this profile.
        tiled=bytearray()
        for by in range(0,h,4):
            for bx in range(0,w,4):
                for y in range(4):
                    for x in range(4):tiled+=bytes((mask[(by+y)*w+bx+x],255))
        mat['texture']=dict(original,name=original['name']+':donor-alpha',format=3,data=bytes(tiled))
        mat['source_mask_sha256']=hashlib.sha256(source).hexdigest()
        mat['state']=dict(mat['state'],depth_write=0)
        mat['shadow_alpha_mask']=True;matched.append(mat['name'])
    return matched


def timber_column_triangle(material,triangle):
    return material==1 and all(abs(v[0][0])<=80 and abs(v[0][2])<=80 for v in triangle) and min(v[0][1]for v in triangle)<5401 and max(v[0][1]for v in triangle)<=6455 and max(v[0][1]for v in triangle)-min(v[0][1]for v in triangle)>100


def source_column_detail(path,parsed,mats,klass,actor_model):
    """Deliberate density repair for MiniWindmillL's timber column only.

    Donor source has identity texmatrix and repeats 16x96px wood every900 units,
    stretching longitudinal texels1.5x. Reuse that exact crop every600 units to
    match its16px/100unit circumferential density. No other UVs are altered.
    """
    if (klass,(actor_model or '').lower(),path.stem.lower())!=('MiniWindmill','miniwindmilll','miniwindmilll'):return None
    chosen=[tri for mi,tri in parsed['triangles']if timber_column_triangle(mi,tri)]
    if len(chosen)!=56:raise ValueError('Unexpected original MiniWindmillL column topology')
    original=mats[1]['texture']
    if (original['name'],original['width'],original['height'],original['format'])!=('J_bianco_obj',256,256,14):raise ValueError('Missing original Bianco timber atlas')
    from sa2_textures import decode_pixels
    pixels=decode_pixels(original);w,h=16,96;tiled=bytearray(w*h*4)
    for y in range(h):
        for x in range(w):
            r,g,b,a=pixels[(y+1)*256+x+210];tile=((y//4)*(w//4)+x//4)*64;pixel=((y%4)*4+x%4)*2
            tiled[tile+pixel:tile+pixel+2]=bytes((a,r));tiled[tile+32+pixel:tile+34+pixel]=bytes((g,b))
    detail=dict(mats[1],texture=dict(original,name='J_bianco_obj:column-grain',width=w,height=h,format=6,wrap_s=0,wrap_t=1,data=bytes(tiled)))
    mats.append(detail)
    old=[v[2]for tri in chosen for v in tri]
    new=[((v[2][0]*256-210)/16,v[0][1]/600)for tri in chosen for v in tri]
    return dict(material=len(mats)-1,triangles=len(chosen),source_crop=[210,1,16,96],source_repeat_height=900,repeat_height=600,
        before_uv_bounds=[[min(v[k]for v in old)for k in range(2)],[max(v[k]for v in old)for k in range(2)]],
        after_uv_bounds=[[min(v[k]for v in new)for k in range(2)],[max(v[k]for v in new)for k in range(2)]],
        policy='Deliberate source-art density adaptation; original texmatrix is identity',source_texture_sha256=hashlib.sha256(original['data']).hexdigest())


def pollution(directory):
    p=directory/'map/ymap.ymp'
    if not p.exists():return []
    data=p.read_bytes();count,offset=struct.unpack_from('>H2xI',data)
    if count>256 or offset+count*44>len(data):raise ValueError('Invalid YMP layers')
    result=[]
    for i in range(count):
        o=offset+i*44;typ,flags,plane=struct.unpack_from('>3H',data,o)
        v,texel,left,top,right,bottom=struct.unpack_from('>6f',data,o+8)
        result.append(dict(type=typ,name=TYPES.get(typ,'unknown'),plane=plane,vertical_offset=v,
                           texel=texel,bounds=[left,top,right,bottom]))
    return result


def collect(directory,scale):
    files={p.relative_to(directory).as_posix().lower():p for p in directory.rglob('*') if p.is_file()}
    objects=list(flatten(scene((directory/'map/scene.bin').read_bytes())))
    geometry=[];colliders=[];textures=[];draws=[];keys={};included=[];failed=[];missing=[];cache={};bindings={};shadows={};columns={}
    def add_col(path,mt):
        vertices,faces=collision(path.read_bytes());vertices=[tuple(v*scale for v in transform(mt,p)) for p in vertices]
        for f in faces:
            s=f['surface'];base=s&0x3fff
            if base in PASS_THROUGH:continue
            ps=[vertices[i] for i in f['indices']];n=cross(*ps);length=math.sqrt(sum(v*v for v in n))
            if length<1e-8:continue
            flags=(1 if s in WATER or base in WATER else 0)|(2 if base in (0x600,0x800) else 0)|(4 if base==6 else 0)
            colliders.append((ps,tuple(v/length for v in n),s,flags))
    def add_model(path,mt,*,water=False,sky=False,klass=None,actor_model=None):
        try:
            key=(path,klass,actor_model)
            if key not in cache:
                parsed=static_model(path.read_bytes())
                if parsed['unsupported']:raise ValueError(str(parsed['unsupported']))
                cs,companion=survey_material_chunks(directory,path,parsed['chunks'],klass,actor_model)
                mats=materials(cs);adapted=source_shadow_policy(cs,mats)
                if adapted:shadows[path.relative_to(directory).as_posix()]=adapted
                detail=source_column_detail(path,parsed,mats,klass,actor_model)
                if detail:columns[path.relative_to(directory).as_posix()]=detail
                cache[key]=(parsed,mats,detail)
                if companion:bindings[path.relative_to(directory).as_posix()]=companion.relative_to(directory).as_posix()
            parsed,mats,detail=cache[key];lookup=[]
            for m in mats:
                t=m['texture'];state=dict(m['state']);flags=m['flags']|(2 if sky else 0)
                if water:flags|=5;state.update(cull=0,depth_write=0,blend_mode=1,blend_src=4,blend_dst=5)
                shadow=m.get('shadow_alpha_mask',False)
                key=(t['width'],t['height'],t['format'],t['wrap_s'],t['wrap_t'],hashlib.sha256(t['data']).hexdigest(),flags,tuple(state[k] for k in MATERIAL_STATE),shadow)
                if key not in keys:keys[key]=len(textures);textures.append(dict(t,flags=flags,state=state,shadow_alpha_mask=shadow))
                lookup.append(keys[key])
            grouped={}
            for mat,tri in parsed['triangles']:
                column=detail and timber_column_triangle(mat,tri)
                effective=detail['material'] if column else mat
                m=mats[effective];converted=[]
                for p,c,uv in tri:
                    point=tuple(v*scale for v in transform(mt,p))
                    rgba=m.get('shadow_rgba',tuple(round(c[i]*m['rgba'][i]/255) for i in range(4)))
                    if column:uv=((uv[0]*256-210)/16,p[1]/600)
                    if water:rgba=(70,170,215,195)
                    converted.append((point,rgba,uv))
                grouped.setdefault(lookup[mat],[]).append((lookup[effective],converted))
            # Keep every original face in its original position/group order.
            # The column crop only splits draw runs, never rearranges faces.
            for runs in grouped.values():
                previous=None
                for material,tri in runs:
                    if material!=previous:draws.append((material,len(geometry),0));previous=material
                    old=draws[-1];draws[-1]=(old[0],old[1],old[2]+1);geometry.append(tri)
            included.append(dict(path=path.relative_to(directory).as_posix(),triangles=len(parsed['triangles']),water=water))
            return True
        except (ValueError,KeyError,IndexError) as error:
            failed.append(dict(path=path.relative_to(directory).as_posix(),error=str(error)));return False
    add_col(directory/'map/map.col',identity())
    for p in sorted((directory/'map/map').glob('building*.col')):add_col(p,identity())
    # Keep stable face ordering for existing DLG/route provenance. write_banks
    # puts sky draw records first, since the native sky disables depth testing.
    for name in ('map','sky','sea','seaindirect','biancoriver'):
        p=directory/f'map/map/{name}.bmd'
        if p.exists():add_model(p,identity(),water=name in ('sea','seaindirect','biancoriver'),sky=name=='sky')
    for obj in objects:
        if obj['klass'] not in PROPS or 'model' not in obj:continue
        name=obj['model'].lower()
        if name in ('reflectsky','reflectparts','seaindirect','biancoriver'):continue
        candidates=prop_model_candidates(obj)
        p=next((files[n.lower()] for n in candidates if n.lower() in files),None)
        if p is None:
            missing.append(dict(klass=obj['klass'],model=obj['model']));continue
        # Sound-only / reflection objects are excluded. Dynamic platforms are
        # inspected at the authored initial transform and reported as frozen.
        mt=matrix(obj['position'],[v*math.pi/180 for v in obj['rotation']],obj['scale'])
        rendered=add_model(p,mt,water='pollution' in name,klass=obj['klass'],actor_model=obj['model'])
        if rendered and p.with_suffix('.col').exists():add_col(p.with_suffix('.col'),mt)
    colliders=unique_collision(colliders)
    return geometry,colliders,textures,draws,dict(included_models=included,failed_models=failed,
        missing_props=list({(v['klass'],v['model']):v for v in missing}.values()),
        object_classes=dict(Counter(o['klass'] for o in objects)),pollution=pollution(directory),material_bindings=bindings,shadow_passes=shadows,column_details=columns,
        omitted_physical_actors=dict(Counter(o['klass'] for o in objects if 'model' in o
            and o['klass'] not in PROPS and (directory/'mapobj'/f"{o['model'].lower()}.col").exists())))


def write_banks(target,geometry,colliders,textures,draws,scale,navigation_step):
    target.mkdir(parents=True,exist_ok=True)
    draws=sorted(draws,key=lambda d:0 if textures[d[0]]['flags']&2 else 2 if textures[d[0]].get('shadow_alpha_mask') else 1)
    raw=bytearray(struct.pack('<4s4I',b'DLV1',2,len(textures),len(draws),len(geometry)))
    for t in textures:raw+=struct.pack('<7I',t['width'],t['height'],t['format'],t['wrap_s'],t['wrap_t'],t['flags'],len(t['data']))+struct.pack('<14I',*(t['state'][k] for k in MATERIAL_STATE))+t['data']
    raw+=b''.join(struct.pack('<3I',*d) for d in draws)
    for tri in geometry:
        for p,c,uv in tri:raw+=struct.pack('<3f4B2f',*p,*c,*uv)
    (target/'delfino.dlv').write_bytes(raw)
    (target/'delfino.dlc').write_bytes(struct.pack('<4s2I',b'DLC1',1,len(colliders))+b''.join(struct.pack('<12f2I',*(v for p in ps for v in p),*n,s,f) for ps,n,s,f in colliders))
    from sunshine_occlusion import groups
    gr=groups(geometry,whole=False);count=max(gr,default=-1)+1
    (target/'delfino.dlg').write_bytes(struct.pack('<4s3I',b'DLG1',1,len(geometry),count)+struct.pack('<'+str(len(gr))+'I',*gr))
    boundary=ledges(colliders)
    (target/'delfino.dls').write_bytes(struct.pack('<4sIf3fI',b'DLS1',2,scale,0,0,3250*scale,len(boundary))+b''.join(struct.pack('<9f',*(v for p in e for v in p)) for e in boundary))
    result=dict(ledges=len(boundary),occlusion_groups=count)
    if navigation_step:
        from sunshine_navigation import build,encode
        nodes,links,gr,nav=build(colliders,step=navigation_step)
        (target/'delfino.dln').write_bytes(encode(nodes,links,gr,nav['step']))
        result['navigation']=nav
    else:
        # A new static conversion must not inherit an old route bank whose
        # nodes may belong to a different geometry/policy revision.
        (target/'delfino.dln').unlink(missing_ok=True)
    return result


def survey(cache,episode,scale,navigation_step=0):
    start=time.monotonic();directory=cache/'archives'/episode
    g,c,t,d,report=collect(directory,scale)
    floor=[ps for ps,n,s,f in c if n[1]>=.65 and not f&3]
    area=sum(math.sqrt(sum(v*v for v in cross(*ps)))/2 for ps in floor)
    heights=sorted(sum(p[1] for p in ps)/3 for ps in floor)
    report.update(episode=episode,scale=scale,scope='Experimental static import; not registered or gameplay accepted',
        render_triangles=len(g),collision_triangles=len(c),textures=len(t),draws=len(d),
        collision_bounds=bounds([p for ps,*_ in c for p in ps]),walkable_surface_area=area,
        walkable_p10_p50_p90_y=[heights[int((len(heights)-1)*q)] for q in (.1,.5,.9)],
        water_triangles=sum(bool(f&1) for *_,f in c),collision_types=dict(Counter(hex(s) for _,_,s,_ in c)))
    target=cache/'ports'/episode
    report.update(write_banks(target,g,c,t,d,scale,navigation_step))
    report['seconds']=round(time.monotonic()-start,2)
    report['bank_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in target.glob('delfino.*')}
    (target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


def shared_material_trial(cache=DEFAULT,episode='bianco0',trial_name='trial-shared-material'):
    """Create a separate trial, preserving the sky-only baseline and physics."""
    cache=Path(cache).expanduser().resolve();repo=payload().resolve()
    if cache==repo or repo in cache.parents:raise ValueError('Private output must stay outside repository')
    if not re.fullmatch(r'bianco[0-7]',episode):raise ValueError('Expected ordinary Bianco episode')
    if not re.fullmatch(r'trial-[a-z-]+',trial_name):raise ValueError('Invalid trial directory name')
    source=cache/'ports'/episode;target=cache/trial_name/episode
    if target.exists():raise ValueError('Shared-material trial destination already exists')
    original=json.loads((source/'report.json').read_text());scale=original['scale']
    before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.glob('delfino.*')}
    geometry,colliders,textures,draws,report=collect(cache/'archives'/episode,scale)
    if report['failed_models']:raise ValueError('Trial contains failed models')
    write_banks(target,geometry,colliders,textures,draws,scale,0)
    unchanged={}
    for name in ('delfino.dlc','delfino.dls','delfino.dlg'):
        if (target/name).read_bytes()!=(source/name).read_bytes():
            raise ValueError('Material-only trial changed '+name)
        unchanged[name]=before[name]
    shutil.copy2(source/'delfino.dln',target/'delfino.dln');unchanged['delfino.dln']=before['delfino.dln']
    if before!={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in source.glob('delfino.*')}:
        raise ValueError('Original trial was changed')
    report.update(episode=episode,scope='Shared texture binding plus sky-first draws only; no gameplay acceptance',
        render_triangles=len(geometry),collision_triangles=len(colliders),textures=len(textures),draws=len(draws),
        baseline_sha256=before,unchanged_banks=unchanged,
        files={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in target.glob('delfino.*')},
        helper_sha256=hashlib.sha256(source_file('sunshine_survey_brg.py').read_bytes()).hexdigest(),
        shared_table_sha256=hashlib.sha256((cache/'archives'/episode/'mapobj/bianco.bmt').read_bytes()).hexdigest())
    (target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


def audit_prop_bindings(cache=DEFAULT,episodes=('bianco0','ricco6','mamma7')):
    """Inspect instantiated donor props without exporting or changing banks."""
    result={}
    for episode in episodes:
        directory=Path(cache)/'archives'/episode
        files={p.relative_to(directory).as_posix().lower():p for p in directory.rglob('*')if p.is_file()}
        rows={};failures=[]
        for obj in flatten(scene((directory/'map/scene.bin').read_bytes())):
            if 'model' not in obj:continue
            path=next((files[n.lower()]for n in prop_model_candidates(obj)if n.lower()in files),None)
            if path is None:continue
            key=(obj['klass'],obj['model'])
            if key in rows:rows[key]['instances']+=1;continue
            try:
                from sunshine_scene import chunks
                base=chunks(path.read_bytes());before=materials(base)
                bound,table=survey_material_chunks(directory,path,base,*key);after=materials(bound)
                old=[m['texture']['name']for m in before];new=[m['texture']['name']for m in after]
                def placeholder(names):return any('dummy' in n.lower() or 'dammy' in n.lower() for n in names)
                rows[key]=dict(klass=key[0],model=key[1],instances=1,imported_class=key[0]in PROPS,
                    before=old,after=new,binding=table.relative_to(directory).as_posix()if table else None,
                    was_placeholder=placeholder(old),remaining_placeholder=placeholder(new))
            except ValueError as error:
                failures.append(dict(klass=key[0],model=key[1],imported_class=key[0]in PROPS,error=str(error)))
        result[episode]=dict(props=list(rows.values()),failures=failures)
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cache',type=Path,default=DEFAULT)
    p.add_argument('--episodes',nargs='+',default=['bianco0','bianco6','ricco0','ricco6','mamma0','mamma7'])
    p.add_argument('--scale',type=float,default=.08190640965783352)
    p.add_argument('--navigation-step',type=float,default=0,help='0 skips expensive route build; 16 is production density')
    p.add_argument('--shared-material-trial',action='store_true',help='Create separate Bianco0 binding trial without changing baseline')
    p.add_argument('--prop-material-trial',action='store_true',help='Create a fresh Bianco0 sign/shared-prop material trial')
    p.add_argument('--shadow-material-trial',action='store_true',help='Create a fresh Bianco0 alpha-mask shadow pass trial')
    p.add_argument('--grain-shadow-trial',action='store_true',help='Create a fresh source-grain/exact-shadow-alpha Bianco0 trial')
    a=p.parse_args();cache=a.cache.expanduser().resolve();repo=payload().resolve()
    if cache==repo or repo in cache.parents:p.error('Private donor output must be outside the repository')
    if a.shared_material_trial or a.prop_material_trial or a.shadow_material_trial or a.grain_shadow_trial:
        name='trial-grain-shadow' if a.grain_shadow_trial else 'trial-shadow-material' if a.shadow_material_trial else 'trial-prop-material' if a.prop_material_trial else 'trial-shared-material'
        r=shared_material_trial(cache,trial_name=name);print(json.dumps(dict(files=r['files'],unchanged_banks=r['unchanged_banks']),indent=2));return
    for episode in a.episodes:
        if '/' in episode or '..' in episode:p.error('Episode must be one archive stem')
        r=survey(cache,episode,a.scale,a.navigation_step)
        print(json.dumps({k:r[k] for k in ('episode','render_triangles','collision_triangles','textures','water_triangles','seconds')}),flush=True)


if __name__=='__main__':main()
