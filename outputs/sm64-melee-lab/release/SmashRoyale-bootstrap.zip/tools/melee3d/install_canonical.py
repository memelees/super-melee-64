#!/usr/bin/env python3
"""Install the tested, unified Melee 3D + Akaneia build."""
import argparse
import json
from pathlib import Path
import shutil
import tempfile
from prepare_akaneia import ROOT, digest

DEFAULT_DISC = Path.home() / 'Projects/melee3d-canonical-disc'
MARKER = 'melee3d-canonical.json'


def runtime_identity(metadata):
    """Identify all generated runtime files, including the separately loaded engine."""
    return {key: metadata[key] for key in
            ('dol_sha256','engine_sha256','gct_sha256','stage_assets')}


def verify_files(directory, metadata):
    expected = {'sys/main.dol': metadata['dol_sha256'],
                'files/m3d_engine.bin': metadata['engine_sha256'],
                'files/codes.gct': metadata['gct_sha256']}
    expected.update({'files/'+name: value for name,value in metadata['stage_assets'].items()})
    for name,value in expected.items():
        if digest(directory / name, 'sha256') != value:
            raise ValueError('Installed/candidate file changed: '+name)


def install(destination):
    directory = ROOT / 'build/canonical/interactive'
    metadata = json.loads((directory / 'build.json').read_text())
    if not metadata['canonical'] or metadata['scripted_test']:
        raise ValueError('Build the interactive canonical candidate first')
    verify_files(directory / 'disc', metadata)
    report = json.loads((ROOT / 'build/canonical/suite-all.json').read_text())
    if not report['passed'] or report['completed'] != 178 or report['total'] != 178:
        raise ValueError('Requires the complete passing canonical integration suite')
    specials = {(case['build']['test_character'], case['build'].get('test_variant'))
                for case in report['results'] if case['build']['test_kind']=='specials'}
    if specials != {(character,variant) for character in range(26,33) for variant in range(8)}:
        raise ValueError('Requires all added-character ground/air special combinations')
    throws = {(case['build']['test_character'],case['build'].get('test_variant'))
              for case in report['results'] if case['build']['test_kind']=='throws'}
    if (throws != {(character,variant) for character in range(26,33) for variant in range(8)}
            or not report.get('throw_rotation',{}).get('passed')
            or report['throw_rotation'].get('count')!=1008
            or report.get('throw_audit_sha256')!=digest(ROOT / 'tools/melee3d/audit_canonical_throws.py','sha256')):
        raise ValueError('Requires the matching four-angle throw/capture audit for every added fighter in both roles')
    aim = {(case['build']['test_character'],case['build'].get('test_variant'))
           for case in report['results'] if case['build']['test_kind']=='throwaim'}
    if aim != {(character,variant) for character in range(26,33) for variant in range(2)}:
        raise ValueError('Requires re-aiming and camera changes during grabs in both roles')
    keys = ['source_sha256', 'engine_core_sha256', 'gct_sha256', 'stage_assets']
    for case in report['results']:
        if not case['passed'] or any(case['build'][key] != metadata[key] for key in keys):
            raise ValueError('Integration results do not match this candidate')
        if case['build']['test_kind'] != 'rules' and case['build']['headers_sha256'] != metadata['headers_sha256']:
            raise ValueError('Headers changed after integration testing')
        if case.get('runtime_identity') != runtime_identity(case['build']):
            raise ValueError('Test engine/assets do not match their runtime report')
        if case['executable_sha256'] != case['build']['dol_sha256']:
            raise ValueError('Test executable hash mismatch')
    menu_directory = ROOT / 'build/canonical/rules-0-32'
    menu_report = json.loads((menu_directory / 'result.json').read_text())
    menu_build = json.loads((menu_directory / 'build.json').read_text())
    if (not menu_report['passed'] or len(menu_report['checks'])<10
            or menu_build.get('menu_fixture_sha256') != digest(ROOT / 'tools/melee3d/run_canonical_menu.py','sha256')
            or menu_report.get('runtime_identity') != runtime_identity(menu_build)
            or menu_report['executable_sha256'] != menu_build['dol_sha256']
            or any(menu_build[key] != metadata[key] for key in keys)):
        raise ValueError('Requires the matching rules-to-match menu check')
    destination = destination.expanduser().resolve()
    if destination.exists() and not (destination / MARKER).is_file():
        raise ValueError('Refusing to replace an unmanaged directory: '+str(destination))
    if destination.exists():
        previous=json.loads((destination / MARKER).read_text())
        verify_files(destination,previous)
        if runtime_identity(previous)==runtime_identity(metadata):
            # A new test fixture can expand acceptance without changing a
            # single game binary. Update the evidence atomically in that case.
            manifest=dict(metadata,acceptance=report,menu_acceptance=menu_report)
            with tempfile.TemporaryDirectory(prefix='.acceptance-',dir=destination) as temporary:
                staged=Path(temporary)/MARKER
                staged.write_text(json.dumps(manifest,indent=2)+'\n')
                shutil.copyfile(destination / MARKER,destination / (MARKER+'.previous'))
                staged.replace(destination / MARKER)
            print('Updated canonical validation: '+str(destination))
            return destination
    backup = destination.with_name(destination.name+'.previous')
    version=2
    while backup.exists():
        backup=destination.with_name(destination.name+f'.previous-{version}')
        version+=1
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.melee3d-install-', dir=destination.parent) as temporary:
        staged = Path(temporary) / 'disc'
        shutil.copytree(directory / 'disc', staged)
        shutil.copyfile(directory / 'payload.map', staged / 'payload.map')
        # Keep controller changes, settings and logs made in the active install.
        if (destination / 'play-profile').is_dir():
            shutil.copytree(destination / 'play-profile', staged / 'play-profile')
        manifest = dict(metadata, acceptance=report, menu_acceptance=menu_report)
        (staged / MARKER).write_text(json.dumps(manifest, indent=2)+'\n')
        verify_files(staged, metadata)
        if destination.exists():
            destination.rename(backup)
        staged.rename(destination)
    print('Installed canonical Melee 3D + Akaneia: '+str(destination))
    return destination


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination', type=Path, default=DEFAULT_DISC)
    install(parser.parse_args().destination)
