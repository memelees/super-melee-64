"""Use the saved stage-select image. Rendering is an explicit authoring command."""
import hashlib,json,os,struct,subprocess,tempfile,zlib
from player_paths import payload

from pathlib import Path

PREVIEW = Path("assets/stage-previews/delfino-plaza.png")
PREVIEWS = {"delfino":PREVIEW,"onett":Path("assets/stage-previews/onett.png"),"castle":Path("assets/stage-previews/peach-castle.png"),"bianco":Path("assets/stage-previews/bianco-hills.png"),"sirena":Path("assets/stage-previews/sirena-beach.png"),"pianta":Path("assets/stage-previews/pianta-village.png")}


def valid_photo(path):
 try:
  data=Path(path).read_bytes()
  return len(data)==12+256*160*4 and data[:12]==struct.pack('<4s2I',b'B3T1',256,160)
 except OSError:return False


def render_preview(bank,cache,*,installation=None,metadata=None,binary=None,graphics_cache=None,backend=None,force=False):
 from player_install import DEFAULT
 from player_play import environment,binary_path
 from player_paths import game_command
 installation=Path(installation or DEFAULT);bank=Path(bank);cache=Path(cache);cache.mkdir(parents=True,exist_ok=True)
 metadata=metadata or json.loads((installation/'player-install.json').read_text());binary=binary_path(binary)
 digest=hashlib.sha256(b'game-photo-v1'+binary.read_bytes()+(bank/'delfino.dlv').read_bytes()).hexdigest()
 target=cache/(digest[:24]+'-game.b3t')
 if not force and valid_photo(target):return target
 with tempfile.TemporaryDirectory(prefix='.stage-photo-',dir=cache) as temporary:
  profile=Path(temporary);output=profile/'photo.b3t'
  env=environment(installation,metadata,profile,2,'sonic','battle','off',cpu_only=True)
  if graphics_cache is not None:env['MELEE_CACHE_DIR']=str(Path(graphics_cache).resolve())
  if backend is not None:env['MELEE_BACKEND']=backend
  env.update(MELEE3D_NATIVE_DELFINO=str(bank),MELEE3D_NATIVE_STAGE_PHOTO=str(output),MELEE_EXIT_AFTER_FRAMES='900',
             MELEE_WINDOW_TITLE='Smash Royale — preparing Plaza preview')
  with (profile/'stdout.txt').open('w') as stream:
   try:completed=subprocess.run(game_command(binary,metadata['melee_path']),cwd=profile,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=90)
   finally:
    (cache/(digest[:24]+'-photo.log')).write_text((profile/'stdout.txt').read_text(errors='replace'))
  if completed.returncode or not valid_photo(output):raise RuntimeError('Could not capture the stage preview. See '+str(cache/(digest[:24]+'-photo.log')))
  os.replace(output,target)
 return target


def png_pixels(path):
 """Decode the small RGBA/zero-filter PNG written by the authoring helper.

 Keeping this format constrained avoids adding an imaging runtime to installs.
 """
 raw=Path(path).read_bytes()
 if len(raw)>200000 or raw[:8]!=b'\x89PNG\r\n\x1a\n':raise ValueError('Invalid saved stage preview')
 cursor=8;parts=[];header=False;ended=False
 while cursor+12<=len(raw):
  length=struct.unpack_from('>I',raw,cursor)[0];kind=raw[cursor+4:cursor+8]
  data=raw[cursor+8:cursor+8+length];end=cursor+12+length
  if end>len(raw) or zlib.crc32(kind+data)!=struct.unpack_from('>I',raw,end-4)[0]:raise ValueError('Corrupt saved stage preview')
  if kind==b'IHDR':
   if header or data!=struct.pack('>2I5B',256,160,8,6,0,0,0):raise ValueError('Stage preview must be 256x160 RGBA')
   header=True
  elif kind==b'IDAT':parts.append(data)
  elif kind==b'IEND':ended=True;break
  else:raise ValueError('Use the stage preview authoring helper to save this PNG')
  cursor=end
 if not header or not ended:raise ValueError('Incomplete saved stage preview')
 expected=160*(1+256*4);decoder=zlib.decompressobj();rows=decoder.decompress(b''.join(parts),expected+1)
 if len(rows)!=expected or not decoder.eof or decoder.unused_data or any(rows[y*1025] for y in range(160)):raise ValueError('Invalid stage preview pixels')
 return b''.join(rows[y*1025+1:(y+1)*1025] for y in range(160))


def photo_png(photo,destination):
 """Losslessly store the renderer's GX texture as a reviewable PNG."""
 if not valid_photo(photo):raise ValueError('Invalid renderer photograph')
 tiled=Path(photo).read_bytes()[12:];pixels=bytearray(256*160*4);offset=0
 for by in range(0,160,4):
  for bx in range(0,256,4):
   tile=tiled[offset:offset+64];offset+=64
   for y in range(4):
    for x in range(4):
     i=(y*4+x)*2;j=((by+y)*256+bx+x)*4
     pixels[j:j+4]=bytes((tile[i+1],tile[32+i],tile[33+i],tile[i]))
 def chunk(kind,data):return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data))
 rows=b''.join(b'\0'+pixels[y*1024:(y+1)*1024] for y in range(160))
 encoded=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>2I5B',256,160,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(rows,9))+chunk(b'IEND',b'')
 destination=Path(destination);destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(encoded)
 if png_pixels(destination)!=pixels:raise ValueError('Stage preview encoding failed')
 return destination


def install_preview(destination):
 """Ship exactly one saved native photograph per selectable map."""
 import shutil
 maps={}
 for name,relative in PREVIEWS.items():
  source=payload()/relative;png_pixels(source)
  target=Path(destination)/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
  maps[name]=dict(path=relative.as_posix(),sha256=hashlib.sha256(source.read_bytes()).hexdigest())
 return dict(**maps["delfino"],source='saved native renderer screenshots',maps=maps)


def preview(cache,*,stage="delfino"):
 if stage not in PREVIEWS:raise ValueError("Unknown stage preview")
 """Load the committed photograph; never start a game or read the disc/map."""
 source=payload()/PREVIEWS[stage];pixels=png_pixels(source)
 digest=hashlib.sha256(source.read_bytes()).hexdigest()[:24]
 cache=Path(cache);cache.mkdir(parents=True,exist_ok=True);target=cache/(digest+'-saved.b3t')
 if valid_photo(target):return target
 tiled=bytearray(struct.pack('<4s2I',b'B3T1',256,160))
 for by in range(0,160,4):
  for bx in range(0,256,4):
   tile=bytearray(64)
   for y in range(4):
    for x in range(4):
     j=((by+y)*256+bx+x)*4;r,g,b,a=pixels[j:j+4];i=(y*4+x)*2
     tile[i]=a;tile[i+1]=r;tile[32+i]=g;tile[33+i]=b
   tiled.extend(tile)
 temporary=None
 try:
  with tempfile.NamedTemporaryFile(dir=cache,prefix='.stage-image-',delete=False) as f:
   temporary=Path(f.name);f.write(tiled)
  os.replace(temporary,target)
 finally:
  if temporary:temporary.unlink(missing_ok=True)
 return target


def native_menu_assets(installation,metadata):
 """Keep the original Melee title/SSS models; Akaneia supplies the CSS grid."""
 from sunshine_extract import filesystem,exact
 directory=Path(installation)/'akaneia/files'
 wanted={'GmTtAll.usd':'M3dTitle.usd','MnSlMap.usd':'M3dStageSelect.usd'}
 if all((directory/alias).is_file() for alias in wanted.values()):return
 with Path(metadata['melee_path']).open('rb') as f:
  header=exact(f,0x440);offset,size=struct.unpack_from('>II',header,0x424)
  if size>8*1024*1024:raise ValueError('Invalid Melee menu source')
  f.seek(offset);entries=filesystem(exact(f,size))
  for name,alias in wanted.items():
   source=next((r for r in entries if r['path']==name),None)
   if source is None or source['size']>8*1024*1024:raise ValueError('Missing original menu archive: '+name)
   f.seek(source['offset']);raw=exact(f,source['size']);target=directory/alias
   if not target.is_file() or target.read_bytes()!=raw:
    temporary=target.with_suffix('.tmp');temporary.write_bytes(raw);temporary.replace(target)


def main():
 import argparse
 from player_install import DEFAULT,verify_install
 from player_stage import visual_bank
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--refresh',action='store_true',help='Explicitly render a new photograph using your private game import')
 p.add_argument('--from-photo',type=Path,help='Save an existing renderer .b3t capture without running the game')
 p.add_argument('--installation',type=Path,default=DEFAULT);a=p.parse_args()
 if not a.refresh and not a.from_photo:p.error('Use --refresh or --from-photo; normal play never renders a thumbnail')
 photo=a.from_photo
 if photo is None:
  metadata=verify_install(a.installation)
  photo=render_preview(visual_bank(a.installation,metadata),a.installation.parent/'authoring-previews',installation=a.installation,metadata=metadata,force=True)
 print(photo_png(photo,payload()/PREVIEW))


if __name__=='__main__':main()
