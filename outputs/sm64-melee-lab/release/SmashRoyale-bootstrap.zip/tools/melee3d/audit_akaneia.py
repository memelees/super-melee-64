#!/usr/bin/env python3
"""Read-only audit of the pinned Akaneia release against a Melee 3D build.

This inventories direct m3d call sites, executable relocation and overlapping
release patches. It does not merge patches or certify compatibility. Requires
pyelftools, as do the repository's other ELF inspection tools.
"""

import argparse
from collections import Counter
import json
from pathlib import Path
import re
import struct

from prepare_akaneia import ROOT, VERSION, RELEASE_URL, digest


def gecko_patches(data):
    """Parse the release's 04/C2 stream, skipping executable payloads.

    Fail closed on unknown code types: blindly scanning payload words produces
    fictitious hooks and is unsuitable for an integration inventory.
    """
    if len(data) < 16 or data[:8] != bytes.fromhex("00d0c0de00d0c0de"):
        raise ValueError("Invalid Gecko header")
    result = []
    cursor = 8
    while cursor + 8 <= len(data):
        offset = cursor
        command, value = struct.unpack_from(">II", data, cursor)
        cursor += 8
        kind = command >> 24
        if kind == 0xF0:
            if value != 0 or cursor != len(data):
                raise ValueError("Malformed Gecko terminator or trailing data")
            return result
        if kind not in (0x04, 0xC2):
            raise ValueError(f"Unsupported Gecko type {kind:02x} at {offset:#x}")
        patch = {
            "type": f"{kind:02X}",
            "address": 0x80000000 | (command & 0x01FFFFFF),
            "gct_offset": offset,
        }
        if kind == 0xC2:
            payload = value * 8
            if not payload or cursor + payload > len(data) - 8:
                raise ValueError(f"Truncated Gecko injection at {offset:#x}")
            patch["payload_bytes"] = payload
            cursor += payload
        else:
            patch["value"] = value
        result.append(patch)
    raise ValueError("Missing Gecko terminator")


def dol_sections(data):
    if len(data) < 0x100:
        raise ValueError("Truncated DOL header")
    sections = []
    for index in range(18):
        offset, address, size = (
            struct.unpack_from(">I", data, base + index * 4)[0]
            for base in (0, 0x48, 0x90)
        )
        if not size:
            continue
        if offset < 0x100 or offset + size > len(data):
            raise ValueError(f"Invalid DOL section {index}")
        sections.append((address, offset, size))
    return sections


def dol_read(data, sections, address, size):
    for start, offset, length in sections:
        if start <= address and address + size <= start + length:
            begin = offset + address - start
            return data[begin:begin + size]
    raise ValueError(f"DOL has no data at {address:#x}+{size:#x}")


def original_functions(path):
    result = {}
    pattern = r"(\S+) = \S+:(0x[\da-fA-F]+);.*type:function size:(0x[\da-fA-F]+)"
    for line in path.read_text().splitlines():
        match = re.match(pattern, line)
        if match:
            name, address, size = match.groups()
            result[name] = (int(address, 16), int(size, 16))
    return result


def m3d_callers(objects, originals):
    from elftools.elf.elffile import ELFFile

    result = {}
    for path in sorted(objects.rglob("*.o")):
        if "m3d" in path.relative_to(objects).parts:
            continue
        with path.open("rb") as stream:
            elf = ELFFile(stream)
            symbols = elf.get_section_by_name(".symtab")
            if symbols is None:
                continue
            functions = [
                symbol for symbol in symbols.iter_symbols()
                if symbol["st_info"]["type"] == "STT_FUNC" and symbol["st_size"]
            ]
            for section in elf.iter_sections():
                if section["sh_type"] != "SHT_RELA":
                    continue
                target_index = section["sh_info"]
                for relocation in section.iter_relocations():
                    callee = symbols.get_symbol(relocation["r_info_sym"]).name
                    if not callee.startswith("m3d_"):
                        continue
                    position = relocation["r_offset"]
                    for function in functions:
                        if function["st_shndx"] != target_index or not (
                            function["st_value"] <= position <
                            function["st_value"] + function["st_size"]
                        ):
                            continue
                        name = function.name.removesuffix("2D")
                        if name not in originals:
                            continue
                        address, size = originals[name]
                        record = result.setdefault(name, {
                            "name": name, "native_address": address,
                            "native_size": size, "objects": set(), "calls": set(),
                        })
                        record["objects"].add(str(path.relative_to(objects)))
                        record["calls"].add(callee)
    for record in result.values():
        for field in ("objects", "calls"):
            record[field] = sorted(record[field])
    return sorted(result.values(), key=lambda record: record["native_address"])


def audit(root, disc):
    from elftools.elf.elffile import ELFFile

    native = root / "orig/GALE01/sys/main.dol"
    current = root / "build/GALE01/main.dol"
    upstream = disc / "sys/main.dol"
    gct = disc / "files/codes.gct"
    symbols_path = root / "config/GALE01/symbols.txt"
    originals = original_functions(symbols_path)
    patches = gecko_patches(gct.read_bytes())
    native_data, upstream_data = native.read_bytes(), upstream.read_bytes()
    native_sections = dol_sections(native_data)
    upstream_sections = dol_sections(upstream_data)
    with (root / "build/GALE01/main.elf").open("rb") as stream:
        elf = ELFFile(stream)
        linked = {
            symbol.name: symbol["st_value"]
            for symbol in elf.get_section_by_name(".symtab").iter_symbols()
            if symbol["st_info"]["type"] == "STT_FUNC"
        }
    callers = m3d_callers(root / "build/GALE01/src/melee", originals)
    for record in callers:
        address, size = record["native_address"], record["native_size"]
        record["linked_address"] = linked.get(record["name"])
        record["release_runtime_overlaps"] = [
            patch for patch in patches if address <= patch["address"] < address + size
        ]
        # A runtime inventory alone misses the static edits in main.dol.
        before = dol_read(native_data, native_sections, address, size)
        after = dol_read(upstream_data, upstream_sections, address, size)
        record["release_static_changed_words"] = sum(
            before[index:index + 4] != after[index:index + 4]
            for index in range(0, size, 4)
        )
    relocated = [
        {"name": name, "native_address": address, "linked_address": linked[name]}
        for name, (address, _) in originals.items()
        if name in linked and linked[name] != address
    ]
    return {
        "release": VERSION, "release_url": RELEASE_URL,
        "combined_3d_ready": False,
        "scope": "Direct m3d call sites only; not an exhaustive ABI or patch-safety proof.",
        "files": {(str(path.relative_to(root)) if path.is_relative_to(root) else str(path)):
                  digest(path, "sha256")
                  for path in (native, current, upstream, gct, symbols_path)},
        "runtime_patch_counts": dict(Counter(patch["type"] for patch in patches)),
        "direct_m3d_native_functions": len(callers),
        "functions_with_runtime_overlaps": sum(
            bool(record["release_runtime_overlaps"]) for record in callers),
        "functions_with_injection_overlaps": sum(
            any(patch["type"] == "C2" for patch in record["release_runtime_overlaps"])
            for record in callers),
        "functions_with_static_overlaps": sum(
            bool(record["release_static_changed_words"]) for record in callers),
        "relocated_native_functions": len(relocated),
        "relocation_examples": [record for record in relocated if record["name"] in (
            "Fighter_procInput", "Fighter_procUpdate", "Fighter_procMap", "Item_8026862C")],
        "functions": callers,
        "required_integration_gates": [
            "Build the shared 3D layer against Akaneia's fixed native ABI.",
            "Merge common function hooks while retaining m-ex dynamic tables and callbacks.",
            "Adapt the dedicated 3D stage catalogue to Akaneia's stage-select system.",
            "Check expanded fighter/item IDs, custom callbacks and emitter transforms.",
            "Test movement, AI, grabs, specials, items and stage transitions for the expanded roster.",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--disc", type=Path, default=ROOT / "build/akaneia/disc")
    parser.add_argument("--output", type=Path, default=ROOT / "build/akaneia/compatibility.json")
    args = parser.parse_args()
    report = audit(ROOT, args.disc.resolve())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(f"Audited {report['direct_m3d_native_functions']} native functions calling the 3D layer")
    print(f"Runtime overlaps: {report['functions_with_runtime_overlaps']}; "
          f"static overlaps: {report['functions_with_static_overlaps']}")
    print(f"Report: {args.output}")
    print("Compatibility is not established; this tool does not create a combined build.")


if __name__ == "__main__":
    main()
