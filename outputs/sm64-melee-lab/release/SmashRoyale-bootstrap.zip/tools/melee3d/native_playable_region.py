"""Source-defined convex playable-region union and grounded support caps."""
import math,struct,json,hashlib
from collections import defaultdict,Counter
from pathlib import Path
EPS=.001

def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
class Region:
 def __init__(self,payload):
  if payload['schema_version']!=1 or payload['coordinate_space']!='native-world-scale-applied-once':raise ValueError('Invalid region schema/space')
  self.payload=payload;self.rows=[];self.grid=defaultdict(list)
  for row in payload['regions']:
   ps=[tuple(map(f32,p))for p in row['polygon']];cap=f32(row['maximum_grounded_floor_y'])
   if not 3<=len(ps)<=64 or not math.isfinite(cap)or any(len(p)!=2 or any(not math.isfinite(v)or abs(v)>20000 for v in p)for p in ps):raise ValueError('Invalid polygon/cap')
   sign=0
   for a,b,c in zip(ps,ps[1:]+ps[:1],ps[2:]+ps[:2]):
    cross=(b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0])
    if abs(cross)<1e-6:continue
    if sign*cross<0:raise ValueError('Nonconvex polygon')
    sign=cross
   if not sign:raise ValueError('Degenerate polygon')
   for a,b in zip(ps,ps[1:]+ps[:1]):
    dx,dz=b[0]-a[0],b[1]-a[1]
    if any(((dx*(q[1]-a[1])-dz*(q[0]-a[0]))*(1 if sign>0 else-1)) < -EPS*math.hypot(dx,dz)for q in ps):raise ValueError('Self-crossing or nonconvex polygon')
   lo=[min(p[k]for p in ps)for k in range(2)];hi=[max(p[k]for p in ps)for k in range(2)];i=len(self.rows);self.rows.append((ps,cap,sign,lo,hi))
   for x in range(math.floor((lo[0]-EPS)/64),math.floor((hi[0]+EPS)/64)+1):
    for z in range(math.floor((lo[1]-EPS)/64),math.floor((hi[1]+EPS)/64)+1):self.grid[x,z].append(i)
 def contains(self,p,grounded=True):
  x,y,z=p
  for i in self.grid.get((math.floor(x/64),math.floor(z/64)),[]):
   ps,cap,sign,lo,hi=self.rows[i]
   if grounded and y>cap+.01:continue
   if all(((b[0]-a[0])*(z-a[1])-(b[1]-a[1])*(x-a[0]))*(1 if sign>0 else-1)>=-EPS*math.hypot(b[0]-a[0],b[1]-a[1])for a,b in zip(ps,ps[1:]+ps[:1])):return True
  return False
 def segment(self,a,b):
  # XZ union coverage: jumps must not cross a KO strip between legal endpoints.
  dx,dz=b[0]-a[0],b[2]-a[2];intervals=[];indices=set()
  for x in range(math.floor((min(a[0],b[0])-EPS)/64),math.floor((max(a[0],b[0])+EPS)/64)+1):
   for z in range(math.floor((min(a[2],b[2])-EPS)/64),math.floor((max(a[2],b[2])+EPS)/64)+1):indices.update(self.grid.get((x,z),[]))
  for i in indices:
   ps,cap,sign,*_=self.rows[i];lo,hi=0.,1.;s=1 if sign>0 else-1
   for p,q in zip(ps,ps[1:]+ps[:1]):
    ex,ez=q[0]-p[0],q[1]-p[1];v=s*(ex*(a[2]-p[1])-ez*(a[0]-p[0]));d=s*(ex*dz-ez*dx);tol=EPS*math.hypot(ex,ez)
    if abs(d)<1e-12:
     if v< -tol:hi=-1;break
    elif d>0:lo=max(lo,(-tol-v)/d)
    else:hi=min(hi,(-tol-v)/d)
   if hi>=lo and hi>=0 and lo<=1:intervals.append((max(0.,lo),min(1.,hi)))
  reached=0.
  for lo,hi in sorted(intervals):
   if lo>reached+1e-8:return False
   reached=max(reached,hi)
  return reached>=1-1e-8
 def encode(self):
  return struct.pack('<4s2I',b'OPR1',1,len(self.rows))+b''.join(struct.pack('<If',len(ps),cap)+b''.join(struct.pack('<2f',*p)for p in ps)for ps,cap,*_ in self.rows)

def filter_graph(nodes,edges,groups,region):
 from sunshine_navigation import components
 selected=[i for i,p in enumerate(nodes)if region.contains(p)];mapping={i:j for j,i in enumerate(selected)};rejected=0;new=[]
 for i in selected:
  row=[]
  for j,kind in edges[i]:
   if j not in mapping:continue
   if not region.segment(nodes[i],nodes[j]):rejected+=1;continue
   row.append((mapping[j],kind))
  new.append(row)
 original=len(nodes);nodes[:]=[nodes[i]for i in selected];edges[:]=new;groups[:]=components([[(j,k)for j,k in e if k!=3]for e in edges])
 return dict(source_regions=len(region.rows),removed_nodes=original-len(nodes),removed_cross_boundary_edges=rejected,method='Exact source polygon union and per-region grounded floor caps; every retained edge has full legal XZ coverage')

def compile_contract(path,archive_hash):
 payload=json.loads(Path(path).read_text())
 if payload['archive_sha256']!=archive_hash:raise ValueError('Playable region archive mismatch')
 region=Region(payload)
 for sample in payload['allowed_samples']:
  if not region.contains(sample['position'],sample.get('grounded',True)):raise ValueError('Allowed region regression failed: '+sample['name'])
 for sample in payload['excluded_samples']:
  if region.contains(sample['position'],sample.get('grounded',True)):raise ValueError('Excluded region regression failed: '+sample['name'])
 return region
