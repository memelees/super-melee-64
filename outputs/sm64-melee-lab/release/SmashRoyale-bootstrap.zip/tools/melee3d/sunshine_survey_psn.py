#!/usr/bin/env python3
"""Private static-conversion survey of Pinna, Sirena/Hotel and Noki scenes.

Uses the existing bounded disc/J3D/COL parsers. Does not alter installed maps,
produce a gameplay release, or claim animated attractions/TEV/navigation parity.
All donor data, thumbnails and banks must be written outside the repository.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
from player_paths import payload,source_file
import struct
import time

from sunshine_extract import extract
from sunshine_scene import bounds, collision, flatten, matrix, scene, static_model, transform
from sunshine_compile import WATER, PASS_THROUGH, MATERIAL_STATE, cross, material_chunks, materials, prop_model_candidates, unique_collision

SCENES = 'pinnaBeach0 pinnaBeach1 pinnaBeach4 pinnaParco0 pinnaParco2 pinnaParco7 sirena0 sirena1 sirena5 sirena7 delfino0 delfino3 casino0 mare0 mare1 mare7 mareUndersea'.split()
DEFAULT = Path.home() / 'Library/Application Support/Memelees/map-survey/pinna-sirena-noki'
# Only visibly static scenery. Doors, moving rides, walls and boats remain
# explicit omissions; matching a model name alone is not a physics contract.
STATIC_CLASSES = {'MapStaticObj','MapObjBase','Palm','PalmOugi','PalmNatume','WoodBox','WoodBarrel','Fence','FenceInner','FenceWaterH','FenceWaterV','RailFence','BiancoFence','Billboard'}
POLLUTION_TYPES = {0:'sink',1:'fire',2:'slip',3:'glass_wall',4:'electric',5:'instant_kill',6:'safe',7:'unknown7',8:'unknown8',10:'unknown10'}


def private(path):
    repo = payload().resolve()
    path = path.expanduser().resolve()
    if path == repo or repo in path.parents:
        raise ValueError('Donor data and converted outputs must stay outside the repository')
    return path


def pollution(directory):
    path = directory / 'map/ymap.ymp'
    if not path.exists(): return []
    data = path.read_bytes()
    if len(data)<8: raise ValueError('Truncated pollution header')
    count = struct.unpack_from('>H',data)[0]
    first = struct.unpack_from('>I',data,4)[0]
    if count>100 or first+count*44>len(data): raise ValueError('Invalid pollution layer table')
    result=[]
    for i in range(count):
        typ,flags,plane,vertical,texel,left,top,right,bottom,w,h,unknown,offset = struct.unpack_from('>3H2x6f2H2I',data,first+i*44)
        result.append(dict(index=i,type=typ,effect=POLLUTION_TYPES.get(typ,'unknown'),flags=flags,plane=plane,
                           vertical_offset=vertical,texel_size=texel,bounds=[left,top,right,bottom],log2_size=[w,h]))
    return result


def floor_metrics(colliders):
    floor=[];water=0;area=0;layers=Counter();verts={};edges=defaultdict(list)
    for ps,n,s,f in colliders:
        if f&1: water+=1
        if f&3 or n[1]<.65: continue
        a=cross(*ps);triangle_area=math.sqrt(sum(v*v for v in a))/2
        area+=triangle_area;layers[math.floor(sum(p[1] for p in ps)/3/32)*32]+=triangle_area
        idx=len(floor);floor.append((ps,n,s,f))
        qs=[tuple(round(v,2) for v in p) for p in ps]
        for a,b in zip(qs,qs[1:]+qs[:1]):edges[tuple(sorted((a,b)))].append(idx)
    parent=list(range(len(floor)))
    def root(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
        return i
    for ids in edges.values():
        for i in ids[1:]:parent[root(i)]=root(ids[0])
    groups=Counter(root(i) for i in range(len(floor)))
    return dict(walkable_triangles=len(floor),walkable_area=round(area,2),water_triangles=water,
                walkable_height_area={str(k):round(v,2) for k,v in sorted(layers.items())},
                exact_shared_edge_floor_components=len(groups),largest_floor_component_triangles=max(groups.values(),default=0),
                topology_limit='Exact shared edges only: excludes jumps, T-junction welding, wall clearance and dynamic objects; not an AI reachability certificate')


def convert(cache, name, scale, output=None, sirena_quality=False):
    start=time.monotonic();directory=cache/'archives'/name;target=private(Path(output)) if output is not None else cache/'converted'/name;target.mkdir(parents=True,exist_ok=True)
    objects=list(flatten(scene((directory/'map/scene.bin').read_bytes())))
    files={p.relative_to(directory).as_posix().lower():p for p in directory.rglob('*') if p.is_file()}
    geometry=[];colliders=[];textures=[];draws=[];groups=[];included=[];omitted=[];failures=[];lookup={};parsed_cache={};material_audit=[];omitted_passes=[]
    identity=matrix((0,0,0),(0,0,0),(1,1,1))
    def add_model(path, mt, water=False, sky=False, klass='base', actor_model=None):
        rel=path.relative_to(directory).as_posix()
        try:
            if path not in parsed_cache:parsed_cache[path]=static_model(path.read_bytes())
            parsed=parsed_cache[path]
            if parsed['unsupported']:raise ValueError('Unsupported shapes: '+str(parsed['unsupported'][:3]))
            from sunshine_survey_brg import survey_material_chunks
            cs,bmt=survey_material_chunks(directory,path,parsed['chunks'],klass,actor_model);mats=materials(cs)
        except (ValueError,KeyError,IndexError,struct.error) as e:
            failures.append(dict(path=rel,reason=str(e)));return False
        material_audit.append(dict(path=rel,companion=bmt.relative_to(directory).as_posix() if bmt else None,
                                   materials=[dict(name=m['name'],texture=m['texture']['name'],rgba=m['rgba'],flags=m['flags'],state=dict(m['state'])) for m in mats]))
        mids=[]
        for m in mats:
            if water:
                m['flags']|=5;m['rgba']=(70,170,215,195)
                m['state'].update(cull=0,depth_write=0,blend_mode=1,blend_src=4,blend_dst=5,alpha_comp0=7,alpha_ref0=0,alpha_op=0,alpha_comp1=7,alpha_ref1=0)
            t=m['texture'];key=(hashlib.sha256(t['data']).hexdigest(),t['width'],t['height'],t['format'],t['wrap_s'],t['wrap_t'],m['flags'],sky,tuple(m['state'][k] for k in MATERIAL_STATE))
            if key not in lookup:lookup[key]=len(textures);textures.append(dict(t,flags=m['flags']|(2 if sky else 0),state=m['state']))
            mids.append(lookup[key])
        bucket=defaultdict(list);group=len(included)
        for material,tri in parsed['triangles']:
            m=mats[material]
            # Sirena's dark pool base is a subtractive untextured TEV pass.
            # Replaying it as standalone white*dark subtracts the whole pool
            # to black. The donor sea mesh already carries its wave surface.
            # Keep the native pool waves and omit only this unsupported pass.
            if sirena_quality and name.startswith('sirena') and rel=='map/map/map.bmd' and m['name']=='_water_Pool_1':
                omitted_passes.append((rel,m['name']));continue
            converted=[(tuple(v*scale for v in transform(mt,p)),tuple(round(c[i]*m['rgba'][i]/255) for i in range(4)),uv) for p,c,uv in tri]
            bucket[mids[material]].append(converted)
        for mat,triangles in bucket.items():
            first=len(geometry);geometry.extend(triangles);draws.append((mat,first,len(triangles)));groups.extend([group]*len(triangles))
        included.append(dict(path=rel,klass=klass,triangles=sum(map(len,bucket.values())),companion_material=bmt.relative_to(directory).as_posix() if bmt else None))
        return True
    def add_collision(path,mt):
        ps,faces=collision(path.read_bytes());ps=[tuple(v*scale for v in transform(mt,p)) for p in ps]
        for f in faces:
            s=f['surface'];base=s&0x3fff
            if base in PASS_THROUGH:continue
            points=[ps[i] for i in f['indices']];n=cross(*points);length=math.sqrt(sum(v*v for v in n))
            if length<1e-8:continue
            flags=(1 if s in WATER or base in WATER else 0)|(2 if base in (0x600,0x800) else 0)|(4 if base==6 else 0)
            colliders.append((points,tuple(v/length for v in n),s,flags))
    base_models=[]
    # Geometry of reflections and pre-authored pollution is not ordinary map
    # geometry. Export pollution separately as an inventory, not an opaque floor.
    # Native sky draws disable depth testing: they must precede terrain.
    for path in sorted((directory/'map/map').glob('*.bmd'),key=lambda p:(p.stem.lower()!='sky',p.name)):
        stem=path.stem.lower()
        if any(k in stem for k in ('reflect','pollution','mirror')):continue
        if add_model(path,identity,water='sea' in stem or 'water' in stem or 'river' in stem,sky=stem=='sky'):base_models.append(path.name)
    for path in sorted([directory/'map/map.col',*(directory/'map/map').glob('*.col')]):
        if 'pollution' not in path.stem.lower():add_collision(path,identity)
    for obj in objects:
        if 'model' not in obj:continue
        candidates=prop_model_candidates(obj)
        # The palm subclasses use the same model candidate mechanism; no
        # class-name substitution if their donor scene names a different mesh.
        path=next((files[k.lower()] for k in candidates if k.lower() in files),None)
        if obj['klass'] not in STATIC_CLASSES:
            if path is not None:omitted.append(dict(klass=obj['klass'],model=obj['model'],reason='dynamic/interaction class requires dedicated behavior review'))
            continue
        if path is None:omitted.append(dict(klass=obj['klass'],model=obj['model'],reason='no supported model candidate'));continue
        mt=matrix(obj['position'],[v*math.pi/180 for v in obj['rotation']],obj['scale'])
        if add_model(path,mt,klass=obj['klass'],actor_model=obj['model']) and path.with_suffix('.col').exists():add_collision(path.with_suffix('.col'),mt)
    colliders=unique_collision(colliders)
    raw=bytearray(struct.pack('<4s4I',b'DLV1',2,len(textures),len(draws),len(geometry)))
    for t in textures:raw+=struct.pack('<7I',t['width'],t['height'],t['format'],t['wrap_s'],t['wrap_t'],t['flags'],len(t['data']))+struct.pack('<14I',*(t['state'][k] for k in MATERIAL_STATE))+t['data']
    raw+=b''.join(struct.pack('<3I',*d) for d in draws)
    for tri in geometry:
        for p,c,uv in tri:raw+=struct.pack('<3f4B2f',*p,*c,*uv)
    (target/'delfino.dlv').write_bytes(raw)
    (target/'delfino.dlc').write_bytes(struct.pack('<4s2I',b'DLC1',1,len(colliders))+b''.join(struct.pack('<12f2I',*(v for p in ps for v in p),*n,s,f) for ps,n,s,f in colliders))
    (target/'delfino.dlg').write_bytes(struct.pack('<4s3I',b'DLG1',1,len(geometry),len(included))+struct.pack('<'+str(len(groups))+'I',*groups))
    (target/'delfino.dls').write_bytes(struct.pack('<4sIf3fI',b'DLS1',2,scale,0,0,3250*scale,0))
    cb=bounds([p for ps,*_ in colliders for p in ps]);metrics=floor_metrics(colliders)
    report=dict(scene=name,status='partial static banks; base geometry blocked' if 'map.bmd' not in base_models else 'static banks converted; not gameplay-ready',scale=scale,base_models=base_models,render_triangles=len(geometry),collision_triangles=len(colliders),textures=len(textures),draws=len(draws),collision_bounds=cb,
                collision_extents=[round(cb[1][i]-cb[0][i],2) for i in range(3)],metrics=metrics,
                included_models=included,omitted_objects=omitted,model_failures=failures,material_audit=material_audit,omitted_material_passes=[dict(path=path,material=material,triangles=count,reason='Standalone subtractive pool pass unsupported; donor wave geometry retained') for (path,material),count in Counter(omitted_passes).items()],scene_classes=dict(Counter(o['klass'] for o in objects)),
                pollution_layers=pollution(directory),pollution_files=[p.relative_to(directory).as_posix() for p in sorted((directory/'map/pollution').glob('*'))],
                animated_model_files=[p.relative_to(directory).as_posix() for p in sorted(directory.rglob('*')) if p.suffix in ('.bck','.btk','.brk','.bpk','.btp')],
                surface_histogram=dict(Counter(s for _,_,s,_ in colliders)),
                files={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in target.iterdir() if p.suffix in ('.dlv','.dlc','.dlg','.dls')},
                limitations=['No live fighter/CPU, navigation, spawn, item, camera, goop, audio or results-loop validation','No J3D TEV parity or animated attractions; no animated donor collision','No new stage selection or installation changes'],seconds=round(time.monotonic()-start,2))
    (target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    # Spatial review only, deliberately marked as collision rather than a
    # game renderer. Donor-derived preview is private alongside the banks.
    from PIL import Image,ImageDraw
    image=Image.new('RGB',(1000,1000),(20,29,39));draw=ImageDraw.Draw(image)
    extent=max(cb[1][0]-cb[0][0],cb[1][2]-cb[0][2]);ratio=920/max(extent,1)
    cx=(cb[1][0]+cb[0][0])/2;cz=(cb[1][2]+cb[0][2])/2
    for ps,n,s,f in sorted(colliders,key=lambda t:sum(p[1] for p in t[0])):
        if not f&1 and n[1]<.65:continue
        h=(sum(p[1] for p in ps)/3-cb[0][1])/max(cb[1][1]-cb[0][1],1)
        color=(25,90,135) if f&1 else (int(65+140*h),int(95+110*h),int(68+70*h))
        draw.polygon([(500+(p[0]-cx)*ratio,500+(p[2]-cz)*ratio) for p in ps],fill=color)
    draw.text((20,20),name+' — static collision coverage; blue = water',(255,255,255))
    image.save(target/'collision-overview.png')
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cache',type=Path,default=DEFAULT);p.add_argument('--scenes',nargs='+',default=SCENES);p.add_argument('--extract',action='store_true');p.add_argument('--source',type=Path);p.add_argument('--scale',type=float);p.add_argument('--navigation',nargs='*',default=[],help='Optionally derive coarse collision-based routes for named converted scenes');a=p.parse_args()
    cache=private(a.cache)
    if a.scale is None:
        from sunshine_scale import measure
        a.scale=measure(Path.home()/'Library/Application Support/Memelees/game-data/sunshine')['scale']
    if not math.isfinite(a.scale) or a.scale<=0:raise ValueError('Positive finite donor scale required')
    if a.extract:
        source=a.source
        if source is None:source=Path(json.loads((Path.home()/'Library/Application Support/Memelees/game-data/sunshine/source.json').read_text())['source'])
        extract(source,cache,['data/scene/'+name+'.szs' for name in a.scenes])
    reports=[]
    for name in a.scenes:
        try:
            report=convert(cache,name,a.scale);reports.append(report)
            print(json.dumps({k:report[k] for k in ('scene','render_triangles','collision_triangles','collision_extents','seconds')},ensure_ascii=True),flush=True)
        except (OSError,ValueError,KeyError,IndexError,struct.error) as e:
            report=dict(scene=name,status='conversion failed',error=str(e));reports.append(report);print(json.dumps(report),flush=True)
    (cache/'survey.json').write_text(json.dumps(reports,indent=2)+'\n')
    for name in a.navigation:
        from sunshine_navigation import build, encode
        target=cache/'converted'/name;data=(target/'delfino.dlc').read_bytes()
        magic,version,count=struct.unpack_from('<4s2I',data)
        if (magic,version)!=(b'DLC1',1) or len(data)!=12+count*56:raise ValueError('Invalid converted collision bank')
        colliders=[]
        for i in range(count):
            v=struct.unpack_from('<12f2I',data,12+i*56)
            colliders.append(([v[:3],v[3:6],v[6:9]],v[9:12],v[12],v[13]))
        start=time.monotonic();nodes,edges,groups,report=build(colliders,step=32)
        (target/'delfino.dln').write_bytes(encode(nodes,edges,groups,report['step']))
        report.update(seconds=round(time.monotonic()-start,2),limitation='Coarse 32-unit geometric candidate routes; native fighter traversal is not tested')
        (target/'navigation-report.json').write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps(dict(scene=name,navigation=report)),flush=True)

if __name__=='__main__':main()
