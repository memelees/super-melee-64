#!/usr/bin/env python3
"""Validate local m-ex registration data and generate native table initializers.

Only table metadata and native source are emitted, inside ignored build output.
The disc's internal ids, port kinds and character ids are separate namespaces.
"""
import json
import re
from pathlib import Path
import struct

from native_compatibility import ROOT, WORK, sha, write_json


class Archive:
    def __init__(self, path):
        self.data = path.read_bytes()
        total, self.size, nr, np, ne = struct.unpack_from(">5I", self.data)
        if total != len(self.data) or self.size > len(self.data)-32:
            raise ValueError("Invalid HSD archive size")
        self.payload = self.data[32:32+self.size]
        table = 32+self.size+nr*4
        strings = table+(np+ne)*8
        self.public = {}
        for i in range(np):
            address, name = struct.unpack_from(">II", self.data, table+i*8)
            end = self.data.index(0, strings+name)
            self.public[self.data[strings+name:end].decode("ascii")] = address

    def object_end(self, start):
        """Next referenced object, not the next pointer *inside* this object."""
        nr=struct.unpack_from('>I',self.data,8)[0]
        table=32+self.size
        if table+nr*4>len(self.data):raise ValueError('Relocation table outside archive')
        destinations=[self.word(struct.unpack_from('>I',self.data,table+i*4)[0]) for i in range(nr)]
        return min([p for p in destinations if start<p<=self.size]+[self.size])

    def word(self, offset):
        if offset < 0 or offset+4 > self.size:
            raise ValueError("HSD metadata word outside data section")
        return struct.unpack_from(">I", self.payload, offset)[0]

    def byte(self, offset):
        if not 0 <= offset < self.size:
            raise ValueError("HSD metadata byte outside data section")
        return self.payload[offset]

    def string(self, offset):
        if not offset:
            return None
        if not 0 <= offset < self.size:
            raise ValueError("HSD metadata string outside data section")
        end = self.payload.index(0, offset)
        return self.payload[offset:end].decode("ascii")


TABLES = ["ftData_OnLoad", "ftData_OnDeath", "ftData_OnUserDataRemove",
          "ftData_CharacterStateTables", "ftData_SpecialN", "ftData_SpecialAirN",
          "ftData_SpecialS", "ftData_SpecialAirS", "ftData_SpecialHi",
          "ftData_SpecialAirHi", "ftData_SpecialLw", "ftData_SpecialAirLw",
          "ftData_OnAbsorb", "ftData_OnItemPickupExt", "ftData_OnItemInvisible",
          "ftData_OnItemVisible", "ftData_OnItemDropExt", "ftData_OnItemPickup",
          "ftData_OnItemDrop", "ftData_UnkMotionStates1", "ftData_UnkMotionStates2",
          "ftData_OnKnockbackEnter", "ftData_OnKnockbackExit", "ftData_UnkMotionStates3",
          "ftData_UnkMotionStates4", "ftKindCalcIndiviParamTable", "ftData_UnkMtxFunc0"]
CHARACTERS = ["Wolf", "Diddy", "Charizard", "Lucas", "Sonic", "Dedede", "Tails"]


def inventory():
    files = ROOT / "build/akaneia/disc/files"
    path = files / "MxDt.dat"
    a = Archive(path)
    root = a.public["mexData"]
    fighter, functions = a.word(root+8), a.word(root+12)
    effect_table=a.word(a.word(root+0x18))
    sound_table=a.word(root+0x10)
    ft = lambda off: a.word(fighter+off)
    row = lambda slot, k: a.word(a.word(functions+4*slot)+4*k)
    result = []
    for i, name in enumerate(CHARACTERS):
        k = 27+i
        bases = [r for r in range(27) if row(0,k) and row(0,r) == row(0,k)]
        # The internal/external map is stored in three-byte FtKindDesc records.
        externals = [e for e in range(33) if a.byte(ft(12)+e*3)==k]
        if len(externals)!=1:
            raise ValueError("Ambiguous external character index: "+name)
        external=externals[0]
        count=a.byte(ft(16)+external*4)
        costumes=a.word(ft(20)+k*4)
        metadata={"name":name,"internal":k,"kind":33+i,"character":34+i,
                  "external":external,"emblem":a.byte(ft(8)+external),"base":bases[0] if bases else 0,
                  "base_inferred_from_default":bool(bases),
                  "file":a.string(a.word(ft(4)+k*8)),
                  "symbol":a.string(a.word(ft(4)+k*8+4)),
                  "animation_file":a.string(a.word(ft(28)+k*4)),
                  "animation_count":a.word(ft(32)+k*8+4),
                  "effect_bank":a.byte(ft(36)+k),
                  "costumes":[[a.string(a.word(costumes+c*16+w*4)) for w in range(3)] for c in range(count)],
                  "defaults":[]}
        metadata['sound_bank']=a.byte(ft(0x38)+external*16)
        metadata['sound_file']=a.string(a.word(a.word(sound_table)+metadata['sound_bank']*4))
        if not 55<metadata['sound_bank']<100 or not metadata['sound_file'] or Path(metadata['sound_file']).name!=metadata['sound_file']:
            raise ValueError('Invalid local fighter sound bank: '+name)
        model=Archive(files/metadata["file"])
        parts=model.word(model.public[metadata["symbol"]]+8)
        for key,field,stride in [("visibility_costume_rows",4,16),("texture_costume_rows",12,4)]:
            table=model.word(parts+field);extent=model.object_end(table)-table
            if not table or extent%stride or not 1<=extent//stride<=32:
                raise ValueError("Invalid authored costume table extent: "+name+" "+key)
            metadata[key]=extent//stride
        bank=metadata["effect_bank"]
        metadata["effect_file"]=a.string(a.word(effect_table+bank*12))
        metadata["effect_symbol"]=a.string(a.word(effect_table+bank*12+4))
        if not 0<=bank<50 or not metadata["effect_file"] or Path(metadata["effect_file"]).name!=metadata["effect_file"]:
            raise ValueError("Invalid local fighter effect bank")
        effects=Archive(files/metadata["effect_file"])
        behavior=effects.public["effBehaviorTable"]
        metadata["effect_behaviors"]=[]
        for count_at,table_at in ((0,4),(8,12)):
            n=effects.word(behavior+count_at)
            if n>1000:raise ValueError("Invalid effect behavior count")
            table=effects.word(behavior+table_at)
            metadata["effect_behaviors"].append([effects.byte(table+j) for j in range(n)])
        if not 1 <= count <= 32 or not 1 <= metadata["animation_count"] <= 1024:
            raise ValueError("Invalid native fighter metadata")
        for slot, table in enumerate(TABLES):
            address=row(slot,k)
            retail=[r for r in range(27) if row(slot,r)==address]
            if address and not retail:
                raise ValueError(f"Unmapped native default {name} slot {slot}: {address:#x}")
            metadata["defaults"].append({"table":table,"source":retail[0] if address else None})
        for filename in [metadata["file"],metadata["animation_file"]]+[c[0] for c in metadata["costumes"]]:
            if not filename or Path(filename).name!=filename or not (files/filename).is_file():
                raise ValueError("Missing/invalid local character asset: "+str(filename))
        fighter_archive=Archive(files/metadata['file'])
        fighter_root=fighter_archive.public[metadata['symbol']]
        limits=[]
        for at in (12,20):
            rows=fighter_archive.word(fighter_root+at)
            end=fighter_archive.object_end(rows)
            if end<=rows or (end-rows)%24:raise ValueError('Ambiguous exact motion-table extent')
            limits.append((end-rows)//24)
        metadata['motion_table_bounds']=limits
        metadata["archive_sha256"]=sha(files/metadata["file"])
        result.append(metadata)
    hud=Archive(files/'IfAll.usd');stock=hud.public['Stc_icns']
    reserved,stride=struct.unpack_from('>HH',hud.payload,stock)
    if reserved!=8 or stride!=a.word(a.word(root)+4):raise ValueError('Unexpected Akaneia stock layout')
    if not hud.word(stock+4) or not hud.public.get('Eblm_matanim_joint'):raise ValueError('Missing Akaneia HUD animations')
    from native_lineup import PLAYERS
    emblems=[0]*40
    for name,_,kind in PLAYERS:
        internal=kind-6 if kind>=33 else kind
        external=[e for e in range(33) if a.byte(ft(12)+e*3)==internal]
        if len(external)!=1:raise ValueError('Ambiguous HUD emblem mapping: '+name)
        emblems[kind]=a.byte(ft(8)+external[0])
    emblems[11]=emblems[10]  # Nana shares the Ice Climbers series.
    report={"emblems":emblems,"stock_reserved":reserved,"stock_stride":stride,"hud_archive_sha256":sha(files/'IfAll.usd'),"mex_archive_sha256":sha(path),"internal_count":a.word(a.word(root)+4),
            "characters":result,"scope":"Local metadata inventory; see live reports for in-game evidence"}
    write_json(WORK/"native-roster.json",report)
    return report


def generate():
    report=inventory()
    from native_lineup import generate as generate_lineup
    generate_lineup(WORK/"melee-pc/src/pc/m3d_player_roster.inc")
    out=WORK/"melee-pc/src/pc/m3d_roster_data.inc"
    lines=["/* Generated from the user's local MxDt.dat. Do not edit or add assets to Git. */"]
    lines.append(f'static const int m3d_internal_count={report["internal_count"]};')
    lines.append('static const unsigned m3d_emblems[40]={'+','.join(map(str,report['emblems']))+'};')
    lines.append(f'static const unsigned m3d_stock_reserved={report["stock_reserved"]},m3d_stock_stride={report["stock_stride"]};')
    quote=lambda s:json.dumps(s) if s is not None else "NULL"
    lines.append("static const M3dCharacter m3d_characters[7] = {")
    for c in report["characters"]:
        lines.append("    {%s,%d,%d,%d,%d,%d,%d,%s,%s,%s,%d,%d,%d,%d,%d,%d,%d,%d,%s}," %
                     (quote(c["name"]),c["kind"],c["character"],c["internal"],c["external"],c["base"],
                      c["effect_bank"],quote(c["file"]),quote(c["symbol"]),quote(c["animation_file"]),c["animation_count"],*c["motion_table_bounds"],len(c["costumes"]),c["visibility_costume_rows"],c["texture_costume_rows"],c["emblem"],c['sound_bank'],quote(c['sound_file'])))
    lines.append("};")
    out.write_text("\n".join(lines)+"\n")
    lines=["/* Local m-ex effect bank metadata; behavior codes only, no model assets. */"]
    for i,c in enumerate(report["characters"]):
        for group,values in enumerate(c["effect_behaviors"]):
            lines.append(f"static const unsigned char types_{i}_{group}[]={{"+','.join(map(str,values))+"};")
    lines.append("static const struct EffectBank banks[7]={")
    for i,c in enumerate(report["characters"]):
        counts=[len(v) for v in c["effect_behaviors"]]
        lines.append(f'    {{{c["kind"]},{c["effect_bank"]},{quote(c["effect_file"])},{quote(c["effect_symbol"])},'
                     f'{{{counts[0]},{counts[1]}}},{{types_{i}_0,types_{i}_1}}}},')
    lines.append("};")
    (out.parent/"m3d_effect_data.inc").write_text('\n'.join(lines)+'\n')
    s=(WORK/"melee-pc/src/melee/ft/ftdata.c").read_text()
    arrays=re.findall(r'\b([A-Za-z_][A-Za-z_0-9]*)\[Ft_Kind_Max\]\s*(?:=|;)',s)
    lines=["/* Generated native registration; local asset names only. */", "void m3d_roster_tables(void)", "{"]
    for i,c in enumerate(report["characters"]):
        k,b=c["kind"],c["base"]
        for table in arrays:
            if table in ("gFtDataList","ft_8045996C","CostumeListsForeachCharacter","ftData_Table_Unk0","ftData_UnkIntPairs"):
                continue
            lines.append(f"    {table}[{k}]={table}[{b}];")
        for default in c["defaults"]:
            value="NULL" if default["source"] is None else f'{default["table"]}[{default["source"]}]'
            lines.append(f'    {default["table"]}[{k}]={value};')
        lines += [f"    ftData_UnkIntBoolFunc0.model_events[{k}]=ftData_UnkIntBoolFunc0.model_events[{b}];",
                  f'    ftData_UnkBytePerCharacter[{k}]={c["effect_bank"]};',
                  f'    ftData_803C1F40[{k}].a={quote(c["file"])};',
                  f'    ftData_803C1F40[{k}].b={quote(c["symbol"])};',
                  f'    ftData_803C23E4[{k}]={quote(c["animation_file"])};',
                  f'    ftData_Table_Unk0[{k}].count={c["animation_count"]};',
                  f'    ftData_UnkIntPairs[{k}].count=ftData_UnkIntPairs[{b}].count;']
        n=len(c["costumes"])
        lines.append(f"    static Fighter_CostumeStrings strings_{i}[{n}]={{")
        lines += ["        {"+",".join(quote(v) for v in costume)+"}," for costume in c["costumes"]]
        lines += ["    };",f"    static UnkCostumeStruct costumes_{i}[{n}];",
                  f"    ftData_803C2360[{k}]=strings_{i};",
                  f"    CostumeListsForeachCharacter[{k}].costume_list=costumes_{i};",
                  f"    CostumeListsForeachCharacter[{k}].numCostumes={n};"]
    lines += ["}"]
    (out.parent/"m3d_roster_tables.inc").write_text("\n".join(lines)+"\n")
    fields=(WORK/"melee-pc/src/melee/ft/types.h").read_text()
    flags=[]
    pattern=r'/\*\s*fp\+([0-9A-Fa-f]+):(\d+)\s*\*/\s*u(?:8|16)\s+(\w+)\s*:\s*(\d+)'
    for offset,bit,member,width in re.findall(pattern,fields):
        offset=int(offset,16)
        if not 0x2218<=offset<=0x222a:continue
        if offset==0x221b:member="x221B."+member
        flags.append(f"M3D_FLAG(0x{offset:x},{bit},{width},{member})")
    (out.parent/"m3d_live_flags.inc").write_text("/* Native named bitfields -> original MSB-first flags. */\n"+"\n".join(flags)+"\n")
    print(WORK/"native-roster.json")
    for c in report["characters"]:
        print(c["name"],"kind",c["kind"],"internal",c["internal"],"base",c["base"],"animations",c["animation_count"])
    return report


def asset_identity(report):
    """Pin every local override used by this controlled in-game roster."""
    names={'MxDt.dat','PlCo.dat','IfAll.usd'}
    for c in report['characters']:
        names.update((c['file'],c['animation_file'],c['effect_file']))
        names.update(costume[0] for costume in c['costumes'])
        names.add('audio/us/'+c['sound_file'])
        if (ROOT/'build/akaneia/disc/files/audio'/c['sound_file']).is_file():names.add('audio/'+c['sound_file'])
    names.update(('audio/smash2.sem','audio/us/smash2.sem'))
    return {name:sha(ROOT/'build/akaneia/disc/files'/name) for name in sorted(names)}


if __name__=="__main__":
    generate()
