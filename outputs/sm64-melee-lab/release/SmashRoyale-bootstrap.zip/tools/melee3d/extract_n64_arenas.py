#!/usr/bin/env python3
"""Extract specific donor arenas from verified US SM64 / OoT 1.2 ROMs.

Writes original/decompressed asset banks, collision JSON and inspection OBJ.
Original units and source flags are preserved; no Melee behavior is implied.
Metadata: n64decomp/sm64 9921382a68bb0c865e5e45eb594d9c64db59b1af;
zeldaret/oot 8a3634ca774a9b58d822cbc2cc09309f31eac6a4 (ntsc-1.2).
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import math

from n64_display_mesh import display_mesh

SM64_SHA = '17ce077343c6133f8c9f2d6d6d9a4ab62c8cd2aa57c40aea1f490b4c8bb21d91'
OOT_SHA = '49acd3885f13b0730119b78fb970911cc8aba614fe383368015c21565983368d'


def mio0(data, base=0):
    magic, size, packed, raw = struct.unpack_from('>4sIII', data, base)
    if magic != b'MIO0' or not 0 < size <= 0x1000000:
        raise ValueError('Invalid MIO0 header')
    bits = base + 16
    packed += base
    raw += base
    out = bytearray()
    mask = flag = 0
    while len(out) < size:
        if mask == 0:
            flag = data[bits]; bits += 1; mask = 128
        if flag & mask:
            out.append(data[raw]); raw += 1
        else:
            code = int.from_bytes(data[packed:packed+2], 'big'); packed += 2
            distance = (code & 4095) + 1
            length = (code >> 12) + 3
            if distance > len(out) or len(out) + length > size:
                raise ValueError('Invalid MIO0 backreference')
            for _ in range(length): out.append(out[-distance])
        mask >>= 1
    return bytes(out), max(bits, packed, raw) - base


def yaz0(data):
    if data[:4] != b'Yaz0': raise ValueError('Invalid Yaz0 header')
    size = struct.unpack_from('>I', data, 4)[0]
    if not 0 < size <= 0x4000000: raise ValueError('Invalid Yaz0 size')
    index = 16
    out = bytearray()
    mask = flag = 0
    while len(out) < size:
        if mask == 0:
            flag = data[index]; index += 1; mask = 128
        if flag & mask:
            out.append(data[index]); index += 1
        else:
            first, second = data[index:index+2]; index += 2
            distance = ((first & 15) << 8 | second) + 1
            length = first >> 4
            if length == 0:
                length = data[index] + 0x12; index += 1
            else: length += 2
            if distance > len(out) or len(out) + length > size:
                raise ValueError('Invalid Yaz0 backreference')
            for _ in range(length): out.append(out[-distance])
        mask >>= 1
    return bytes(out)


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def obj(path, meshes):
    lines = ['# Extracted source geometry; original game units, Y up']
    count = 0
    for mesh in meshes:
        lines.append('o ' + mesh['name'])
        for x, y, z in mesh['vertices']: lines.append(f'v {x} {y} {z}')
        for tri in mesh['triangles']:
            lines.append('f ' + ' '.join(str(i + count + 1) for i in tri['indices']))
        count += len(mesh['vertices'])
    path.write_text('\n'.join(lines) + '\n')


def sm64_collision(bank, offset, name):
    tag, count = struct.unpack_from('>HH', bank, offset)
    if tag != 0x40 or not 0 < count < 10000: raise ValueError('Invalid SM64 vertices')
    vertices = [list(struct.unpack_from('>hhh', bank, offset+4+i*6)) for i in range(count)]
    index = offset + 4 + count*6
    triangles = []
    while True:
        surface = struct.unpack_from('>H', bank, index)[0]; index += 2
        if surface == 0x41: break
        if 0x40 <= surface < 0x65: raise ValueError('Unexpected SM64 collision command')
        n = struct.unpack_from('>H', bank, index)[0]; index += 2
        if n > 10000: raise ValueError('Invalid SM64 triangle count')
        special = surface in (0x4, 0xE, 0x24, 0x25, 0x27, 0x2C, 0x2D)
        for _ in range(n):
            ids = list(struct.unpack_from('>HHH', bank, index)); index += 6
            if max(ids) >= count: raise ValueError('SM64 triangle index out of bounds')
            tri = dict(indices=ids, source_surface=surface)
            if special:
                tri['source_parameter'] = struct.unpack_from('>h', bank, index)[0]; index += 2
            triangles.append(tri)
    return dict(name=name, bank_offset=offset, vertices=vertices, triangles=triangles)


def extract_sm64(rom, out):
    signature = struct.pack('>HHhhhhhh', 0x40, 24, -8191, -6143, 8192, 8192, -6143, 8192)
    candidates = []
    start = 0
    while True:
        start = rom.find(b'MIO0', start)
        if start < 0: break
        try:
            bank, size = mio0(rom, start)
            if bank[0x49C8:0x49C8+len(signature)] == signature:
                candidates.append((start, size, bank))
        except (ValueError, IndexError, struct.error): pass
        start += 4
    if len(candidates) != 1: raise ValueError(f'Expected exactly one Bowser 3 bank, found {len(candidates)}')
    start, size, bank = candidates[0]
    out.mkdir(parents=True, exist_ok=True)
    (out/'segment07.mio0').write_bytes(rom[start:start+size])
    (out/'segment07.bin').write_bytes(bank)
    banks = {7:bank}
    # Resolve the actual LOAD_MIO0/LOAD_RAW commands following this bank load.
    load = rom.find(struct.pack('>II', 0x180C0007, start))
    if load < 0: raise ValueError('Bowser level loader not found')
    bank_rom_end = struct.unpack_from('>I',rom,load+8)[0]
    (out/'segment07.mio0').write_bytes(rom[start:bank_rom_end])
    # This level's raw geometry/script bank follows its compressed stage bank.
    script_loader = rom.find(struct.pack('>II',0x0010000E,bank_rom_end))
    if script_loader < 0: raise ValueError('Bowser script/geometry bank not found')
    script_end = struct.unpack_from('>I',rom,script_loader+8)[0]
    (out/'segment0E.bin').write_bytes(rom[bank_rom_end:script_end])
    dependencies = [dict(segment=14, rom_start=bank_rom_end, rom_end=script_end, size=script_end-bank_rom_end)]
    for step in range(1,4):
        command, rs, re = struct.unpack_from('>III', rom, load+step*12)
        seg = command & 255
        data = mio0(rom, rs)[0] if command >> 24 == 0x18 else rom[rs:re]
        banks[seg] = data
        (out/f'segment{seg:02X}.bin').write_bytes(data)
        dependencies.append(dict(segment=seg, rom_start=rs, rom_end=re, size=len(data)))
    roots = [0x070046B0, 0x070022A8, 0x070025E0, 0x07002918, 0x07002C50,
             0x07002F88, 0x070032C0, 0x070035F8, 0x07003930, 0x07003C68, 0x07003FA0]
    visuals = [display_mesh(banks, address, 'star_visual' if i==0 else f'platform_{i}_visual', capture_materials=True)
               for i,address in enumerate(roots)]
    stand = display_mesh(banks, 0x07004958, 'bomb_stand_template', capture_materials=True)
    # Read US-revision display-list pointers from the extracted geometry bank.
    # Decomp symbol names retain older offsets and are not runtime addresses.
    bomb_body_dl = struct.unpack_from('>I',banks[13],0xBD4)[0]
    bomb_billboard_dl = struct.unpack_from('>I',banks[13],0xBE8)[0]
    bomb_scale = struct.unpack_from('>I',banks[13],0xBC8)[0]/65536
    mine = display_mesh(banks,bomb_body_dl,'bomb_body_template',capture_materials=True)
    eyes = display_mesh(banks,bomb_billboard_dl,'bomb_billboard_template',capture_materials=True)
    save_json(out/'visual_meshes.json', visuals)
    obj(out/'stage_visual.obj', visuals)
    obj(out/'star_only_visual.obj',[visuals[0]])
    obj(out/'bomb_body.obj', [mine])
    obj(out/'bomb_billboard.obj',[eyes])
    obj(out/'bomb_stand.obj', [stand])
    offsets = [0x49C8] + [0x4B94+i*0x84 for i in range(10)]
    meshes = [sm64_collision(bank, offset, 'permanent_star' if i == 0 else f'falling_platform_{i}')
              for i, offset in enumerate(offsets)]
    bombs = [[-2122,512,-2912],[-3362,512,1121],[0,512,3584],[3363,512,1121],[2123,512,-2912]]
    stands = [[-3362,-204,1121],[0,-204,3584],[3362,-204,1126],[2123,-204,-2912],[-2122,-204,-2912]]
    instances=[]
    for label,template,positions,scale in [('stand',stand,stands,1),('bomb',mine,bombs,bomb_scale),
                                            ('bomb_sprite',eyes,bombs,bomb_scale)]:
        for i,pos in enumerate(positions):
            instances.append(dict(template, name=f'{label}_{i}',
                                  vertices=[[pos[j]+v[j]*scale for j in range(3)] for v in template['vertices']],
                                  billboard_center=pos if label=='bomb_sprite' else None))
    save_json(out/'prop_visual_meshes.json',instances)
    obj(out/'assembled_visual.obj',visuals+instances)
    # Verify the five OBJECT command positions exist in this ROM's raw script.
    for pos in stands:
        if struct.pack('>hhh',*pos) not in bank:
            raise ValueError('Bowser stand placement absent from level bank')
    for pos in bombs:
        if struct.pack('>hhh', *pos) not in rom:
            raise ValueError('Bowser bomb placement absent from verified ROM')
    save_json(out/'collision.json', meshes)
    obj(out/'collision.obj', meshes)
    manifest = dict(arena='Bowser in the Sky — final Bowser arena',
                    source_bank_rom_offset=start, compressed_size=bank_rom_end-start, decoder_bytes_consumed=size, decompressed_size=len(bank),
                    source_sha256=SM64_SHA, units='original SM64 units; Y up',
                    dependencies=dependencies, visual_triangles=sum(len(m['triangles']) for m in visuals),
                    collision_meshes=len(meshes), vertices=sum(len(m['vertices']) for m in meshes),
                    triangles=sum(len(m['triangles']) for m in meshes),
                    bomb_stands=stands, bomb_model_scale=bomb_scale, bomb_body_display_list=bomb_body_dl, bomb_billboard_display_list=bomb_billboard_dl, bombs=[dict(position=p, behavior='bhvBowserBomb; hazard code not ported') for p in bombs],
                    notes=['Bank includes original stage visual display lists and textures.',
                           'Permanent star and all ten outer floor sections exported separately.',
                           'Bombs and falling-floor behavior require shared Melee hazard components.'])
    save_json(out/'manifest.json', manifest)
    return manifest


def commands(data):
    for index in range(0, 0x400, 8):
        command = data[index]
        yield command, data[index+1], struct.unpack_from('>I', data, index+4)[0]
        if command == 0x14: return
    raise ValueError('Scene command list has no end')


def oot_collision(data, offset, name, pointer):
    nv = struct.unpack_from('>H', data, offset+12)[0]
    vp = pointer(struct.unpack_from('>I', data, offset+16)[0])
    nt = struct.unpack_from('>H', data, offset+20)[0]
    tp = pointer(struct.unpack_from('>I', data, offset+24)[0])
    if not 0 < nv < 10000 or not 0 < nt < 20000: raise ValueError('Invalid OoT collision counts')
    vertices = [list(struct.unpack_from('>hhh', data, vp+i*6)) for i in range(nv)]
    triangles = []
    for i in range(nt):
        words = struct.unpack_from('>8H', data, tp+i*16)
        ids = [w & 0x1FFF for w in words[1:4]]
        if max(ids) >= nv: raise ValueError('OoT triangle index out of bounds')
        triangles.append(dict(indices=ids, source_surface=words[0], source_vertex_flags=list(words[1:4]),
                              source_plane=list(words[4:])))
    return dict(name=name, vertices=vertices, triangles=triangles)


def extract_oot(rom, out):
    indices = {'ganon_boss_scene':1386, 'ganon_boss_room_0':1387,
               'ovl_Bg_Ganon_Otyuka':259, 'object_ganon':705, 'object_ganon_objects':788,
               'Audiobank':3,'Audioseq':4,'Audiotable':5,'code':27}
    out.mkdir(parents=True, exist_ok=True)
    files = {}
    metadata = []
    for name, index in indices.items():
        vs, ve, rs, re = struct.unpack_from('>IIII', rom, 0x7960+index*16)
        if rs == 0xFFFFFFFF or ve <= vs: raise ValueError('Invalid OoT DMA entry')
        data = yaz0(rom[rs:re]) if re else rom[rs:rs+ve-vs]
        if len(data) != ve-vs: raise ValueError('OoT DMA size mismatch')
        files[name] = data
        (out/f'{name}.bin').write_bytes(data)
        metadata.append(dict(name=name, dma_index=index, vrom_start=vs, vrom_end=ve,
                             rom_start=rs, rom_end=re, size=len(data), sha256=hashlib.sha256(data).hexdigest()))
    scene, room = files['ganon_boss_scene'], files['ganon_boss_room_0']
    environment = dict(lights=[])
    for offset in range(0,0x400,8):
        cmd=scene[offset:offset+8]
        if cmd[0]==0x14:break
        if cmd[0]==0x15:
            environment['sound']=dict(spec=cmd[1],ambience=cmd[6],scene_sequence=cmd[7],
                                      fight_sequence=100,
                                      source='Boss_Ganon explicitly starts NA_BGM_GANONDORF_BOSS')
        elif cmd[0]==0x11:
            environment['skybox']=dict(id=cmd[4],config=cmd[5],light_mode=cmd[6],
                                        source='SKYBOX_UNSET_1D; no separate sky texture DMA case')
        elif cmd[0]==0x0F:
            base=struct.unpack_from('>I',cmd,4)[0]&0xffffff
            for i in range(cmd[1]):
                light=scene[base+i*22:base+(i+1)*22]
                if len(light)!=22:raise ValueError('truncated environment light')
                environment['lights'].append(dict(ambient=list(light[:3]),
                    light1_direction=list(struct.unpack_from('>3b',light,3)),light1_color=list(light[6:9]),
                    light2_direction=list(struct.unpack_from('>3b',light,9)),light2_color=list(light[12:15]),
                    fog_color=list(light[15:18]),blend_fog_near=struct.unpack_from('>H',light,18)[0],
                    z_far=struct.unpack_from('>h',light,20)[0]))
    save_json(out/'scene_environment.json',environment)
    # US 1.2 table symbols come from the pinned baserom config. Preserve the
    # actual fight track, rather than confusing the scene's tower-organ BGM
    # with the sequence that the boss actor starts when combat begins.
    code=files['code'];code_vram=0x800116E0
    tables={'fonts':0x80113DF0-code_vram,'sequence_fonts':0x80114060-code_vram,
            'sequences':0x80114220-code_vram,'samples':0x80114910-code_vram}
    def audio_entry(table,index):
        base=tables[table];count=struct.unpack_from('>H',code,base)[0]
        visited=set()
        while True:
            if index in visited or not 0<=index<count:raise ValueError('invalid audio table alias')
            visited.add(index)
            row=struct.unpack_from('>IIbb3H',code,base+16+index*16)
            if row[1]:return dict(index=index,offset=row[0],size=row[1],medium=row[2],cache=row[3],short_data=list(row[4:]))
            index=row[0]
    music=out/'music';music.mkdir(exist_ok=True)
    def audio_save(name,bank,entry):
        raw=files[bank][entry['offset']:entry['offset']+entry['size']]
        if len(raw)!=entry['size']:raise ValueError('audio data extends beyond source bank')
        (music/name).write_bytes(raw)
        return dict(file=name,bank=bank,table=entry,sha256=hashlib.sha256(raw).hexdigest())
    track=audio_entry('sequences',100)
    audio=[audio_save('ganondorf_boss.seq','Audioseq',track)]
    font_base=tables['sequence_fonts'];font_list=font_base+struct.unpack_from('>H',code,font_base+200)[0]
    font_ids=list(code[font_list+1:font_list+1+code[font_list]])
    sample_ids=set()
    for font in font_ids:
        entry=audio_entry('fonts',font)
        audio.append(audio_save(f'font_{font:02x}.bin','Audiobank',entry))
        sample_ids.update(i for i in (entry['short_data'][0]>>8,entry['short_data'][0]&255) if i!=255)
    for sample in sorted(sample_ids):
        audio.append(audio_save(f'sample_bank_{sample:02x}.bin','Audiotable',audio_entry('samples',sample)))
    save_json(music/'dependencies.json',dict(sequence=100,name='NA_BGM_GANONDORF_BOSS',fonts=font_ids,
               files=audio,status='source sequence/font/sample dependencies extracted; synthesis conversion pending'))
    meshes = []
    for command, count, ptr in commands(scene):
        if command == 3:
            meshes.append(oot_collision(scene, ptr & 0xFFFFFF, 'static_room_collision', lambda p:p & 0xFFFFFF))
    actors = []
    for command, count, ptr in commands(room):
        if command == 1:
            for i in range(count):
                actor, x,y,z, rx,ry,rz, params = struct.unpack_from('>HhhhhhhH', room, (ptr & 0xFFFFFF)+i*16)
                actors.append(dict(id=actor, position=[x,y,z], rotation=[rx,ry,rz], parameters=params))
    overlay = files['ovl_Bg_Ganon_Otyuka']
    tile = oot_collision(overlay, 0x1110+0x13B0, 'collapsing_tile_template', lambda p:p-0x80A54200)
    save_json(out/'tile_collision.json', tile)
    placed = []
    for i, actor in enumerate(actors):
        if actor['id'] != 0x106: continue
        angle = actor['rotation'][1]*math.pi/32768
        x,y,z = actor['position']
        verts = [[x+vx*math.cos(angle)+vz*math.sin(angle), y+vy,
                  z-vx*math.sin(angle)+vz*math.cos(angle)] for vx,vy,vz in tile['vertices']]
        placed.append(dict(name=f'floor_tile_{i}', vertices=verts, triangles=tile['triangles'],
                           source_actor=actor))
    save_json(out/'placed_tiles.json', placed)
    obj(out/'complete_collision.obj', meshes+placed)
    # Room shape type 0 references static opaque and translucent display lists.
    visuals = []
    banks = {2:scene,3:room}
    for command,count,ptr in commands(room):
        if command != 0x0A: continue
        shape = ptr & 0xFFFFFF
        if room[shape] != 0: raise ValueError('Unexpected Ganondorf room shape')
        n = room[shape+1]
        entries = struct.unpack_from('>I',room,shape+4)[0] & 0xFFFFFF
        for i in range(n):
            for layer,address in zip(['opaque','translucent'], struct.unpack_from('>II',room,entries+i*8)):
                if address:
                    visuals.append(display_mesh(banks,address,f'room_{i}_{layer}',newer=True))
    save_json(out/'visual_meshes.json', visuals)
    obj(out/'room_visual.obj', visuals)
    tile_parts = [display_mesh({},0x80A54200+0x1110+offset,label,True,(0x80A54200,overlay))
                  for label,offset in [('top',0x8D0),('bottom',0x928),('side',0x980)]]
    save_json(out/'tile_visual_templates.json',tile_parts)
    floor_visuals = []
    for i,actor in enumerate(actors):
        if actor['id']!=0x106: continue
        parts = [(tile_parts[0],0,0,0),(tile_parts[1],0,0,0)]
        parts += [(tile_parts[2],dx,dz,angle) for dx,dz,angle in
                  [(60,0,math.pi/2),(-60,0,-math.pi/2),(0,60,0),(0,-60,math.pi)]]
        verts,tris=[],[]
        for part,dx,dz,angle in parts:
            base = len(verts)
            verts.extend([[actor['position'][0]+dx+x*math.cos(angle)+z*math.sin(angle),
                           actor['position'][1]+y,
                           actor['position'][2]+dz-x*math.sin(angle)+z*math.cos(angle)]
                          for x,y,z in part['vertices']])
            tris.extend(dict(indices=[base+k for k in t['indices']]) for t in part['triangles'])
        floor_visuals.append(dict(name=f'tile_visual_{i}',vertices=verts,triangles=tris,
                                  source_actor=actor))
    save_json(out/'floor_visual_meshes.json',floor_visuals)
    obj(out/'assembled_visual.obj',visuals+floor_visuals)
    save_json(out/'actors.json', actors)
    # ACTOR_BG_GANON_OTYUKA verified from the pinned decomp actor table.
    # Keep raw IDs and placements until the caller identifies tile instances.
    save_json(out/'collision.json', meshes)
    obj(out/'static_collision.obj', meshes)
    obj(out/'tile_collision.obj', [tile])
    manifest = dict(arena='Ganondorf battle chamber (ganon_boss)', source_sha256=OOT_SHA,
                    files=metadata, actors=len(actors), placed_floor_actors=len(placed), fight_floor_tiles=sum(a['parameters']!=0x23 for a in actors if a['id']==0x106),
                    static_visual_triangles=sum(len(m['triangles']) for m in visuals),
                    static_collision_vertices=sum(len(m['vertices']) for m in meshes),
                    static_collision_triangles=sum(len(m['triangles']) for m in meshes),
                    tile_template_vertices=len(tile['vertices']), tile_template_triangles=len(tile['triangles']),
                    notes=['Complete scene/room banks retain original display lists and textures.',
                           'Collapsing floor is dynamic actor geometry, not the static room collision.',
                           'Native collapse triggers and boss behavior are not ported.'])
    save_json(out/'manifest.json', manifest)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('game', choices=['sm64','oot'])
    parser.add_argument('rom', type=Path)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    data = args.rom.read_bytes()
    expected = SM64_SHA if args.game == 'sm64' else OOT_SHA
    if hashlib.sha256(data).hexdigest() != expected:
        parser.error('ROM revision/hash differs from the verified extraction metadata')
    try:
        result = (extract_sm64 if args.game == 'sm64' else extract_oot)(data, args.out)
        print(json.dumps(result, indent=2))
    except (ValueError, IndexError, struct.error) as error:
        parser.exit(1, f'Extraction failed: {error}\n')


if __name__ == '__main__': main()
